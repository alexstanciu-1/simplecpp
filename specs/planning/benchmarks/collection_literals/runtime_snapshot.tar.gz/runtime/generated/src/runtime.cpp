// Generated from reviewed runtime metadata. Do not edit.
#include "scpp/numeric.hpp"
#include "scalar_semantics.hpp"
#include "scpp/string.hpp"
#include "sequence_semantics.hpp"
#include "scpp/vectors.hpp"
#include "vector_buffer.hpp"
#include "scpp/carriers.hpp"
#include "carrier_semantics.hpp"
#include "scpp/conversions.hpp"
#include "scpp/value_error.hpp"
namespace scpp {
struct string::storage { std::string bytes; };
namespace detail { struct string_access {
    static std::string_view read(const string& value) noexcept {
        if (value.is_inline()) return {value.rep_.small.bytes, value.rep_.small.tag};
        return value.rep_.large.ptr->bytes;
    }
    static string own(std::string bytes) {
        string result;
        if (bytes.size() <= string::inline_capacity) init(result, bytes);
        else result.rep_.large = {255, new string::storage{std::move(bytes)}};
        return result;
    }
    static string ascii_case(string result, bool upper, bool first_only) {
        auto* data = result.is_inline() ? result.rep_.small.bytes : result.rep_.large.ptr->bytes.data();
        const auto size = read(result).size();
        const auto limit = first_only && size > 1 ? 1 : size;
        for (std::size_t i = 0; i < limit; ++i) {
            auto& ch = data[i];
            if (upper && ch >= 'a' && ch <= 'z') ch -= 'a' - 'A';
            else if (!upper && ch >= 'A' && ch <= 'Z') ch += 'a' - 'A';
        }
        return result;
    }
    // Called only during construction, with the empty short member active.
    static void init(string& value, std::string_view bytes) {
        if (bytes.size() <= string::inline_capacity) {
            bytes.copy(value.rep_.small.bytes, bytes.size());
            value.rep_.small.tag = static_cast<unsigned char>(bytes.size());
        } else {
            value.rep_.large = {255, new string::storage{std::string(bytes)}};
        }
    }
}; }
string::~string() { if (!is_inline()) delete rep_.large.ptr; }
string::string(const string& other) { detail::string_access::init(*this, detail::string_access::read(other)); }
string::string(string&& other) noexcept : rep_(other.rep_) { other.rep_.small = {}; }
string& string::operator=(const string& other) {
    if (this != &other) *this = string(other);
    return *this;
}
string& string::operator=(string&& other) noexcept {
    if (this != &other) {
        clear();
        rep_ = other.rep_;
        other.rep_.small = {};
    }
    return *this;
}
string::string(const char* bytes) {
    if (!bytes) throw std::invalid_argument("null_string_pointer");
    detail::string_access::init(*this, bytes);
}
string::string(const char* bytes, __INT64_TYPE__ count) {
    if (!bytes) throw std::invalid_argument("null_string_pointer");
    detail::string_access::init(*this, {bytes, detail::byte_count(count)});
}
__INT64_TYPE__ string::size() const { return detail::checked_integer_cast<__INT64_TYPE__>(detail::string_access::read(*this).size()); }
bool_t string::empty() const noexcept { return detail::string_access::read(*this).empty(); }
const char* string::data() const noexcept { return detail::string_access::read(*this).data(); }
void string::append(const string& other) {
    const auto suffix = detail::string_access::read(other);
    if (!is_inline()) {
        rep_.large.ptr->bytes.append(suffix);
    } else if (suffix.size() <= inline_capacity - rep_.small.tag) {
        const auto length = rep_.small.tag;
        suffix.copy(rep_.small.bytes + length, suffix.size());
        rep_.small.tag = static_cast<unsigned char>(length + suffix.size());
        rep_.small.bytes[rep_.small.tag] = '\0';
    } else {
        std::string joined(detail::string_access::read(*this));
        joined.append(suffix);
        rep_.large = {255, new storage{std::move(joined)}};
    }
}
void string::clear() noexcept {
    if (!is_inline()) delete rep_.large.ptr;
    rep_.small = {};
}
uint8 string::byte_at(int64 index) const {
    const auto bytes = detail::string_access::read(*this);
    return static_cast<uint8>(bytes[detail::sequence_index(index, bytes.size())]);
}
void string::set_byte(int64 index, uint8 value) {
    const auto offset = detail::sequence_index(index, detail::string_access::read(*this).size());
    char* bytes = is_inline() ? rep_.small.bytes : rep_.large.ptr->bytes.data();
    bytes[offset] = static_cast<char>(value);
}
string operator+(string left, const string& right) { left.append(right); return left; }
string& operator+=(string& left, const string& right) { left.append(right); return left; }
bool_t operator==(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) == detail::string_access::read(right)}; }
bool_t operator>(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) > detail::string_access::read(right)}; }
bool_t operator>=(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) >= detail::string_access::read(right)}; }
bool_t operator<(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) < detail::string_access::read(right)}; }
bool_t operator<=(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) <= detail::string_access::read(right)}; }
bool_t operator!=(const string& left, const string& right) noexcept { return bool_t{detail::string_access::read(left) != detail::string_access::read(right)}; }
namespace str { string format_bool(bool_t value) { return value ? string{"true", 4} : string{"false", 5}; } }
namespace str { string format_float64(float64 value) { char buffer[128]; const auto size = detail::format_decimal_into(value, buffer); return string{buffer, static_cast<__INT64_TYPE__>(size)}; } }
namespace str { string format_int64(int64 value) { char buffer[128]; const auto size = detail::format_decimal_into(value, buffer); return string{buffer, static_cast<__INT64_TYPE__>(size)}; } }
namespace str { string format_uint8(uint8 value) { char buffer[128]; const auto size = detail::format_decimal_into(value, buffer); return string{buffer, static_cast<__INT64_TYPE__>(size)}; } }
namespace detail {
static int64 compare_byte_views(std::string_view left, std::string_view right, bool_t insensitive) {
    if (!insensitive) return left.compare(right);
    for (std::size_t i = 0; i < std::min(left.size(), right.size()); ++i) {
        const int difference = fold_ascii_byte(left[i]) - fold_ascii_byte(right[i]);
        if (difference != 0) return difference;
    }
    return (left.size() > right.size()) - (left.size() < right.size());
}
}
namespace str {
string hex_encode(const string& value) {
    constexpr char digits[] = "0123456789abcdef";
    const auto bytes = detail::string_access::read(value);
    std::string output;
    if (bytes.size() > output.max_size() / 2) throw std::length_error("hex encoding too large");
    output.resize(bytes.size() * 2);
    std::size_t pos = 0;
    for (unsigned char byte : bytes) {
        output[pos++] = digits[byte >> 4];
        output[pos++] = digits[byte & 15];
    }
    return detail::string_access::own(std::move(output));
}
}
namespace str {
result_or_false_string hex_decode(const string& value) {
    const auto text = detail::string_access::read(value);
    if (text.size() % 2) return result_or_false_string::from_false();
    const auto digit = [](unsigned char ch) -> int {
        if (ch >= '0' && ch <= '9') return ch - '0';
        if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
        if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
        return -1;
    };
    std::string output;
    output.reserve(text.size() / 2);
    for (std::size_t i = 0; i < text.size(); i += 2) {
        const int high = digit(text[i]);
        const int low = digit(text[i + 1]);
        if (high < 0 || low < 0) return result_or_false_string::from_false();
        output.push_back(static_cast<char>((high << 4) | low));
    }
    return result_or_false_string{detail::string_access::own(std::move(output))};
}
}
namespace str { string ascii_lower_first(const string& value) { return detail::string_access::ascii_case(value, false, true); } }
namespace str {
static string trim_edges(const string& value, trim_side side, const auto& matches) {
    auto bytes = detail::string_access::read(value);
    if (side != trim_side::end)
        while (!bytes.empty() && matches(bytes.front())) bytes.remove_prefix(1);
    if (side != trim_side::start)
        while (!bytes.empty() && matches(bytes.back())) bytes.remove_suffix(1);
    return string{bytes.data(), static_cast<__INT64_TYPE__>(bytes.size())};
}
string trim_bytes(const string& value, trim_side side, trim_set set) {
    const char extra = set == trim_set::php_space ? '\0' : '\f';
    return trim_edges(value, side, [extra](char ch) {
        return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\v' || ch == '\r' || ch == extra;
    });
}
string trim_bytes(const string& value, const string& mask, trim_side side) {
    const auto bytes = detail::string_access::read(mask);
    if (bytes.empty()) return value;
    unsigned char members[32]{};
    for (unsigned char byte : bytes)
        members[byte >> 3] |= static_cast<unsigned char>(1u << (byte & 7));
    return trim_edges(value, side, [&members](unsigned char byte) {
        return (members[byte >> 3] & (1u << (byte & 7))) != 0;
    });
}
}
namespace detail {
// The input is an unsigned fixed-point decimal. Round the digits before inserting literal separators.
static string format_number_digits(std::string digits, bool negative, int64 decimals, const string& point, const string& group) {
    const auto dot = digits.find('.');
    const int64 whole = static_cast<int64>(dot == std::string::npos ? digits.size() : dot);
    if (dot != std::string::npos) digits.erase(dot, 1);
    const int64 fraction = static_cast<int64>(digits.size()) - whole;
    if (decimals < -whole) {
        digits = "0";
    } else if (decimals < fraction) {
        const auto keep = static_cast<std::size_t>(whole + decimals);
        const bool up = digits[keep] >= '5';
        digits.resize(keep);
        if (up) {
            auto last = digits.find_last_not_of('9');
            if (last == std::string::npos) {
                digits.assign(keep + 1, '0');
                digits.front() = '1';
            } else {
                ++digits[last];
                std::fill(digits.begin() + last + 1, digits.end(), '0');
            }
        }
        if (decimals < 0) {
            if (digits.find_first_not_of('0') == std::string::npos) digits = "0";
            else digits.append(static_cast<std::size_t>(-decimals), '0');
        }
    }
    const auto precision = static_cast<std::uint64_t>(std::max<int64>(0, decimals));
    const auto significant_fraction = static_cast<std::size_t>(std::clamp<int64>(decimals, 0, fraction));
    const auto integral = digits.size() - significant_fraction;
    negative = negative && digits.find_first_not_of('0') != std::string::npos;
    const auto separator = string_access::read(group);
    const auto decimal = string_access::read(point);
    std::string out;
    const auto limit = std::min<std::uint64_t>(out.max_size(), std::numeric_limits<int64>::max());
    std::uint64_t size = integral + negative;
    const auto account = [&](std::uint64_t count, std::uint64_t width) {
        if (width && count > (limit - size) / width) throw std::length_error("number_format_too_large");
        size += count * width;
    };
    account(precision, 1);
    account(precision != 0, decimal.size());
    account((integral - 1) / 3, separator.size());
    out.reserve(static_cast<std::size_t>(size));
    if (negative) out.push_back('-');
    for (std::size_t i = 0; i < integral; ++i) {
        if (i && (integral - i) % 3 == 0) out += separator;
        out.push_back(digits[i]);
    }
    if (precision) {
        out += decimal;
        out.append(digits, integral, significant_fraction);
        out.append(static_cast<std::size_t>(precision - significant_fraction), '0');
    }
    return string_access::own(std::move(out));
}
}
namespace str {
string number_format(int64 value, int64 decimals, const string& point, const string& group) {
    auto digits = std::to_string(value);
    if (value < 0) digits.erase(0, 1);
    return detail::format_number_digits(std::move(digits), value < 0, decimals, point, group);
}
string number_format(float64 value, int64 decimals, const string& point, const string& group) {
    if (!std::isfinite(value)) return std::isnan(value) ? string{"nan", 3} : string{"inf", 3};
    const auto magnitude = std::fabs(value);
    // A binary64 has at most 309 integer and 1074 fractional decimal digits.
    char buffer[1400];
    auto formatted = std::to_chars(buffer, buffer + sizeof(buffer), magnitude, std::chars_format::fixed);
    const auto dot = std::find(buffer, formatted.ptr, '.');
    const auto fraction = dot == formatted.ptr ? 0 : formatted.ptr - dot - 1;
    // At visible decimal ties round the shortest fixed spelling. Beyond that spelling,
    // use its exact terminating decimal so the shared half-away rule rounds only once.
    if (decimals > fraction && magnitude != std::trunc(magnitude)) {
        int exponent;
        std::frexp(magnitude, &exponent);
        const int exact_places = std::min(1074, std::numeric_limits<float64>::digits - exponent);
        formatted = std::to_chars(buffer, buffer + sizeof(buffer), magnitude, std::chars_format::fixed, exact_places);
    }
    if (formatted.ec != std::errc{}) throw std::length_error("number_format_too_large");
    return detail::format_number_digits({buffer, formatted.ptr}, value < 0, decimals, point, group);
}
}
namespace str {
string pad_bytes(const string& subject, int64 width, const string& fill, int64 side, bool reject_empty) {
    const auto pattern = detail::string_access::read(fill);
    if (reject_empty && pattern.empty()) throw ValueError("str_pad(): Argument #3 ($pad_string) must not be empty");
    if (side < static_cast<int64>(pad_side::left) || side > static_cast<int64>(pad_side::both))
        throw ValueError("str_pad(): Argument #4 ($pad_type) must be STR_PAD_LEFT, STR_PAD_RIGHT, or STR_PAD_BOTH");
    if (width <= subject.size() || pattern.empty()) return subject;

    const auto bytes = detail::string_access::read(subject);
    const auto extra = static_cast<std::size_t>(width) - bytes.size();
    const auto left = side == static_cast<int64>(pad_side::both) ? extra / 2
                    : side == static_cast<int64>(pad_side::left) ? extra : 0;
    std::string output;
    output.reserve(static_cast<std::size_t>(width));
    const auto append_fill = [&](std::size_t count) {
        if (pattern.size() == 1) { output.append(count, pattern.front()); return; }
        while (count >= pattern.size()) {
            output.append(pattern);
            count -= pattern.size();
        }
        output.append(pattern.substr(0, count));
    };
    append_fill(left);
    output.append(bytes);
    append_fill(extra - left);
    return detail::string_access::own(std::move(output));
}
}
namespace str { bool_t contains(const string& value, const string& other) { return detail::string_access::read(value).contains(detail::string_access::read(other)); } }
namespace str { bool_t ends_with(const string& value, const string& other) { return detail::string_access::read(value).ends_with(detail::string_access::read(other)); } }
namespace str { string repeat(const string& value, int64 other) { return detail::string_access::own(detail::repeat_bytes(detail::string_access::read(value), other)); } }
namespace str {
static string replace_bytes_impl(const string& subject, const string& search, const string& replacement, replace_mode mode, const auto& on_match) {
    const auto needle = detail::string_access::read(search);
    if (needle.empty()) return subject;
    auto remaining = detail::string_access::read(subject);
    auto match = remaining.find(needle);
    if (match == std::string_view::npos) return subject;

    const auto inserted = detail::string_access::read(replacement);
    std::string output;
    do {
        output.append(remaining.substr(0, match));
        output.append(inserted);
        on_match();
        remaining.remove_prefix(match + needle.size());
        if (mode == replace_mode::first) break;
        match = remaining.find(needle);
    } while (match != std::string_view::npos);
    output.append(remaining);
    return detail::string_access::own(std::move(output));
}
string replace_bytes(const string& subject, const string& search, const string& replacement, replace_mode mode) {
    return replace_bytes_impl(subject, search, replacement, mode, [] {});
}
}
namespace str {
string replace_bytes(const string& subject, const string& search, const string& replacement, replace_mode mode, int64& count) {
    int64 matches = 0;
    auto result = replace_bytes_impl(subject, search, replacement, mode, [&matches] { ++matches; });
    count = matches;
    return result;
}
}
namespace str { bool_t starts_with(const string& value, const string& other) { return detail::string_access::read(value).starts_with(detail::string_access::read(other)); } }
namespace str { int64 compare_bytes(const string& left, const string& right, bool_t insensitive) { return detail::compare_byte_views(detail::string_access::read(left), detail::string_access::read(right), insensitive); } }
namespace str { string byte_from_int(int64 value) {
    if (value < 0 || value > 255) throw std::invalid_argument("Byte value must be between 0 and 255");
    const char byte = static_cast<char>(value);
    return string{&byte, 1};
} }
namespace str {
// Private specializations keep the runtime API concrete and the exact search on string_view's fast path.
template<bool reverse, bool folded>
static std::size_t byte_match(std::string_view subject, std::string_view needle, std::size_t pos) {
    if constexpr (!folded) return reverse ? subject.rfind(needle, pos) : subject.find(needle, pos);
    if (needle.size() > subject.size()) return std::string_view::npos;
    const auto last = subject.size() - needle.size();
    if (!reverse && pos > last) return std::string_view::npos;
    auto start = reverse ? std::min(pos, last) : pos;
    if (needle.empty()) return start;
    const auto first = detail::fold_ascii_byte(needle.front());
    for (;;) {
        if (detail::fold_ascii_byte(subject[start]) == first) {
            std::size_t i = 1;
            while (i < needle.size() && detail::fold_ascii_byte(subject[start + i]) == detail::fold_ascii_byte(needle[i])) ++i;
            if (i == needle.size()) return start;
        }
        if (reverse ? start == 0 : start == last) return std::string_view::npos;
        if constexpr (reverse) --start;
        else ++start;
    }
}
template<bool reverse, bool folded>
static int64 search_position(std::string_view subject, std::string_view needle, int64 offset, search_policy policy) {
    const auto size = detail::checked_integer_cast<int64>(subject.size());
    const bool suffix = policy == search_policy::signed_offset && reverse && offset >= 0;
    if (policy == search_policy::signed_offset) {
        if (offset < 0) offset += size;
        if (offset < 0 || offset > size) throw ValueError("Search offset outside subject");
    } else if (policy == search_policy::clamp) {
        if (offset < 0) offset = 0;
        else if (offset > size) offset = size;
    } else {
        if (offset < 0) throw ValueError("Search position must be nonnegative");
        if (offset > size) {
            if (!reverse) return -1;
            offset = size;
        }
    }
    const auto pos = static_cast<std::size_t>(offset);
    if (suffix) subject.remove_prefix(pos);
    const auto match = byte_match<reverse, folded>(subject, needle, suffix ? std::string_view::npos : pos);
    if (match == std::string_view::npos) return -1;
    return detail::checked_integer_cast<int64>(match) + (suffix ? offset : 0);
}
}
namespace str {
int64 ascii_find(const string& subject, const string& needle) {
    const auto pos = byte_match<false, true>(detail::string_access::read(subject), detail::string_access::read(needle),
        false ? std::string_view::npos : 0);
    return pos == std::string_view::npos ? -1 : detail::checked_integer_cast<int64>(pos);
}
int64 ascii_find(const string& subject, const string& needle, int64 offset, search_policy policy) {
    return search_position<false, true>(detail::string_access::read(subject), detail::string_access::read(needle), offset, policy);
}
}
namespace str {
int64 compare_prefix(const string& left, const string& right, int64 limit, bool_t insensitive) {
    if (limit < 0) throw ValueError("Byte comparison limit must be nonnegative");
    if (limit == 0) return 0;
    const auto count = static_cast<std::size_t>(std::min<std::uint64_t>(limit, std::string_view::npos));
    return detail::compare_byte_views(detail::string_access::read(left).substr(0, count),
        detail::string_access::read(right).substr(0, count), insensitive);
}
}
namespace str {
int64 find(const string& subject, const string& needle) {
    const auto pos = byte_match<false, false>(detail::string_access::read(subject), detail::string_access::read(needle),
        false ? std::string_view::npos : 0);
    return pos == std::string_view::npos ? -1 : detail::checked_integer_cast<int64>(pos);
}
int64 find(const string& subject, const string& needle, int64 offset, search_policy policy) {
    return search_position<false, false>(detail::string_access::read(subject), detail::string_access::read(needle), offset, policy);
}
}
namespace str {
int64 ascii_rfind(const string& subject, const string& needle) {
    const auto pos = byte_match<true, true>(detail::string_access::read(subject), detail::string_access::read(needle),
        true ? std::string_view::npos : 0);
    return pos == std::string_view::npos ? -1 : detail::checked_integer_cast<int64>(pos);
}
int64 ascii_rfind(const string& subject, const string& needle, int64 offset, search_policy policy) {
    return search_position<true, true>(detail::string_access::read(subject), detail::string_access::read(needle), offset, policy);
}
}
namespace str {
int64 rfind(const string& subject, const string& needle) {
    const auto pos = byte_match<true, false>(detail::string_access::read(subject), detail::string_access::read(needle),
        true ? std::string_view::npos : 0);
    return pos == std::string_view::npos ? -1 : detail::checked_integer_cast<int64>(pos);
}
int64 rfind(const string& subject, const string& needle, int64 offset, search_policy policy) {
    return search_position<true, false>(detail::string_access::read(subject), detail::string_access::read(needle), offset, policy);
}
}
namespace str { string ascii_lower(const string& value) { return detail::string_access::ascii_case(value, false, false); } }
namespace str { string ascii_upper(const string& value) { return detail::string_access::ascii_case(value, true, false); } }
namespace str {
static int64 byte_position(int64 size, int64 index) {
    if (index < 0) return index < -size ? 0 : size + index;
    return index > size ? size : index;
}
}
namespace str {
string slice_bytes(const string& value, int64 start, int64 bound, slice_bound mode) {
    const int64 size = value.size();
    const int64 begin = byte_position(size, start);
    int64 end = size;
    if (mode == slice_bound::exclusive_end || (mode == slice_bound::length && bound < 0))
        end = byte_position(size, bound);
    else if (mode == slice_bound::length && bound < size - begin)
        end = begin + bound;
    if (end <= begin) return string{};
    return string{value.data() + begin, end - begin};
}
}
namespace str {
int64 compare_window(const string& subject, const string& other, int64 offset, int64 length, bool_t insensitive) {
    const int64 size = subject.size();
    if (offset < 0) offset += size;
    if (offset < 0 || offset > size) offset = size;
    const int64 available = size - offset;
    const int64 limit = length < 0 ? std::max<int64>(0, available + length) : length;
    const auto left = detail::string_access::read(subject).substr(static_cast<std::size_t>(offset),
        static_cast<std::size_t>(std::min(available, limit)));
    const auto right = detail::string_access::read(other).substr(0, static_cast<std::size_t>(std::min(other.size(), limit)));
    return detail::compare_byte_views(left, right, insensitive);
}
int64 compare_window(const string& subject, const string& other, int64 offset) {
    return compare_window(subject, other, offset, std::numeric_limits<int64>::max(), false);
}
}
namespace str {
static int64 count_byte_window(const string& value, const string& other, int64 offset, const int64* length) {
    const auto needle = detail::string_access::read(other);
    if (needle.empty()) throw ValueError("Substring count requires a nonempty needle");
    auto remaining = detail::string_access::read(value);
    const auto size = detail::checked_integer_cast<int64>(remaining.size());
    if (offset < 0) offset += size;
    if (offset < 0 || offset > size) throw ValueError("Substring count offset outside subject");
    const auto available = size - offset;
    auto width = available;
    if (length) {
        width = *length < 0 ? available + *length : *length;
        if (width < 0 || width > available) throw ValueError("Substring count length outside subject");
    }
    remaining = remaining.substr(static_cast<std::size_t>(offset), static_cast<std::size_t>(width));
    std::size_t count = 0;
    for (auto match = remaining.find(needle); match != std::string_view::npos; match = remaining.find(needle)) {
        ++count;
        remaining.remove_prefix(match + needle.size());
    }
    return detail::checked_integer_cast<int64>(count);
}
int64 count_matches(const string& value, const string& other) { return count_byte_window(value, other, 0, nullptr); }
int64 count_matches(const string& value, const string& other, int64 offset) { return count_byte_window(value, other, offset, nullptr); }
int64 count_matches(const string& value, const string& other, int64 offset, int64 length) { return count_byte_window(value, other, offset, &length); }
}
namespace str {
string substr_replace(const string& subject, const string& replacement, int64 offset, int64 length) {
    const int64 size = subject.size();
    const int64 begin = byte_position(size, offset);
    int64 removed;
    if (length < 0) {
        const int64 end = byte_position(size, length);
        if (end <= begin) return subject;
        removed = end - begin;
    } else {
        removed = length > size - begin ? size - begin : length;
    }
    std::string output(detail::string_access::read(subject));
    output.replace(static_cast<std::size_t>(begin), static_cast<std::size_t>(removed), detail::string_access::read(replacement));
    return detail::string_access::own(std::move(output));
}
}
namespace str { string ascii_upper_first(const string& value) { return detail::string_access::ascii_case(value, true, true); } }
struct vector_int64::storage {
    using element_type = int64;
static_assert(__is_constructible(element_type, const element_type&), "collections/vector requires e.copy_constructible");
static element_type& element_type_contract_value() noexcept;
static_assert(noexcept(element_type_contract_value().~element_type()), "collections/vector requires e.nothrow_destructible");
static_assert(__is_nothrow_assignable(element_type&, element_type&&), "collections/vector requires e.nothrow_move_assignable");
static_assert(__is_nothrow_constructible(element_type, element_type&&), "collections/vector requires e.nothrow_move_constructible");

    unsigned char* data = nullptr;
    std::size_t count = 0;
    std::size_t capacity = 0;

    storage() noexcept = default;
    storage(const storage& other) {
        data = detail::vector_allocate(other.count, sizeof(element_type), alignof(element_type));
        capacity = other.count;
        try {
            while (count < other.count) {
                ::new (data + count * sizeof(element_type)) element_type(other[count]);
                ++count;
            }
        } catch (...) {
            clear();
            detail::vector_deallocate(data, alignof(element_type));
            throw;
        }
    }
    storage& operator=(const storage&) = delete;
    ~storage() { clear(); detail::vector_deallocate(data, alignof(element_type)); }
    std::size_t size() const noexcept { return count; }
    bool empty() const noexcept { return count == 0; }
    const element_type* iteration_select(int64 position, int64 limit) const noexcept {
        return position < limit && static_cast<unsigned long long>(position) < count
            ? &(*this)[static_cast<std::size_t>(position)] : nullptr;
    }
    element_type& operator[](std::size_t index) noexcept { return *reinterpret_cast<element_type*>(data + index * sizeof(element_type)); }
    const element_type& operator[](std::size_t index) const noexcept { return *reinterpret_cast<const element_type*>(data + index * sizeof(element_type)); }
    const element_type& front() const noexcept { return (*this)[0]; }
    void clear() noexcept { while (count != 0) (*this)[--count].~element_type(); }
    void reserve(std::size_t required) {
        if (required <= capacity) return;
        const auto next_capacity = detail::vector_growth(capacity, required, sizeof(element_type));
        auto* next = detail::vector_allocate(next_capacity, sizeof(element_type), alignof(element_type));
        for (std::size_t i = 0; i < count; ++i) {
            ::new (next + i * sizeof(element_type)) element_type(static_cast<element_type&&>((*this)[i]));
            (*this)[i].~element_type();
        }
        detail::vector_deallocate(data, alignof(element_type));
        data = next;
        capacity = next_capacity;
    }
    void append(element_type&& value) {
        reserve(count + 1);
        ::new (data + count * sizeof(element_type)) element_type(static_cast<element_type&&>(value));
        ++count;
    }
    void remove(std::size_t offset) noexcept {
        for (std::size_t i = offset; i + 1 < count; ++i) (*this)[i] = static_cast<element_type&&>((*this)[i + 1]);
        (*this)[--count].~element_type();
    }
};
struct vector_string::storage {
    using element_type = string;
static_assert(__is_constructible(element_type, const element_type&), "collections/vector requires e.copy_constructible");
static element_type& element_type_contract_value() noexcept;
static_assert(noexcept(element_type_contract_value().~element_type()), "collections/vector requires e.nothrow_destructible");
static_assert(__is_nothrow_assignable(element_type&, element_type&&), "collections/vector requires e.nothrow_move_assignable");
static_assert(__is_nothrow_constructible(element_type, element_type&&), "collections/vector requires e.nothrow_move_constructible");

    unsigned char* data = nullptr;
    std::size_t count = 0;
    std::size_t capacity = 0;

    storage() noexcept = default;
    storage(const storage& other) {
        data = detail::vector_allocate(other.count, sizeof(element_type), alignof(element_type));
        capacity = other.count;
        try {
            while (count < other.count) {
                ::new (data + count * sizeof(element_type)) element_type(other[count]);
                ++count;
            }
        } catch (...) {
            clear();
            detail::vector_deallocate(data, alignof(element_type));
            throw;
        }
    }
    storage& operator=(const storage&) = delete;
    ~storage() { clear(); detail::vector_deallocate(data, alignof(element_type)); }
    std::size_t size() const noexcept { return count; }
    bool empty() const noexcept { return count == 0; }
    const element_type* iteration_select(int64 position, int64 limit) const noexcept {
        return position < limit && static_cast<unsigned long long>(position) < count
            ? &(*this)[static_cast<std::size_t>(position)] : nullptr;
    }
    element_type& operator[](std::size_t index) noexcept { return *reinterpret_cast<element_type*>(data + index * sizeof(element_type)); }
    const element_type& operator[](std::size_t index) const noexcept { return *reinterpret_cast<const element_type*>(data + index * sizeof(element_type)); }
    const element_type& front() const noexcept { return (*this)[0]; }
    void clear() noexcept { while (count != 0) (*this)[--count].~element_type(); }
    void reserve(std::size_t required) {
        if (required <= capacity) return;
        const auto next_capacity = detail::vector_growth(capacity, required, sizeof(element_type));
        auto* next = detail::vector_allocate(next_capacity, sizeof(element_type), alignof(element_type));
        for (std::size_t i = 0; i < count; ++i) {
            ::new (next + i * sizeof(element_type)) element_type(static_cast<element_type&&>((*this)[i]));
            (*this)[i].~element_type();
        }
        detail::vector_deallocate(data, alignof(element_type));
        data = next;
        capacity = next_capacity;
    }
    void append(element_type&& value) {
        reserve(count + 1);
        ::new (data + count * sizeof(element_type)) element_type(static_cast<element_type&&>(value));
        ++count;
    }
    void remove(std::size_t offset) noexcept {
        for (std::size_t i = offset; i + 1 < count; ++i) (*this)[i] = static_cast<element_type&&>((*this)[i + 1]);
        (*this)[--count].~element_type();
    }
};
namespace detail { struct vector_access {
    static const vector_int64::storage& read(const vector_int64& value) noexcept { static const vector_int64::storage empty; return value.storage_ ? *value.storage_ : empty; }
    static const vector_string::storage& read(const vector_string& value) noexcept { static const vector_string::storage empty; return value.storage_ ? *value.storage_ : empty; }
}; }
vector_int64::~vector_int64() { delete storage_; }
vector_int64::vector_int64(const vector_int64& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
vector_int64::vector_int64(vector_int64&& other) noexcept : storage_(other.storage_) { other.storage_ = nullptr; }
vector_int64& vector_int64::operator=(const vector_int64& other) { if (this != &other) { vector_int64 copy(other); auto* old = storage_; storage_ = copy.storage_; copy.storage_ = old; } return *this; }
vector_int64& vector_int64::operator=(vector_int64&& other) noexcept { if (this != &other) { delete storage_; storage_ = other.storage_; other.storage_ = nullptr; } return *this; }
int64 vector_int64::size() const { return static_cast<int64>(detail::vector_access::read(*this).size()); }
bool_t vector_int64::empty() const noexcept { return detail::vector_access::read(*this).empty(); }
void vector_int64::clear() noexcept { if (storage_) storage_->clear(); }
void vector_int64::append(int64 value) {
    if (storage_) { storage_->append(static_cast<int64&&>(value)); return; }
    auto* fresh = new storage;
    try { fresh->append(static_cast<int64&&>(value)); }
    catch (...) { delete fresh; throw; }
    storage_ = fresh;
}
int64 vector_int64::at(int64 index) const { const auto& values = detail::vector_access::read(*this); return values[detail::vector_index(index, values.size())]; }
void vector_int64::set(int64 index, int64 value) { const auto offset = detail::vector_index(index, detail::vector_access::read(*this).size()); (*storage_)[offset] = static_cast<int64&&>(value); }
bool_t vector_int64::remove(int64 index) {
    if (!has(index)) return false;
    storage_->remove(static_cast<std::size_t>(index));
    return true;
}
bool_t vector_int64::has(int64 index) const noexcept {
    return index >= 0 && storage_ && static_cast<unsigned long long>(index) < storage_->size();
}
int64 vector_int64::iteration_limit() const { return size(); }
bool_t vector_int64::iteration_next(int64& position, int64 limit, int64& value) const {
    int64 key;
    return iteration_next(position, limit, key, value);
}
bool_t vector_int64::iteration_next(int64& position, int64 limit, int64& key, int64& value) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    const auto* item = storage_ ? storage_->iteration_select(position, limit) : nullptr;
    if (!item) return false;
    auto selected = *item;
    const auto selected_key = position;
    ++position;
    key = selected_key;
    value = static_cast<int64&&>(selected);
    return true;
}
int64 vector_int64::at(int index) const { return at(static_cast<int64>(index)); }
void vector_int64::append(int value) { append(static_cast<int64>(value)); }
void vector_int64::set(int64 index, int value) { set(index, static_cast<int64>(value)); }
void vector_int64::set(int index, int64 value) { set(static_cast<int64>(index), static_cast<int64&&>(value)); }
void vector_int64::set(int index, int value) { set(static_cast<int64>(index), static_cast<int64>(value)); }
bool_t operator==(const vector_int64& left, const vector_int64& right) {
    const auto& a = detail::vector_access::read(left);
    const auto& b = detail::vector_access::read(right);
    if (a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) if (!(a[i] == b[i])) return false;
    return true;
}
bool_t operator!=(const vector_int64& left, const vector_int64& right) {
    const auto& a = detail::vector_access::read(left);
    const auto& b = detail::vector_access::read(right);
    if (a.size() != b.size()) return true;
    for (std::size_t i = 0; i < a.size(); ++i) if (!(a[i] == b[i])) return true;
    return false;
}
vector_string::~vector_string() { delete storage_; }
vector_string::vector_string(const vector_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
vector_string::vector_string(vector_string&& other) noexcept : storage_(other.storage_) { other.storage_ = nullptr; }
vector_string& vector_string::operator=(const vector_string& other) { if (this != &other) { vector_string copy(other); auto* old = storage_; storage_ = copy.storage_; copy.storage_ = old; } return *this; }
vector_string& vector_string::operator=(vector_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = other.storage_; other.storage_ = nullptr; } return *this; }
int64 vector_string::size() const { return static_cast<int64>(detail::vector_access::read(*this).size()); }
bool_t vector_string::empty() const noexcept { return detail::vector_access::read(*this).empty(); }
void vector_string::clear() noexcept { if (storage_) storage_->clear(); }
void vector_string::append(string value) {
    if (storage_) { storage_->append(static_cast<string&&>(value)); return; }
    auto* fresh = new storage;
    try { fresh->append(static_cast<string&&>(value)); }
    catch (...) { delete fresh; throw; }
    storage_ = fresh;
}
string vector_string::at(int64 index) const { const auto& values = detail::vector_access::read(*this); return values[detail::vector_index(index, values.size())]; }
void vector_string::set(int64 index, string value) { const auto offset = detail::vector_index(index, detail::vector_access::read(*this).size()); (*storage_)[offset] = static_cast<string&&>(value); }
bool_t vector_string::remove(int64 index) {
    if (!has(index)) return false;
    storage_->remove(static_cast<std::size_t>(index));
    return true;
}
bool_t vector_string::has(int64 index) const noexcept {
    return index >= 0 && storage_ && static_cast<unsigned long long>(index) < storage_->size();
}
int64 vector_string::iteration_limit() const { return size(); }
bool_t vector_string::iteration_next(int64& position, int64 limit, string& value) const {
    int64 key;
    return iteration_next(position, limit, key, value);
}
bool_t vector_string::iteration_next(int64& position, int64 limit, int64& key, string& value) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    const auto* item = storage_ ? storage_->iteration_select(position, limit) : nullptr;
    if (!item) return false;
    auto selected = *item;
    const auto selected_key = position;
    ++position;
    key = selected_key;
    value = static_cast<string&&>(selected);
    return true;
}
string vector_string::at(int index) const { return at(static_cast<int64>(index)); }
void vector_string::append(const char* value) { append(string{value}); }
void vector_string::set(int64 index, const char* value) { set(index, string{value}); }
void vector_string::set(int index, string value) { set(static_cast<int64>(index), static_cast<string&&>(value)); }
void vector_string::set(int index, const char* value) { set(static_cast<int64>(index), string{value}); }
bool_t operator==(const vector_string& left, const vector_string& right) {
    const auto& a = detail::vector_access::read(left);
    const auto& b = detail::vector_access::read(right);
    if (a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) if (!(a[i] == b[i])) return false;
    return true;
}
bool_t operator!=(const vector_string& left, const vector_string& right) {
    const auto& a = detail::vector_access::read(left);
    const auto& b = detail::vector_access::read(right);
    if (a.size() != b.size()) return true;
    for (std::size_t i = 0; i < a.size(); ++i) if (!(a[i] == b[i])) return true;
    return false;
}
namespace str {
vector_string split(const string& subject, const string& separator) {
    return split(subject, separator, std::numeric_limits<int64>::max(), split_policy::cap);
}
vector_string split(const string& subject, const string& separator, int64 limit, split_policy policy) {
    const auto delimiter = detail::string_access::read(separator);
    if (delimiter.empty()) throw ValueError("Split requires a nonempty separator");
    auto remaining = detail::string_access::read(subject);
    vector_string parts;
    if (limit < 0) {
        if (policy == split_policy::cap) throw ValueError("Split limit must be nonnegative");
        // Count kept fields from the negative limit without allocating dropped fields or negating INT64_MIN.
        auto tail = remaining;
        for (auto match = tail.find(delimiter); match != std::string_view::npos; match = tail.find(delimiter)) {
            ++limit;
            tail.remove_prefix(match + delimiter.size());
        }
        ++limit;
        policy = split_policy::cap;
    } else if (policy == split_policy::remainder && limit == 0) {
        limit = 1;
    }
    while (limit > 0) {
        const auto match = policy == split_policy::remainder && limit == 1 ? std::string_view::npos : remaining.find(delimiter);
        const auto field = remaining.substr(0, match);
        parts.append(string{field.data(), detail::checked_integer_cast<int64>(field.size())});
        if (match == std::string_view::npos) break;
        remaining.remove_prefix(match + delimiter.size());
        --limit;
    }
    return parts;
}
}
namespace str {
string join(const vector_string& pieces, const string& separator) {
    const auto& values = detail::vector_access::read(pieces);
    if (values.empty()) return string{};
    const auto delimiter = detail::string_access::read(separator);
    std::string output(detail::string_access::read(values.front()));
    for (std::size_t i = 1; i < values.size(); ++i) {
        output.append(delimiter);
        output.append(detail::string_access::read(values[i]));
    }
    return detail::string_access::own(std::move(output));
}
}
const error_t error_t::no_error{};
error_t::error_t(string message, int64 line, string file) : present_(true), message_(std::move(message)), line_(line), file_(std::move(file)) {}
bool_t error_t::has_error() const noexcept { return bool_t{present_}; }
error_t::operator bool() const noexcept { return present_; }
string error_t::get_message() const { return message_; }
int64 error_t::get_line() const noexcept { return line_; }
string error_t::get_file() const { return file_; }
struct nullable_bool_t::storage { using content_type = detail::carrier_storage<bool_t>; content_type content; };
nullable_bool_t::~nullable_bool_t() { delete storage_; }
nullable_bool_t::nullable_bool_t(const nullable_bool_t& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
nullable_bool_t::nullable_bool_t(nullable_bool_t&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
nullable_bool_t& nullable_bool_t::operator=(const nullable_bool_t& other) { if (this != &other) { nullable_bool_t copy(other); std::swap(storage_, copy.storage_); } return *this; }
nullable_bool_t& nullable_bool_t::operator=(nullable_bool_t&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
nullable_bool_t::nullable_bool_t(bool_t value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t nullable_bool_t::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
bool_t nullable_bool_t::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
nullable_bool_t::operator bool_t() const { return value(); }
nullable_bool_t::nullable_bool_t(null_t) noexcept {}
void nullable_bool_t::reset() noexcept { delete storage_; storage_ = nullptr; }
struct nullable_int64::storage { using content_type = detail::carrier_storage<int64>; content_type content; };
nullable_int64::~nullable_int64() { delete storage_; }
nullable_int64::nullable_int64(const nullable_int64& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
nullable_int64::nullable_int64(nullable_int64&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
nullable_int64& nullable_int64::operator=(const nullable_int64& other) { if (this != &other) { nullable_int64 copy(other); std::swap(storage_, copy.storage_); } return *this; }
nullable_int64& nullable_int64::operator=(nullable_int64&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
nullable_int64::nullable_int64(int64 value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t nullable_int64::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
int64 nullable_int64::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
nullable_int64::operator int64() const { return value(); }
nullable_int64::nullable_int64(null_t) noexcept {}
void nullable_int64::reset() noexcept { delete storage_; storage_ = nullptr; }
struct nullable_string::storage { using content_type = detail::carrier_storage<string>; content_type content; };
nullable_string::~nullable_string() { delete storage_; }
nullable_string::nullable_string(const nullable_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
nullable_string::nullable_string(nullable_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
nullable_string& nullable_string::operator=(const nullable_string& other) { if (this != &other) { nullable_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
nullable_string& nullable_string::operator=(nullable_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
nullable_string::nullable_string(string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t nullable_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
string nullable_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
nullable_string::operator string() const { return value(); }
nullable_string::nullable_string(null_t) noexcept {}
void nullable_string::reset() noexcept { delete storage_; storage_ = nullptr; }
struct nullable_vector_string::storage { using content_type = detail::carrier_storage<vector_string>; content_type content; };
nullable_vector_string::~nullable_vector_string() { delete storage_; }
nullable_vector_string::nullable_vector_string(const nullable_vector_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
nullable_vector_string::nullable_vector_string(nullable_vector_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
nullable_vector_string& nullable_vector_string::operator=(const nullable_vector_string& other) { if (this != &other) { nullable_vector_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
nullable_vector_string& nullable_vector_string::operator=(nullable_vector_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
nullable_vector_string::nullable_vector_string(vector_string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t nullable_vector_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
vector_string nullable_vector_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
nullable_vector_string::operator vector_string() const { return value(); }
nullable_vector_string::nullable_vector_string(null_t) noexcept {}
void nullable_vector_string::reset() noexcept { delete storage_; storage_ = nullptr; }
struct result_bool_t::storage { using content_type = detail::carrier_storage<bool_t, error_t>; content_type content; };
result_bool_t::~result_bool_t() { delete storage_; }
result_bool_t::result_bool_t(const result_bool_t& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_bool_t::result_bool_t(result_bool_t&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_bool_t& result_bool_t::operator=(const result_bool_t& other) { if (this != &other) { result_bool_t copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_bool_t& result_bool_t::operator=(result_bool_t&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_bool_t::result_bool_t(bool_t value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_bool_t::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : true}; }
bool_t result_bool_t::value() const { if (!storage_) return bool_t{}; if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_bool_t::operator bool_t() const { return value(); }
result_bool_t::result_bool_t(error_t error) : storage_(new storage{storage::content_type::failure(std::move(error))}) {}
bool_t result_bool_t::has_error() const noexcept { return bool_t{storage_ && storage_->content.has_error()}; }
error_t result_bool_t::error() const { if (!storage_) throw std::runtime_error("result_no_error"); return storage_->content.error(); }
struct result_int64::storage { using content_type = detail::carrier_storage<int64, error_t>; content_type content; };
result_int64::~result_int64() { delete storage_; }
result_int64::result_int64(const result_int64& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_int64::result_int64(result_int64&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_int64& result_int64::operator=(const result_int64& other) { if (this != &other) { result_int64 copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_int64& result_int64::operator=(result_int64&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_int64::result_int64(int64 value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_int64::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : true}; }
int64 result_int64::value() const { if (!storage_) return int64{}; if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_int64::operator int64() const { return value(); }
result_int64::result_int64(error_t error) : storage_(new storage{storage::content_type::failure(std::move(error))}) {}
bool_t result_int64::has_error() const noexcept { return bool_t{storage_ && storage_->content.has_error()}; }
error_t result_int64::error() const { if (!storage_) throw std::runtime_error("result_no_error"); return storage_->content.error(); }
struct result_or_bool_bool_t::storage { using content_type = detail::carrier_storage<bool_t>; content_type content; };
result_or_bool_bool_t::~result_or_bool_bool_t() { delete storage_; }
result_or_bool_bool_t::result_or_bool_bool_t(const result_or_bool_bool_t& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_bool_bool_t::result_or_bool_bool_t(result_or_bool_bool_t&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_bool_bool_t& result_or_bool_bool_t::operator=(const result_or_bool_bool_t& other) { if (this != &other) { result_or_bool_bool_t copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_bool_bool_t& result_or_bool_bool_t::operator=(result_or_bool_bool_t&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_bool_bool_t::result_or_bool_bool_t(bool_t value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_bool_bool_t::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
bool_t result_or_bool_bool_t::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_bool_bool_t::operator bool_t() const { return value(); }
void result_or_bool_bool_t::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_bool_bool_t result_or_bool_bool_t::from_false() noexcept { return {}; }
bool_t result_or_bool_bool_t::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
result_or_bool_bool_t result_or_bool_bool_t::from_true() { result_or_bool_bool_t out; out.storage_ = new storage{storage::content_type::sentinel_true()}; return out; }
bool_t result_or_bool_bool_t::is_true() const noexcept { return bool_t{storage_ && storage_->content.is_true()}; }
struct result_or_bool_int64::storage { using content_type = detail::carrier_storage<int64>; content_type content; };
result_or_bool_int64::~result_or_bool_int64() { delete storage_; }
result_or_bool_int64::result_or_bool_int64(const result_or_bool_int64& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_bool_int64::result_or_bool_int64(result_or_bool_int64&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_bool_int64& result_or_bool_int64::operator=(const result_or_bool_int64& other) { if (this != &other) { result_or_bool_int64 copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_bool_int64& result_or_bool_int64::operator=(result_or_bool_int64&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_bool_int64::result_or_bool_int64(int64 value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_bool_int64::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
int64 result_or_bool_int64::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_bool_int64::operator int64() const { return value(); }
void result_or_bool_int64::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_bool_int64 result_or_bool_int64::from_false() noexcept { return {}; }
bool_t result_or_bool_int64::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
result_or_bool_int64 result_or_bool_int64::from_true() { result_or_bool_int64 out; out.storage_ = new storage{storage::content_type::sentinel_true()}; return out; }
bool_t result_or_bool_int64::is_true() const noexcept { return bool_t{storage_ && storage_->content.is_true()}; }
struct result_or_bool_string::storage { using content_type = detail::carrier_storage<string>; content_type content; };
result_or_bool_string::~result_or_bool_string() { delete storage_; }
result_or_bool_string::result_or_bool_string(const result_or_bool_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_bool_string::result_or_bool_string(result_or_bool_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_bool_string& result_or_bool_string::operator=(const result_or_bool_string& other) { if (this != &other) { result_or_bool_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_bool_string& result_or_bool_string::operator=(result_or_bool_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_bool_string::result_or_bool_string(string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_bool_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
string result_or_bool_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_bool_string::operator string() const { return value(); }
void result_or_bool_string::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_bool_string result_or_bool_string::from_false() noexcept { return {}; }
bool_t result_or_bool_string::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
result_or_bool_string result_or_bool_string::from_true() { result_or_bool_string out; out.storage_ = new storage{storage::content_type::sentinel_true()}; return out; }
bool_t result_or_bool_string::is_true() const noexcept { return bool_t{storage_ && storage_->content.is_true()}; }
struct result_or_bool_vector_string::storage { using content_type = detail::carrier_storage<vector_string>; content_type content; };
result_or_bool_vector_string::~result_or_bool_vector_string() { delete storage_; }
result_or_bool_vector_string::result_or_bool_vector_string(const result_or_bool_vector_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_bool_vector_string::result_or_bool_vector_string(result_or_bool_vector_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_bool_vector_string& result_or_bool_vector_string::operator=(const result_or_bool_vector_string& other) { if (this != &other) { result_or_bool_vector_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_bool_vector_string& result_or_bool_vector_string::operator=(result_or_bool_vector_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_bool_vector_string::result_or_bool_vector_string(vector_string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_bool_vector_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
vector_string result_or_bool_vector_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_bool_vector_string::operator vector_string() const { return value(); }
void result_or_bool_vector_string::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_bool_vector_string result_or_bool_vector_string::from_false() noexcept { return {}; }
bool_t result_or_bool_vector_string::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
result_or_bool_vector_string result_or_bool_vector_string::from_true() { result_or_bool_vector_string out; out.storage_ = new storage{storage::content_type::sentinel_true()}; return out; }
bool_t result_or_bool_vector_string::is_true() const noexcept { return bool_t{storage_ && storage_->content.is_true()}; }
struct result_or_false_bool_t::storage { using content_type = detail::carrier_storage<bool_t>; content_type content; };
result_or_false_bool_t::~result_or_false_bool_t() { delete storage_; }
result_or_false_bool_t::result_or_false_bool_t(const result_or_false_bool_t& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_false_bool_t::result_or_false_bool_t(result_or_false_bool_t&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_false_bool_t& result_or_false_bool_t::operator=(const result_or_false_bool_t& other) { if (this != &other) { result_or_false_bool_t copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_false_bool_t& result_or_false_bool_t::operator=(result_or_false_bool_t&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_false_bool_t::result_or_false_bool_t(bool_t value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_false_bool_t::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
bool_t result_or_false_bool_t::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_false_bool_t::operator bool_t() const { return value(); }
void result_or_false_bool_t::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_false_bool_t result_or_false_bool_t::from_false() noexcept { return {}; }
bool_t result_or_false_bool_t::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
struct result_or_false_int64::storage { using content_type = detail::carrier_storage<int64>; content_type content; };
result_or_false_int64::~result_or_false_int64() { delete storage_; }
result_or_false_int64::result_or_false_int64(const result_or_false_int64& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_false_int64::result_or_false_int64(result_or_false_int64&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_false_int64& result_or_false_int64::operator=(const result_or_false_int64& other) { if (this != &other) { result_or_false_int64 copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_false_int64& result_or_false_int64::operator=(result_or_false_int64&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_false_int64::result_or_false_int64(int64 value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_false_int64::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
int64 result_or_false_int64::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_false_int64::operator int64() const { return value(); }
void result_or_false_int64::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_false_int64 result_or_false_int64::from_false() noexcept { return {}; }
bool_t result_or_false_int64::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
struct result_or_false_string::storage { using content_type = detail::carrier_storage<string>; content_type content; };
result_or_false_string::~result_or_false_string() { delete storage_; }
result_or_false_string::result_or_false_string(const result_or_false_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_false_string::result_or_false_string(result_or_false_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_false_string& result_or_false_string::operator=(const result_or_false_string& other) { if (this != &other) { result_or_false_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_false_string& result_or_false_string::operator=(result_or_false_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_false_string::result_or_false_string(string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_false_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
string result_or_false_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_false_string::operator string() const { return value(); }
void result_or_false_string::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_false_string result_or_false_string::from_false() noexcept { return {}; }
bool_t result_or_false_string::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
struct result_or_false_vector_string::storage { using content_type = detail::carrier_storage<vector_string>; content_type content; };
result_or_false_vector_string::~result_or_false_vector_string() { delete storage_; }
result_or_false_vector_string::result_or_false_vector_string(const result_or_false_vector_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_or_false_vector_string::result_or_false_vector_string(result_or_false_vector_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_or_false_vector_string& result_or_false_vector_string::operator=(const result_or_false_vector_string& other) { if (this != &other) { result_or_false_vector_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_or_false_vector_string& result_or_false_vector_string::operator=(result_or_false_vector_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_or_false_vector_string::result_or_false_vector_string(vector_string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_or_false_vector_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : false}; }
vector_string result_or_false_vector_string::value() const { if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_or_false_vector_string::operator vector_string() const { return value(); }
void result_or_false_vector_string::reset() noexcept { delete storage_; storage_ = nullptr; }
result_or_false_vector_string result_or_false_vector_string::from_false() noexcept { return {}; }
bool_t result_or_false_vector_string::is_false() const noexcept { return bool_t{!storage_ || storage_->content.is_false()}; }
struct result_string::storage { using content_type = detail::carrier_storage<string, error_t>; content_type content; };
result_string::~result_string() { delete storage_; }
result_string::result_string(const result_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_string::result_string(result_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_string& result_string::operator=(const result_string& other) { if (this != &other) { result_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_string& result_string::operator=(result_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_string::result_string(string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : true}; }
string result_string::value() const { if (!storage_) return string{}; if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_string::operator string() const { return value(); }
result_string::result_string(error_t error) : storage_(new storage{storage::content_type::failure(std::move(error))}) {}
bool_t result_string::has_error() const noexcept { return bool_t{storage_ && storage_->content.has_error()}; }
error_t result_string::error() const { if (!storage_) throw std::runtime_error("result_no_error"); return storage_->content.error(); }
struct result_vector_string::storage { using content_type = detail::carrier_storage<vector_string, error_t>; content_type content; };
result_vector_string::~result_vector_string() { delete storage_; }
result_vector_string::result_vector_string(const result_vector_string& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
result_vector_string::result_vector_string(result_vector_string&& other) noexcept : storage_(std::exchange(other.storage_, nullptr)) {}
result_vector_string& result_vector_string::operator=(const result_vector_string& other) { if (this != &other) { result_vector_string copy(other); std::swap(storage_, copy.storage_); } return *this; }
result_vector_string& result_vector_string::operator=(result_vector_string&& other) noexcept { if (this != &other) { delete storage_; storage_ = std::exchange(other.storage_, nullptr); } return *this; }
result_vector_string::result_vector_string(vector_string value) : storage_(new storage{storage::content_type{std::move(value)}}) {}
bool_t result_vector_string::has_value() const noexcept { return bool_t{storage_ ? storage_->content.has_value() : true}; }
vector_string result_vector_string::value() const { if (!storage_) return vector_string{}; if (!storage_) throw std::runtime_error("carrier_no_value"); return storage_->content.value(); }
result_vector_string::operator vector_string() const { return value(); }
result_vector_string::result_vector_string(error_t error) : storage_(new storage{storage::content_type::failure(std::move(error))}) {}
bool_t result_vector_string::has_error() const noexcept { return bool_t{storage_ && storage_->content.has_error()}; }
error_t result_vector_string::error() const { if (!storage_) throw std::runtime_error("result_no_error"); return storage_->content.error(); }
static_assert(std::is_same_v<bool, bool>);
static_assert(std::is_same_v<double, double>);
float64 checked_bool_t_to_float64(bool_t value) noexcept { return detail::numeric_cast<float64>(value); }
static_assert(std::is_same_v<__INT16_TYPE__, short>);
int16 checked_bool_t_to_int16(bool_t value) noexcept { return detail::numeric_cast<int16>(value); }
static_assert(std::is_same_v<__INT32_TYPE__, int>);
int32 checked_bool_t_to_int32(bool_t value) noexcept { return detail::numeric_cast<int32>(value); }
static_assert(std::is_same_v<__INT64_TYPE__, long>);
int64 checked_bool_t_to_int64(bool_t value) noexcept { return detail::numeric_cast<int64>(value); }
static_assert(std::is_same_v<__INT8_TYPE__, signed char>);
int8 checked_bool_t_to_int8(bool_t value) noexcept { return detail::numeric_cast<int8>(value); }
static_assert(std::is_same_v<__UINT16_TYPE__, unsigned short>);
uint16 checked_bool_t_to_uint16(bool_t value) noexcept { return detail::numeric_cast<uint16>(value); }
static_assert(std::is_same_v<__UINT32_TYPE__, unsigned int>);
uint32 checked_bool_t_to_uint32(bool_t value) noexcept { return detail::numeric_cast<uint32>(value); }
static_assert(std::is_same_v<__UINT8_TYPE__, unsigned char>);
uint8 checked_bool_t_to_uint8(bool_t value) noexcept { return detail::numeric_cast<uint8>(value); }
bool_t checked_float64_to_bool_t(float64 value) noexcept { return detail::truth_cast<bool_t>(value); }
int16 checked_float64_to_int16(float64 value) { return detail::floating_integer_cast<int16>(value); }
int32 checked_float64_to_int32(float64 value) { return detail::floating_integer_cast<int32>(value); }
int64 checked_float64_to_int64(float64 value) { return detail::floating_integer_cast<int64>(value); }
int8 checked_float64_to_int8(float64 value) { return detail::floating_integer_cast<int8>(value); }
uint16 checked_float64_to_uint16(float64 value) { return detail::floating_integer_cast<uint16>(value); }
uint32 checked_float64_to_uint32(float64 value) { return detail::floating_integer_cast<uint32>(value); }
uint8 checked_float64_to_uint8(float64 value) { return detail::floating_integer_cast<uint8>(value); }
bool_t checked_int16_to_bool_t(int16 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_int16_to_float64(int16 value) noexcept { return detail::numeric_cast<float64>(value); }
int32 checked_int16_to_int32(int16 value) noexcept { return detail::checked_integer_cast<int32>(value); }
int64 checked_int16_to_int64(int16 value) noexcept { return detail::checked_integer_cast<int64>(value); }
int8 checked_int16_to_int8(int16 value) { return detail::checked_integer_cast<int8>(value); }
uint16 checked_int16_to_uint16(int16 value) { return detail::checked_integer_cast<uint16>(value); }
uint32 checked_int16_to_uint32(int16 value) { return detail::checked_integer_cast<uint32>(value); }
uint8 checked_int16_to_uint8(int16 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_int32_to_bool_t(int32 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_int32_to_float64(int32 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_int32_to_int16(int32 value) { return detail::checked_integer_cast<int16>(value); }
int64 checked_int32_to_int64(int32 value) noexcept { return detail::checked_integer_cast<int64>(value); }
int8 checked_int32_to_int8(int32 value) { return detail::checked_integer_cast<int8>(value); }
uint16 checked_int32_to_uint16(int32 value) { return detail::checked_integer_cast<uint16>(value); }
uint32 checked_int32_to_uint32(int32 value) { return detail::checked_integer_cast<uint32>(value); }
uint8 checked_int32_to_uint8(int32 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_int64_to_bool_t(int64 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_int64_to_float64(int64 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_int64_to_int16(int64 value) { return detail::checked_integer_cast<int16>(value); }
int32 checked_int64_to_int32(int64 value) { return detail::checked_integer_cast<int32>(value); }
int8 checked_int64_to_int8(int64 value) { return detail::checked_integer_cast<int8>(value); }
uint16 checked_int64_to_uint16(int64 value) { return detail::checked_integer_cast<uint16>(value); }
uint32 checked_int64_to_uint32(int64 value) { return detail::checked_integer_cast<uint32>(value); }
uint8 checked_int64_to_uint8(int64 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_int8_to_bool_t(int8 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_int8_to_float64(int8 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_int8_to_int16(int8 value) noexcept { return detail::checked_integer_cast<int16>(value); }
int32 checked_int8_to_int32(int8 value) noexcept { return detail::checked_integer_cast<int32>(value); }
int64 checked_int8_to_int64(int8 value) noexcept { return detail::checked_integer_cast<int64>(value); }
uint16 checked_int8_to_uint16(int8 value) { return detail::checked_integer_cast<uint16>(value); }
uint32 checked_int8_to_uint32(int8 value) { return detail::checked_integer_cast<uint32>(value); }
uint8 checked_int8_to_uint8(int8 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_string_to_bool_t(const string& value) { return detail::parse_boolean_text(detail::string_access::read(value)); }
float64 checked_string_to_float64(const string& value) { return detail::parse_decimal<float64>(detail::string_access::read(value)); }
int64 checked_string_to_int64(const string& value) { return detail::parse_decimal<int64>(detail::string_access::read(value)); }
bool_t checked_uint16_to_bool_t(uint16 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_uint16_to_float64(uint16 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_uint16_to_int16(uint16 value) { return detail::checked_integer_cast<int16>(value); }
int32 checked_uint16_to_int32(uint16 value) noexcept { return detail::checked_integer_cast<int32>(value); }
int64 checked_uint16_to_int64(uint16 value) noexcept { return detail::checked_integer_cast<int64>(value); }
int8 checked_uint16_to_int8(uint16 value) { return detail::checked_integer_cast<int8>(value); }
uint32 checked_uint16_to_uint32(uint16 value) noexcept { return detail::checked_integer_cast<uint32>(value); }
uint8 checked_uint16_to_uint8(uint16 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_uint32_to_bool_t(uint32 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_uint32_to_float64(uint32 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_uint32_to_int16(uint32 value) { return detail::checked_integer_cast<int16>(value); }
int32 checked_uint32_to_int32(uint32 value) { return detail::checked_integer_cast<int32>(value); }
int64 checked_uint32_to_int64(uint32 value) noexcept { return detail::checked_integer_cast<int64>(value); }
int8 checked_uint32_to_int8(uint32 value) { return detail::checked_integer_cast<int8>(value); }
uint16 checked_uint32_to_uint16(uint32 value) { return detail::checked_integer_cast<uint16>(value); }
uint8 checked_uint32_to_uint8(uint32 value) { return detail::checked_integer_cast<uint8>(value); }
bool_t checked_uint8_to_bool_t(uint8 value) noexcept { return detail::truth_cast<bool_t>(value); }
float64 checked_uint8_to_float64(uint8 value) noexcept { return detail::numeric_cast<float64>(value); }
int16 checked_uint8_to_int16(uint8 value) noexcept { return detail::checked_integer_cast<int16>(value); }
int32 checked_uint8_to_int32(uint8 value) noexcept { return detail::checked_integer_cast<int32>(value); }
int64 checked_uint8_to_int64(uint8 value) noexcept { return detail::checked_integer_cast<int64>(value); }
int8 checked_uint8_to_int8(uint8 value) { return detail::checked_integer_cast<int8>(value); }
uint16 checked_uint8_to_uint16(uint8 value) noexcept { return detail::checked_integer_cast<uint16>(value); }
uint32 checked_uint8_to_uint32(uint8 value) noexcept { return detail::checked_integer_cast<uint32>(value); }
static_assert(std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::radix == 2 && std::numeric_limits<double>::digits == 53 && std::numeric_limits<double>::max_exponent == 1024);
static_assert(sizeof(float64) == sizeof(double));
string::string(bool_t value) { detail::string_access::init(*this, detail::format_boolean_text(value)); }
string::string(float64 value) { detail::string_access::init(*this, detail::format_decimal(value)); }
string::string(int64 value) { detail::string_access::init(*this, detail::format_decimal(value)); }
static_assert(std::numeric_limits<int>::digits == 31);
static_assert(std::numeric_limits<int>::is_signed == true);
static_assert(std::numeric_limits<long>::digits == 63);
static_assert(std::numeric_limits<long>::is_signed == true);
static_assert(std::numeric_limits<long long>::digits == 63);
static_assert(std::numeric_limits<long long>::is_signed == true);
static_assert(std::numeric_limits<unsigned int>::digits == 32);
static_assert(std::numeric_limits<unsigned int>::is_signed == false);
static_assert(std::numeric_limits<unsigned long>::digits == 64);
static_assert(std::numeric_limits<unsigned long>::is_signed == false);
static_assert(std::numeric_limits<unsigned long long>::digits == 64);
static_assert(std::numeric_limits<unsigned long long>::is_signed == false);
static_assert(sizeof(uint8) == sizeof(__UINT8_TYPE__));
static_assert(alignof(uint8) == alignof(__UINT8_TYPE__));
static_assert(std::numeric_limits<__UINT8_TYPE__>::digits == 8);
static_assert(sizeof(int16) == sizeof(__INT16_TYPE__));
static_assert(alignof(int16) == alignof(__INT16_TYPE__));
static_assert(std::numeric_limits<__INT16_TYPE__>::digits == 15);
static_assert(sizeof(int32) == sizeof(__INT32_TYPE__));
static_assert(alignof(int32) == alignof(__INT32_TYPE__));
static_assert(std::numeric_limits<__INT32_TYPE__>::digits == 31);
static_assert(sizeof(int64) == sizeof(__INT64_TYPE__));
static_assert(alignof(int64) == alignof(__INT64_TYPE__));
static_assert(std::numeric_limits<__INT64_TYPE__>::digits == 63);
static_assert(sizeof(int8) == sizeof(__INT8_TYPE__));
static_assert(alignof(int8) == alignof(__INT8_TYPE__));
static_assert(std::numeric_limits<__INT8_TYPE__>::digits == 7);
static_assert(sizeof(uint16) == sizeof(__UINT16_TYPE__));
static_assert(alignof(uint16) == alignof(__UINT16_TYPE__));
static_assert(std::numeric_limits<__UINT16_TYPE__>::digits == 16);
static_assert(sizeof(uint32) == sizeof(__UINT32_TYPE__));
static_assert(alignof(uint32) == alignof(__UINT32_TYPE__));
static_assert(std::numeric_limits<__UINT32_TYPE__>::digits == 32);
__INT16_TYPE__ int16_divide(__INT16_TYPE__ left, __INT16_TYPE__ right) { return detail::integer_divide(left, right); }
__INT16_TYPE__ int16_remainder(__INT16_TYPE__ left, __INT16_TYPE__ right) { return detail::integer_remainder(left, right); }
__INT16_TYPE__ int16_shift_left(__INT16_TYPE__ left, ::int64_t right) { return detail::integer_shift_left(left, right); }
__INT16_TYPE__ int16_shift_right(__INT16_TYPE__ left, ::int64_t right) { return detail::integer_shift_right(left, right); }
__INT32_TYPE__ int32_divide(__INT32_TYPE__ left, __INT32_TYPE__ right) { return detail::integer_divide(left, right); }
__INT32_TYPE__ int32_remainder(__INT32_TYPE__ left, __INT32_TYPE__ right) { return detail::integer_remainder(left, right); }
__INT32_TYPE__ int32_shift_left(__INT32_TYPE__ left, ::int64_t right) { return detail::integer_shift_left(left, right); }
__INT32_TYPE__ int32_shift_right(__INT32_TYPE__ left, ::int64_t right) { return detail::integer_shift_right(left, right); }
__INT8_TYPE__ int8_divide(__INT8_TYPE__ left, __INT8_TYPE__ right) { return detail::integer_divide(left, right); }
__INT8_TYPE__ int8_remainder(__INT8_TYPE__ left, __INT8_TYPE__ right) { return detail::integer_remainder(left, right); }
__INT8_TYPE__ int8_shift_left(__INT8_TYPE__ left, ::int64_t right) { return detail::integer_shift_left(left, right); }
__INT8_TYPE__ int8_shift_right(__INT8_TYPE__ left, ::int64_t right) { return detail::integer_shift_right(left, right); }
__UINT16_TYPE__ uint16_divide(__UINT16_TYPE__ left, __UINT16_TYPE__ right) { return detail::integer_divide(left, right); }
__UINT16_TYPE__ uint16_remainder(__UINT16_TYPE__ left, __UINT16_TYPE__ right) { return detail::integer_remainder(left, right); }
__UINT16_TYPE__ uint16_shift_left(__UINT16_TYPE__ left, ::int64_t right) { return detail::integer_shift_left(left, right); }
__UINT16_TYPE__ uint16_shift_right(__UINT16_TYPE__ left, ::int64_t right) { return detail::integer_shift_right(left, right); }
__UINT32_TYPE__ uint32_divide(__UINT32_TYPE__ left, __UINT32_TYPE__ right) { return detail::integer_divide(left, right); }
__UINT32_TYPE__ uint32_remainder(__UINT32_TYPE__ left, __UINT32_TYPE__ right) { return detail::integer_remainder(left, right); }
__UINT32_TYPE__ uint32_shift_left(__UINT32_TYPE__ left, ::int64_t right) { return detail::integer_shift_left(left, right); }
__UINT32_TYPE__ uint32_shift_right(__UINT32_TYPE__ left, ::int64_t right) { return detail::integer_shift_right(left, right); }
}
