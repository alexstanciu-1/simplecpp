// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/output.hpp"
#include "scpp/string.hpp"
#define SCPP_OUTPUT_HAS_STRING 1
