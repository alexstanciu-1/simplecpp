// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/core/scalars.hpp"
#include "scpp/string.hpp"
#include "scpp/vectors.hpp"
namespace scpp {
class error_t final {
public:
    error_t() = default;
    explicit error_t(string message, int64 line = int64{}, string file = string{});
    static const error_t no_error;
    bool_t has_error() const noexcept;
    explicit operator bool() const noexcept;
    string get_message() const;
    int64 get_line() const noexcept;
    string get_file() const;
#ifdef __SIZEOF_INT128__
explicit error_t(string, __int128) = delete;
#endif
#ifdef __SIZEOF_INT128__
explicit error_t(string, __int128, string) = delete;
#endif
explicit error_t(string, bool) = delete;
explicit error_t(string, bool, string) = delete;
explicit error_t(string, char) = delete;
explicit error_t(string, char, string) = delete;
explicit error_t(string, char16_t) = delete;
explicit error_t(string, char16_t, string) = delete;
explicit error_t(string, char32_t) = delete;
explicit error_t(string, char32_t, string) = delete;
explicit error_t(string, char8_t) = delete;
explicit error_t(string, char8_t, string) = delete;
explicit error_t(string, decltype(nullptr)) = delete;
explicit error_t(string, decltype(nullptr), string) = delete;
explicit error_t(string, double) = delete;
explicit error_t(string, double, string) = delete;
explicit error_t(string, float) = delete;
explicit error_t(string, float, string) = delete;
explicit error_t(string, int) = delete;
explicit error_t(string, int, string) = delete;
explicit error_t(string, long double) = delete;
explicit error_t(string, long double, string) = delete;
explicit error_t(string, long long) = delete;
explicit error_t(string, long long, string) = delete;
explicit error_t(string, short) = delete;
explicit error_t(string, short, string) = delete;
explicit error_t(string, signed char) = delete;
explicit error_t(string, signed char, string) = delete;
#ifdef __SIZEOF_INT128__
explicit error_t(string, unsigned __int128) = delete;
#endif
#ifdef __SIZEOF_INT128__
explicit error_t(string, unsigned __int128, string) = delete;
#endif
explicit error_t(string, unsigned char) = delete;
explicit error_t(string, unsigned char, string) = delete;
explicit error_t(string, unsigned int) = delete;
explicit error_t(string, unsigned int, string) = delete;
explicit error_t(string, unsigned long) = delete;
explicit error_t(string, unsigned long long) = delete;
explicit error_t(string, unsigned long long, string) = delete;
explicit error_t(string, unsigned long, string) = delete;
explicit error_t(string, unsigned short) = delete;
explicit error_t(string, unsigned short, string) = delete;
explicit error_t(string, const void*) = delete;
explicit error_t(string, const void*, string) = delete;
explicit error_t(string, wchar_t) = delete;
explicit error_t(string, wchar_t, string) = delete;
private:
    bool present_ = false;
    string message_;
    int64 line_{};
    string file_;
};
class nullable_bool_t final {
public:
    nullable_bool_t() noexcept = default;
    ~nullable_bool_t();
    nullable_bool_t(const nullable_bool_t&);
    nullable_bool_t(nullable_bool_t&&) noexcept;
    nullable_bool_t& operator=(const nullable_bool_t&);
    nullable_bool_t& operator=(nullable_bool_t&&) noexcept;
    explicit nullable_bool_t(bool_t value);
    bool_t has_value() const noexcept;
    bool_t value() const;
    operator bool_t() const;
#ifdef __SIZEOF_INT128__
explicit nullable_bool_t(__int128) = delete;
#endif
explicit nullable_bool_t(char) = delete;
explicit nullable_bool_t(char16_t) = delete;
explicit nullable_bool_t(char32_t) = delete;
explicit nullable_bool_t(char8_t) = delete;
explicit nullable_bool_t(double) = delete;
explicit nullable_bool_t(float) = delete;
explicit nullable_bool_t(int) = delete;
explicit nullable_bool_t(long) = delete;
explicit nullable_bool_t(long double) = delete;
explicit nullable_bool_t(long long) = delete;
explicit nullable_bool_t(short) = delete;
explicit nullable_bool_t(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit nullable_bool_t(unsigned __int128) = delete;
#endif
explicit nullable_bool_t(unsigned char) = delete;
explicit nullable_bool_t(unsigned int) = delete;
explicit nullable_bool_t(unsigned long) = delete;
explicit nullable_bool_t(unsigned long long) = delete;
explicit nullable_bool_t(unsigned short) = delete;
explicit nullable_bool_t(const void*) = delete;
explicit nullable_bool_t(wchar_t) = delete;
    explicit nullable_bool_t(null_t) noexcept;
    void reset() noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class nullable_int64 final {
public:
    nullable_int64() noexcept = default;
    ~nullable_int64();
    nullable_int64(const nullable_int64&);
    nullable_int64(nullable_int64&&) noexcept;
    nullable_int64& operator=(const nullable_int64&);
    nullable_int64& operator=(nullable_int64&&) noexcept;
    explicit nullable_int64(int64 value);
    bool_t has_value() const noexcept;
    int64 value() const;
    operator int64() const;
#ifdef __SIZEOF_INT128__
explicit nullable_int64(__int128) = delete;
#endif
explicit nullable_int64(bool) = delete;
explicit nullable_int64(char) = delete;
explicit nullable_int64(char16_t) = delete;
explicit nullable_int64(char32_t) = delete;
explicit nullable_int64(char8_t) = delete;
explicit nullable_int64(double) = delete;
explicit nullable_int64(float) = delete;
explicit nullable_int64(int) = delete;
explicit nullable_int64(long double) = delete;
explicit nullable_int64(long long) = delete;
explicit nullable_int64(short) = delete;
explicit nullable_int64(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit nullable_int64(unsigned __int128) = delete;
#endif
explicit nullable_int64(unsigned char) = delete;
explicit nullable_int64(unsigned int) = delete;
explicit nullable_int64(unsigned long) = delete;
explicit nullable_int64(unsigned long long) = delete;
explicit nullable_int64(unsigned short) = delete;
explicit nullable_int64(const void*) = delete;
explicit nullable_int64(wchar_t) = delete;
    explicit nullable_int64(null_t) noexcept;
    void reset() noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class nullable_string final {
public:
    nullable_string() noexcept = default;
    ~nullable_string();
    nullable_string(const nullable_string&);
    nullable_string(nullable_string&&) noexcept;
    nullable_string& operator=(const nullable_string&);
    nullable_string& operator=(nullable_string&&) noexcept;
    explicit nullable_string(string value);
    bool_t has_value() const noexcept;
    string value() const;
    operator string() const;
explicit nullable_string(const void*) = delete;
    explicit nullable_string(null_t) noexcept;
    void reset() noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class nullable_vector_string final {
public:
    nullable_vector_string() noexcept = default;
    ~nullable_vector_string();
    nullable_vector_string(const nullable_vector_string&);
    nullable_vector_string(nullable_vector_string&&) noexcept;
    nullable_vector_string& operator=(const nullable_vector_string&);
    nullable_vector_string& operator=(nullable_vector_string&&) noexcept;
    explicit nullable_vector_string(vector_string value);
    bool_t has_value() const noexcept;
    vector_string value() const;
    operator vector_string() const;
explicit nullable_vector_string(const void*) = delete;
    explicit nullable_vector_string(null_t) noexcept;
    void reset() noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_bool_t final {
public:
    result_bool_t() noexcept = default;
    ~result_bool_t();
    result_bool_t(const result_bool_t&);
    result_bool_t(result_bool_t&&) noexcept;
    result_bool_t& operator=(const result_bool_t&);
    result_bool_t& operator=(result_bool_t&&) noexcept;
    explicit result_bool_t(bool_t value);
    bool_t has_value() const noexcept;
    bool_t value() const;
    operator bool_t() const;
#ifdef __SIZEOF_INT128__
explicit result_bool_t(__int128) = delete;
#endif
explicit result_bool_t(char) = delete;
explicit result_bool_t(char16_t) = delete;
explicit result_bool_t(char32_t) = delete;
explicit result_bool_t(char8_t) = delete;
explicit result_bool_t(decltype(nullptr)) = delete;
explicit result_bool_t(double) = delete;
explicit result_bool_t(float) = delete;
explicit result_bool_t(int) = delete;
explicit result_bool_t(long) = delete;
explicit result_bool_t(long double) = delete;
explicit result_bool_t(long long) = delete;
explicit result_bool_t(short) = delete;
explicit result_bool_t(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_bool_t(unsigned __int128) = delete;
#endif
explicit result_bool_t(unsigned char) = delete;
explicit result_bool_t(unsigned int) = delete;
explicit result_bool_t(unsigned long) = delete;
explicit result_bool_t(unsigned long long) = delete;
explicit result_bool_t(unsigned short) = delete;
explicit result_bool_t(const void*) = delete;
explicit result_bool_t(wchar_t) = delete;
    explicit result_bool_t(error_t error);
    bool_t has_error() const noexcept;
    error_t error() const;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_int64 final {
public:
    result_int64() noexcept = default;
    ~result_int64();
    result_int64(const result_int64&);
    result_int64(result_int64&&) noexcept;
    result_int64& operator=(const result_int64&);
    result_int64& operator=(result_int64&&) noexcept;
    explicit result_int64(int64 value);
    bool_t has_value() const noexcept;
    int64 value() const;
    operator int64() const;
#ifdef __SIZEOF_INT128__
explicit result_int64(__int128) = delete;
#endif
explicit result_int64(bool) = delete;
explicit result_int64(char) = delete;
explicit result_int64(char16_t) = delete;
explicit result_int64(char32_t) = delete;
explicit result_int64(char8_t) = delete;
explicit result_int64(decltype(nullptr)) = delete;
explicit result_int64(double) = delete;
explicit result_int64(float) = delete;
explicit result_int64(int) = delete;
explicit result_int64(long double) = delete;
explicit result_int64(long long) = delete;
explicit result_int64(short) = delete;
explicit result_int64(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_int64(unsigned __int128) = delete;
#endif
explicit result_int64(unsigned char) = delete;
explicit result_int64(unsigned int) = delete;
explicit result_int64(unsigned long) = delete;
explicit result_int64(unsigned long long) = delete;
explicit result_int64(unsigned short) = delete;
explicit result_int64(const void*) = delete;
explicit result_int64(wchar_t) = delete;
    explicit result_int64(error_t error);
    bool_t has_error() const noexcept;
    error_t error() const;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_bool_bool_t final {
public:
    result_or_bool_bool_t() noexcept = default;
    ~result_or_bool_bool_t();
    result_or_bool_bool_t(const result_or_bool_bool_t&);
    result_or_bool_bool_t(result_or_bool_bool_t&&) noexcept;
    result_or_bool_bool_t& operator=(const result_or_bool_bool_t&);
    result_or_bool_bool_t& operator=(result_or_bool_bool_t&&) noexcept;
    explicit result_or_bool_bool_t(bool_t value);
    bool_t has_value() const noexcept;
    bool_t value() const;
    operator bool_t() const;
#ifdef __SIZEOF_INT128__
explicit result_or_bool_bool_t(__int128) = delete;
#endif
explicit result_or_bool_bool_t(char) = delete;
explicit result_or_bool_bool_t(char16_t) = delete;
explicit result_or_bool_bool_t(char32_t) = delete;
explicit result_or_bool_bool_t(char8_t) = delete;
explicit result_or_bool_bool_t(decltype(nullptr)) = delete;
explicit result_or_bool_bool_t(double) = delete;
explicit result_or_bool_bool_t(float) = delete;
explicit result_or_bool_bool_t(int) = delete;
explicit result_or_bool_bool_t(long) = delete;
explicit result_or_bool_bool_t(long double) = delete;
explicit result_or_bool_bool_t(long long) = delete;
explicit result_or_bool_bool_t(short) = delete;
explicit result_or_bool_bool_t(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_or_bool_bool_t(unsigned __int128) = delete;
#endif
explicit result_or_bool_bool_t(unsigned char) = delete;
explicit result_or_bool_bool_t(unsigned int) = delete;
explicit result_or_bool_bool_t(unsigned long) = delete;
explicit result_or_bool_bool_t(unsigned long long) = delete;
explicit result_or_bool_bool_t(unsigned short) = delete;
explicit result_or_bool_bool_t(const void*) = delete;
explicit result_or_bool_bool_t(wchar_t) = delete;
    void reset() noexcept;
    static result_or_bool_bool_t from_false() noexcept;
    bool_t is_false() const noexcept;
    static result_or_bool_bool_t from_true();
    bool_t is_true() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_bool_int64 final {
public:
    result_or_bool_int64() noexcept = default;
    ~result_or_bool_int64();
    result_or_bool_int64(const result_or_bool_int64&);
    result_or_bool_int64(result_or_bool_int64&&) noexcept;
    result_or_bool_int64& operator=(const result_or_bool_int64&);
    result_or_bool_int64& operator=(result_or_bool_int64&&) noexcept;
    explicit result_or_bool_int64(int64 value);
    bool_t has_value() const noexcept;
    int64 value() const;
    operator int64() const;
#ifdef __SIZEOF_INT128__
explicit result_or_bool_int64(__int128) = delete;
#endif
explicit result_or_bool_int64(bool) = delete;
explicit result_or_bool_int64(char) = delete;
explicit result_or_bool_int64(char16_t) = delete;
explicit result_or_bool_int64(char32_t) = delete;
explicit result_or_bool_int64(char8_t) = delete;
explicit result_or_bool_int64(decltype(nullptr)) = delete;
explicit result_or_bool_int64(double) = delete;
explicit result_or_bool_int64(float) = delete;
explicit result_or_bool_int64(int) = delete;
explicit result_or_bool_int64(long double) = delete;
explicit result_or_bool_int64(long long) = delete;
explicit result_or_bool_int64(short) = delete;
explicit result_or_bool_int64(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_or_bool_int64(unsigned __int128) = delete;
#endif
explicit result_or_bool_int64(unsigned char) = delete;
explicit result_or_bool_int64(unsigned int) = delete;
explicit result_or_bool_int64(unsigned long) = delete;
explicit result_or_bool_int64(unsigned long long) = delete;
explicit result_or_bool_int64(unsigned short) = delete;
explicit result_or_bool_int64(const void*) = delete;
explicit result_or_bool_int64(wchar_t) = delete;
    void reset() noexcept;
    static result_or_bool_int64 from_false() noexcept;
    bool_t is_false() const noexcept;
    static result_or_bool_int64 from_true();
    bool_t is_true() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_bool_string final {
public:
    result_or_bool_string() noexcept = default;
    ~result_or_bool_string();
    result_or_bool_string(const result_or_bool_string&);
    result_or_bool_string(result_or_bool_string&&) noexcept;
    result_or_bool_string& operator=(const result_or_bool_string&);
    result_or_bool_string& operator=(result_or_bool_string&&) noexcept;
    explicit result_or_bool_string(string value);
    bool_t has_value() const noexcept;
    string value() const;
    operator string() const;
    void reset() noexcept;
    static result_or_bool_string from_false() noexcept;
    bool_t is_false() const noexcept;
    static result_or_bool_string from_true();
    bool_t is_true() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_bool_vector_string final {
public:
    result_or_bool_vector_string() noexcept = default;
    ~result_or_bool_vector_string();
    result_or_bool_vector_string(const result_or_bool_vector_string&);
    result_or_bool_vector_string(result_or_bool_vector_string&&) noexcept;
    result_or_bool_vector_string& operator=(const result_or_bool_vector_string&);
    result_or_bool_vector_string& operator=(result_or_bool_vector_string&&) noexcept;
    explicit result_or_bool_vector_string(vector_string value);
    bool_t has_value() const noexcept;
    vector_string value() const;
    operator vector_string() const;
    void reset() noexcept;
    static result_or_bool_vector_string from_false() noexcept;
    bool_t is_false() const noexcept;
    static result_or_bool_vector_string from_true();
    bool_t is_true() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_false_bool_t final {
public:
    result_or_false_bool_t() noexcept = default;
    ~result_or_false_bool_t();
    result_or_false_bool_t(const result_or_false_bool_t&);
    result_or_false_bool_t(result_or_false_bool_t&&) noexcept;
    result_or_false_bool_t& operator=(const result_or_false_bool_t&);
    result_or_false_bool_t& operator=(result_or_false_bool_t&&) noexcept;
    explicit result_or_false_bool_t(bool_t value);
    bool_t has_value() const noexcept;
    bool_t value() const;
    operator bool_t() const;
#ifdef __SIZEOF_INT128__
explicit result_or_false_bool_t(__int128) = delete;
#endif
explicit result_or_false_bool_t(char) = delete;
explicit result_or_false_bool_t(char16_t) = delete;
explicit result_or_false_bool_t(char32_t) = delete;
explicit result_or_false_bool_t(char8_t) = delete;
explicit result_or_false_bool_t(decltype(nullptr)) = delete;
explicit result_or_false_bool_t(double) = delete;
explicit result_or_false_bool_t(float) = delete;
explicit result_or_false_bool_t(int) = delete;
explicit result_or_false_bool_t(long) = delete;
explicit result_or_false_bool_t(long double) = delete;
explicit result_or_false_bool_t(long long) = delete;
explicit result_or_false_bool_t(short) = delete;
explicit result_or_false_bool_t(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_or_false_bool_t(unsigned __int128) = delete;
#endif
explicit result_or_false_bool_t(unsigned char) = delete;
explicit result_or_false_bool_t(unsigned int) = delete;
explicit result_or_false_bool_t(unsigned long) = delete;
explicit result_or_false_bool_t(unsigned long long) = delete;
explicit result_or_false_bool_t(unsigned short) = delete;
explicit result_or_false_bool_t(const void*) = delete;
explicit result_or_false_bool_t(wchar_t) = delete;
    void reset() noexcept;
    static result_or_false_bool_t from_false() noexcept;
    bool_t is_false() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_false_int64 final {
public:
    result_or_false_int64() noexcept = default;
    ~result_or_false_int64();
    result_or_false_int64(const result_or_false_int64&);
    result_or_false_int64(result_or_false_int64&&) noexcept;
    result_or_false_int64& operator=(const result_or_false_int64&);
    result_or_false_int64& operator=(result_or_false_int64&&) noexcept;
    explicit result_or_false_int64(int64 value);
    bool_t has_value() const noexcept;
    int64 value() const;
    operator int64() const;
#ifdef __SIZEOF_INT128__
explicit result_or_false_int64(__int128) = delete;
#endif
explicit result_or_false_int64(bool) = delete;
explicit result_or_false_int64(char) = delete;
explicit result_or_false_int64(char16_t) = delete;
explicit result_or_false_int64(char32_t) = delete;
explicit result_or_false_int64(char8_t) = delete;
explicit result_or_false_int64(decltype(nullptr)) = delete;
explicit result_or_false_int64(double) = delete;
explicit result_or_false_int64(float) = delete;
explicit result_or_false_int64(int) = delete;
explicit result_or_false_int64(long double) = delete;
explicit result_or_false_int64(long long) = delete;
explicit result_or_false_int64(short) = delete;
explicit result_or_false_int64(signed char) = delete;
#ifdef __SIZEOF_INT128__
explicit result_or_false_int64(unsigned __int128) = delete;
#endif
explicit result_or_false_int64(unsigned char) = delete;
explicit result_or_false_int64(unsigned int) = delete;
explicit result_or_false_int64(unsigned long) = delete;
explicit result_or_false_int64(unsigned long long) = delete;
explicit result_or_false_int64(unsigned short) = delete;
explicit result_or_false_int64(const void*) = delete;
explicit result_or_false_int64(wchar_t) = delete;
    void reset() noexcept;
    static result_or_false_int64 from_false() noexcept;
    bool_t is_false() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_false_string final {
public:
    result_or_false_string() noexcept = default;
    ~result_or_false_string();
    result_or_false_string(const result_or_false_string&);
    result_or_false_string(result_or_false_string&&) noexcept;
    result_or_false_string& operator=(const result_or_false_string&);
    result_or_false_string& operator=(result_or_false_string&&) noexcept;
    explicit result_or_false_string(string value);
    bool_t has_value() const noexcept;
    string value() const;
    operator string() const;
    void reset() noexcept;
    static result_or_false_string from_false() noexcept;
    bool_t is_false() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_or_false_vector_string final {
public:
    result_or_false_vector_string() noexcept = default;
    ~result_or_false_vector_string();
    result_or_false_vector_string(const result_or_false_vector_string&);
    result_or_false_vector_string(result_or_false_vector_string&&) noexcept;
    result_or_false_vector_string& operator=(const result_or_false_vector_string&);
    result_or_false_vector_string& operator=(result_or_false_vector_string&&) noexcept;
    explicit result_or_false_vector_string(vector_string value);
    bool_t has_value() const noexcept;
    vector_string value() const;
    operator vector_string() const;
    void reset() noexcept;
    static result_or_false_vector_string from_false() noexcept;
    bool_t is_false() const noexcept;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_string final {
public:
    result_string() noexcept = default;
    ~result_string();
    result_string(const result_string&);
    result_string(result_string&&) noexcept;
    result_string& operator=(const result_string&);
    result_string& operator=(result_string&&) noexcept;
    explicit result_string(string value);
    bool_t has_value() const noexcept;
    string value() const;
    operator string() const;
    explicit result_string(error_t error);
    bool_t has_error() const noexcept;
    error_t error() const;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class result_vector_string final {
public:
    result_vector_string() noexcept = default;
    ~result_vector_string();
    result_vector_string(const result_vector_string&);
    result_vector_string(result_vector_string&&) noexcept;
    result_vector_string& operator=(const result_vector_string&);
    result_vector_string& operator=(result_vector_string&&) noexcept;
    explicit result_vector_string(vector_string value);
    bool_t has_value() const noexcept;
    vector_string value() const;
    operator vector_string() const;
    explicit result_vector_string(error_t error);
    bool_t has_error() const noexcept;
    error_t error() const;
private:
    struct storage;
    storage* storage_ = nullptr;
};
}
