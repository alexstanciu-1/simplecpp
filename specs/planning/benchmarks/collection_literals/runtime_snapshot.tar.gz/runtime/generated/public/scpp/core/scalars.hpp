// Generated from reviewed runtime metadata. Do not edit.
#pragma once
namespace scpp {
using uint8 = __UINT8_TYPE__;
using int64 = __INT64_TYPE__;
using bool_t = bool;
using float64 = double;
using null_t = decltype(nullptr);
inline constexpr null_t null = nullptr;
using byte = uint8;
using float_t = float64;
using int_t = int64;
}
namespace scpp::types {
using ::scpp::uint8;
using ::scpp::int64;
using ::scpp::bool_t;
using ::scpp::float64;
using ::scpp::null_t;
using ::scpp::byte;
using ::scpp::float_t;
using ::scpp::int_t;
}
