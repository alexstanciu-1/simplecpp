// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/carriers.hpp"
#include "scpp/core/scalars.hpp"
#include "scpp/string.hpp"
namespace scpp {
class hash_int64_int64 final {
public:
    hash_int64_int64() noexcept = default;
    ~hash_int64_int64();
    hash_int64_int64(const hash_int64_int64&);
    hash_int64_int64(hash_int64_int64&&) noexcept;
    hash_int64_int64& operator=(const hash_int64_int64&);
    hash_int64_int64& operator=(hash_int64_int64&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    bool_t has(const int64& key) const;
    int64 at(const int64& key) const;
    void set(int64 key, int64 value);
    bool_t remove(const int64& key);
    void clear() noexcept;
    nullable_int64 find(const int64& key) const;
    // Compiler traversal API: physical positions, not live entry count.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, int64& value) const;
    bool_t iteration_next(int64& position, int64 limit, int64& key, int64& value) const;
#ifdef __SIZEOF_INT128__
void has(__int128) const = delete;
#endif
void has(bool) const = delete;
void has(char) const = delete;
void has(char16_t) const = delete;
void has(char32_t) const = delete;
void has(char8_t) const = delete;
void has(decltype(nullptr)) const = delete;
void has(double) const = delete;
void has(float) const = delete;
void has(int) const = delete;
void has(long double) const = delete;
void has(long long) const = delete;
void has(short) const = delete;
void has(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void has(unsigned __int128) const = delete;
#endif
void has(unsigned char) const = delete;
void has(unsigned int) const = delete;
void has(unsigned long) const = delete;
void has(unsigned long long) const = delete;
void has(unsigned short) const = delete;
void has(const void*) const = delete;
void has(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void at(__int128) const = delete;
#endif
void at(bool) const = delete;
void at(char) const = delete;
void at(char16_t) const = delete;
void at(char32_t) const = delete;
void at(char8_t) const = delete;
void at(decltype(nullptr)) const = delete;
void at(double) const = delete;
void at(float) const = delete;
void at(int) const = delete;
void at(long double) const = delete;
void at(long long) const = delete;
void at(short) const = delete;
void at(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void at(unsigned __int128) const = delete;
#endif
void at(unsigned char) const = delete;
void at(unsigned int) const = delete;
void at(unsigned long) const = delete;
void at(unsigned long long) const = delete;
void at(unsigned short) const = delete;
void at(const void*) const = delete;
void at(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void find(__int128) const = delete;
#endif
void find(bool) const = delete;
void find(char) const = delete;
void find(char16_t) const = delete;
void find(char32_t) const = delete;
void find(char8_t) const = delete;
void find(decltype(nullptr)) const = delete;
void find(double) const = delete;
void find(float) const = delete;
void find(int) const = delete;
void find(long double) const = delete;
void find(long long) const = delete;
void find(short) const = delete;
void find(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void find(unsigned __int128) const = delete;
#endif
void find(unsigned char) const = delete;
void find(unsigned int) const = delete;
void find(unsigned long) const = delete;
void find(unsigned long long) const = delete;
void find(unsigned short) const = delete;
void find(const void*) const = delete;
void find(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void remove(__int128) = delete;
#endif
void remove(bool) = delete;
void remove(char) = delete;
void remove(char16_t) = delete;
void remove(char32_t) = delete;
void remove(char8_t) = delete;
void remove(decltype(nullptr)) = delete;
void remove(double) = delete;
void remove(float) = delete;
void remove(int) = delete;
void remove(long double) = delete;
void remove(long long) = delete;
void remove(short) = delete;
void remove(signed char) = delete;
#ifdef __SIZEOF_INT128__
void remove(unsigned __int128) = delete;
#endif
void remove(unsigned char) = delete;
void remove(unsigned int) = delete;
void remove(unsigned long) = delete;
void remove(unsigned long long) = delete;
void remove(unsigned short) = delete;
void remove(const void*) = delete;
void remove(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void set(__int128, int64) = delete;
#endif
void set(bool, int64) = delete;
void set(char, int64) = delete;
void set(char16_t, int64) = delete;
void set(char32_t, int64) = delete;
void set(char8_t, int64) = delete;
void set(decltype(nullptr), int64) = delete;
void set(double, int64) = delete;
void set(float, int64) = delete;
void set(int, int64) = delete;
void set(long double, int64) = delete;
void set(long long, int64) = delete;
#ifdef __SIZEOF_INT128__
void set(int64, __int128) = delete;
#endif
void set(int64, bool) = delete;
void set(int64, char) = delete;
void set(int64, char16_t) = delete;
void set(int64, char32_t) = delete;
void set(int64, char8_t) = delete;
void set(int64, decltype(nullptr)) = delete;
void set(int64, double) = delete;
void set(int64, float) = delete;
void set(int64, int) = delete;
void set(int64, long double) = delete;
void set(int64, long long) = delete;
void set(int64, short) = delete;
void set(int64, signed char) = delete;
#ifdef __SIZEOF_INT128__
void set(int64, unsigned __int128) = delete;
#endif
void set(int64, unsigned char) = delete;
void set(int64, unsigned int) = delete;
void set(int64, unsigned long) = delete;
void set(int64, unsigned long long) = delete;
void set(int64, unsigned short) = delete;
void set(int64, const void*) = delete;
void set(int64, wchar_t) = delete;
void set(short, int64) = delete;
void set(signed char, int64) = delete;
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, int64) = delete;
#endif
void set(unsigned char, int64) = delete;
void set(unsigned int, int64) = delete;
void set(unsigned long long, int64) = delete;
void set(unsigned long, int64) = delete;
void set(unsigned short, int64) = delete;
void set(const void*, int64) = delete;
void set(wchar_t, int64) = delete;
    int64 append(int64 value);
#ifdef __SIZEOF_INT128__
void append(__int128) = delete;
#endif
void append(bool) = delete;
void append(char) = delete;
void append(char16_t) = delete;
void append(char32_t) = delete;
void append(char8_t) = delete;
void append(decltype(nullptr)) = delete;
void append(double) = delete;
void append(float) = delete;
void append(int) = delete;
void append(long double) = delete;
void append(long long) = delete;
void append(short) = delete;
void append(signed char) = delete;
#ifdef __SIZEOF_INT128__
void append(unsigned __int128) = delete;
#endif
void append(unsigned char) = delete;
void append(unsigned int) = delete;
void append(unsigned long) = delete;
void append(unsigned long long) = delete;
void append(unsigned short) = delete;
void append(const void*) = delete;
void append(wchar_t) = delete;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class hash_int64_string final {
public:
    hash_int64_string() noexcept = default;
    ~hash_int64_string();
    hash_int64_string(const hash_int64_string&);
    hash_int64_string(hash_int64_string&&) noexcept;
    hash_int64_string& operator=(const hash_int64_string&);
    hash_int64_string& operator=(hash_int64_string&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    bool_t has(const string& key) const;
    int64 at(const string& key) const;
    void set(string key, int64 value);
    bool_t remove(const string& key);
    void clear() noexcept;
    nullable_int64 find(const string& key) const;
    // Compiler traversal API: physical positions, not live entry count.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, int64& value) const;
    bool_t iteration_next(int64& position, int64 limit, string& key, int64& value) const;
#ifdef __SIZEOF_INT128__
void set(string, __int128) = delete;
#endif
void set(string, bool) = delete;
void set(string, char) = delete;
void set(string, char16_t) = delete;
void set(string, char32_t) = delete;
void set(string, char8_t) = delete;
void set(string, decltype(nullptr)) = delete;
void set(string, double) = delete;
void set(string, float) = delete;
void set(string, int) = delete;
void set(string, long double) = delete;
void set(string, long long) = delete;
void set(string, short) = delete;
void set(string, signed char) = delete;
#ifdef __SIZEOF_INT128__
void set(string, unsigned __int128) = delete;
#endif
void set(string, unsigned char) = delete;
void set(string, unsigned int) = delete;
void set(string, unsigned long) = delete;
void set(string, unsigned long long) = delete;
void set(string, unsigned short) = delete;
void set(string, const void*) = delete;
void set(string, wchar_t) = delete;
private:
    struct storage;
    storage* storage_ = nullptr;
};
class hash_string_int64 final {
public:
    hash_string_int64() noexcept = default;
    ~hash_string_int64();
    hash_string_int64(const hash_string_int64&);
    hash_string_int64(hash_string_int64&&) noexcept;
    hash_string_int64& operator=(const hash_string_int64&);
    hash_string_int64& operator=(hash_string_int64&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    bool_t has(const int64& key) const;
    string at(const int64& key) const;
    void set(int64 key, string value);
    bool_t remove(const int64& key);
    void clear() noexcept;
    nullable_string find(const int64& key) const;
    // Compiler traversal API: physical positions, not live entry count.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, string& value) const;
    bool_t iteration_next(int64& position, int64 limit, int64& key, string& value) const;
#ifdef __SIZEOF_INT128__
void has(__int128) const = delete;
#endif
void has(bool) const = delete;
void has(char) const = delete;
void has(char16_t) const = delete;
void has(char32_t) const = delete;
void has(char8_t) const = delete;
void has(decltype(nullptr)) const = delete;
void has(double) const = delete;
void has(float) const = delete;
void has(int) const = delete;
void has(long double) const = delete;
void has(long long) const = delete;
void has(short) const = delete;
void has(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void has(unsigned __int128) const = delete;
#endif
void has(unsigned char) const = delete;
void has(unsigned int) const = delete;
void has(unsigned long) const = delete;
void has(unsigned long long) const = delete;
void has(unsigned short) const = delete;
void has(const void*) const = delete;
void has(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void at(__int128) const = delete;
#endif
void at(bool) const = delete;
void at(char) const = delete;
void at(char16_t) const = delete;
void at(char32_t) const = delete;
void at(char8_t) const = delete;
void at(decltype(nullptr)) const = delete;
void at(double) const = delete;
void at(float) const = delete;
void at(int) const = delete;
void at(long double) const = delete;
void at(long long) const = delete;
void at(short) const = delete;
void at(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void at(unsigned __int128) const = delete;
#endif
void at(unsigned char) const = delete;
void at(unsigned int) const = delete;
void at(unsigned long) const = delete;
void at(unsigned long long) const = delete;
void at(unsigned short) const = delete;
void at(const void*) const = delete;
void at(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void find(__int128) const = delete;
#endif
void find(bool) const = delete;
void find(char) const = delete;
void find(char16_t) const = delete;
void find(char32_t) const = delete;
void find(char8_t) const = delete;
void find(decltype(nullptr)) const = delete;
void find(double) const = delete;
void find(float) const = delete;
void find(int) const = delete;
void find(long double) const = delete;
void find(long long) const = delete;
void find(short) const = delete;
void find(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void find(unsigned __int128) const = delete;
#endif
void find(unsigned char) const = delete;
void find(unsigned int) const = delete;
void find(unsigned long) const = delete;
void find(unsigned long long) const = delete;
void find(unsigned short) const = delete;
void find(const void*) const = delete;
void find(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void remove(__int128) = delete;
#endif
void remove(bool) = delete;
void remove(char) = delete;
void remove(char16_t) = delete;
void remove(char32_t) = delete;
void remove(char8_t) = delete;
void remove(decltype(nullptr)) = delete;
void remove(double) = delete;
void remove(float) = delete;
void remove(int) = delete;
void remove(long double) = delete;
void remove(long long) = delete;
void remove(short) = delete;
void remove(signed char) = delete;
#ifdef __SIZEOF_INT128__
void remove(unsigned __int128) = delete;
#endif
void remove(unsigned char) = delete;
void remove(unsigned int) = delete;
void remove(unsigned long) = delete;
void remove(unsigned long long) = delete;
void remove(unsigned short) = delete;
void remove(const void*) = delete;
void remove(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void set(__int128, string) = delete;
#endif
void set(bool, string) = delete;
void set(char, string) = delete;
void set(char16_t, string) = delete;
void set(char32_t, string) = delete;
void set(char8_t, string) = delete;
void set(decltype(nullptr), string) = delete;
void set(double, string) = delete;
void set(float, string) = delete;
void set(int, string) = delete;
void set(long double, string) = delete;
void set(long long, string) = delete;
void set(short, string) = delete;
void set(signed char, string) = delete;
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, string) = delete;
#endif
void set(unsigned char, string) = delete;
void set(unsigned int, string) = delete;
void set(unsigned long long, string) = delete;
void set(unsigned long, string) = delete;
void set(unsigned short, string) = delete;
void set(const void*, string) = delete;
void set(wchar_t, string) = delete;
    int64 append(string value);
private:
    struct storage;
    storage* storage_ = nullptr;
};
class hash_string_string final {
public:
    hash_string_string() noexcept = default;
    ~hash_string_string();
    hash_string_string(const hash_string_string&);
    hash_string_string(hash_string_string&&) noexcept;
    hash_string_string& operator=(const hash_string_string&);
    hash_string_string& operator=(hash_string_string&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    bool_t has(const string& key) const;
    string at(const string& key) const;
    void set(string key, string value);
    bool_t remove(const string& key);
    void clear() noexcept;
    nullable_string find(const string& key) const;
    // Compiler traversal API: physical positions, not live entry count.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, string& value) const;
    bool_t iteration_next(int64& position, int64 limit, string& key, string& value) const;
private:
    struct storage;
    storage* storage_ = nullptr;
};
}
