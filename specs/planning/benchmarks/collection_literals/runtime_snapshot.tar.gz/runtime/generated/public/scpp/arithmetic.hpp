// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include <stdint.h>

namespace scpp {
// Native int64 arithmetic with existing zero-divisor errors; signed overflow is not checked.
::int64_t int64_divide(::int64_t left, ::int64_t right);
::int64_t int64_remainder(::int64_t left, ::int64_t right);
// Unsigned narrow results preserve their representation; zero divisors are rejected.
::uint8_t uint8_divide(::uint8_t left, ::uint8_t right);
::uint8_t uint8_remainder(::uint8_t left, ::uint8_t right);
// Checked counts use the declared left width; the active integer count domains fit int64.
::int64_t int64_shift_left(::int64_t left, ::int64_t count);
::int64_t int64_shift_right(::int64_t left, ::int64_t count);
::uint8_t uint8_shift_left(::uint8_t left, ::int64_t count);
::uint8_t uint8_shift_right(::uint8_t left, ::int64_t count);
__INT16_TYPE__ int16_divide(__INT16_TYPE__ left, __INT16_TYPE__ right);
__INT16_TYPE__ int16_remainder(__INT16_TYPE__ left, __INT16_TYPE__ right);
__INT16_TYPE__ int16_shift_left(__INT16_TYPE__ left, ::int64_t right);
__INT16_TYPE__ int16_shift_right(__INT16_TYPE__ left, ::int64_t right);
__INT32_TYPE__ int32_divide(__INT32_TYPE__ left, __INT32_TYPE__ right);
__INT32_TYPE__ int32_remainder(__INT32_TYPE__ left, __INT32_TYPE__ right);
__INT32_TYPE__ int32_shift_left(__INT32_TYPE__ left, ::int64_t right);
__INT32_TYPE__ int32_shift_right(__INT32_TYPE__ left, ::int64_t right);
__INT8_TYPE__ int8_divide(__INT8_TYPE__ left, __INT8_TYPE__ right);
__INT8_TYPE__ int8_remainder(__INT8_TYPE__ left, __INT8_TYPE__ right);
__INT8_TYPE__ int8_shift_left(__INT8_TYPE__ left, ::int64_t right);
__INT8_TYPE__ int8_shift_right(__INT8_TYPE__ left, ::int64_t right);
__UINT16_TYPE__ uint16_divide(__UINT16_TYPE__ left, __UINT16_TYPE__ right);
__UINT16_TYPE__ uint16_remainder(__UINT16_TYPE__ left, __UINT16_TYPE__ right);
__UINT16_TYPE__ uint16_shift_left(__UINT16_TYPE__ left, ::int64_t right);
__UINT16_TYPE__ uint16_shift_right(__UINT16_TYPE__ left, ::int64_t right);
__UINT32_TYPE__ uint32_divide(__UINT32_TYPE__ left, __UINT32_TYPE__ right);
__UINT32_TYPE__ uint32_remainder(__UINT32_TYPE__ left, __UINT32_TYPE__ right);
__UINT32_TYPE__ uint32_shift_left(__UINT32_TYPE__ left, ::int64_t right);
__UINT32_TYPE__ uint32_shift_right(__UINT32_TYPE__ left, ::int64_t right);
// Binary64 division rejects both signs of zero; other results follow native IEEE arithmetic.
double float64_divide(double left, double right);
// Three-way floating comparison rejects unordered NaN operands.
::int64_t float64_compare(double left, double right);
// Exact signed integer power; negative exponents and out-of-range results throw.
::int64_t int64_power(::int64_t left, ::int64_t right);
}
