// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/vectors.hpp"
namespace scpp::php {
inline ::scpp::vector_string explode(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::split(arg1, arg0); }
}
namespace scpp::php {
inline ::scpp::vector_string explode(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::split(arg1, arg0, arg2, ::scpp::str::split_policy::remainder); }
}
namespace scpp::php {
inline ::scpp::string implode(const ::scpp::string& arg0, const ::scpp::vector_string& arg1) { return ::scpp::str::join(arg1, arg0); }
}
