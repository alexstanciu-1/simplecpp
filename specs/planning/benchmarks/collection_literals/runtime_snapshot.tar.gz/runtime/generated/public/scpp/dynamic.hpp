// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/core/scalars.hpp"
#include "scpp/string.hpp"
#include "scpp/boxed_key.hpp"
#include "scpp/boxed_kind.hpp"
namespace scpp { namespace detail { struct ownership_access; } 
class dynamic final {
public:
    dynamic() noexcept;
    ~dynamic() noexcept;
    dynamic(const dynamic&) noexcept;
    dynamic(dynamic&&) noexcept;
    dynamic& operator=(const dynamic&) noexcept;
    dynamic& operator=(dynamic&&) noexcept;
    static dynamic from_boolean(bool_t value) noexcept;
    static dynamic from_integer(int64 value) noexcept;
    static dynamic from_floating(float64 value) noexcept;
    static dynamic from_string(const string& value);
    static dynamic container();
    boxed_kind kind() const noexcept;
    bool_t get_boolean() const;
    int64 get_integer() const;
    float64 get_floating() const;
    string get_string() const;
    dynamic read(const int64& key) const;
    dynamic read(const string& key) const;
    bool_t has(const int64& key) const;
    bool_t has(const string& key) const;
    void set(int64 key, dynamic value);
    void set(const string& key, dynamic value);
    bool_t remove(const int64& key);
    bool_t remove(const string& key);
    int64 append(dynamic value);
    int64 container_size() const;
    bool_t is_packed_container() const;
    void clean() noexcept;
    // Compiler traversal API; key_index == -1 selects key_text. No table owner is retained.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, dynamic& value) const;
    bool_t iteration_next(int64& position, int64 limit, int64& key_index, string& key_text, dynamic& value) const;
    dynamic source_read(int64 key) const { return read(key); }
    dynamic source_read(const boxed_text_key& key) const;
    void source_set(int64 key, const dynamic& value) { set(key, value); }
    void source_set(const boxed_text_key& key, const dynamic& value);
#ifdef __SIZEOF_INT128__
static void from_boolean(__int128) = delete;
#endif
static void from_boolean(char) = delete;
static void from_boolean(char16_t) = delete;
static void from_boolean(char32_t) = delete;
static void from_boolean(char8_t) = delete;
static void from_boolean(decltype(nullptr)) = delete;
static void from_boolean(double) = delete;
static void from_boolean(float) = delete;
static void from_boolean(int) = delete;
static void from_boolean(long) = delete;
static void from_boolean(long double) = delete;
static void from_boolean(long long) = delete;
static void from_boolean(short) = delete;
static void from_boolean(signed char) = delete;
#ifdef __SIZEOF_INT128__
static void from_boolean(unsigned __int128) = delete;
#endif
static void from_boolean(unsigned char) = delete;
static void from_boolean(unsigned int) = delete;
static void from_boolean(unsigned long) = delete;
static void from_boolean(unsigned long long) = delete;
static void from_boolean(unsigned short) = delete;
static void from_boolean(const void*) = delete;
static void from_boolean(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
static void from_integer(__int128) = delete;
#endif
static void from_integer(bool) = delete;
static void from_integer(char) = delete;
static void from_integer(char16_t) = delete;
static void from_integer(char32_t) = delete;
static void from_integer(char8_t) = delete;
static void from_integer(decltype(nullptr)) = delete;
static void from_integer(double) = delete;
static void from_integer(float) = delete;
static void from_integer(int) = delete;
static void from_integer(long double) = delete;
static void from_integer(long long) = delete;
static void from_integer(short) = delete;
static void from_integer(signed char) = delete;
#ifdef __SIZEOF_INT128__
static void from_integer(unsigned __int128) = delete;
#endif
static void from_integer(unsigned char) = delete;
static void from_integer(unsigned int) = delete;
static void from_integer(unsigned long) = delete;
static void from_integer(unsigned long long) = delete;
static void from_integer(unsigned short) = delete;
static void from_integer(const void*) = delete;
static void from_integer(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
static void from_floating(__int128) = delete;
#endif
static void from_floating(bool) = delete;
static void from_floating(char) = delete;
static void from_floating(char16_t) = delete;
static void from_floating(char32_t) = delete;
static void from_floating(char8_t) = delete;
static void from_floating(decltype(nullptr)) = delete;
static void from_floating(float) = delete;
static void from_floating(int) = delete;
static void from_floating(long) = delete;
static void from_floating(long double) = delete;
static void from_floating(long long) = delete;
static void from_floating(short) = delete;
static void from_floating(signed char) = delete;
#ifdef __SIZEOF_INT128__
static void from_floating(unsigned __int128) = delete;
#endif
static void from_floating(unsigned char) = delete;
static void from_floating(unsigned int) = delete;
static void from_floating(unsigned long) = delete;
static void from_floating(unsigned long long) = delete;
static void from_floating(unsigned short) = delete;
static void from_floating(const void*) = delete;
static void from_floating(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void read(__int128) const = delete;
#endif
void read(bool) const = delete;
void read(char) const = delete;
void read(char16_t) const = delete;
void read(char32_t) const = delete;
void read(char8_t) const = delete;
void read(decltype(nullptr)) const = delete;
void read(double) const = delete;
void read(float) const = delete;
void read(int) const = delete;
void read(long double) const = delete;
void read(long long) const = delete;
void read(short) const = delete;
void read(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void read(unsigned __int128) const = delete;
#endif
void read(unsigned char) const = delete;
void read(unsigned int) const = delete;
void read(unsigned long) const = delete;
void read(unsigned long long) const = delete;
void read(unsigned short) const = delete;
void read(const void*) const = delete;
void read(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void has(__int128) const = delete;
#endif
void has(bool) const = delete;
void has(char) const = delete;
void has(char16_t) const = delete;
void has(char32_t) const = delete;
void has(char8_t) const = delete;
void has(decltype(nullptr)) const = delete;
void has(double) const = delete;
void has(float) const = delete;
void has(int) const = delete;
void has(long double) const = delete;
void has(long long) const = delete;
void has(short) const = delete;
void has(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void has(unsigned __int128) const = delete;
#endif
void has(unsigned char) const = delete;
void has(unsigned int) const = delete;
void has(unsigned long) const = delete;
void has(unsigned long long) const = delete;
void has(unsigned short) const = delete;
void has(const void*) const = delete;
void has(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void remove(__int128) = delete;
#endif
void remove(bool) = delete;
void remove(char) = delete;
void remove(char16_t) = delete;
void remove(char32_t) = delete;
void remove(char8_t) = delete;
void remove(decltype(nullptr)) = delete;
void remove(double) = delete;
void remove(float) = delete;
void remove(int) = delete;
void remove(long double) = delete;
void remove(long long) = delete;
void remove(short) = delete;
void remove(signed char) = delete;
#ifdef __SIZEOF_INT128__
void remove(unsigned __int128) = delete;
#endif
void remove(unsigned char) = delete;
void remove(unsigned int) = delete;
void remove(unsigned long) = delete;
void remove(unsigned long long) = delete;
void remove(unsigned short) = delete;
void remove(const void*) = delete;
void remove(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void set(__int128, dynamic) = delete;
#endif
void set(bool, dynamic) = delete;
void set(char, dynamic) = delete;
void set(char16_t, dynamic) = delete;
void set(char32_t, dynamic) = delete;
void set(char8_t, dynamic) = delete;
void set(decltype(nullptr), dynamic) = delete;
void set(double, dynamic) = delete;
void set(float, dynamic) = delete;
void set(int, dynamic) = delete;
void set(long double, dynamic) = delete;
void set(long long, dynamic) = delete;
void set(short, dynamic) = delete;
void set(signed char, dynamic) = delete;
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, dynamic) = delete;
#endif
void set(unsigned char, dynamic) = delete;
void set(unsigned int, dynamic) = delete;
void set(unsigned long long, dynamic) = delete;
void set(unsigned long, dynamic) = delete;
void set(unsigned short, dynamic) = delete;
void set(const void*, dynamic) = delete;
void set(wchar_t, dynamic) = delete;
private:
    friend struct detail::ownership_access;
    alignas(8) unsigned char storage_[24];
};
scpp::int64 boxed_dynamic_typed_destination_int64(const dynamic& v);
scpp::int64 boxed_dynamic_explicit_cast_int64(const dynamic& v);
scpp::int64 boxed_dynamic_assignment_int64(const dynamic& v);
scpp::bool_t boxed_dynamic_typed_destination_bool_t(const dynamic& v);
scpp::bool_t boxed_dynamic_explicit_cast_bool_t(const dynamic& v);
scpp::bool_t boxed_dynamic_assignment_bool_t(const dynamic& v);
scpp::float64 boxed_dynamic_typed_destination_float64(const dynamic& v);
scpp::float64 boxed_dynamic_explicit_cast_float64(const dynamic& v);
scpp::float64 boxed_dynamic_assignment_float64(const dynamic& v);
scpp::int16 boxed_dynamic_typed_destination_int16(const dynamic& v);
scpp::int16 boxed_dynamic_explicit_cast_int16(const dynamic& v);
scpp::int32 boxed_dynamic_typed_destination_int32(const dynamic& v);
scpp::int32 boxed_dynamic_explicit_cast_int32(const dynamic& v);
scpp::int8 boxed_dynamic_typed_destination_int8(const dynamic& v);
scpp::int8 boxed_dynamic_explicit_cast_int8(const dynamic& v);
scpp::null_t boxed_dynamic_typed_destination_null_t(const dynamic& v);
scpp::null_t boxed_dynamic_explicit_cast_null_t(const dynamic& v);
scpp::null_t boxed_dynamic_assignment_null_t(const dynamic& v);
scpp::string boxed_dynamic_typed_destination_string(const dynamic& v);
scpp::string boxed_dynamic_explicit_cast_string(const dynamic& v);
scpp::string boxed_dynamic_assignment_string(const dynamic& v);
scpp::uint16 boxed_dynamic_typed_destination_uint16(const dynamic& v);
scpp::uint16 boxed_dynamic_explicit_cast_uint16(const dynamic& v);
scpp::uint32 boxed_dynamic_typed_destination_uint32(const dynamic& v);
scpp::uint32 boxed_dynamic_explicit_cast_uint32(const dynamic& v);
scpp::uint8 boxed_dynamic_typed_destination_uint8(const dynamic& v);
scpp::uint8 boxed_dynamic_explicit_cast_uint8(const dynamic& v);
dynamic boxed_add_int64_dynamic(scpp::int64 a, const dynamic& b);
dynamic boxed_add_float64_dynamic(scpp::float64 a, const dynamic& b);
dynamic boxed_add_int16_dynamic(scpp::int16 a, const dynamic& b);
dynamic boxed_add_int32_dynamic(scpp::int32 a, const dynamic& b);
dynamic boxed_add_int8_dynamic(scpp::int8 a, const dynamic& b);
dynamic boxed_add_uint16_dynamic(scpp::uint16 a, const dynamic& b);
dynamic boxed_add_uint32_dynamic(scpp::uint32 a, const dynamic& b);
dynamic boxed_add_uint8_dynamic(scpp::uint8 a, const dynamic& b);
dynamic boxed_add_dynamic_int64(const dynamic& a, scpp::int64 b);
dynamic boxed_add_dynamic_float64(const dynamic& a, scpp::float64 b);
dynamic boxed_add_dynamic_int16(const dynamic& a, scpp::int16 b);
dynamic boxed_add_dynamic_int32(const dynamic& a, scpp::int32 b);
dynamic boxed_add_dynamic_int8(const dynamic& a, scpp::int8 b);
dynamic boxed_add_dynamic_uint16(const dynamic& a, scpp::uint16 b);
dynamic boxed_add_dynamic_uint32(const dynamic& a, scpp::uint32 b);
dynamic boxed_add_dynamic_uint8(const dynamic& a, scpp::uint8 b);
dynamic boxed_add_dynamic_dynamic(const dynamic& a, const dynamic& b);
bool boxed_less_int64_dynamic(scpp::int64 a, const dynamic& b);
bool boxed_less_float64_dynamic(scpp::float64 a, const dynamic& b);
bool boxed_less_int16_dynamic(scpp::int16 a, const dynamic& b);
bool boxed_less_int32_dynamic(scpp::int32 a, const dynamic& b);
bool boxed_less_int8_dynamic(scpp::int8 a, const dynamic& b);
bool boxed_less_string_dynamic(const string& a, const dynamic& b);
bool boxed_less_uint16_dynamic(scpp::uint16 a, const dynamic& b);
bool boxed_less_uint32_dynamic(scpp::uint32 a, const dynamic& b);
bool boxed_less_uint8_dynamic(scpp::uint8 a, const dynamic& b);
bool boxed_less_dynamic_int64(const dynamic& a, scpp::int64 b);
bool boxed_less_dynamic_float64(const dynamic& a, scpp::float64 b);
bool boxed_less_dynamic_int16(const dynamic& a, scpp::int16 b);
bool boxed_less_dynamic_int32(const dynamic& a, scpp::int32 b);
bool boxed_less_dynamic_int8(const dynamic& a, scpp::int8 b);
bool boxed_less_dynamic_string(const dynamic& a, const string& b);
bool boxed_less_dynamic_uint16(const dynamic& a, scpp::uint16 b);
bool boxed_less_dynamic_uint32(const dynamic& a, scpp::uint32 b);
bool boxed_less_dynamic_uint8(const dynamic& a, scpp::uint8 b);
bool boxed_less_dynamic_dynamic(const dynamic& a, const dynamic& b);
bool boxed_less_equal_int64_dynamic(scpp::int64 a, const dynamic& b);
bool boxed_less_equal_float64_dynamic(scpp::float64 a, const dynamic& b);
bool boxed_less_equal_int16_dynamic(scpp::int16 a, const dynamic& b);
bool boxed_less_equal_int32_dynamic(scpp::int32 a, const dynamic& b);
bool boxed_less_equal_int8_dynamic(scpp::int8 a, const dynamic& b);
bool boxed_less_equal_string_dynamic(const string& a, const dynamic& b);
bool boxed_less_equal_uint16_dynamic(scpp::uint16 a, const dynamic& b);
bool boxed_less_equal_uint32_dynamic(scpp::uint32 a, const dynamic& b);
bool boxed_less_equal_uint8_dynamic(scpp::uint8 a, const dynamic& b);
bool boxed_less_equal_dynamic_int64(const dynamic& a, scpp::int64 b);
bool boxed_less_equal_dynamic_float64(const dynamic& a, scpp::float64 b);
bool boxed_less_equal_dynamic_int16(const dynamic& a, scpp::int16 b);
bool boxed_less_equal_dynamic_int32(const dynamic& a, scpp::int32 b);
bool boxed_less_equal_dynamic_int8(const dynamic& a, scpp::int8 b);
bool boxed_less_equal_dynamic_string(const dynamic& a, const string& b);
bool boxed_less_equal_dynamic_uint16(const dynamic& a, scpp::uint16 b);
bool boxed_less_equal_dynamic_uint32(const dynamic& a, scpp::uint32 b);
bool boxed_less_equal_dynamic_uint8(const dynamic& a, scpp::uint8 b);
bool boxed_less_equal_dynamic_dynamic(const dynamic& a, const dynamic& b);
bool boxed_greater_int64_dynamic(scpp::int64 a, const dynamic& b);
bool boxed_greater_float64_dynamic(scpp::float64 a, const dynamic& b);
bool boxed_greater_int16_dynamic(scpp::int16 a, const dynamic& b);
bool boxed_greater_int32_dynamic(scpp::int32 a, const dynamic& b);
bool boxed_greater_int8_dynamic(scpp::int8 a, const dynamic& b);
bool boxed_greater_string_dynamic(const string& a, const dynamic& b);
bool boxed_greater_uint16_dynamic(scpp::uint16 a, const dynamic& b);
bool boxed_greater_uint32_dynamic(scpp::uint32 a, const dynamic& b);
bool boxed_greater_uint8_dynamic(scpp::uint8 a, const dynamic& b);
bool boxed_greater_dynamic_int64(const dynamic& a, scpp::int64 b);
bool boxed_greater_dynamic_float64(const dynamic& a, scpp::float64 b);
bool boxed_greater_dynamic_int16(const dynamic& a, scpp::int16 b);
bool boxed_greater_dynamic_int32(const dynamic& a, scpp::int32 b);
bool boxed_greater_dynamic_int8(const dynamic& a, scpp::int8 b);
bool boxed_greater_dynamic_string(const dynamic& a, const string& b);
bool boxed_greater_dynamic_uint16(const dynamic& a, scpp::uint16 b);
bool boxed_greater_dynamic_uint32(const dynamic& a, scpp::uint32 b);
bool boxed_greater_dynamic_uint8(const dynamic& a, scpp::uint8 b);
bool boxed_greater_dynamic_dynamic(const dynamic& a, const dynamic& b);
bool boxed_greater_equal_int64_dynamic(scpp::int64 a, const dynamic& b);
bool boxed_greater_equal_float64_dynamic(scpp::float64 a, const dynamic& b);
bool boxed_greater_equal_int16_dynamic(scpp::int16 a, const dynamic& b);
bool boxed_greater_equal_int32_dynamic(scpp::int32 a, const dynamic& b);
bool boxed_greater_equal_int8_dynamic(scpp::int8 a, const dynamic& b);
bool boxed_greater_equal_string_dynamic(const string& a, const dynamic& b);
bool boxed_greater_equal_uint16_dynamic(scpp::uint16 a, const dynamic& b);
bool boxed_greater_equal_uint32_dynamic(scpp::uint32 a, const dynamic& b);
bool boxed_greater_equal_uint8_dynamic(scpp::uint8 a, const dynamic& b);
bool boxed_greater_equal_dynamic_int64(const dynamic& a, scpp::int64 b);
bool boxed_greater_equal_dynamic_float64(const dynamic& a, scpp::float64 b);
bool boxed_greater_equal_dynamic_int16(const dynamic& a, scpp::int16 b);
bool boxed_greater_equal_dynamic_int32(const dynamic& a, scpp::int32 b);
bool boxed_greater_equal_dynamic_int8(const dynamic& a, scpp::int8 b);
bool boxed_greater_equal_dynamic_string(const dynamic& a, const string& b);
bool boxed_greater_equal_dynamic_uint16(const dynamic& a, scpp::uint16 b);
bool boxed_greater_equal_dynamic_uint32(const dynamic& a, scpp::uint32 b);
bool boxed_greater_equal_dynamic_uint8(const dynamic& a, scpp::uint8 b);
bool boxed_greater_equal_dynamic_dynamic(const dynamic& a, const dynamic& b);
}
