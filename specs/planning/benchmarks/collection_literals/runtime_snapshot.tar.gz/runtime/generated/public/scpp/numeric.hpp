// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/core/scalars.hpp"
#include "scpp/numeric/scalars.hpp"
namespace scpp {
}
