// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/string.hpp"
namespace scpp::js {
inline ::scpp::string trimStart(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::start, ::scpp::str::trim_set::ascii_space); }
}
namespace scpp::js {
inline ::scpp::string padEnd(const ::scpp::string& arg0, ::scpp::int64 arg1, const ::scpp::string& arg2 = ::scpp::string{" ", 1}) { return ::scpp::str::pad_bytes(arg0, arg1, arg2, static_cast<::scpp::int64>(::scpp::str::pad_side::right), false); }
}
namespace scpp::js {
inline ::scpp::string padStart(const ::scpp::string& arg0, ::scpp::int64 arg1, const ::scpp::string& arg2 = ::scpp::string{" ", 1}) { return ::scpp::str::pad_bytes(arg0, arg1, arg2, static_cast<::scpp::int64>(::scpp::str::pad_side::left), false); }
}
namespace scpp::js {
inline ::scpp::string trimEnd(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::end, ::scpp::str::trim_set::ascii_space); }
}
namespace scpp::js {
inline ::scpp::bool_t includes(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::contains(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::bool_t endsWith(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::ends_with(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::string repeat(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::repeat(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::string replaceAll(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg0, arg1, arg2, ::scpp::str::replace_mode::all); }
}
namespace scpp::js {
inline ::scpp::string replace(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg0, arg1, arg2, ::scpp::str::replace_mode::first); }
}
namespace scpp::js {
inline ::scpp::bool_t startsWith(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::starts_with(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::int64 indexOf(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::find(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::int64 indexOf(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::find(arg0, arg1, arg2, ::scpp::str::search_policy::clamp); }
}
namespace scpp::js {
inline ::scpp::int64 lastIndexOf(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::rfind(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::int64 lastIndexOf(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::rfind(arg0, arg1, arg2, ::scpp::str::search_policy::clamp); }
}
namespace scpp::js {
inline ::scpp::string toLowerCase(const ::scpp::string& arg0) { return ::scpp::str::ascii_lower(arg0); }
}
namespace scpp::js {
inline ::scpp::string toUpperCase(const ::scpp::string& arg0) { return ::scpp::str::ascii_upper(arg0); }
}
namespace scpp::js {
inline ::scpp::string slice(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::slice_bytes(arg0, arg1, 0, ::scpp::str::slice_bound::to_end); }
}
namespace scpp::js {
inline ::scpp::string slice(const ::scpp::string& arg0, ::scpp::int64 arg1, ::scpp::int64 arg2) { return ::scpp::str::slice_bytes(arg0, arg1, arg2, ::scpp::str::slice_bound::exclusive_end); }
}
namespace scpp::js {
inline ::scpp::int64 countMatches(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::count_matches(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::int64 countMatches(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::count_matches(arg0, arg1, arg2); }
}
namespace scpp::js {
inline ::scpp::int64 countMatches(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3) { return ::scpp::str::count_matches(arg0, arg1, arg2, arg3); }
}
namespace scpp::js {
inline ::scpp::string trim(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::both, ::scpp::str::trim_set::ascii_space); }
}
