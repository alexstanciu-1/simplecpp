// Generated from reviewed runtime metadata. Do not edit.
#pragma once
namespace scpp { enum class boxed_kind { null, boolean, integer, floating, string, container }; }
