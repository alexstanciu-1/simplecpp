// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/string.hpp"
namespace scpp::cpp {
inline ::scpp::string trim_start(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::start, ::scpp::str::trim_set::ascii_space); }
}
namespace scpp::cpp {
inline ::scpp::string pad_end(const ::scpp::string& arg0, ::scpp::int64 arg1, const ::scpp::string& arg2 = ::scpp::string{" ", 1}) { return ::scpp::str::pad_bytes(arg0, arg1, arg2, static_cast<::scpp::int64>(::scpp::str::pad_side::right), false); }
}
namespace scpp::cpp {
inline ::scpp::string pad_start(const ::scpp::string& arg0, ::scpp::int64 arg1, const ::scpp::string& arg2 = ::scpp::string{" ", 1}) { return ::scpp::str::pad_bytes(arg0, arg1, arg2, static_cast<::scpp::int64>(::scpp::str::pad_side::left), false); }
}
namespace scpp::cpp {
inline ::scpp::string trim_end(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::end, ::scpp::str::trim_set::ascii_space); }
}
namespace scpp::cpp {
inline ::scpp::bool_t contains(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::contains(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::bool_t ends_with(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::ends_with(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::string repeat(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::repeat(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::string replace_all(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg0, arg1, arg2, ::scpp::str::replace_mode::all); }
}
namespace scpp::cpp {
inline ::scpp::string replace_first(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg0, arg1, arg2, ::scpp::str::replace_mode::first); }
}
namespace scpp::cpp {
inline ::scpp::bool_t starts_with(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::starts_with(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::int64 find(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::find(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::int64 find(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::find(arg0, arg1, arg2, ::scpp::str::search_policy::nonnegative); }
}
namespace scpp::cpp {
inline ::scpp::int64 rfind(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::rfind(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::int64 rfind(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::rfind(arg0, arg1, arg2, ::scpp::str::search_policy::nonnegative); }
}
namespace scpp::cpp {
inline ::scpp::string to_lower(const ::scpp::string& arg0) { return ::scpp::str::ascii_lower(arg0); }
}
namespace scpp::cpp {
inline ::scpp::string to_upper(const ::scpp::string& arg0) { return ::scpp::str::ascii_upper(arg0); }
}
namespace scpp::cpp {
inline ::scpp::string substr(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::slice_bytes(arg0, arg1, 0, ::scpp::str::slice_bound::to_end); }
}
namespace scpp::cpp {
inline ::scpp::string substr(const ::scpp::string& arg0, ::scpp::int64 arg1, ::scpp::int64 arg2) { return ::scpp::str::slice_bytes(arg0, arg1, arg2, ::scpp::str::slice_bound::length); }
}
namespace scpp::cpp {
inline ::scpp::int64 count_matches(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::count_matches(arg0, arg1); }
}
namespace scpp::cpp {
inline ::scpp::int64 count_matches(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::count_matches(arg0, arg1, arg2); }
}
namespace scpp::cpp {
inline ::scpp::int64 count_matches(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3) { return ::scpp::str::count_matches(arg0, arg1, arg2, arg3); }
}
namespace scpp::cpp {
inline ::scpp::string trim(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::both, ::scpp::str::trim_set::ascii_space); }
}
