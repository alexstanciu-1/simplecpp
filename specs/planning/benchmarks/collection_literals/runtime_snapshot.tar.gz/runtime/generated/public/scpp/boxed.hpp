// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/dynamic.hpp"
#include "scpp/mixed.hpp"
