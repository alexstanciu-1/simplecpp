// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include <stdexcept>
namespace scpp { class ValueError : public std::invalid_argument { public: using std::invalid_argument::invalid_argument; }; }
