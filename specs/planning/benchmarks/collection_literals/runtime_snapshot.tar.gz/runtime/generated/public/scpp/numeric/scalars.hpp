// Generated from reviewed runtime metadata. Do not edit.
#pragma once
namespace scpp {
using int16 = __INT16_TYPE__;
using int32 = __INT32_TYPE__;
using int8 = __INT8_TYPE__;
using uint16 = __UINT16_TYPE__;
using uint32 = __UINT32_TYPE__;
}
namespace scpp::types {
using ::scpp::int16;
using ::scpp::int32;
using ::scpp::int8;
using ::scpp::uint16;
using ::scpp::uint32;
}
