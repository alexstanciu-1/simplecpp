// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/string.hpp"
namespace scpp::php {
inline ::scpp::string bin2hex(const ::scpp::string& arg0) { return ::scpp::str::hex_encode(arg0); }
}
#include "scpp/carriers.hpp"
namespace scpp::php {
inline ::scpp::result_or_false_string hex2bin(const ::scpp::string& arg0) { return ::scpp::str::hex_decode(arg0); }
}
namespace scpp::php {
inline ::scpp::string lcfirst(const ::scpp::string& arg0) { return ::scpp::str::ascii_lower_first(arg0); }
}
namespace scpp::php {
inline ::scpp::string ltrim(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::start, ::scpp::str::trim_set::php_space); }
}
namespace scpp::php {
inline ::scpp::string ltrim(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::trim_bytes(arg0, arg1, ::scpp::str::trim_side::start); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::int64 arg0) { return ::scpp::str::number_format(arg0, 0, ::scpp::string{".", 1}, ::scpp::string{",", 1}); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::float64 arg0) { return ::scpp::str::number_format(arg0, 0, ::scpp::string{".", 1}, ::scpp::string{",", 1}); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::int64 arg0, ::scpp::int64 arg1) { return ::scpp::str::number_format(arg0, arg1, ::scpp::string{".", 1}, ::scpp::string{",", 1}); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::float64 arg0, ::scpp::int64 arg1) { return ::scpp::str::number_format(arg0, arg1, ::scpp::string{".", 1}, ::scpp::string{",", 1}); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::int64 arg0, ::scpp::int64 arg1, const ::scpp::string& arg2, const ::scpp::string& arg3) { return ::scpp::str::number_format(arg0, arg1, arg2, arg3); }
}
namespace scpp::php {
inline ::scpp::string number_format(::scpp::float64 arg0, ::scpp::int64 arg1, const ::scpp::string& arg2, const ::scpp::string& arg3) { return ::scpp::str::number_format(arg0, arg1, arg2, arg3); }
}
namespace scpp::php {
inline ::scpp::string rtrim(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::end, ::scpp::str::trim_set::php_space); }
}
namespace scpp::php {
inline ::scpp::string rtrim(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::trim_bytes(arg0, arg1, ::scpp::str::trim_side::end); }
}
namespace scpp::php {
inline ::scpp::bool_t str_contains(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::contains(arg0, arg1); }
}
namespace scpp::php {
inline ::scpp::bool_t str_ends_with(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::ends_with(arg0, arg1); }
}
namespace scpp::php { inline constexpr ::scpp::int64 STR_PAD_BOTH = 2; }
namespace scpp::php { inline constexpr ::scpp::int64 STR_PAD_LEFT = 0; }
namespace scpp::php { inline constexpr ::scpp::int64 STR_PAD_RIGHT = 1; }
namespace scpp::php {
inline ::scpp::string str_pad(const ::scpp::string& arg0, ::scpp::int64 arg1, const ::scpp::string& arg2 = ::scpp::string{" ", 1}, ::scpp::int64 arg3 = STR_PAD_RIGHT) { return ::scpp::str::pad_bytes(arg0, arg1, arg2, arg3, true); }
}
namespace scpp::php {
inline ::scpp::string str_repeat(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::repeat(arg0, arg1); }
}
namespace scpp::php {
inline ::scpp::string str_replace(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg2, arg0, arg1, ::scpp::str::replace_mode::all); }
}
namespace scpp::php {
inline ::scpp::string str_replace(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2, ::scpp::int64& arg3) { return ::scpp::str::replace_bytes(arg2, arg0, arg1, ::scpp::str::replace_mode::all, arg3); }
}
namespace scpp::php {
inline ::scpp::string str_replace_first(const ::scpp::string& arg0, const ::scpp::string& arg1, const ::scpp::string& arg2) { return ::scpp::str::replace_bytes(arg2, arg0, arg1, ::scpp::str::replace_mode::first); }
}
namespace scpp::php {
inline ::scpp::bool_t str_starts_with(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::starts_with(arg0, arg1); }
}
namespace scpp::php {
inline ::scpp::int64 strcasecmp(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::compare_bytes(arg0, arg1, true); }
}
namespace scpp::php {
inline ::scpp::int64 strcmp(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::compare_bytes(arg0, arg1, false); }
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 stripos(const ::scpp::string& arg0, const ::scpp::string& arg1) {
    const auto offset = ::scpp::str::ascii_find(arg0, arg1);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 stripos(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) {
    const auto offset = ::scpp::str::ascii_find(arg0, arg1, arg2, ::scpp::str::search_policy::signed_offset);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::int64 strncasecmp(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::compare_prefix(arg0, arg1, arg2, true); }
}
namespace scpp::php {
inline ::scpp::int64 strncmp(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::compare_prefix(arg0, arg1, arg2, false); }
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strpos(const ::scpp::string& arg0, const ::scpp::string& arg1) {
    const auto offset = ::scpp::str::find(arg0, arg1);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strpos(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) {
    const auto offset = ::scpp::str::find(arg0, arg1, arg2, ::scpp::str::search_policy::signed_offset);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strripos(const ::scpp::string& arg0, const ::scpp::string& arg1) {
    const auto offset = ::scpp::str::ascii_rfind(arg0, arg1);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strripos(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) {
    const auto offset = ::scpp::str::ascii_rfind(arg0, arg1, arg2, ::scpp::str::search_policy::signed_offset);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strrpos(const ::scpp::string& arg0, const ::scpp::string& arg1) {
    const auto offset = ::scpp::str::rfind(arg0, arg1);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::result_or_false_int64 strrpos(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) {
    const auto offset = ::scpp::str::rfind(arg0, arg1, arg2, ::scpp::str::search_policy::signed_offset);
    if (offset == -1) return ::scpp::result_or_false_int64::from_false();
    return ::scpp::result_or_false_int64{offset};
}
}
namespace scpp::php {
inline ::scpp::string strtolower(const ::scpp::string& arg0) { return ::scpp::str::ascii_lower(arg0); }
}
namespace scpp::php {
inline ::scpp::string strtoupper(const ::scpp::string& arg0) { return ::scpp::str::ascii_upper(arg0); }
}
namespace scpp::php {
inline ::scpp::string substr(const ::scpp::string& arg0, ::scpp::int64 arg1) { return ::scpp::str::slice_bytes(arg0, arg1, 0, ::scpp::str::slice_bound::to_end); }
}
namespace scpp::php {
inline ::scpp::string substr(const ::scpp::string& arg0, ::scpp::int64 arg1, ::scpp::int64 arg2) { return ::scpp::str::slice_bytes(arg0, arg1, arg2, ::scpp::str::slice_bound::length); }
}
namespace scpp::php {
inline ::scpp::int64 substr_compare(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::compare_window(arg0, arg1, arg2); }
}
namespace scpp::php {
inline ::scpp::int64 substr_compare(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3) { return ::scpp::str::compare_window(arg0, arg1, arg2, arg3); }
}
namespace scpp::php {
inline ::scpp::int64 substr_compare(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3, ::scpp::bool_t arg4) { return ::scpp::str::compare_window(arg0, arg1, arg2, arg3, arg4); }
}
namespace scpp::php {
inline ::scpp::int64 substr_count(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::count_matches(arg0, arg1); }
}
namespace scpp::php {
inline ::scpp::int64 substr_count(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::count_matches(arg0, arg1, arg2); }
}
namespace scpp::php {
inline ::scpp::int64 substr_count(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3) { return ::scpp::str::count_matches(arg0, arg1, arg2, arg3); }
}
namespace scpp::php {
inline ::scpp::string substr_replace(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2, ::scpp::int64 arg3 = 0) { return ::scpp::str::substr_replace(arg0, arg1, arg2, arg3); }
}
namespace scpp::php {
inline ::scpp::string trim(const ::scpp::string& arg0) { return ::scpp::str::trim_bytes(arg0, ::scpp::str::trim_side::both, ::scpp::str::trim_set::php_space); }
}
namespace scpp::php {
inline ::scpp::string trim(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::trim_bytes(arg0, arg1, ::scpp::str::trim_side::both); }
}
namespace scpp::php {
inline ::scpp::string ucfirst(const ::scpp::string& arg0) { return ::scpp::str::ascii_upper_first(arg0); }
}
