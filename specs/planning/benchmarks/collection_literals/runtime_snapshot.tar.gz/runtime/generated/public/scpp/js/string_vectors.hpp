// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/vectors.hpp"
namespace scpp::js {
inline ::scpp::vector_string split(const ::scpp::string& arg0, const ::scpp::string& arg1) { return ::scpp::str::split(arg0, arg1); }
}
namespace scpp::js {
inline ::scpp::vector_string split(const ::scpp::string& arg0, const ::scpp::string& arg1, ::scpp::int64 arg2) { return ::scpp::str::split(arg0, arg1, (arg2 & 0xffffffffLL), ::scpp::str::split_policy::cap); }
}
namespace scpp::js {
inline ::scpp::string join(const ::scpp::vector_string& arg0, const ::scpp::string& arg1) { return ::scpp::str::join(arg0, arg1); }
}
