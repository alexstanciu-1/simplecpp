// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/string.hpp"
#include "scpp/core/scalars.hpp"
#include "scpp/numeric/scalars.hpp"
namespace scpp {
struct boxed_text_key { int64 index; string text; };
int64 boxed_key(int64 key);
boxed_text_key boxed_key(string key);
}
