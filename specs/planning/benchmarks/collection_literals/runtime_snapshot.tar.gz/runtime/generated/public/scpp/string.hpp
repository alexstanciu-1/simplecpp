// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/core/scalars.hpp"
namespace scpp {
namespace detail { struct string_access; }
class string final {
public:
    string() noexcept = default;
    ~string();
    string(const string&);
    string(string&&) noexcept;
    string& operator=(const string&);
    string& operator=(string&&) noexcept;
    explicit string(const char*);
    explicit string(const char*, __INT64_TYPE__);
    explicit string(int) = delete;
    explicit string(unsigned int) = delete;
    explicit string(unsigned long) = delete;
    explicit string(long long) = delete;
    explicit string(unsigned long long) = delete;
    explicit string(short) = delete;
    explicit string(unsigned short) = delete;
    explicit string(char) = delete;
    explicit string(signed char) = delete;
    explicit string(unsigned char) = delete;
    explicit string(wchar_t) = delete;
    explicit string(char8_t) = delete;
    explicit string(char16_t) = delete;
    explicit string(char32_t) = delete;
    explicit string(float) = delete;
    explicit string(long double) = delete;
#ifdef __SIZEOF_INT128__
    explicit string(__int128) = delete;
    explicit string(unsigned __int128) = delete;
#endif
    explicit string(bool_t value);
    explicit string(float64 value);
    explicit string(int64 value);
    uint8 byte_at(int64 index) const;
    void set_byte(int64 index, uint8 value);
    static constexpr unsigned inline_capacity = 22;
    bool is_inline() const noexcept { return rep_.small.tag <= inline_capacity; }
    __INT64_TYPE__ size() const;
    bool_t empty() const noexcept;
    const char* data() const noexcept;
    void append(const string&);
    void clear() noexcept;
private:
    struct storage;
    // Common initial tag is readable in either standard-layout union member.
    struct short_form { unsigned char tag; char bytes[inline_capacity + 1]; };
    struct long_form { unsigned char tag; storage* ptr; };
    union representation { short_form small{}; long_form large; } rep_;
    friend struct detail::string_access;
};
static_assert(sizeof(string) == 24);
string operator+(string left, const string& right);
string& operator+=(string& left, const string& right);
bool_t operator==(const string& left, const string& right) noexcept;
bool_t operator>(const string& left, const string& right) noexcept;
bool_t operator>=(const string& left, const string& right) noexcept;
bool_t operator<(const string& left, const string& right) noexcept;
bool_t operator<=(const string& left, const string& right) noexcept;
bool_t operator!=(const string& left, const string& right) noexcept;
namespace str { string format_bool(bool_t value); }
namespace str { string format_float64(float64 value); }
namespace str { string format_int64(int64 value); }
namespace str { string format_uint8(uint8 value); }
namespace str { string hex_encode(const string& value); }
class result_or_false_string;
namespace str { result_or_false_string hex_decode(const string& value); }
namespace str { string ascii_lower_first(const string& value); }
namespace str { enum class trim_side { both, start, end }; enum class trim_set { php_space, ascii_space }; }
namespace str { string trim_bytes(const string& value, trim_side side, trim_set set); string trim_bytes(const string& value, const string& mask, trim_side side); }
namespace str { string number_format(int64 value, int64 decimals, const string& point, const string& group); }
namespace str { string number_format(float64 value, int64 decimals, const string& point, const string& group); }
namespace str { enum class pad_side : int64 { left = 0, right = 1, both = 2 }; }
namespace str { string pad_bytes(const string& subject, int64 width, const string& fill, int64 side, bool reject_empty); }
namespace str { bool_t contains(const string& value, const string& other); }
namespace str { bool_t ends_with(const string& value, const string& other); }
namespace str { string repeat(const string& value, int64 other); }
namespace str { enum class replace_mode { first, all }; }
namespace str { string replace_bytes(const string& subject, const string& search, const string& replacement, replace_mode mode); }
namespace str { string replace_bytes(const string& subject, const string& search, const string& replacement, replace_mode mode, int64& count); }
namespace str { bool_t starts_with(const string& value, const string& other); }
namespace str { int64 compare_bytes(const string& left, const string& right, bool_t insensitive); }
namespace str { string byte_from_int(int64 value); }
namespace str { enum class search_policy { signed_offset, clamp, nonnegative }; }
namespace str { int64 ascii_find(const string& subject, const string& needle); int64 ascii_find(const string& subject, const string& needle, int64 offset, search_policy policy); }
namespace str { inline int64 byte_length(const string& value) { return value.size(); } }
namespace str { int64 compare_prefix(const string& left, const string& right, int64 limit, bool_t insensitive); }
namespace str { int64 find(const string& subject, const string& needle); int64 find(const string& subject, const string& needle, int64 offset, search_policy policy); }
namespace str { int64 ascii_rfind(const string& subject, const string& needle); int64 ascii_rfind(const string& subject, const string& needle, int64 offset, search_policy policy); }
namespace str { int64 rfind(const string& subject, const string& needle); int64 rfind(const string& subject, const string& needle, int64 offset, search_policy policy); }
namespace str { string ascii_lower(const string& value); }
namespace str { string ascii_upper(const string& value); }
namespace str { enum class slice_bound { to_end, length, exclusive_end }; string slice_bytes(const string& value, int64 start, int64 bound, slice_bound mode); }
namespace str { int64 compare_window(const string& subject, const string& other, int64 offset); int64 compare_window(const string& subject, const string& other, int64 offset, int64 length, bool_t insensitive = false); }
namespace str { int64 count_matches(const string& value, const string& other); int64 count_matches(const string& value, const string& other, int64 offset); int64 count_matches(const string& value, const string& other, int64 offset, int64 length); }
namespace str { string substr_replace(const string& subject, const string& replacement, int64 offset, int64 length); }
namespace str { string ascii_upper_first(const string& value); }
}
namespace scpp::types { using ::scpp::string; }
