// Generated from reviewed runtime metadata. Do not edit.
#pragma once
#include "scpp/core/scalars.hpp"
#include "scpp/string.hpp"
namespace scpp {
namespace detail { struct vector_access; }
class vector_int64;
class vector_string;
class vector_int64 final {
public:
    vector_int64() noexcept = default;
    ~vector_int64();
    vector_int64(const vector_int64&);
    vector_int64(vector_int64&&) noexcept;
    vector_int64& operator=(const vector_int64&);
    vector_int64& operator=(vector_int64&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    void clear() noexcept;
    bool_t remove(int64 index);
    bool_t has(int64 index) const noexcept;
    void append(int64 value);
    int64 at(int64 index) const;
    void set(int64 index, int64 value);
    // Compiler traversal API: caller keeps this wrapper alive; no element references escape.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, int64& value) const;
    bool_t iteration_next(int64& position, int64 limit, int64& key, int64& value) const;
    int64 at(int index) const;
    void append(int value);
    void set(int64 index, int value);
    void set(int index, int64 value);
    void set(int index, int value);
#ifdef __SIZEOF_INT128__
void at(__int128) const = delete;
#endif
void at(bool) const = delete;
void at(char) const = delete;
void at(char16_t) const = delete;
void at(char32_t) const = delete;
void at(char8_t) const = delete;
void at(decltype(nullptr)) const = delete;
void at(double) const = delete;
void at(float) const = delete;
void at(long double) const = delete;
void at(long long) const = delete;
void at(short) const = delete;
void at(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void at(unsigned __int128) const = delete;
#endif
void at(unsigned char) const = delete;
void at(unsigned int) const = delete;
void at(unsigned long) const = delete;
void at(unsigned long long) const = delete;
void at(unsigned short) const = delete;
void at(const void*) const = delete;
void at(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void remove(__int128) = delete;
#endif
void remove(bool) = delete;
void remove(char) = delete;
void remove(char16_t) = delete;
void remove(char32_t) = delete;
void remove(char8_t) = delete;
void remove(decltype(nullptr)) = delete;
void remove(double) = delete;
void remove(float) = delete;
void remove(int) = delete;
void remove(long double) = delete;
void remove(long long) = delete;
void remove(short) = delete;
void remove(signed char) = delete;
#ifdef __SIZEOF_INT128__
void remove(unsigned __int128) = delete;
#endif
void remove(unsigned char) = delete;
void remove(unsigned int) = delete;
void remove(unsigned long) = delete;
void remove(unsigned long long) = delete;
void remove(unsigned short) = delete;
void remove(const void*) = delete;
void remove(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void has(__int128) const = delete;
#endif
void has(bool) const = delete;
void has(char) const = delete;
void has(char16_t) const = delete;
void has(char32_t) const = delete;
void has(char8_t) const = delete;
void has(decltype(nullptr)) const = delete;
void has(double) const = delete;
void has(float) const = delete;
void has(int) const = delete;
void has(long double) const = delete;
void has(long long) const = delete;
void has(short) const = delete;
void has(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void has(unsigned __int128) const = delete;
#endif
void has(unsigned char) const = delete;
void has(unsigned int) const = delete;
void has(unsigned long) const = delete;
void has(unsigned long long) const = delete;
void has(unsigned short) const = delete;
void has(const void*) const = delete;
void has(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void append(__int128) = delete;
#endif
void append(bool) = delete;
void append(char) = delete;
void append(char16_t) = delete;
void append(char32_t) = delete;
void append(char8_t) = delete;
void append(decltype(nullptr)) = delete;
void append(double) = delete;
void append(float) = delete;
void append(long double) = delete;
void append(long long) = delete;
void append(short) = delete;
void append(signed char) = delete;
#ifdef __SIZEOF_INT128__
void append(unsigned __int128) = delete;
#endif
void append(unsigned char) = delete;
void append(unsigned int) = delete;
void append(unsigned long) = delete;
void append(unsigned long long) = delete;
void append(unsigned short) = delete;
void append(const void*) = delete;
void append(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void set(__int128, int) = delete;
#endif
#ifdef __SIZEOF_INT128__
void set(__int128, int64) = delete;
#endif
void set(bool, int) = delete;
void set(bool, int64) = delete;
void set(char, int) = delete;
void set(char, int64) = delete;
void set(char16_t, int) = delete;
void set(char16_t, int64) = delete;
void set(char32_t, int) = delete;
void set(char32_t, int64) = delete;
void set(char8_t, int) = delete;
void set(char8_t, int64) = delete;
void set(decltype(nullptr), int) = delete;
void set(decltype(nullptr), int64) = delete;
void set(double, int) = delete;
void set(double, int64) = delete;
void set(float, int) = delete;
void set(float, int64) = delete;
#ifdef __SIZEOF_INT128__
void set(int, __int128) = delete;
#endif
void set(int, bool) = delete;
void set(int, char) = delete;
void set(int, char16_t) = delete;
void set(int, char32_t) = delete;
void set(int, char8_t) = delete;
void set(int, decltype(nullptr)) = delete;
void set(int, double) = delete;
void set(int, float) = delete;
void set(int, long double) = delete;
void set(int, long long) = delete;
void set(int, short) = delete;
void set(int, signed char) = delete;
#ifdef __SIZEOF_INT128__
void set(int, unsigned __int128) = delete;
#endif
void set(int, unsigned char) = delete;
void set(int, unsigned int) = delete;
void set(int, unsigned long) = delete;
void set(int, unsigned long long) = delete;
void set(int, unsigned short) = delete;
void set(int, const void*) = delete;
void set(int, wchar_t) = delete;
void set(long double, int) = delete;
void set(long double, int64) = delete;
void set(long long, int) = delete;
void set(long long, int64) = delete;
#ifdef __SIZEOF_INT128__
void set(int64, __int128) = delete;
#endif
void set(int64, bool) = delete;
void set(int64, char) = delete;
void set(int64, char16_t) = delete;
void set(int64, char32_t) = delete;
void set(int64, char8_t) = delete;
void set(int64, decltype(nullptr)) = delete;
void set(int64, double) = delete;
void set(int64, float) = delete;
void set(int64, long double) = delete;
void set(int64, long long) = delete;
void set(int64, short) = delete;
void set(int64, signed char) = delete;
#ifdef __SIZEOF_INT128__
void set(int64, unsigned __int128) = delete;
#endif
void set(int64, unsigned char) = delete;
void set(int64, unsigned int) = delete;
void set(int64, unsigned long) = delete;
void set(int64, unsigned long long) = delete;
void set(int64, unsigned short) = delete;
void set(int64, const void*) = delete;
void set(int64, wchar_t) = delete;
void set(short, int) = delete;
void set(short, int64) = delete;
void set(signed char, int) = delete;
void set(signed char, int64) = delete;
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, int) = delete;
#endif
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, int64) = delete;
#endif
void set(unsigned char, int) = delete;
void set(unsigned char, int64) = delete;
void set(unsigned int, int) = delete;
void set(unsigned int, int64) = delete;
void set(unsigned long long, int) = delete;
void set(unsigned long long, int64) = delete;
void set(unsigned long, int) = delete;
void set(unsigned long, int64) = delete;
void set(unsigned short, int) = delete;
void set(unsigned short, int64) = delete;
void set(const void*, int) = delete;
void set(const void*, int64) = delete;
void set(wchar_t, int) = delete;
void set(wchar_t, int64) = delete;
private:
    struct storage;
    storage* storage_ = nullptr;
    friend struct detail::vector_access;
};
bool_t operator==(const vector_int64& left, const vector_int64& right);
bool_t operator!=(const vector_int64& left, const vector_int64& right);
class vector_string final {
public:
    vector_string() noexcept = default;
    ~vector_string();
    vector_string(const vector_string&);
    vector_string(vector_string&&) noexcept;
    vector_string& operator=(const vector_string&);
    vector_string& operator=(vector_string&&) noexcept;
    int64 size() const;
    bool_t empty() const noexcept;
    void clear() noexcept;
    bool_t remove(int64 index);
    bool_t has(int64 index) const noexcept;
    void append(string value);
    string at(int64 index) const;
    void set(int64 index, string value);
    // Compiler traversal API: caller keeps this wrapper alive; no element references escape.
    int64 iteration_limit() const;
    bool_t iteration_next(int64& position, int64 limit, string& value) const;
    bool_t iteration_next(int64& position, int64 limit, int64& key, string& value) const;
    string at(int index) const;
    void append(const char* value);
    void set(int64 index, const char* value);
    void set(int index, string value);
    void set(int index, const char* value);
#ifdef __SIZEOF_INT128__
void at(__int128) const = delete;
#endif
void at(bool) const = delete;
void at(char) const = delete;
void at(char16_t) const = delete;
void at(char32_t) const = delete;
void at(char8_t) const = delete;
void at(decltype(nullptr)) const = delete;
void at(double) const = delete;
void at(float) const = delete;
void at(long double) const = delete;
void at(long long) const = delete;
void at(short) const = delete;
void at(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void at(unsigned __int128) const = delete;
#endif
void at(unsigned char) const = delete;
void at(unsigned int) const = delete;
void at(unsigned long) const = delete;
void at(unsigned long long) const = delete;
void at(unsigned short) const = delete;
void at(const void*) const = delete;
void at(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void remove(__int128) = delete;
#endif
void remove(bool) = delete;
void remove(char) = delete;
void remove(char16_t) = delete;
void remove(char32_t) = delete;
void remove(char8_t) = delete;
void remove(decltype(nullptr)) = delete;
void remove(double) = delete;
void remove(float) = delete;
void remove(int) = delete;
void remove(long double) = delete;
void remove(long long) = delete;
void remove(short) = delete;
void remove(signed char) = delete;
#ifdef __SIZEOF_INT128__
void remove(unsigned __int128) = delete;
#endif
void remove(unsigned char) = delete;
void remove(unsigned int) = delete;
void remove(unsigned long) = delete;
void remove(unsigned long long) = delete;
void remove(unsigned short) = delete;
void remove(const void*) = delete;
void remove(wchar_t) = delete;
#ifdef __SIZEOF_INT128__
void has(__int128) const = delete;
#endif
void has(bool) const = delete;
void has(char) const = delete;
void has(char16_t) const = delete;
void has(char32_t) const = delete;
void has(char8_t) const = delete;
void has(decltype(nullptr)) const = delete;
void has(double) const = delete;
void has(float) const = delete;
void has(int) const = delete;
void has(long double) const = delete;
void has(long long) const = delete;
void has(short) const = delete;
void has(signed char) const = delete;
#ifdef __SIZEOF_INT128__
void has(unsigned __int128) const = delete;
#endif
void has(unsigned char) const = delete;
void has(unsigned int) const = delete;
void has(unsigned long) const = delete;
void has(unsigned long long) const = delete;
void has(unsigned short) const = delete;
void has(const void*) const = delete;
void has(wchar_t) const = delete;
#ifdef __SIZEOF_INT128__
void set(__int128, const char*) = delete;
#endif
#ifdef __SIZEOF_INT128__
void set(__int128, string) = delete;
#endif
void set(bool, const char*) = delete;
void set(bool, string) = delete;
void set(char, const char*) = delete;
void set(char, string) = delete;
void set(char16_t, const char*) = delete;
void set(char16_t, string) = delete;
void set(char32_t, const char*) = delete;
void set(char32_t, string) = delete;
void set(char8_t, const char*) = delete;
void set(char8_t, string) = delete;
void set(decltype(nullptr), const char*) = delete;
void set(decltype(nullptr), string) = delete;
void set(double, const char*) = delete;
void set(double, string) = delete;
void set(float, const char*) = delete;
void set(float, string) = delete;
void set(long double, const char*) = delete;
void set(long double, string) = delete;
void set(long long, const char*) = delete;
void set(long long, string) = delete;
void set(short, const char*) = delete;
void set(short, string) = delete;
void set(signed char, const char*) = delete;
void set(signed char, string) = delete;
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, const char*) = delete;
#endif
#ifdef __SIZEOF_INT128__
void set(unsigned __int128, string) = delete;
#endif
void set(unsigned char, const char*) = delete;
void set(unsigned char, string) = delete;
void set(unsigned int, const char*) = delete;
void set(unsigned int, string) = delete;
void set(unsigned long long, const char*) = delete;
void set(unsigned long long, string) = delete;
void set(unsigned long, const char*) = delete;
void set(unsigned long, string) = delete;
void set(unsigned short, const char*) = delete;
void set(unsigned short, string) = delete;
void set(const void*, const char*) = delete;
void set(const void*, string) = delete;
void set(wchar_t, const char*) = delete;
void set(wchar_t, string) = delete;
private:
    struct storage;
    storage* storage_ = nullptr;
    friend struct detail::vector_access;
};
bool_t operator==(const vector_string& left, const vector_string& right);
bool_t operator!=(const vector_string& left, const vector_string& right);
namespace str { vector_string split(const string& subject, const string& separator); }
namespace str { enum class split_policy { remainder, cap }; vector_string split(const string& subject, const string& separator, int64 limit, split_policy policy); }
namespace str { string join(const vector_string& pieces, const string& separator); }
}
