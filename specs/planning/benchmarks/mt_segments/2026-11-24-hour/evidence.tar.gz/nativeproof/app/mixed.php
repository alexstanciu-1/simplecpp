function parallel(): int { return 7; }
function tick(int &$calls, int $result): int {
    $calls += 1;
    return $result;
}
function capped_batch(vector<int> &$ids, int $parts, int $limit, int &$calls): vector<int> {
    return parallel (workers: 5) {
        job (each: $part in 0 ..< $parts, workers: tick($calls, $limit),
             read: $id = segment($ids,$part,1)) { return note_entry($id[0]); }
        sibling(segment($ids,12,1));
        sibling(segment($ids,13,1));
    };
}
function independent_caps(vector<int> &$ids): vector<int> {
    return parallel {
        job (each: $i in 0 ..< 4, workers: 1,
             read: $id = segment($ids,$i,1)) { return note_entry($id[0]); }
        job (each: $i in 0 ..< 10, workers: 2,
             read: $id = segment($ids,balanced_range(14,14,$i + 4))) { return note_entry($id[0]); }
    };
}
function sibling(read_segment<int> $id): int { return note_entry($id[0]); }
function mixed_each(int $parts): int {
    $calls = 0;
    $cells vector<int> = [0,0,0];
    $results = parallel (workers: tick($calls, 1)) {
        job (each: $i in 0 ..< tick($calls, $parts), write: $a = segment($cells,$i,1),
             value: $v = tick($calls,$i)) { $a[0] = $v; return $i; }
        single_slot(segment($cells,2,1));
        job (each: $i in 0 ..< 1, read: $a = segment($cells,0,0)) { return 9; }
    };
    return $calls * 100 + $results[$parts] + $results[$parts + 1];
}
function each_batch(vector<int> &$entries, vector<int> &$output, int $parts, int $cap, int $width): vector<int> {
    return parallel (workers: $cap) {
        job (each: $part in 0 ..< $parts,
             workers: 3, write: $entered = segment($entries,$part,1),
             write: $dst = segment($output,balanced_range($width,$width,$part % $width)),
             value: $base = $part + 10) {
            $entered[0] = $entered[0] + 1;
            $dst[0] = $base;
            return $part;
        }
    };
}
function range_batch(const vector<int> &$input, vector<int> &$output, int $parts, int $part): vector<int> {
    $range = balanced_range(count($input), $parts, $part);
    return parallel {
        job (read: $src = segment($input,$range), write: $dst = segment($output,$range)) {
            $i = 0;
            while ($i < count($src)) {
                $dst[$i] = $src[$i];
                $i += 1;
            }
            return $i;
        }
    };
}
function grow_for_range(vector<int> &$cells, int &$calls): segment_range {
    $cells[] = 2;
    $calls += 1;
    return balanced_range(count($cells),2,1);
}
function snapshot_range(): int {
    $cells vector<int> = [1];
    $calls = 0;
    $s = mt_join(single_slot(segment($cells,0,1)), single_slot(segment($cells,grow_for_range($cells,$calls))));
    return $calls * 100 + $s[0] + $s[1];
}
function range_for(int $size, int $parts, int $part): segment_range {
    return balanced_range($size,$parts,$part);
}
function range_end(segment_range $range): int { return $range->offset + $range->length; }
function read_first(read_segment<Point> $points): int { return $points[0]->x; }
function relay_read(read_segment<Point> $points): int { return read_first($points); }
function read_batch(const vector<Point> &$rows, vector<int> &$cells, int $offset): vector<int> {
    return parallel {
        relay_read(segment($rows,0,2));
        job (read: $points = segment($rows,0,1), read: $a = segment($cells,1,1),
             write: $out = segment($cells,$offset,1), value: $extra = 1) {
            $out[0] = relay_read($points) + $a[0] + $extra;
            return $out[0];
        }
    };
}
function check_snapshots(): void {
    $snap vector<int> = [5];
    $seed = 2;
    $s = parallel {
        single_slot(segment($snap,0,1));
        job (value: $first = $seed, write: $dst = segment($snap,1,1),
             value: $second = extend_input($snap,$seed), value: $rate = 0.5) {
            if ($rate < 1.0) { $first += 10; }
            $dst[0] = $first + $second;
            return $dst[0];
        }
    };
    echo $seed, count($snap), $s[0], $s[1], $snap[1];
}
function extend_input(vector<int> &$cells, int &$seed): int {
    $seed += 1;
    $cells[] = $seed;
    return $seed;
}
function check_blocks(vector<int> &$cells): void {
    $more = parallel { job (write: $cell = segment($cells,0,1)) { return single_slot($cell); } };
    parallel { single_slot(segment($cells,0,1)); };
    echo $more[0], $cells[0], parallel();
}
const int WIDTH = 5;
const int LIMIT = WIDTH * 2;
function adjustment(): int { return LIMIT; }
function mixed_batch(vector<int> &$cells, vector<int> &$alias, int $last): vector<int> {
    return mt_join(single_slot(segment($cells,0,1)),
                   three_slots(segment($cells,1,1), segment($cells,2,1), segment($alias,$last,1)));
}
function pair_batch(vector<int> &$cells, vector<int> &$alias, int $offset): vector<int> {
    return parallel {
        single_slot(segment($cells,3,1));
        job (write: $prices = segment($cells,0,1), write: $fees = segment($alias,$offset,1)) {
            $sum = 0;
            $i = 0;
            while ($i < count($prices)) {
                $prices[$i] = $prices[$i] + $fees[$i];
                $fees[$i] = 0;
                $sum += $prices[$i];
                $i += 1;
            }
            return $sum;
        }
    };
}
function single_slot(segment<int> $a): int {
    if (Point::ENABLED) { $a[0] = $a[0] + adjustment(); }
    return $a[0];
}
function three_slots(segment<int> $a, segment<int> $b, segment<int> $c): int {
    $a[0] = $a[0] + 20 + STR_PAD_LEFT;
    $b[0] = $b[0] + 30;
    $c[0] = $c[0] + 40;
    return $a[0] + $b[0] + $c[0];
}
