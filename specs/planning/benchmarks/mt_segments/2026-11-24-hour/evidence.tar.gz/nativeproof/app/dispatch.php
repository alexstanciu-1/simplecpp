function dispatch(vector<Point> &$rows, vector<int> &$deltas, vector<int> &$other, int $offset): vector<int>{ return parallel (workers: 2) {
        work(segment($rows,0,1), segment($deltas,0,1));
        job (value: $enabled = true, write: $points = segment($rows,1,1),
             value: $index = $offset - 1, write: $changes = segment($other,$offset,1)) {
            if (!$enabled) { return 0; }
            return update($points, $changes, $index);
        }
        job (each: $part in 0..<2, workers: 1, read: $empty = segment($rows,balanced_range(0,2,$part))) { return $part + count($empty); }
    }; }