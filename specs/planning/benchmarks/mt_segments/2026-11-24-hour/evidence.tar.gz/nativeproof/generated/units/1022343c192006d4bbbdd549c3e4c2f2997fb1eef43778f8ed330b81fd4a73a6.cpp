// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/hashes.hpp>
#include <scpp/mt_segment.hpp>
#include <scpp/mt_segments.hpp>
#include <scpp/string.hpp>
#include <scpp/vectors.hpp>
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
namespace App {
class scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de;
::scpp::vector_int64 hash_batch_([[maybe_unused]] ::scpp::hash_int64_int64 &var_table_0, [[maybe_unused]] ::scpp::hash_int64_int64 &var_alias_1, [[maybe_unused]] ::scpp::vector_int64 &var_entered_2, [[maybe_unused]] ::scpp::int64 var_offset_3);
::scpp::int64 read_order_([[maybe_unused]] ::scpp::mt::segment var_s_0);
::scpp::vector_int64 read_pair_([[maybe_unused]] ::scpp::hash_int64_int64 &var_table_0, [[maybe_unused]] ::scpp::int64 var_offset_1, [[maybe_unused]] ::scpp::int64 var_length_2);
::scpp::int64 record_hash_();
::scpp::int64 update_hash_([[maybe_unused]] ::scpp::mt::segment var_s_0);
}
#include "a2ce18fdad2a0d6054422a6e3f424c7dcda7bdf45263f956df2073e0911b85ac.hpp"
namespace App {
::scpp::int64 record_hash_()
{
	[[maybe_unused]] scpp_records::Point var_one_0 = {};
	[[maybe_unused]] scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de var_records_1 = scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de{};
	var_records_1.set(scpp::string{"a", 1}, var_one_0);
	var_records_1.set(scpp::string{"b", 1}, var_one_0);
	[[maybe_unused]] scpp::vector_int64 var_result_2 = ([&]() { const struct values_0 { ::scpp::mt::segment_range range0; } snapshot_0{::scpp::mt::balanced_range(2LL, 1LL, 0LL)}; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow_hash(var_records_1, snapshot_0.range0.offset, snapshot_0.range0.length) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_slice_0) -> ::scpp::int64 {
{ const auto hash_view = var_slice_0; int64_t hash_cursor = 0; while (hash_view.next(hash_cursor)) {
[[maybe_unused]] const auto& var_key_1 = *static_cast<const scpp::string*>(hash_view.key(hash_cursor));
[[maybe_unused]] auto& var_row_2 = *static_cast<scpp_records::Point*>(hash_view.writable_value(hash_cursor));
	if (((var_key_1 == scpp::string{"b", 1}))) {
		(var_row_2).x = 5LL;
	}
} }
	return (var_slice_0).count();
}(inputs[0]); }}}; ::scpp::mt::join(jobs, 1); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	return ([&]() -> scpp::int64 { const auto binary_left = ([&]() -> scpp::int64 { const auto binary_left = (var_result_2).at(0L); const auto binary_right = (var_records_1.at(scpp::string{"a", 1})).x; return (binary_left + binary_right); }()); const auto binary_right = (var_records_1.at(scpp::string{"b", 1})).x; return (binary_left + binary_right); }());
}

::scpp::int64 read_order_([[maybe_unused]] ::scpp::mt::segment var_s_0)
{
	[[maybe_unused]] scpp::int64 var_order_1 = 0;
{ const auto hash_view = var_s_0; int64_t hash_cursor = 0; while (hash_view.next(hash_cursor)) {
[[maybe_unused]] const auto& var_key_2 = *static_cast<const scpp::int64*>(hash_view.key(hash_cursor));
[[maybe_unused]] auto& var_v_3 = *static_cast<const scpp::int64*>(hash_view.value(hash_cursor));
	var_order_1 = ((var_order_1 * 10LL) + var_key_2);
} }
	return var_order_1;
}

::scpp::vector_int64 read_pair_([[maybe_unused]] ::scpp::hash_int64_int64 &var_table_0, [[maybe_unused]] ::scpp::int64 var_offset_1, [[maybe_unused]] ::scpp::int64 var_length_2)
{
	return ([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow_hash_read(var_table_0, var_offset_1, var_length_2) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow_hash_read(var_table_0, var_offset_1, var_length_2) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return read_order_(inputs[0]); }}, {grants_1, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_s_0) -> ::scpp::int64 {
	return (var_s_0).count();
}(inputs[0]); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::int64 update_hash_([[maybe_unused]] ::scpp::mt::segment var_s_0)
{
	[[maybe_unused]] scpp::int64 var_order_1 = 0;
{ const auto hash_view = var_s_0; int64_t hash_cursor = 0; while (hash_view.next(hash_cursor)) {
[[maybe_unused]] const auto& var_key_2 = *static_cast<const scpp::int64*>(hash_view.key(hash_cursor));
[[maybe_unused]] auto& var_value_3 = *static_cast<scpp::int64*>(hash_view.writable_value(hash_cursor));
	var_order_1 = ((var_order_1 * 10LL) + var_key_2);
	var_value_3 += 10LL;
} }
	return var_order_1;
}

::scpp::vector_int64 hash_batch_([[maybe_unused]] ::scpp::hash_int64_int64 &var_table_0, [[maybe_unused]] ::scpp::hash_int64_int64 &var_alias_1, [[maybe_unused]] ::scpp::vector_int64 &var_entered_2, [[maybe_unused]] ::scpp::int64 var_offset_3)
{
	return ([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_entered_2, 0LL, 1LL), ::scpp::mt::job::borrow_hash(var_table_0, 1LL, 2LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_entered_2, 1LL, 1LL), ::scpp::mt::job::borrow_hash_read(var_alias_1, var_offset_3, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_flag_0, [[maybe_unused]] ::scpp::mt::segment var_slice_1) -> ::scpp::int64 {
	{ auto& slot = (*static_cast<scpp::int64*>((var_flag_0).at(0LL)));  slot = 1L; }
	return update_hash_(var_slice_1);
}(inputs[0], inputs[1]); }}, {grants_1, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_flag_0, [[maybe_unused]] ::scpp::mt::segment var_slice_1) -> ::scpp::int64 {
	{ auto& slot = (*static_cast<scpp::int64*>((var_flag_0).at(0LL)));  slot = 1L; }
{ const auto hash_view = var_slice_1; int64_t hash_cursor = 0; while (hash_view.next(hash_cursor)) {
[[maybe_unused]] const auto& var_key_2 = *static_cast<const scpp::int64*>(hash_view.key(hash_cursor));
[[maybe_unused]] auto& var_value_3 = *static_cast<const scpp::int64*>(hash_view.value(hash_cursor));
	return var_key_2;
} }
	return 0LL;
}(inputs[0], inputs[1]); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}
}
