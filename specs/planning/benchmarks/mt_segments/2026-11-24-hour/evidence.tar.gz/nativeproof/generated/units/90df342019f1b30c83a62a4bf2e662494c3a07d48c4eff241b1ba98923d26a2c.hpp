// Concrete application collection; include after complete element declarations.
#ifndef SCPP_CONCRETE_90DF342019F1B30C83A62A4BF2E662494C3A07D48C4EFF241B1BA98923D26A2C
#define SCPP_CONCRETE_90DF342019F1B30C83A62A4BF2E662494C3A07D48C4EFF241B1BA98923D26A2C
#include <scpp/core/scalars.hpp>
#include <scpp/value_error.hpp>
namespace scpp::mt { struct job; }
#ifndef SCPP_CONCRETE_SUPPORT_F5F7B1BC89D81F37010A220417F93DE3A62C697E0E3DD9D8D511FBEB729705EB
#define SCPP_CONCRETE_SUPPORT_F5F7B1BC89D81F37010A220417F93DE3A62C697E0E3DD9D8D511FBEB729705EB

#include <stddef.h>
#include <cstddef>
#include <stdint.h>
#include <new>
#include <stdexcept>

namespace scpp::detail {
// Shared untyped allocation mechanics; concrete generated code owns every element lifetime.
inline size_t vector_capacity_limit(size_t element_size) noexcept {
    return static_cast<size_t>(PTRDIFF_MAX) / element_size;
}
inline size_t vector_growth(size_t capacity, size_t required, size_t element_size) {
    const auto limit = vector_capacity_limit(element_size);
    if (required > limit) throw std::length_error("vector_too_large");
    const auto grown = capacity == 0 ? (limit < 4 ? limit : 4)
        : (capacity > limit / 2 ? limit : capacity * 2);
    return grown < required ? required : grown;
}
inline unsigned char* vector_allocate(size_t capacity, size_t element_size, size_t alignment) {
    if (capacity > vector_capacity_limit(element_size)) throw std::length_error("vector_too_large");
    if (capacity == 0) return nullptr;
    const auto bytes = capacity * element_size;
    return static_cast<unsigned char*>(alignment > __STDCPP_DEFAULT_NEW_ALIGNMENT__
        ? ::operator new(bytes, static_cast<std::align_val_t>(alignment)) : ::operator new(bytes));
}
inline void vector_deallocate(unsigned char* data, size_t alignment) noexcept {
    if (alignment > __STDCPP_DEFAULT_NEW_ALIGNMENT__) ::operator delete(data, static_cast<std::align_val_t>(alignment));
    else ::operator delete(data);
}
inline size_t vector_index(int64_t index, size_t count) {
    if (index < 0 || static_cast<uint64_t>(index) >= count) throw std::out_of_range("sequence_index_out_of_range");
    return static_cast<size_t>(index);
}
}

#endif
namespace App {
using ::scpp::bool_t;
namespace detail { struct access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20; }
class scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 final {
public:
struct iteration_output {
    using value_type = scpp_records::Point;
    // Compiler-owned copied value; empty construction never invokes the element constructor.
    union { value_type value; unsigned char empty[sizeof(value_type)]; };
    bool active = false;
    iteration_output() noexcept : empty{} {}
    iteration_output(const iteration_output&) = delete;
    iteration_output& operator=(const iteration_output&) = delete;
    iteration_output(iteration_output&& other) noexcept : empty{} {
        if (other.active) { ::new (&value) value_type(static_cast<value_type&&>(other.value)); active = true; }
    }
    ~iteration_output() { if (active) value.~value_type(); }
    void publish(value_type selected) noexcept {
        if (active) value = static_cast<value_type&&>(selected);
        else { ::new (&value) value_type(static_cast<value_type&&>(selected)); active = true; }
    }
};
    bool_t iteration_next(scpp::int64& position, scpp::int64 limit, iteration_output& output) const;
    bool_t iteration_next(scpp::int64& position, scpp::int64 limit, scpp::int64& key, iteration_output& output) const;

    scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20() noexcept = default;
    ~scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20();
    scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20(const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&);
    scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20(scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&&) noexcept;
    scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& operator=(const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&);
    scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& operator=(scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&&) noexcept;
    scpp::int64 size() const;
    bool_t empty() const noexcept;
    void clear() noexcept;
    bool_t remove(scpp::int64 index);
    bool_t has(scpp::int64 index) const noexcept;
    void append(scpp_records::Point value);
    scpp_records::Point at(scpp::int64 index) const;
    void set(scpp::int64 index, scpp_records::Point value);
    // Compiler traversal API: caller keeps this wrapper alive; no element references escape.
    scpp::int64 iteration_limit() const;
    bool_t iteration_next(scpp::int64& position, scpp::int64 limit, scpp_records::Point& value) const;
    bool_t iteration_next(scpp::int64& position, scpp::int64 limit, scpp::int64& key, scpp_records::Point& value) const;
    void reserve(scpp::int64 count);

private:
    friend struct ::scpp::mt::job;
    scpp_records::Point* mt_data() noexcept;
    const scpp_records::Point* mt_data() const noexcept;

struct storage;
storage* storage_ = nullptr;
friend struct detail::access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
friend struct destination_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
};
struct scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::storage {
    using element_type = scpp_records::Point;
static_assert(__is_constructible(element_type, const element_type&), "collections/vector requires e.copy_constructible");
static element_type& element_type_contract_value() noexcept;
static_assert(noexcept(element_type_contract_value().~element_type()), "collections/vector requires e.nothrow_destructible");
static_assert(__is_nothrow_assignable(element_type&, element_type&&), "collections/vector requires e.nothrow_move_assignable");
static_assert(__is_nothrow_constructible(element_type, element_type&&), "collections/vector requires e.nothrow_move_constructible");

    unsigned char* data = nullptr;
    std::size_t count = 0;
    std::size_t capacity = 0;

    storage() noexcept = default;
    storage(const storage& other) {
        data = ::scpp::detail::vector_allocate(other.count, sizeof(element_type), alignof(element_type));
        capacity = other.count;
        try {
            while (count < other.count) {
                ::new (data + count * sizeof(element_type)) element_type(other[count]);
                ++count;
            }
        } catch (...) {
            clear();
            ::scpp::detail::vector_deallocate(data, alignof(element_type));
            throw;
        }
    }
    storage& operator=(const storage&) = delete;
    ~storage() { clear(); ::scpp::detail::vector_deallocate(data, alignof(element_type)); }
    std::size_t size() const noexcept { return count; }
    bool empty() const noexcept { return count == 0; }
    const element_type* iteration_select(scpp::int64 position, scpp::int64 limit) const noexcept {
        return position < limit && static_cast<unsigned long long>(position) < count
            ? &(*this)[static_cast<std::size_t>(position)] : nullptr;
    }
    element_type& operator[](std::size_t index) noexcept { return *reinterpret_cast<element_type*>(data + index * sizeof(element_type)); }
    const element_type& operator[](std::size_t index) const noexcept { return *reinterpret_cast<const element_type*>(data + index * sizeof(element_type)); }
    const element_type& front() const noexcept { return (*this)[0]; }
    void clear() noexcept { while (count != 0) (*this)[--count].~element_type(); }
    void reserve(std::size_t required) {
        if (required <= capacity) return;
        const auto next_capacity = ::scpp::detail::vector_growth(capacity, required, sizeof(element_type));
        auto* next = ::scpp::detail::vector_allocate(next_capacity, sizeof(element_type), alignof(element_type));
        for (std::size_t i = 0; i < count; ++i) {
            ::new (next + i * sizeof(element_type)) element_type(static_cast<element_type&&>((*this)[i]));
            (*this)[i].~element_type();
        }
        ::scpp::detail::vector_deallocate(data, alignof(element_type));
        data = next;
        capacity = next_capacity;
    }
    void append(element_type&& value) {
        reserve(count + 1);
        ::new (data + count * sizeof(element_type)) element_type(static_cast<element_type&&>(value));
        ++count;
    }
    void remove(std::size_t offset) noexcept {
        for (std::size_t i = offset; i + 1 < count; ++i) (*this)[i] = static_cast<element_type&&>((*this)[i + 1]);
        (*this)[--count].~element_type();
    }
};

namespace detail { struct access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 {
    static const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::storage& read(const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& value) noexcept { static const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::storage empty; return value.storage_ ? *value.storage_ : empty; }

}; }
inline scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::~scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20() { delete storage_; }
inline scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20(const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
inline scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20(scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&& other) noexcept : storage_(other.storage_) { other.storage_ = nullptr; }
inline scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::operator=(const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& other) { if (this != &other) { scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 copy(other); auto* old = storage_; storage_ = copy.storage_; copy.storage_ = old; } return *this; }
inline scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20& scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::operator=(scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20&& other) noexcept { if (this != &other) { delete storage_; storage_ = other.storage_; other.storage_ = nullptr; } return *this; }
inline scpp::int64 scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::size() const { return static_cast<scpp::int64>(detail::access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::read(*this).size()); }
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::empty() const noexcept { return detail::access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::read(*this).empty(); }
inline void scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::clear() noexcept { if (storage_) storage_->clear(); }
inline void scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::append(scpp_records::Point value) {
    if (storage_) { storage_->append(static_cast<scpp_records::Point&&>(value)); return; }
    auto* fresh = new storage;
    try { fresh->append(static_cast<scpp_records::Point&&>(value)); }
    catch (...) { delete fresh; throw; }
    storage_ = fresh;
}
inline scpp_records::Point scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::at(scpp::int64 index) const { const auto& values = detail::access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::read(*this); return values[::scpp::detail::vector_index(index, values.size())]; }
inline void scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::set(scpp::int64 index, scpp_records::Point value) { const auto offset = ::scpp::detail::vector_index(index, detail::access_scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::read(*this).size()); (*storage_)[offset] = static_cast<scpp_records::Point&&>(value); }
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::remove(scpp::int64 index) {
    if (!has(index)) return false;
    storage_->remove(static_cast<std::size_t>(index));
    return true;
}
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::has(scpp::int64 index) const noexcept {
    return index >= 0 && storage_ && static_cast<unsigned long long>(index) < storage_->size();
}
inline scpp_records::Point* scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::mt_data() noexcept { return storage_ ? reinterpret_cast<scpp_records::Point*>(storage_->data) : nullptr; }
inline const scpp_records::Point* scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::mt_data() const noexcept { return storage_ ? reinterpret_cast<const scpp_records::Point*>(storage_->data) : nullptr; }
inline void scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::reserve(scpp::int64 count) {
    if (count < 0) throw ::scpp::ValueError("negative_vector_capacity");
    if (static_cast<unsigned long long>(count) > ::scpp::detail::vector_capacity_limit(sizeof(scpp_records::Point)))
        throw std::length_error("vector_capacity_out_of_range");
    if (count == 0) return;
    if (storage_) { storage_->reserve(static_cast<std::size_t>(count)); return; }
    auto* fresh = new storage;
    try { fresh->reserve(static_cast<std::size_t>(count)); }
    catch (...) { delete fresh; throw; }
    storage_ = fresh;
}
inline scpp::int64 scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::iteration_limit() const { return size(); }
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::iteration_next(scpp::int64& position, scpp::int64 limit, scpp_records::Point& value) const {
    scpp::int64 key;
    return iteration_next(position, limit, key, value);
}
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::iteration_next(scpp::int64& position, scpp::int64 limit, scpp::int64& key, scpp_records::Point& value) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    const auto* item = storage_ ? storage_->iteration_select(position, limit) : nullptr;
    if (!item) return false;
    auto selected = *item;
    const auto selected_key = position;
    ++position;
    key = selected_key;
    value = static_cast<scpp_records::Point&&>(selected);
    return true;
}

inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::iteration_next(scpp::int64& position, scpp::int64 limit, iteration_output& output) const {
    scpp::int64 key;
    return iteration_next(position, limit, key, output);
}
inline bool_t scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20::iteration_next(scpp::int64& position, scpp::int64 limit, scpp::int64& key, iteration_output& output) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    const auto* item = storage_ ? storage_->iteration_select(position, limit) : nullptr;
    if (!item) return false;
    auto selected = *item;
    key = position++;
    output.publish(static_cast<scpp_records::Point&&>(selected));
    return true;
}

}

#endif
