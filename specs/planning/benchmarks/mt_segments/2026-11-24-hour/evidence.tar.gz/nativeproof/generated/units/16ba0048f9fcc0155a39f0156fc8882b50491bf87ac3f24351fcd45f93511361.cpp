// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include "16ba0048f9fcc0155a39f0156fc8882b50491bf87ac3f24351fcd45f93511361.hpp"
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
#include "aa95c45d84019dc4f58e62e37172bc144bbff580540d63fc67612d3f6a635d0c.hpp"
namespace App {
::scpp::int64 work_([[maybe_unused]] ::scpp::mt::segment var_rows_0, [[maybe_unused]] ::scpp::mt::segment var_deltas_1)
{
	[[maybe_unused]] scpp::int64 var_i_2 = 0;
	[[maybe_unused]] scpp::int64 var_subtotal_3 = 0;
	while (([&]() -> scpp::bool_t { const auto binary_left = var_i_2; const auto binary_right = (var_rows_0).count(); return (binary_left < binary_right); }())) {
		{ const auto compound_previous = var_subtotal_3; var_subtotal_3 = (compound_previous + ([&]() -> scpp::int64 { scpp::mt::segment argument_38_0 = var_rows_0; scpp::mt::segment argument_38_1 = var_deltas_1; return update_(static_cast<scpp::mt::segment&&>(argument_38_0), static_cast<scpp::mt::segment&&>(argument_38_1), var_i_2); }())); }
		var_i_2 += 1LL;
	}
	return var_subtotal_3;
}
}
