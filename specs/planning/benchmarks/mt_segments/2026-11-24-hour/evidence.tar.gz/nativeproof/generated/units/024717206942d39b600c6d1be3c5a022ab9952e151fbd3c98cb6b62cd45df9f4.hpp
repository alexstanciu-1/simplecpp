// Generated cross-unit declarations.
#pragma once
#include <scpp/core/scalars.hpp>
namespace App {
::scpp::int64 note_entry_([[maybe_unused]] ::scpp::int64 var_id_0);
}
