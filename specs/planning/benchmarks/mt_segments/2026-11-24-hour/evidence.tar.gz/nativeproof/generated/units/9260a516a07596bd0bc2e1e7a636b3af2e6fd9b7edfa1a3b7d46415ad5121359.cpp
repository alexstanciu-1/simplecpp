// Generated from completed source-owned bodies.
#include <scpp/entry.hpp>
SCPP_REQUIRE_ENTRY_TARGET(31);

#include <scpp/core/scalars.hpp>
#include <scpp/output.hpp>
#include <scpp/value_error.hpp>
#include <scpp/vectors.hpp>
#include "16ed3a3db181da836b71e07f20691b990547f4b0f014f8d246cc123a73d511cb.hpp"
#include "4188f199e401dbc855e82231c5d2c25534d78b51ea04bf60ba170bdc56c7b033.hpp"
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
namespace App {
class scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
}
#include "90df342019f1b30c83a62a4bf2e662494c3a07d48c4eff241b1ba98923d26a2c.hpp"
namespace App {
int scpp_entry_body()
{
	[[maybe_unused]] scpp_records::Point var_p_0 = {};
	[[maybe_unused]] scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 var_rows_1 = scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20{};
	(var_rows_1).append(var_p_0);
	(var_rows_1).append(var_p_0);
	(var_rows_1).append(var_p_0);
	[[maybe_unused]] scpp::vector_int64 var_deltas_2 = ([&]() {
    scpp::int64 input[]{2L, 4L, 6L};
    return scpp::vector_int64::from_owned(input, 3);
}());
	[[maybe_unused]] scpp::int64 var_split_3 = 1;
	[[maybe_unused]] scpp::vector_int64 var_out_4 = dispatch_(var_rows_1, var_deltas_2, var_deltas_2, var_split_3);
	scpp::echo_int((var_out_4).at(0L));
	scpp::echo_int((var_out_4).at(1L));
	scpp::echo_int(((var_rows_1).at(0L)).x);
	scpp::echo_int(((var_rows_1).at(1L)).x);
	scpp::echo_int(((var_rows_1).at(2L)).x);
	scpp::echo_int((var_deltas_2).at(0L));
	scpp::echo_int((var_deltas_2).at(1L));
	scpp::echo_int((var_deltas_2).at(2L));
	[[maybe_unused]] scpp::vector_int64 var_cells_5 = ([&]() {
    scpp::int64 input[]{1L, 2L, 3L, 4L};
    return scpp::vector_int64::from_owned(input, 4);
}());
	[[maybe_unused]] scpp::vector_int64 var_m_6 = mixed_batch_(var_cells_5, var_cells_5, 3LL);
	scpp::echo_int((var_m_6).at(0L));
	scpp::echo_int((var_m_6).at(1L));
	scpp::echo_int((var_cells_5).at(0L));
	scpp::echo_int((var_cells_5).at(1L));
	scpp::echo_int((var_cells_5).at(2L));
	scpp::echo_int((var_cells_5).at(3L));
	check_blocks_(var_cells_5);
	[[maybe_unused]] scpp::vector_int64 var_fresh_7 = ([&]() {
    scpp::int64 input[]{1L, 2L, 3L, 4L};
    return scpp::vector_int64::from_owned(input, 4);
}());
	[[maybe_unused]] scpp::vector_int64 var_pair_8 = pair_batch_(var_fresh_7, var_fresh_7, 1LL);
	scpp::echo_int((var_pair_8).at(0L));
	scpp::echo_int((var_pair_8).at(1L));
	scpp::echo_int((var_fresh_7).at(0L));
	scpp::echo_int((var_fresh_7).at(1L));
	check_snapshots_();
	scpp::echo_int(mixed_each_(0LL));
	scpp::echo_int(mixed_each_(2LL));
	[[maybe_unused]] scpp::vector_int64 var_r_9 = read_batch_(var_rows_1, var_fresh_7, 0LL);
	scpp::echo_int((var_r_9).at(0L));
	scpp::echo_int((var_r_9).at(1L));
	scpp::echo_int((var_fresh_7).at(0L));
	return 0;
}
}
