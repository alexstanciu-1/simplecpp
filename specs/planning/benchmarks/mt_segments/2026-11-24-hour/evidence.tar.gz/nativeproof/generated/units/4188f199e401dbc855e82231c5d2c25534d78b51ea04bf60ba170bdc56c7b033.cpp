// Generated from completed source-owned bodies.
#include <scpp/arithmetic.hpp>
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include <scpp/mt_segments.hpp>
#include <scpp/output.hpp>
#include <scpp/value_error.hpp>
#include <scpp/vectors.hpp>
#include <stdexcept>
#include <vector>
#include "024717206942d39b600c6d1be3c5a022ab9952e151fbd3c98cb6b62cd45df9f4.hpp"
#include "4188f199e401dbc855e82231c5d2c25534d78b51ea04bf60ba170bdc56c7b033.hpp"
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
namespace App {
class scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
::scpp::int64 adjustment_();
::scpp::vector_int64 capped_batch_([[maybe_unused]] ::scpp::vector_int64 &var_ids_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_limit_2, [[maybe_unused]] ::scpp::int64 &var_calls_3);
::scpp::vector_int64 each_batch_([[maybe_unused]] ::scpp::vector_int64 &var_entries_0, [[maybe_unused]] ::scpp::vector_int64 &var_output_1, [[maybe_unused]] ::scpp::int64 var_parts_2, [[maybe_unused]] ::scpp::int64 var_cap_3, [[maybe_unused]] ::scpp::int64 var_width_4);
::scpp::int64 extend_input_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::int64 &var_seed_1);
::scpp::mt::segment_range grow_for_range_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::int64 &var_calls_1);
::scpp::vector_int64 independent_caps_([[maybe_unused]] ::scpp::vector_int64 &var_ids_0);
::scpp::int64 parallel_();
::scpp::vector_int64 range_batch_([[maybe_unused]] const ::scpp::vector_int64 &var_input_0, [[maybe_unused]] ::scpp::vector_int64 &var_output_1, [[maybe_unused]] ::scpp::int64 var_parts_2, [[maybe_unused]] ::scpp::int64 var_part_3);
::scpp::int64 range_end_([[maybe_unused]] ::scpp::mt::segment_range var_range_0);
::scpp::mt::segment_range range_for_([[maybe_unused]] ::scpp::int64 var_size_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_part_2);
::scpp::int64 read_first_([[maybe_unused]] ::scpp::mt::segment var_points_0);
::scpp::int64 relay_read_([[maybe_unused]] ::scpp::mt::segment var_points_0);
::scpp::int64 sibling_([[maybe_unused]] ::scpp::mt::segment var_id_0);
::scpp::int64 single_slot_([[maybe_unused]] ::scpp::mt::segment var_a_0);
::scpp::int64 snapshot_range_();
::scpp::int64 three_slots_([[maybe_unused]] ::scpp::mt::segment var_a_0, [[maybe_unused]] ::scpp::mt::segment var_b_1, [[maybe_unused]] ::scpp::mt::segment var_c_2);
::scpp::int64 tick_([[maybe_unused]] ::scpp::int64 &var_calls_0, [[maybe_unused]] ::scpp::int64 var_result_1);
}
#include "90df342019f1b30c83a62a4bf2e662494c3a07d48c4eff241b1ba98923d26a2c.hpp"
namespace App {
::scpp::int64 parallel_()
{
	return 7LL;
}

::scpp::int64 tick_([[maybe_unused]] ::scpp::int64 &var_calls_0, [[maybe_unused]] ::scpp::int64 var_result_1)
{
	var_calls_0 += 1LL;
	return var_result_1;
}

::scpp::vector_int64 capped_batch_([[maybe_unused]] ::scpp::vector_int64 &var_ids_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_limit_2, [[maybe_unused]] ::scpp::int64 &var_calls_3)
{
	return ([&]() { const auto workers = 5LL; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = var_parts_1; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); const auto workers_0 = tick_(var_calls_3, var_limit_2); if (workers_0 <= 0) throw std::invalid_argument("Job workers must be positive"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_part_4 = 0; var_part_4 < count_0; ++var_part_4) values_list_0.push_back({var_part_4, {var_part_4, 1LL}}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[1]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow_read(var_ids_0, snapshot_0.range1.offset, snapshot_0.range1.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_part_0, [[maybe_unused]] ::scpp::mt::segment var_id_1) -> ::scpp::int64 {
	return note_entry_((*static_cast<const scpp::int64*>((var_id_1).read_at(0LL))));
}(static_cast<const values_0*>(context)->v0, inputs[0]); }}); } ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow_read(var_ids_0, 12LL, 1LL) }; jobs.push_back({grants_1, [](const ::scpp::mt::segment* inputs) { return sibling_(inputs[0]); }}); ::scpp::mt::segment grants_2[]{ ::scpp::mt::job::borrow_read(var_ids_0, 13LL, 1LL) }; jobs.push_back({grants_2, [](const ::scpp::mt::segment* inputs) { return sibling_(inputs[0]); }}); const ::scpp::mt::job_entry entries[]{{values_list_0.size(), workers_0}, {1, 1}, {1, 1}}; ::scpp::mt::join(jobs.data(), jobs.size(), workers, entries, 3); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::vector_int64 independent_caps_([[maybe_unused]] ::scpp::vector_int64 &var_ids_0)
{
	return ([&]() { const auto count_0 = 4LL; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); const auto workers_0 = 1LL; if (workers_0 <= 0) throw std::invalid_argument("Job workers must be positive"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_i_1 = 0; var_i_1 < count_0; ++var_i_1) values_list_0.push_back({var_i_1, {var_i_1, 1LL}}); const auto count_1 = 10LL; if (count_1 < 0) throw std::invalid_argument("each bound must be nonnegative"); const auto workers_1 = 2LL; if (workers_1 <= 0) throw std::invalid_argument("Job workers must be positive"); struct values_1 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_1> values_list_1; values_list_1.reserve(count_1); for (::scpp::int64 var_i_2 = 0; var_i_2 < count_1; ++var_i_2) values_list_1.push_back({var_i_2, ::scpp::mt::balanced_range(14LL, 14LL, (var_i_2 + 4LL))}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[1]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow_read(var_ids_0, snapshot_0.range1.offset, snapshot_0.range1.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_i_0, [[maybe_unused]] ::scpp::mt::segment var_id_1) -> ::scpp::int64 {
	return note_entry_((*static_cast<const scpp::int64*>((var_id_1).read_at(0LL))));
}(static_cast<const values_0*>(context)->v0, inputs[0]); }}); } struct grants_1 { ::scpp::mt::segment slots[1]; }; std::vector<grants_1> grants_list_1; grants_list_1.reserve(values_list_1.size()); for (const auto& snapshot_1 : values_list_1) { grants_list_1.push_back({::scpp::mt::job::borrow_read(var_ids_0, snapshot_1.range1.offset, snapshot_1.range1.length)}); jobs.push_back({grants_list_1.back().slots, snapshot_1, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_i_0, [[maybe_unused]] ::scpp::mt::segment var_id_1) -> ::scpp::int64 {
	return note_entry_((*static_cast<const scpp::int64*>((var_id_1).read_at(0LL))));
}(static_cast<const values_1*>(context)->v0, inputs[0]); }}); } const ::scpp::mt::job_entry entries[]{{values_list_0.size(), workers_0}, {values_list_1.size(), workers_1}}; ::scpp::mt::join(jobs.data(), jobs.size(), INT64_MAX, entries, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::int64 sibling_([[maybe_unused]] ::scpp::mt::segment var_id_0)
{
	return note_entry_((*static_cast<const scpp::int64*>((var_id_0).read_at(0LL))));
}

::scpp::int64 mixed_each_([[maybe_unused]] ::scpp::int64 var_parts_0)
{
	[[maybe_unused]] scpp::int64 var_calls_1 = 0;
	[[maybe_unused]] scpp::vector_int64 var_cells_2 = ([&]() {
    scpp::int64 input[]{0L, 0L, 0L};
    return scpp::vector_int64::from_owned(input, 3);
}());
	[[maybe_unused]] scpp::vector_int64 var_results_5 = ([&]() { const auto workers = tick_(var_calls_1, 1LL); if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = tick_(var_calls_1, var_parts_0); if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; scpp::int64 v2; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_i_3 = 0; var_i_3 < count_0; ++var_i_3) values_list_0.push_back({var_i_3, {var_i_3, 1LL}, tick_(var_calls_1, var_i_3)}); const auto count_2 = 1LL; if (count_2 < 0) throw std::invalid_argument("each bound must be nonnegative"); struct values_2 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_2> values_list_2; values_list_2.reserve(count_2); for (::scpp::int64 var_i_4 = 0; var_i_4 < count_2; ++var_i_4) values_list_2.push_back({var_i_4, {0LL, 0LL}}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[1]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow(var_cells_2, snapshot_0.range1.offset, snapshot_0.range1.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_i_0, [[maybe_unused]] ::scpp::mt::segment var_a_1, [[maybe_unused]] ::scpp::int64 var_v_2) -> ::scpp::int64 {
	{ auto& slot = (*static_cast<scpp::int64*>((var_a_1).at(0LL)));  slot = var_v_2; }
	return var_i_0;
}(static_cast<const values_0*>(context)->v0, inputs[0], static_cast<const values_0*>(context)->v2); }}); } ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_cells_2, 2LL, 1LL) }; jobs.push_back({grants_1, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}); struct grants_2 { ::scpp::mt::segment slots[1]; }; std::vector<grants_2> grants_list_2; grants_list_2.reserve(values_list_2.size()); for (const auto& snapshot_2 : values_list_2) { grants_list_2.push_back({::scpp::mt::job::borrow_read(var_cells_2, snapshot_2.range1.offset, snapshot_2.range1.length)}); jobs.push_back({grants_list_2.back().slots, snapshot_2, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_i_0, [[maybe_unused]] ::scpp::mt::segment var_a_1) -> ::scpp::int64 {
	return 9LL;
}(static_cast<const values_2*>(context)->v0, inputs[0]); }}); } ::scpp::mt::join(jobs.data(), jobs.size(), workers); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	return ([&]() -> scpp::int64 { const auto binary_left = ([&]() -> scpp::int64 { const auto binary_left = (var_calls_1 * 100LL); const auto binary_right = (var_results_5).at(var_parts_0); return (binary_left + binary_right); }()); const auto binary_right = (var_results_5).at(static_cast<scpp::int64>((var_parts_0 + 1LL))); return (binary_left + binary_right); }());
}

::scpp::vector_int64 each_batch_([[maybe_unused]] ::scpp::vector_int64 &var_entries_0, [[maybe_unused]] ::scpp::vector_int64 &var_output_1, [[maybe_unused]] ::scpp::int64 var_parts_2, [[maybe_unused]] ::scpp::int64 var_cap_3, [[maybe_unused]] ::scpp::int64 var_width_4)
{
	return ([&]() { const auto workers = var_cap_3; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = var_parts_2; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); const auto workers_0 = 3LL; if (workers_0 <= 0) throw std::invalid_argument("Job workers must be positive"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; ::scpp::mt::segment_range range2; scpp::int64 v3; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_part_5 = 0; var_part_5 < count_0; ++var_part_5) values_list_0.push_back({var_part_5, {var_part_5, 1LL}, ([&]() { const auto argument_502_0 = var_width_4; const auto argument_502_1 = var_width_4; return ::scpp::mt::balanced_range(argument_502_0, argument_502_1, scpp::int64_remainder(var_part_5, var_width_4)); }()), (var_part_5 + 10LL)}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[2]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow(var_entries_0, snapshot_0.range1.offset, snapshot_0.range1.length), ::scpp::mt::job::borrow(var_output_1, snapshot_0.range2.offset, snapshot_0.range2.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_part_0, [[maybe_unused]] ::scpp::mt::segment var_entered_1, [[maybe_unused]] ::scpp::mt::segment var_dst_2, [[maybe_unused]] ::scpp::int64 var_base_3) -> ::scpp::int64 {
	{ auto& slot = (*static_cast<scpp::int64*>((var_entered_1).at(0LL)));  slot = static_cast<scpp::int64>(((*static_cast<scpp::int64*>((var_entered_1).at(0LL))) + 1LL)); }
	{ auto& slot = (*static_cast<scpp::int64*>((var_dst_2).at(0LL)));  slot = var_base_3; }
	return var_part_0;
}(static_cast<const values_0*>(context)->v0, inputs[0], inputs[1], static_cast<const values_0*>(context)->v3); }}); } const ::scpp::mt::job_entry entries[]{{values_list_0.size(), workers_0}}; ::scpp::mt::join(jobs.data(), jobs.size(), workers, entries, 1); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::vector_int64 range_batch_([[maybe_unused]] const ::scpp::vector_int64 &var_input_0, [[maybe_unused]] ::scpp::vector_int64 &var_output_1, [[maybe_unused]] ::scpp::int64 var_parts_2, [[maybe_unused]] ::scpp::int64 var_part_3)
{
	[[maybe_unused]] scpp::mt::segment_range var_range_4 = ([&]() { const auto argument_581_0 = (var_input_0).size(); const auto argument_581_1 = var_parts_2; return ::scpp::mt::balanced_range(argument_581_0, argument_581_1, var_part_3); }());
	return ([&]() { const struct values_0 { ::scpp::mt::segment_range range0; ::scpp::mt::segment_range range1; } snapshot_0{var_range_4, var_range_4}; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow_read(var_input_0, snapshot_0.range0.offset, snapshot_0.range0.length), ::scpp::mt::job::borrow(var_output_1, snapshot_0.range1.offset, snapshot_0.range1.length) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_src_0, [[maybe_unused]] ::scpp::mt::segment var_dst_1) -> ::scpp::int64 {
	[[maybe_unused]] scpp::int64 var_i_2 = 0;
	while (([&]() -> scpp::bool_t { const auto binary_left = var_i_2; const auto binary_right = (var_src_0).count(); return (binary_left < binary_right); }())) {
		{ auto& slot = (*static_cast<scpp::int64*>((var_dst_1).at(var_i_2)));  slot = (*static_cast<const scpp::int64*>((var_src_0).read_at(var_i_2))); }
		var_i_2 += 1LL;
	}
	return var_i_2;
}(inputs[0], inputs[1]); }}}; ::scpp::mt::join(jobs, 1); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::mt::segment_range grow_for_range_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::int64 &var_calls_1)
{
	(var_cells_0).append(2L);
	var_calls_1 += 1LL;
	return ::scpp::mt::balanced_range((var_cells_0).size(), 2LL, 1LL);
}

::scpp::int64 snapshot_range_()
{
	[[maybe_unused]] scpp::vector_int64 var_cells_0 = ([&]() {
    scpp::int64 input[]{1L};
    return scpp::vector_int64::from_owned(input, 1);
}());
	[[maybe_unused]] scpp::int64 var_calls_1 = 0;
	[[maybe_unused]] scpp::vector_int64 var_s_2 = ([&]() { const struct values_1 { ::scpp::mt::segment_range range0; } snapshot_1{grow_for_range_(var_cells_0, var_calls_1)}; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_cells_0, 0LL, 1LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_cells_0, snapshot_1.range0.offset, snapshot_1.range0.length) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}, {grants_1, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	return ([&]() -> scpp::int64 { const auto binary_left = ([&]() -> scpp::int64 { const auto binary_left = (var_calls_1 * 100LL); const auto binary_right = (var_s_2).at(0L); return (binary_left + binary_right); }()); const auto binary_right = (var_s_2).at(1L); return (binary_left + binary_right); }());
}

::scpp::mt::segment_range range_for_([[maybe_unused]] ::scpp::int64 var_size_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_part_2)
{
	return ::scpp::mt::balanced_range(var_size_0, var_parts_1, var_part_2);
}

::scpp::int64 range_end_([[maybe_unused]] ::scpp::mt::segment_range var_range_0)
{
	return ([&]() -> scpp::int64 { const auto binary_left = (var_range_0).offset; const auto binary_right = (var_range_0).length; return (binary_left + binary_right); }());
}

::scpp::int64 read_first_([[maybe_unused]] ::scpp::mt::segment var_points_0)
{
	return ((*static_cast<const scpp_records::Point*>((var_points_0).read_at(0LL)))).x;
}

::scpp::int64 relay_read_([[maybe_unused]] ::scpp::mt::segment var_points_0)
{
	return read_first_(var_points_0);
}

::scpp::vector_int64 read_batch_([[maybe_unused]] const scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 &var_rows_0, [[maybe_unused]] ::scpp::vector_int64 &var_cells_1, [[maybe_unused]] ::scpp::int64 var_offset_2)
{
	return ([&]() { const struct values_1 { scpp::int64 v3; } snapshot_1{1LL}; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow_read(var_rows_0, 0LL, 2LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow_read(var_rows_0, 0LL, 1LL), ::scpp::mt::job::borrow_read(var_cells_1, 1LL, 1LL), ::scpp::mt::job::borrow(var_cells_1, var_offset_2, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return relay_read_(inputs[0]); }}, {grants_1, snapshot_1, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::mt::segment var_points_0, [[maybe_unused]] ::scpp::mt::segment var_a_1, [[maybe_unused]] ::scpp::mt::segment var_out_2, [[maybe_unused]] ::scpp::int64 var_extra_3) -> ::scpp::int64 {
	{ auto& slot = (*static_cast<scpp::int64*>((var_out_2).at(0LL)));  slot = static_cast<scpp::int64>(([&]() -> scpp::int64 { const auto binary_left = ([&]() -> scpp::int64 { const auto binary_left = relay_read_(var_points_0); const auto binary_right = (*static_cast<const scpp::int64*>((var_a_1).read_at(0LL))); return (binary_left + binary_right); }()); const auto binary_right = var_extra_3; return (binary_left + binary_right); }())); }
	return (*static_cast<scpp::int64*>((var_out_2).at(0LL)));
}(inputs[0], inputs[1], inputs[2], static_cast<const values_1*>(context)->v3); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

void check_snapshots_()
{
	[[maybe_unused]] scpp::vector_int64 var_snap_0 = ([&]() {
    scpp::int64 input[]{5L};
    return scpp::vector_int64::from_owned(input, 1);
}());
	[[maybe_unused]] scpp::int64 var_seed_1 = 2;
	[[maybe_unused]] scpp::vector_int64 var_s_2 = ([&]() { const struct values_1 { scpp::int64 v0; scpp::int64 v2; scpp::float64 v3; } snapshot_1{var_seed_1, extend_input_(var_snap_0, var_seed_1), 0x1.0000000000000p-1}; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_snap_0, 0LL, 1LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_snap_0, 1LL, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}, {grants_1, snapshot_1, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_first_0, [[maybe_unused]] ::scpp::mt::segment var_dst_1, [[maybe_unused]] ::scpp::int64 var_second_2, [[maybe_unused]] ::scpp::float64 var_rate_3) -> ::scpp::int64 {
	if (var_rate_3 < 0x1.0000000000000p0) {
		var_first_0 += 10LL;
	}
	{ auto& slot = (*static_cast<scpp::int64*>((var_dst_1).at(0LL)));  slot = static_cast<scpp::int64>((var_first_0 + var_second_2)); }
	return (*static_cast<scpp::int64*>((var_dst_1).at(0LL)));
}(static_cast<const values_1*>(context)->v0, inputs[0], static_cast<const values_1*>(context)->v2, static_cast<const values_1*>(context)->v3); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	scpp::echo_int(var_seed_1);
	scpp::echo_int((var_snap_0).size());
	scpp::echo_int((var_s_2).at(0L));
	scpp::echo_int((var_s_2).at(1L));
	scpp::echo_int((var_snap_0).at(1L));
}

::scpp::int64 extend_input_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::int64 &var_seed_1)
{
	var_seed_1 += 1LL;
	(var_cells_0).append(var_seed_1);
	return var_seed_1;
}

void check_blocks_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0)
{
	[[maybe_unused]] scpp::vector_int64 var_more_1 = ([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_cells_0, 0LL, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_cell_0) -> ::scpp::int64 {
	return single_slot_(var_cell_0);
}(inputs[0]); }}}; ::scpp::mt::join(jobs, 1); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_cells_0, 0LL, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}}; ::scpp::mt::join(jobs, 1); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
	scpp::echo_int((var_more_1).at(0L));
	scpp::echo_int((var_cells_0).at(0L));
	scpp::echo_int(parallel_());
}

::scpp::int64 adjustment_()
{
	return 10LL;
}

::scpp::vector_int64 mixed_batch_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::vector_int64 &var_alias_1, [[maybe_unused]] ::scpp::int64 var_last_2)
{
	return ([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_cells_0, 0LL, 1LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_cells_0, 1LL, 1LL), ::scpp::mt::job::borrow(var_cells_0, 2LL, 1LL), ::scpp::mt::job::borrow(var_alias_1, var_last_2, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}, {grants_1, [](const ::scpp::mt::segment* inputs) { return three_slots_(inputs[0], inputs[1], inputs[2]); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::vector_int64 pair_batch_([[maybe_unused]] ::scpp::vector_int64 &var_cells_0, [[maybe_unused]] ::scpp::vector_int64 &var_alias_1, [[maybe_unused]] ::scpp::int64 var_offset_2)
{
	return ([&]() { ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_cells_0, 3LL, 1LL) }; ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_cells_0, 0LL, 1LL), ::scpp::mt::job::borrow(var_alias_1, var_offset_2, 1LL) }; ::scpp::mt::job jobs[]{{grants_0, [](const ::scpp::mt::segment* inputs) { return single_slot_(inputs[0]); }}, {grants_1, [](const ::scpp::mt::segment* inputs) { return []([[maybe_unused]] ::scpp::mt::segment var_prices_0, [[maybe_unused]] ::scpp::mt::segment var_fees_1) -> ::scpp::int64 {
	[[maybe_unused]] scpp::int64 var_sum_2 = 0;
	[[maybe_unused]] scpp::int64 var_i_3 = 0;
	while (([&]() -> scpp::bool_t { const auto binary_left = var_i_3; const auto binary_right = (var_prices_0).count(); return (binary_left < binary_right); }())) {
		{ auto& slot = (*static_cast<scpp::int64*>((var_prices_0).at(var_i_3)));  slot = static_cast<scpp::int64>(([&]() -> scpp::int64 { const auto binary_left = (*static_cast<scpp::int64*>((var_prices_0).at(var_i_3))); const auto binary_right = (*static_cast<scpp::int64*>((var_fees_1).at(var_i_3))); return (binary_left + binary_right); }())); }
		{ auto& slot = (*static_cast<scpp::int64*>((var_fees_1).at(var_i_3)));  slot = 0L; }
		{ const auto compound_previous = var_sum_2; var_sum_2 = (compound_previous + (*static_cast<scpp::int64*>((var_prices_0).at(var_i_3)))); }
		var_i_3 += 1LL;
	}
	return var_sum_2;
}(inputs[0], inputs[1]); }}}; ::scpp::mt::join(jobs, 2); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::int64 single_slot_([[maybe_unused]] ::scpp::mt::segment var_a_0)
{
	if (true) {
		{ auto& slot = (*static_cast<scpp::int64*>((var_a_0).at(0LL)));  slot = static_cast<scpp::int64>(([&]() -> scpp::int64 { const auto binary_left = (*static_cast<scpp::int64*>((var_a_0).at(0LL))); const auto binary_right = adjustment_(); return (binary_left + binary_right); }())); }
	}
	return (*static_cast<scpp::int64*>((var_a_0).at(0LL)));
}

::scpp::int64 three_slots_([[maybe_unused]] ::scpp::mt::segment var_a_0, [[maybe_unused]] ::scpp::mt::segment var_b_1, [[maybe_unused]] ::scpp::mt::segment var_c_2)
{
	{ auto& slot = (*static_cast<scpp::int64*>((var_a_0).at(0LL)));  slot = static_cast<scpp::int64>(([&]() -> scpp::int64 { const auto binary_left = ((*static_cast<scpp::int64*>((var_a_0).at(0LL))) + 20LL); const auto binary_right = 0LL; return (binary_left + binary_right); }())); }
	{ auto& slot = (*static_cast<scpp::int64*>((var_b_1).at(0LL)));  slot = static_cast<scpp::int64>(((*static_cast<scpp::int64*>((var_b_1).at(0LL))) + 30LL)); }
	{ auto& slot = (*static_cast<scpp::int64*>((var_c_2).at(0LL)));  slot = static_cast<scpp::int64>(((*static_cast<scpp::int64*>((var_c_2).at(0LL))) + 40LL)); }
	return ([&]() -> scpp::int64 { const auto binary_left = ([&]() -> scpp::int64 { const auto binary_left = (*static_cast<scpp::int64*>((var_a_0).at(0LL))); const auto binary_right = (*static_cast<scpp::int64*>((var_b_1).at(0LL))); return (binary_left + binary_right); }()); const auto binary_right = (*static_cast<scpp::int64*>((var_c_2).at(0LL))); return (binary_left + binary_right); }());
}
}
