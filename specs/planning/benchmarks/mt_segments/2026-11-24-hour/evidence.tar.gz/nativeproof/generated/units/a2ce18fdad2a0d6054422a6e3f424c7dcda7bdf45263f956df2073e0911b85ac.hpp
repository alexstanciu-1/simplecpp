// Concrete application collection; include after complete element declarations.
#ifndef SCPP_CONCRETE_A2CE18FDAD2A0D6054422A6E3F424C7DCDA7BDF45263F956DF2073E0911B85AC
#define SCPP_CONCRETE_A2CE18FDAD2A0D6054422A6E3F424C7DCDA7BDF45263F956DF2073E0911B85AC
#include <scpp/core/scalars.hpp>
#include <scpp/string.hpp>
namespace scpp::mt { struct job; }
#include "new"
#include "stdexcept"
#include "cstring"
#ifndef SCPP_CONCRETE_SUPPORT_E9BA9E3C0436F035CAF7DDF2605388B13AD2B7AF32E8682CC63137518FE76DB0
#define SCPP_CONCRETE_SUPPORT_E9BA9E3C0436F035CAF7DDF2605388B13AD2B7AF32E8682CC63137518FE76DB0

#include <cstddef>
#include <cstdint>

namespace scpp::detail {
// Type-independent index mechanics. Typed recipes own key equality and entry lifetimes.
struct hash_candidate {
    std::uint32_t position;
    std::uint32_t bucket;
};
class concrete_hash_index final {
    unsigned char* controls_ = nullptr;
    void* buckets_ = nullptr;
    std::uint32_t capacity_ = 0;
    std::uint32_t size_ = 0;
    std::uint32_t deleted_ = 0;
    unsigned char width_ = 0;
public:
    concrete_hash_index() noexcept = default;
    concrete_hash_index(std::uint32_t capacity, std::size_t physical_count);
    concrete_hash_index(const concrete_hash_index&) = delete;
    concrete_hash_index& operator=(const concrete_hash_index&) = delete;
    ~concrete_hash_index();
    void swap(concrete_hash_index& other) noexcept;
    std::uint32_t capacity() const noexcept { return capacity_; }
    std::uint32_t size() const noexcept { return size_; }
    std::uint32_t deleted() const noexcept { return deleted_; }
    unsigned index_bytes() const noexcept { return width_; }
    bool holds(std::size_t physical_count) const noexcept {
        return width_ == 4 || (width_ == 2 && physical_count <= 65536) || (width_ == 1 && physical_count <= 256);
    }
    hash_candidate next(std::uint64_t hash, std::uint32_t& offset) const noexcept;
    void add(std::uint64_t hash, std::uint32_t position) noexcept;
    void erase(std::uint32_t bucket) noexcept;
};
std::uint64_t hash_pointer(const void* key) noexcept;
std::uint64_t hash_integer(std::int64_t key) noexcept;
std::uint64_t hash_string_bytes(const char* bytes, std::size_t size) noexcept;
}

#endif
namespace App {
using ::scpp::bool_t;
class scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de final {
public:
struct iteration_output {
    using value_type = scpp_records::Point;
    // Compiler-owned copied value; empty construction never invokes the element constructor.
    union { value_type value; unsigned char empty[sizeof(value_type)]; };
    bool active = false;
    iteration_output() noexcept : empty{} {}
    iteration_output(const iteration_output&) = delete;
    iteration_output& operator=(const iteration_output&) = delete;
    iteration_output(iteration_output&& other) noexcept : empty{} {
        if (other.active) { ::new (&value) value_type(static_cast<value_type&&>(other.value)); active = true; }
    }
    ~iteration_output() { if (active) value.~value_type(); }
    void publish(value_type selected) noexcept {
        if (active) value = static_cast<value_type&&>(selected);
        else { ::new (&value) value_type(static_cast<value_type&&>(selected)); active = true; }
    }
};
    ::scpp::int64 iteration_limit() const;
    bool_t iteration_next(::scpp::int64& position, ::scpp::int64 limit, iteration_output& output) const;
    bool_t iteration_next(::scpp::int64& position, ::scpp::int64 limit, ::scpp::string& key, iteration_output& output) const;

    struct keyed_entry { ::scpp::string key; scpp_records::Point value; };
    class keyed_input final {
        keyed_entry* data_;
    public:
        explicit keyed_input(keyed_entry* values) noexcept : data_(values) {}
        keyed_input(const keyed_input&) = delete;
        keyed_input& operator=(const keyed_input&) = delete;
        ~keyed_input() noexcept;
        keyed_entry* data() const noexcept { return data_; }
    };
    static scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de from_owned_entries(keyed_entry* values, ::scpp::int64 count);

    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de() noexcept = default;
    ~scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de();
    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de(const scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&);
    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de(scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&&) noexcept;
    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& operator=(const scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&);
    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& operator=(scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&&) noexcept;
    ::scpp::int64 size() const;
    bool_t empty() const noexcept;
    bool_t has(const ::scpp::string& key) const;
    scpp_records::Point at(const ::scpp::string& key) const;
    void set(::scpp::string key, scpp_records::Point value);
    bool_t remove(const ::scpp::string& key);
    void clear() noexcept;
    bool_t iteration_next_key(::scpp::int64& position, ::scpp::int64 limit, ::scpp::string& key) const;
    scpp_records::Point iteration_current_value(::scpp::int64 position) const;


private:
    friend struct ::scpp::mt::job;
    const unsigned char* mt_live() const noexcept;
    const void* mt_field(::scpp::int64 position, bool key) const noexcept;

    struct storage;
    storage* storage_ = nullptr;
};
struct scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::storage {
    using key_type = ::scpp::string;
static_assert(__is_constructible(key_type, const key_type&), "collections/hash requires k.copy_constructible");
static key_type& key_type_contract_value() noexcept;
static_assert(noexcept(key_type_contract_value().~key_type()), "collections/hash requires k.nothrow_destructible");
static_assert(__is_nothrow_assignable(key_type&, key_type&&), "collections/hash requires k.nothrow_move_assignable");
static_assert(__is_nothrow_constructible(key_type, key_type&&), "collections/hash requires k.nothrow_move_constructible");
using value_type = scpp_records::Point;
static_assert(__is_constructible(value_type, const value_type&), "collections/hash requires v.copy_constructible");
static value_type& value_type_contract_value() noexcept;
static_assert(noexcept(value_type_contract_value().~value_type()), "collections/hash requires v.nothrow_destructible");
static_assert(__is_nothrow_assignable(value_type&, value_type&&), "collections/hash requires v.nothrow_move_assignable");
static_assert(__is_nothrow_constructible(value_type, value_type&&), "collections/hash requires v.nothrow_move_constructible");

    struct entry { key_type key; value_type value; };
    unsigned char* data = nullptr;
    unsigned char* live = nullptr;
    std::size_t used = 0;
    std::size_t capacity = 0;
    std::size_t live_size = 0;
    ::scpp::detail::concrete_hash_index index;

    static std::uint64_t hash_key(const key_type& key) noexcept { return ::scpp::detail::hash_string_bytes(key.data(), static_cast<std::size_t>(key.size())); }
    static bool equal_key(const key_type& left, const key_type& right) noexcept { return left.size() == right.size() && (left.size() == 0 || ::memcmp(left.data(), right.data(), static_cast<std::size_t>(left.size())) == 0); }
    static std::uint32_t checked_capacity(std::uint64_t count) {
        if (count > UINT32_MAX) throw std::length_error("hash_index_capacity_limit");
        return static_cast<std::uint32_t>(count);
    }
    static unsigned char* allocate(std::size_t count) {
        if (count > static_cast<std::size_t>(PTRDIFF_MAX) / sizeof(entry)) throw std::length_error("hash_physical_entry_limit");
        return static_cast<unsigned char*>(alignof(entry) > __STDCPP_DEFAULT_NEW_ALIGNMENT__
            ? ::operator new(count * sizeof(entry), static_cast<std::align_val_t>(alignof(entry))) : ::operator new(count * sizeof(entry)));
    }
    static void deallocate(unsigned char* pointer) noexcept {
        if (alignof(entry) > __STDCPP_DEFAULT_NEW_ALIGNMENT__) ::operator delete(pointer, static_cast<std::align_val_t>(alignof(entry)));
        else ::operator delete(pointer);
    }
    entry& at_slot(std::size_t position) noexcept { return *reinterpret_cast<entry*>(data + position * sizeof(entry)); }
    const entry& at_slot(std::size_t position) const noexcept { return *reinterpret_cast<const entry*>(data + position * sizeof(entry)); }
    storage() noexcept = default;
    storage(const storage& other) {
        try {
            reserve(other.used);
            used = other.used;
            for (std::size_t i = 0; i < used; ++i) {
                if (!other.live[i]) continue;
                ::new (data + i * sizeof(entry)) entry{other.at_slot(i).key, other.at_slot(i).value};
                live[i] = 1;
                ++live_size;
            }
            if (live_size) rehash(checked_capacity(static_cast<std::uint64_t>(used) * 2), used);
        } catch (...) { release(); throw; }
    }
    storage(storage&& other) noexcept { swap(other); }
    storage& operator=(const storage& other) { if (this != &other) { storage copy(other); swap(copy); } return *this; }
    storage& operator=(storage&& other) noexcept { if (this != &other) { storage discarded; swap(discarded); swap(other); } return *this; }
    ~storage() { release(); }
    void swap(storage& other) noexcept {
        auto* d = data; data = other.data; other.data = d;
        auto* l = live; live = other.live; other.live = l;
        auto u = used; used = other.used; other.used = u;
        auto c = capacity; capacity = other.capacity; other.capacity = c;
        auto s = live_size; live_size = other.live_size; other.live_size = s;
        index.swap(other.index);
    }
    void release() noexcept {
        for (std::size_t i = 0; i < used; ++i) if (live[i]) at_slot(i).~entry();
        deallocate(data); ::operator delete(live);
        data = nullptr; live = nullptr; used = capacity = live_size = 0;
    }
    void clear() noexcept { storage empty; swap(empty); }
    void reserve(std::size_t required) {
        if (required <= capacity) return;
        const auto limit = static_cast<std::size_t>(PTRDIFF_MAX) / sizeof(entry);
        if (required > limit) throw std::length_error("hash_physical_entry_limit");
        auto next_capacity = capacity == 0 ? (limit < 4 ? limit : 4) : (capacity > limit / 2 ? limit : capacity * 2);
        if (next_capacity < required) next_capacity = required;
        auto* next = allocate(next_capacity);
        unsigned char* next_live;
        try { next_live = static_cast<unsigned char*>(::operator new(next_capacity)); }
        catch (...) { deallocate(next); throw; }
        for (std::size_t i = 0; i < next_capacity; ++i) next_live[i] = 0;
        for (std::size_t i = 0; i < used; ++i) {
            if (!live[i]) continue;
            auto& old = at_slot(i);
            ::new (next + i * sizeof(entry)) entry{static_cast<key_type&&>(old.key), static_cast<value_type&&>(old.value)};
            next_live[i] = 1;
            old.~entry();
        }
        deallocate(data); ::operator delete(live);
        data = next; live = next_live; capacity = next_capacity;
    }
    void rehash(std::uint32_t buckets, std::size_t physical_count) {
        ::scpp::detail::concrete_hash_index next(buckets, physical_count);
        for (std::size_t i = 0; i < used; ++i) if (live[i]) next.add(hash_key(at_slot(i).key), static_cast<std::uint32_t>(i));
        index.swap(next);
    }
    ::scpp::detail::hash_candidate locate(const key_type& key) const noexcept {
        const auto hash = hash_key(key);
        std::uint32_t offset = 0;
        for (;;) {
            const auto found = index.next(hash, offset);
            if (found.position == UINT32_MAX || equal_key(at_slot(found.position).key, key)) return found;
        }
    }
    const value_type* find(const key_type& key) const noexcept {
        const auto found = locate(key);
        return found.position == UINT32_MAX ? nullptr : &at_slot(found.position).value;
    }
    void set(key_type key, value_type value) {
        const auto found = locate(key);
        if (found.position != UINT32_MAX) { at_slot(found.position).value = static_cast<value_type&&>(value); return; }
        insert_new(static_cast<key_type&&>(key), static_cast<value_type&&>(value));
    }
    // Caller has established absence. Shared by replacement-aware set and unique construction.
    void insert_new(key_type&& key, value_type&& value) {
        if (used >= UINT32_MAX) throw std::length_error("hash_physical_entry_limit");
        reserve(used + 1);
        const auto buckets = index.capacity();
        if (!buckets || static_cast<std::uint64_t>(index.size()) + index.deleted() >= static_cast<std::uint64_t>(buckets) * 3 / 4 || !index.holds(used + 1)) {
            const auto next = !buckets ? 4 : (index.size() >= buckets / 2 ? checked_capacity(static_cast<std::uint64_t>(buckets) * 2) : buckets);
            rehash(next, used + 1);
        }
        ::new (data + used * sizeof(entry)) entry{static_cast<key_type&&>(key), static_cast<value_type&&>(value)};
        live[used] = 1;
        index.add(hash_key(at_slot(used).key), static_cast<std::uint32_t>(used));
        ++used; ++live_size;
    }
    bool remove(const key_type& key) noexcept {
        const auto found = locate(key);
        if (found.position == UINT32_MAX) return false;
        index.erase(found.bucket);
        at_slot(found.position).~entry();
        live[found.position] = 0;
        --live_size;
        return true;
    }
    std::size_t size() const noexcept { return live_size; }
    std::size_t physical_size() const noexcept { return used; }
    unsigned index_bytes() const noexcept { return index.index_bytes(); }
    const entry* iteration_select(std::int64_t& position, std::int64_t limit) const noexcept {
        auto next = static_cast<std::uint64_t>(position);
        const auto end = static_cast<std::uint64_t>(limit) < used ? static_cast<std::uint64_t>(limit) : used;
        while (next < end && !live[next]) ++next;
        position = static_cast<std::int64_t>(next);
        return next < end ? &at_slot(next) : nullptr;
    }
    bool iteration_next(std::int64_t& position, std::int64_t limit, value_type& value, key_type* key = nullptr) const {
        auto selected_position = position;
        const auto* item = iteration_select(selected_position, limit);
        if (!item) { position = selected_position; return false; }
        value_type selected = item->value;
        if (key) { key_type selected_key = item->key; *key = static_cast<key_type&&>(selected_key); }
        value = static_cast<value_type&&>(selected);
        position = selected_position + 1;
        return true;
    }

};

inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::~scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de() { delete storage_; }
inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de(const scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& other) : storage_(other.storage_ ? new storage(*other.storage_) : nullptr) {}
inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de(scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&& other) noexcept : storage_(other.storage_) { other.storage_ = nullptr; }
inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::operator=(const scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& other) { if (this != &other) { scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de copy(other); auto* old = storage_; storage_ = copy.storage_; copy.storage_ = old; } return *this; }
inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de& scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::operator=(scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de&& other) noexcept { if (this != &other) { delete storage_; storage_ = other.storage_; other.storage_ = nullptr; } return *this; }

inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::keyed_input::~keyed_input() noexcept { delete[] data_; }
inline scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::from_owned_entries(keyed_entry* values, ::scpp::int64 count) {
    if (count < 0 || static_cast<std::uint64_t>(count) > UINT32_MAX / 2
        || static_cast<std::uint64_t>(count) > static_cast<std::size_t>(PTRDIFF_MAX) / sizeof(storage::entry))
        throw std::length_error("hash_initializer_size_limit");
    scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de result;
    if (count == 0) return result;
    result.storage_ = new storage;
    auto& target = *result.storage_;
    target.reserve(static_cast<std::size_t>(count));
    const auto buckets = count < 2 ? 4 : static_cast<std::uint32_t>(count) * 2;
    target.rehash(buckets, static_cast<std::size_t>(count));
    for (::scpp::int64 i = 0; i < count; ++i) {
        if (target.find(values[i].key)) throw std::invalid_argument("duplicate_initializer_key");
        target.insert_new(static_cast<storage::key_type&&>(values[i].key), static_cast<storage::value_type&&>(values[i].value));
    }
    return result;
}

inline ::scpp::int64 scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::size() const { return static_cast<::scpp::int64>(storage_ ? storage_->size() : 0); }
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::empty() const noexcept { return bool_t{!storage_ || storage_->size() == 0}; }
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::has(const ::scpp::string& key) const { return bool_t{storage_ && storage_->find(key)}; }
inline scpp_records::Point scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::at(const ::scpp::string& key) const { const auto* value = storage_ ? storage_->find(key) : nullptr; if (!value) throw std::out_of_range("hash_missing_key"); return *value; }
inline void scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::set(::scpp::string key, scpp_records::Point value) { if (!storage_) storage_ = new storage; storage_->set(static_cast<::scpp::string&&>(key), static_cast<scpp_records::Point&&>(value)); }
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::remove(const ::scpp::string& key) { return bool_t{storage_ && storage_->remove(key)}; }
inline void scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::clear() noexcept { delete storage_; storage_ = nullptr; }
inline const unsigned char* scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::mt_live() const noexcept { return storage_ ? storage_->live : nullptr; }
inline const void* scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::mt_field(::scpp::int64 position, bool key) const noexcept {
    const auto& entry = storage_->at_slot(position);
    return key ? static_cast<const void*>(&entry.key) : static_cast<const void*>(&entry.value);
}
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::iteration_next_key(::scpp::int64& position, ::scpp::int64 limit, ::scpp::string& key) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    auto selected_position = position;
    const auto* selected = storage_ ? storage_->iteration_select(selected_position, limit) : nullptr;
    if (!selected) { position = selected_position; return false; }
    auto selected_key = selected->key;
    key = static_cast<::scpp::string&&>(selected_key);
    position = selected_position + 1;
    return true;
}

inline scpp_records::Point scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::iteration_current_value(::scpp::int64 position) const {
    if (position <= 0 || !storage_) throw std::out_of_range("iteration_bounds");
    const auto slot = static_cast<std::uint64_t>(position - 1);
    if (slot >= storage_->used || !storage_->live[slot]) throw std::out_of_range("iteration_bounds");
    return storage_->at_slot(slot).value;
}


inline ::scpp::int64 scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::iteration_limit() const { return static_cast<::scpp::int64>(storage_ ? storage_->physical_size() : 0); }
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::iteration_next(::scpp::int64& position, ::scpp::int64 limit, iteration_output& output) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    auto selected_position = position;
    const auto* selected = storage_ ? storage_->iteration_select(selected_position, limit) : nullptr;
    if (!selected) { position = selected_position; return false; }
    output.publish(selected->value);
    position = selected_position + 1;
    return true;
}
inline bool_t scpp_hash_c2c8d9d0c97bbb9660e3d6ed1f2b2841821aa03ccc77ab0821d8348d7786f2de::iteration_next(::scpp::int64& position, ::scpp::int64 limit, ::scpp::string& key, iteration_output& output) const {
    if (position < 0 || limit < 0) throw std::out_of_range("iteration_bounds");
    auto selected_position = position;
    const auto* selected = storage_ ? storage_->iteration_select(selected_position, limit) : nullptr;
    if (!selected) { position = selected_position; return false; }
    auto selected_value = selected->value;
    auto selected_key = selected->key;
    key = static_cast<::scpp::string&&>(selected_key);
    output.publish(static_cast<scpp_records::Point&&>(selected_value));
    position = selected_position + 1;
    return true;
}

}

#endif
