// Generated cross-unit declarations.
#pragma once
#include <scpp/core/scalars.hpp>
#include <scpp/value_error.hpp>
#include <scpp/vectors.hpp>
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
namespace App {
class scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
::scpp::vector_int64 dispatch_([[maybe_unused]] scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 &var_rows_0, [[maybe_unused]] ::scpp::vector_int64 &var_deltas_1, [[maybe_unused]] ::scpp::vector_int64 &var_other_2, [[maybe_unused]] ::scpp::int64 var_offset_3);
}
