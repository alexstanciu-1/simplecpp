// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
#include "aa95c45d84019dc4f58e62e37172bc144bbff580540d63fc67612d3f6a635d0c.hpp"
namespace App {
::scpp::int64 update_([[maybe_unused]] ::scpp::mt::segment var_rows_0, [[maybe_unused]] ::scpp::mt::segment var_deltas_1, [[maybe_unused]] ::scpp::int64 var_i_2)
{
	((*static_cast<scpp_records::Point*>((var_rows_0).at(var_i_2)))).x = ([&]() -> scpp::int64 { const auto binary_left = ((*static_cast<scpp_records::Point*>((var_rows_0).at(var_i_2)))).x; const auto binary_right = (*static_cast<scpp::int64*>((var_deltas_1).at(var_i_2))); return (binary_left + binary_right); }());
	{ auto& slot = (*static_cast<scpp::int64*>((var_deltas_1).at(var_i_2)));  slot = static_cast<scpp::int64>(((*static_cast<scpp::int64*>((var_deltas_1).at(var_i_2))) + 1LL)); }
	return ((*static_cast<scpp_records::Point*>((var_rows_0).at(var_i_2)))).x;
}
}
