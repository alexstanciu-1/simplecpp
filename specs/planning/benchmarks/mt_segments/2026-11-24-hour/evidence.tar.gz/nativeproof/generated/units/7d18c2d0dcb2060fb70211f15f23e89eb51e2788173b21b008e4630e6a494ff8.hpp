// Generated inline record layout.
#pragma once
#include <scpp/core/scalars.hpp>
namespace App {
namespace scpp_records {
struct Point {
	::scpp::int64 x = 1;
};
}

}
