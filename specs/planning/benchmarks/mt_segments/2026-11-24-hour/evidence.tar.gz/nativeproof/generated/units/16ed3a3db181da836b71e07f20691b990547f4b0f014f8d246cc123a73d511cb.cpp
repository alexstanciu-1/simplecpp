// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include <scpp/mt_segments.hpp>
#include <scpp/value_error.hpp>
#include <scpp/vectors.hpp>
#include <stdexcept>
#include <vector>
#include "16ba0048f9fcc0155a39f0156fc8882b50491bf87ac3f24351fcd45f93511361.hpp"
#include "16ed3a3db181da836b71e07f20691b990547f4b0f014f8d246cc123a73d511cb.hpp"
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
#include "aa95c45d84019dc4f58e62e37172bc144bbff580540d63fc67612d3f6a635d0c.hpp"
namespace App {
class scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20;
}
#include "90df342019f1b30c83a62a4bf2e662494c3a07d48c4eff241b1ba98923d26a2c.hpp"
namespace App {
::scpp::vector_int64 dispatch_([[maybe_unused]] scpp_vector_13ebbe8070173297ad475e9e8b091ac76cf8fda0c321a32aa7a3dbc344335a20 &var_rows_0, [[maybe_unused]] ::scpp::vector_int64 &var_deltas_1, [[maybe_unused]] ::scpp::vector_int64 &var_other_2, [[maybe_unused]] ::scpp::int64 var_offset_3)
{
	return ([&]() { const auto workers = 2LL; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const struct values_1 { scpp::bool_t v0; scpp::int64 v2; } snapshot_1{true, (var_offset_3 - 1LL)}; const auto count_2 = 2LL; if (count_2 < 0) throw std::invalid_argument("each bound must be nonnegative"); const auto workers_2 = 1LL; if (workers_2 <= 0) throw std::invalid_argument("Job workers must be positive"); struct values_2 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_2> values_list_2; values_list_2.reserve(count_2); for (::scpp::int64 var_part_4 = 0; var_part_4 < count_2; ++var_part_4) values_list_2.push_back({var_part_4, ::scpp::mt::balanced_range(0LL, 2LL, var_part_4)}); std::vector<::scpp::mt::job> jobs; ::scpp::mt::segment grants_0[]{ ::scpp::mt::job::borrow(var_rows_0, 0LL, 1LL), ::scpp::mt::job::borrow(var_deltas_1, 0LL, 1LL) }; jobs.push_back({grants_0, [](const ::scpp::mt::segment* inputs) { return work_(inputs[0], inputs[1]); }}); ::scpp::mt::segment grants_1[]{ ::scpp::mt::job::borrow(var_rows_0, 1LL, 1LL), ::scpp::mt::job::borrow(var_other_2, var_offset_3, 1LL) }; jobs.push_back({grants_1, snapshot_1, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::bool_t var_enabled_0, [[maybe_unused]] ::scpp::mt::segment var_points_1, [[maybe_unused]] ::scpp::int64 var_index_2, [[maybe_unused]] ::scpp::mt::segment var_changes_3) -> ::scpp::int64 {
	if (!var_enabled_0) {
		return 0LL;
	}
	return ([&]() -> scpp::int64 { scpp::mt::segment argument_116_0 = var_points_1; scpp::mt::segment argument_116_1 = var_changes_3; return update_(static_cast<scpp::mt::segment&&>(argument_116_0), static_cast<scpp::mt::segment&&>(argument_116_1), var_index_2); }());
}(static_cast<const values_1*>(context)->v0, inputs[0], static_cast<const values_1*>(context)->v2, inputs[1]); }}); struct grants_2 { ::scpp::mt::segment slots[1]; }; std::vector<grants_2> grants_list_2; grants_list_2.reserve(values_list_2.size()); for (const auto& snapshot_2 : values_list_2) { grants_list_2.push_back({::scpp::mt::job::borrow_read(var_rows_0, snapshot_2.range1.offset, snapshot_2.range1.length)}); jobs.push_back({grants_list_2.back().slots, snapshot_2, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_part_0, [[maybe_unused]] ::scpp::mt::segment var_empty_1) -> ::scpp::int64 {
	return ([&]() -> scpp::int64 { const auto binary_left = var_part_0; const auto binary_right = (var_empty_1).count(); return (binary_left + binary_right); }());
}(static_cast<const values_2*>(context)->v0, inputs[0]); }}); } const ::scpp::mt::job_entry entries[]{{1, 1}, {1, 1}, {values_list_2.size(), workers_2}}; ::scpp::mt::join(jobs.data(), jobs.size(), workers, entries, 3); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}
}
