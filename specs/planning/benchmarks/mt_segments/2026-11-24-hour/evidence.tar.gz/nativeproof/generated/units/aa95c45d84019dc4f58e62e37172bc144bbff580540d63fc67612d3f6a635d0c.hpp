// Generated cross-unit declarations.
#pragma once
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include "7d18c2d0dcb2060fb70211f15f23e89eb51e2788173b21b008e4630e6a494ff8.hpp"
namespace App {
::scpp::int64 update_([[maybe_unused]] ::scpp::mt::segment var_rows_0, [[maybe_unused]] ::scpp::mt::segment var_deltas_1, [[maybe_unused]] ::scpp::int64 var_i_2);
}
