import itertools,random,subprocess,os
print("round,compiler,policy,workers,sample,ms",flush=True)
for epoch in range(15):
    matrix=list(itertools.product(('clang++','g++'),('active','sleep'),(0,1,2,4,8)))
    random.Random(84+epoch).shuffle(matrix)
    for c,policy,n in matrix:
        r=subprocess.run(['nice','-n','5','taskset','-c','0-7','./stock-'+c,str(n)],capture_output=True,text=True,
                         check=True,timeout=60,env=dict(os.environ,SCPP_MT_WAIT=policy))
        for line in r.stdout.splitlines():
            print(f'{epoch},{c},{policy},{n},{line}',flush=True)
