function reconcile_batch(vector<Stock> &$rows, vector<int> &$adj, int $workers): vector<int> {
    $n=count($rows);
    return parallel (workers: $workers) {
        job (each: $part in 0 ..< $workers,
             write: $stock=segment($rows,balanced_range($n,$workers,$part)),
             write: $changes=segment($adj,balanced_range($n,$workers,$part))) {
            return reconcile($stock,$changes);
        }
    };
}
