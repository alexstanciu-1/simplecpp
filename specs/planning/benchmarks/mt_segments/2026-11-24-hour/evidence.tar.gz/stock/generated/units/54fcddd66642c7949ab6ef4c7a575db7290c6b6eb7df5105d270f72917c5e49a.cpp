// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include "09c82af46dc91298e8d00357d426705c907747a69c7fbfbba21d278b0d4c22f0.hpp"
#include "54fcddd66642c7949ab6ef4c7a575db7290c6b6eb7df5105d270f72917c5e49a.hpp"
#include "df5aec6b0f0befeb0e281890baf73760bb7ffb0f5a7ad68e9af48b376ef36a3d.hpp"
namespace App {
::scpp::int64 reconcile_([[maybe_unused]] ::scpp::mt::segment var_stock_0, [[maybe_unused]] ::scpp::mt::segment var_adjustments_1)
{
	[[maybe_unused]] scpp::int64 var_i_2 = 0;
	[[maybe_unused]] scpp::int64 var_subtotal_3 = 0;
	while (([&]() -> scpp::bool_t { const auto binary_left = var_i_2; const auto binary_right = (var_stock_0).count(); return (binary_left < binary_right); }())) {
		[[maybe_unused]] scpp::int64 var_quantity_4 = ([&]() -> scpp::int64 { const auto binary_left = ((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).on_hand; const auto binary_right = (*static_cast<scpp::int64*>((var_adjustments_1).at(var_i_2))); return (binary_left + binary_right); }());
		[[maybe_unused]] scpp::int64 var_available_5 = ([&]() -> scpp::int64 { const auto binary_left = var_quantity_4; const auto binary_right = ((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).reserved; return (binary_left - binary_right); }());
		[[maybe_unused]] scpp::int64 var_value_6 = ([&]() -> scpp::int64 { scpp::int64 argument_63_0 = var_available_5; scpp::int64 argument_63_1 = ((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).unit_cost_cents; return inventory_value_(argument_63_0, argument_63_1); }());
		((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).on_hand = var_quantity_4;
		((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).available = var_available_5;
		((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).value_cents = var_value_6;
		((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).revision = (((*static_cast<scpp_records::Stock*>((var_stock_0).at(var_i_2)))).revision + 1LL);
		{ auto& slot = (*static_cast<scpp::int64*>((var_adjustments_1).at(var_i_2)));  slot = 0L; }
		var_subtotal_3 += var_value_6;
		var_i_2 += 1LL;
	}
	return var_subtotal_3;
}
}
