// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include "df5aec6b0f0befeb0e281890baf73760bb7ffb0f5a7ad68e9af48b376ef36a3d.hpp"
namespace App {
::scpp::int64 inventory_value_([[maybe_unused]] ::scpp::int64 var_available_0, [[maybe_unused]] ::scpp::int64 var_unit_cost_1)
{
	return (var_available_0 * var_unit_cost_1);
}
}
