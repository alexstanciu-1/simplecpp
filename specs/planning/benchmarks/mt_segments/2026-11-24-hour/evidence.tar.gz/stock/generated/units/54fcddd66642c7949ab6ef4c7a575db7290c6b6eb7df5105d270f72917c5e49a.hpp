// Generated cross-unit declarations.
#pragma once
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include "09c82af46dc91298e8d00357d426705c907747a69c7fbfbba21d278b0d4c22f0.hpp"
namespace App {
::scpp::int64 reconcile_([[maybe_unused]] ::scpp::mt::segment var_stock_0, [[maybe_unused]] ::scpp::mt::segment var_adjustments_1);
}
