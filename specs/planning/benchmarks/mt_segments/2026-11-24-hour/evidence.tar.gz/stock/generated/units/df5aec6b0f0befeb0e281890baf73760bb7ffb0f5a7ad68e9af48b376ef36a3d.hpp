// Generated cross-unit declarations.
#pragma once
#include <scpp/core/scalars.hpp>
namespace App {
::scpp::int64 inventory_value_([[maybe_unused]] ::scpp::int64 var_available_0, [[maybe_unused]] ::scpp::int64 var_unit_cost_1);
}
