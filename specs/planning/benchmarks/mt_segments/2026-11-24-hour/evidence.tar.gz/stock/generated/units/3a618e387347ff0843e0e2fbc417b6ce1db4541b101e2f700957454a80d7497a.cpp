// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/mt_segment.hpp>
#include <scpp/mt_segments.hpp>
#include <scpp/value_error.hpp>
#include <scpp/vectors.hpp>
#include <stdexcept>
#include <vector>
#include "09c82af46dc91298e8d00357d426705c907747a69c7fbfbba21d278b0d4c22f0.hpp"
#include "54fcddd66642c7949ab6ef4c7a575db7290c6b6eb7df5105d270f72917c5e49a.hpp"
namespace App {
class scpp_vector_27eb5dab144cfe6284636b5666ce76926891c0ad3487c39039b2ec5c678e58f3;
::scpp::vector_int64 reconcile_batch_([[maybe_unused]] scpp_vector_27eb5dab144cfe6284636b5666ce76926891c0ad3487c39039b2ec5c678e58f3 &var_rows_0, [[maybe_unused]] ::scpp::vector_int64 &var_adj_1, [[maybe_unused]] ::scpp::int64 var_workers_2);
}
#include "a17d6b378be79f7b1f3dd330a0d034983b24437163596280e0df13ed4c4c966e.hpp"
namespace App {
::scpp::vector_int64 reconcile_batch_([[maybe_unused]] scpp_vector_27eb5dab144cfe6284636b5666ce76926891c0ad3487c39039b2ec5c678e58f3 &var_rows_0, [[maybe_unused]] ::scpp::vector_int64 &var_adj_1, [[maybe_unused]] ::scpp::int64 var_workers_2)
{
	[[maybe_unused]] scpp::int64 var_n_3 = (var_rows_0).size();
	return ([&]() { const auto workers = var_workers_2; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = var_workers_2; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; ::scpp::mt::segment_range range2; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_part_4 = 0; var_part_4 < count_0; ++var_part_4) values_list_0.push_back({var_part_4, ::scpp::mt::balanced_range(var_n_3, var_workers_2, var_part_4), ::scpp::mt::balanced_range(var_n_3, var_workers_2, var_part_4)}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[2]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow(var_rows_0, snapshot_0.range1.offset, snapshot_0.range1.length), ::scpp::mt::job::borrow(var_adj_1, snapshot_0.range2.offset, snapshot_0.range2.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_part_0, [[maybe_unused]] ::scpp::mt::segment var_stock_1, [[maybe_unused]] ::scpp::mt::segment var_changes_2) -> ::scpp::int64 {
	return ([&]() -> scpp::int64 { scpp::mt::segment argument_91_0 = var_stock_1; scpp::mt::segment argument_91_1 = var_changes_2; return reconcile_(static_cast<scpp::mt::segment&&>(argument_91_0), static_cast<scpp::mt::segment&&>(argument_91_1)); }());
}(static_cast<const values_0*>(context)->v0, inputs[0], inputs[1]); }}); } ::scpp::mt::join(jobs.data(), jobs.size(), workers); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}
}
