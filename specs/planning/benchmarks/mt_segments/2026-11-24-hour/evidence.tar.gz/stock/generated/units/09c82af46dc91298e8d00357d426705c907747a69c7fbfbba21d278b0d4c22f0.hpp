// Generated inline record layout.
#pragma once
#include <scpp/core/scalars.hpp>
namespace App {
namespace scpp_records {
struct Stock {
	::scpp::int64 sku{};
	::scpp::int64 warehouse{};
	::scpp::int64 on_hand{};
	::scpp::int64 reserved{};
	::scpp::int64 incoming{};
	::scpp::int64 unit_cost_cents{};
	::scpp::int64 available{};
	::scpp::int64 value_cents{};
	::scpp::int64 reorder_point{};
	::scpp::int64 reorder_qty{};
	::scpp::int64 supplier{};
	::scpp::int64 bin{};
	::scpp::int64 last_count{};
	::scpp::int64 last_receipt{};
	::scpp::int64 last_sale{};
	::scpp::int64 revision{};
};
}

}
