#include "types.hpp"
#include <scpp/mt_segments.hpp>
#include <scpp/vectors.hpp>
#include <chrono>
#include <cstdio>
#include <cstdlib>
using I=scpp::int64;
namespace App {
I reconcile_(scpp::mt::segment,scpp::mt::segment);
scpp::vector_int64 reconcile_batch_(Rows&,scpp::vector_int64&,I);
}
int main(int argc,char**argv){
    if(argc!=2)return 1;
    I workers=std::atoi(argv[1]),n=65536;
    Rows rows; scpp::vector_int64 changes;
    using Stock=App::scpp_records::Stock;
    static_assert(sizeof(Stock)==128);
    for(I i=0;i<n;++i){
        Stock s{};
        s.on_hand=500+i%300;s.reserved=i%21;s.unit_cost_cents=50+i%10000;
        rows.append(s);changes.append(i%11-5);
    }
    auto stock=scpp::mt::job::borrow(rows,0,n);
    auto adj=scpp::mt::job::borrow(changes,0,n);
    I expected[8]{},total=0;
    for(I i=0;i<n;++i){I v=(500+i%300+i%11-5-i%21)*(50+i%10000);total+=v;expected[i/(n/(workers?workers:1))]+=v;}
    auto run=[&](){
        if(workers){auto res=App::reconcile_batch_(rows,changes,workers);
            for(I i=0;i<workers;++i)if(res.at(i)!=expected[i])std::abort();
        }else if(App::reconcile_(stock,adj)!=total)std::abort();
    };
    run();
    for(int rep=0;rep<9;++rep){
        auto begin=std::chrono::steady_clock::now();
        for(int pass=0;pass<8;++pass)run();
        double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        std::printf("%d,%.4f\n",rep,ms);
    }
    for(I i=0;i<n;++i){
        auto& s=*static_cast<const Stock*>(stock.read_at(i));
        if(s.on_hand!=500+i%300+i%11-5 || s.revision!=73 || changes.at(i)!=0 ||
           s.available!=s.on_hand-s.reserved || s.value_cents!=s.available*s.unit_cost_cents) return 2;
    }
}
