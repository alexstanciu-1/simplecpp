function mix_value(int $v, int $steps): int {
    $j = 0;
    while ($j < $steps) {
        $v = ($v * 48271 + 1) % 2147483647;
        $j += 1;
    }
    return $v;
}
function vector_pass(vector<int> &$data, int $parts, int $steps): vector<int> {
    $n = count($data);
    return parallel (workers: $parts) {
        job (each: $p in 0 ..< $parts, write: $s = segment($data,balanced_range($n,$parts,$p)), value: $k = $steps) {
            $i = 0;
            while ($i < count($s)) {
                $s[$i] = mix_value($s[$i],$k);
                $i += 1;
            }
            return $i;
        }
    };
}
function hash_pass(hash<int,int> &$data, int $parts, int $steps): vector<int> {
    $n = count($data);
    return parallel (workers: $parts) {
        job (each: $p in 0 ..< $parts, write: $s = segment($data,balanced_range($n,$parts,$p)), value: $k = $steps) {
            foreach ($s as $v) { $v = mix_value($v,$k); }
            return count($s);
        }
    };
}
