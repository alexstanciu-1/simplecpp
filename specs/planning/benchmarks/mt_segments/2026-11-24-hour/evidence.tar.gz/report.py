import collections,csv,datetime,pathlib,re,statistics,sys
d=pathlib.Path(__file__).parent
dest=pathlib.Path(sys.argv[1])
def rows(*files):
    return [row for file in files for row in csv.DictReader((d/file).open())]
def grouped(rs,keys,metric):
    groups=collections.defaultdict(list)
    for r in rs:groups[tuple(r[k] for k in keys)].append(float(r[metric]))
    return {k:statistics.median(v) for k,v in groups.items()}
main=rows('dev002.csv','later.csv'); records=rows('stock.csv'); fan=rows('fanout.csv')
g=grouped(main,('compiler','policy','layout','steps','workers'),'ms')
tails=collections.defaultdict(list)
for r in main:
    if r['steps']=='365' and r['workers']=='8':
        tails[r['compiler'],r['policy'],r['layout']].append(float(r['ms']))
stock=grouped(records,('compiler','policy','workers'),'ms')
fans=grouped(fan,('compiler','layout','cap','partitions'),'us')
log=(d/'soak.log').read_text()
suites=log.count('100% tests passed, 0 tests failed out of 1')
counts=list(zip(*(tuple(map(int,m)) for m in re.findall(r'accepted=(\d+) overlap=(\d+) bounds=(\d+)',(d/'differential.log').read_text()))))
assert len(counts)==3 and sum(map(sum,counts))==1200000
def table(head,body):
    return '\n'.join(['| '+' | '.join(head)+' |','|'+'---|'*len(head),*['| '+' | '.join(map(str,r))+' |' for r in body]])
ts=datetime.datetime.now(datetime.timezone.utc).strftime('%H:%M:%S')
L=['# Joined MT tests and dev002 benchmarks','', 'Doc Status: supporting','',
   f'Tested commit `adbb0dd1e` on 2026-11-24. Monitoring began at 12:35:11 UTC. Report generated at {ts} UTC.',
   '', '## Correctness','',
   f'- {suites} fresh `compiler_mt_segments_native` runs passed. Each compiled the four frontend fixtures and ran native checks with both sleep and active waiting. The suite covers scalar snapshots, balanced ranges, per-job and group caps, overlap rejection, vectors, hashes and worker failure.',
   '- All ten adjacent compiler, collection, generator, and hash storage tests passed.',
   '- On dev002 the repository native MT probe ran ten times per compiler and pool policy, 40 runs total. Each observed three simultaneous scans and two simultaneous sibling jobs with group cap five and scan cap three.',
   f'- A native differential test replayed 600,000 seeded four-job scenarios under each pool policy (1,200,000 batches in total) while deleting, replacing and reinserting hash keys. Against an independent insertion-order model, {sum(counts[0]):,} succeeded, {sum(counts[1]):,} rejected an overlap and {sum(counts[2]):,} rejected bounds. Every rejection verified zero worker entries and unchanged values.',
   '- The randomized run used Clang AddressSanitizer and UndefinedBehaviorSanitizer. Leak checking ran separately with Valgrind under both policies. Both Memcheck runs reported zero errors and zero bytes held at exit.',
   '- Four simultaneous join callers reused the same read grant and injected worker errors. AddressSanitizer/UndefinedBehaviorSanitizer and Clang ThreadSanitizer each completed 20,000 joins over the two policies. Clang ThreadSanitizer also checked 200,000 randomized batches. GCC ThreadSanitizer failed during startup on both hosts with an unexpected memory mapping.',
   '', '## Fixed-size scalar workloads','',
   'All timings are from dev002. Clang 18.1.3 and GCC 13.3.0 each built the emitted C++ and the production MT runtime with C++23 and O3. Processes were restricted to CPUs 0 through 7, one hardware thread from each physical core, with ordinary scheduler placement within that set. Timings include admission, dispatch and join. Initialization, pool startup and full-result verification run outside the timer. The scalar driver also checks partition counts inside the timed loop. Each benchmark process ran independently and compiler/policy/worker configurations were shuffled.',
   '',f'{len(main):,} verified samples cover 65,536 live entries, eight passes and two intensities. The heavy pass applies 365 dependent arithmetic updates per entry. The light pass applies one. A sparse hash was built with 131,072 keys and every other key deleted. The scaling baseline in this table is the same one-worker joined implementation. Times are pooled medians in milliseconds per eight passes.',
   '',table(['Compiler','Pool','Layout','Steps','1 worker','2','4','8','8-worker speedup'],
           [(c,p,l,k,*(f'{g[c,p,l,k,n]:.3f}' for n in ('1','2','4','8')),f'{g[c,p,l,k,"1"]/g[c,p,l,k,"8"]:.2f}×') for c in ('clang++','g++') for p in ('sleep','active') for l in ('vector','hash','holes') for k in ('1','365')]),
   '', '### Eight-worker variation', '',
   'The machine was shared and workers could migrate within the CPU mask. Figures below are milliseconds per eight heavy passes. P90 uses the nearest-rank sample. The samples within one process share its pool and OS placement. These measurements establish timing variation, without identifying a cause.',
   '',table(['Compiler','Pool','Layout','Median','P90','Maximum'],[(c,p,l,f'{statistics.median(v):.1f}',f'{sorted(v)[(9*len(v)+9)//10-1]:.1f}',f'{max(v):.1f}') for (c,p,l),v in sorted(tails.items())]),
   '', '## Inventory records','',
   f'{len(records):,} samples. Eight passes over 65,536 128-byte stock records and their adjustment vector. The direct baseline calls the same compiled worker without the pool. The joined paths use the real runtime, consume per-worker subtotals and verify all rows after timing. Median milliseconds per eight passes.',
   '',table(['Compiler','Pool','Direct','1 worker','2','4','8','8 vs direct'],[(c,p,*(f'{stock[c,p,n]:.3f}' for n in ('0','1','2','4','8')),f'{stock[c,p,"0"]/stock[c,p,"8"]:.2f}×')for c in ('clang++','g++')for p in ('sleep','active')]),
   '', '## Runtime-sized batches','',
   f'{len(fan):,} samples. One increment per live entry, fixed total of 65,536 and a sleeping pool. Time covers one generated batch through return of the result vector. Entry counts and values were verified outside the timer. Median microseconds per batch.',
   '',table(['Compiler','Layout','Worker cap','8 partitions','64','256','1,024'],[(c,l,cap,*(f'{fans[c,l,cap,n]:.1f}' for n in ('8','64','256','1024')))for c in ('clang++','g++') for l in ('vector','hash') for cap in ('1','8')]),
   '', 'The many-partition timings include grant construction, admission, scheduling, kernel work and result construction. The current admission implementation compares each nonempty interval with prior intervals. These end-to-end timings do not isolate the contribution of that comparison.',
   '', '## Evidence','',
   'The accompanying archive contains raw timings, focused logs, benchmark inputs and drivers. WSL2 supplied correctness results only. No timing evidence from WSL2 is pooled with dev002.']
dest.write_text('\n'.join(L)+'\n')
