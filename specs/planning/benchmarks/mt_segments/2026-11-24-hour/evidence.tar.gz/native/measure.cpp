#include <scpp/vectors.hpp>
#include <scpp/hashes.hpp>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <string_view>
using I=scpp::int64;
namespace App {
scpp::vector_int64 vector_pass_(scpp::vector_int64&, I, I);
scpp::vector_int64 hash_pass_(scpp::hash_int64_int64&, I, I);
}
int main(int argc,char**argv){
    if(argc!=5)return 1;
    std::string_view mode=argv[1];
    const I parts=std::atoll(argv[2]), steps=std::atoll(argv[3]), passes=8, n=65536;
    const int repetitions=std::atoi(argv[4]);
    const I stride=mode=="holes"?2:1;
    scpp::vector_int64 vec;
    scpp::hash_int64_int64 hash;
    auto pass=[&](I work){
        auto result=mode=="vector"?App::vector_pass_(vec,parts,work):App::hash_pass_(hash,parts,work);
        for(I p=0;p<parts;++p) if(result.at(p)!=n/parts) std::abort();
    };
    if(mode=="vector"){for(I i=0;i<n;++i) vec.append(i+1);}
    else {
        for(I i=0;i<n*stride;++i) hash.set(i,i/stride+1);
        if(stride==2)for(I i=1;i<2*n;i+=2) if(!hash.remove(i))return 2;
    }
    pass(0);
    for(int rep=0;rep<repetitions;++rep){
        auto begin=std::chrono::steady_clock::now();
        for(I p=0;p<passes;++p)pass(steps);
        double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        std::printf("%d,%.4f\n",rep,ms);
    }
    // Independent modular exponentiation of the affine transform, outside the timed interval.
    I mul=1,add=0,a=48271,b=1,mod=2147483647;
    for(I k=steps*passes*repetitions;k;k/=2){
        if(k%2){mul=mul*a%mod;add=(a*add+b)%mod;}
        b=(a*b+b)%mod; a=a*a%mod;
    }
    for(I i=0;i<n;i++) if((mode=="vector"?vec.at(i):hash.at(i*stride))!=(mul*(i+1)+add)%mod)return 3;
}
