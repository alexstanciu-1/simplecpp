#include <scpp/hashes.hpp>
#include <scpp/mt_segments.hpp>
#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <stdexcept>
#include <vector>
using I=scpp::int64;
using namespace scpp::mt;
struct Want { I start, length; bool write; };
struct Expected { const I* keys; I count; bool write; std::atomic<int>* entered; };
I inspect(const segment* s,const void* context){
    auto& expected=*static_cast<const Expected*>(context);
    ++*expected.entered;
    I i=0,cursor=0,total=0;
    while(s->next(cursor)){
        assert(i<expected.count && *static_cast<const I*>(s->key(cursor))==expected.keys[i]);
        if(expected.write) ++*static_cast<I*>(s->writable_value(cursor));
        total+=*static_cast<const I*>(s->value(cursor)); ++i;
    }
    assert(i==expected.count);return total;
}
int main(int argc,char**argv){
    assert(argc==3); std::mt19937 gen(std::atoi(argv[1]));
    scpp::hash_int64_int64 h; std::vector<I> order; std::array<I,128> model{};
    unsigned bounds=0,overlap=0,ok=0;
    for(int round=0;round<std::atoi(argv[2]);++round){
        I key=gen()%128;
        auto it=std::find(order.begin(),order.end(),key);
        if(gen()%3 && it!=order.end()){assert(h.remove(key));order.erase(it);}
        else {if(it==order.end())order.push_back(key);model[key]=gen()%10000;h.set(key,model[key]);}
        I n=order.size(); assert(n==h.size());
        std::vector<segment> grants; std::vector<job> jobs;
        std::array<Expected,4> expected; std::array<Want,4> ranges;
        grants.reserve(4);std::atomic<int> entered{};
        bool valid=true,conflict=false;
        for(int p=0;p<4;++p){
            I off=gen()%(n+1),len=gen()%(1+std::min<I>(6,n-off));
            if(p==3 && gen()%11==0){off=n;len=1;}
            bool write=gen()%2;
            ranges[p]={off,len,write};
            if(off+len>n)valid=false;
            for(int j=0;j<p;++j){
                auto r=ranges[j];
                if(len && r.length && (write||r.write) && std::max(off,r.start)<std::min(off+len,r.start+r.length))conflict=true;
            }
            expected[p]={len && valid ? order.data()+off : nullptr,len,write,&entered};
            grants.push_back(write?job::borrow_hash(h,off,len):job::borrow_hash_read(h,off,len));
        }
        // Each job references exactly one stable grant descriptor.
        segment inputs[][1]={{grants[0]},{grants[1]},{grants[2]},{grants[3]}};
        for(int p=0;p<4;++p)jobs.emplace_back(inputs[p],expected[p],inspect);
        bool accepted=false;
        try{join(jobs.data(),4,4);accepted=true;}
        catch(const std::out_of_range&){assert(!valid);++bounds;}
        catch(const std::invalid_argument&){assert(conflict);++overlap;}
        assert(accepted==(valid&&!conflict));assert(entered==(accepted?4:0));
        if(accepted){++ok;for(int p=0;p<4;++p){
            auto r=ranges[p];I sum=0;
            for(I i=0;i<r.length;++i){auto& v=model[order[r.start+i]];if(r.write)++v;sum+=v;}
            assert(sum==jobs[p].result);
        }}
        for(I k:order)assert(h.at(k)==model[k]);
    }
    std::printf("accepted=%u overlap=%u bounds=%u\n",ok,overlap,bounds);
}
