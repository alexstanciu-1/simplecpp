#include <scpp/mt_segments.hpp>
#include <scpp/hashes.hpp>
#include <array>
#include <atomic>
#include <barrier>
#include <cassert>
#include <cstdio>
#include <stdexcept>
#include <thread>
#include <vector>
using namespace scpp::mt;
using I=scpp::int64;
struct Batch {std::atomic<int> done{}; bool fail=false;};
struct Context {Batch* batch;int slot;};
I work(const segment* grants,const void* v){
    auto& ctx=*static_cast<const Context*>(v); I cursor=0,sum=0;
    while(grants->next(cursor))sum+=*static_cast<const I*>(grants->value(cursor));
    ++ctx.batch->done;
    if(ctx.slot==1 && ctx.batch->fail)throw std::runtime_error("probe");
    return sum+ctx.slot;
}
int main(){
    scpp::hash_int64_int64 table;
    for(I i=0;i<100;++i)table.set(i,i);
    for(I i=0;i<100;i+=2)assert(table.remove(i));
    // Identical grant descriptor arrays are reused by concurrent join callers.
    segment grants[][1]={{job::borrow_hash_read(table,2,5)},{job::borrow_hash_read(table,2,5)},{job::borrow_hash_read(table,2,5)}};
    std::barrier start(4);
    std::vector<std::thread> threads;
    for(int c=0;c<4;++c)threads.emplace_back([&,c]{
        start.arrive_and_wait();
        for(int round=0;round<2500;++round){
            Batch b;b.fail=(round+c)%17==0;
            Context ctx[]={{&b,0},{&b,1},{&b,2}};
            job jobs[]={{grants[0],ctx[0],work},{grants[1],ctx[1],work},{grants[2],ctx[2],work}};
            bool failed=false;
            try{join(jobs,3,3);}catch(const std::runtime_error& e){failed=std::string_view(e.what())=="probe";}
            assert(b.done==3 && failed==b.fail);
            if(!failed)for(int i=0;i<3;++i)assert(jobs[i].result==45+i);
        }
    });
    for(auto& th:threads)th.join();
    puts("10000 concurrent-caller joins verified");
}
