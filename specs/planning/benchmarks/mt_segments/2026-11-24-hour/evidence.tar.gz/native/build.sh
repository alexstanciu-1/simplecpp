set -eu
for compiler in clang++ g++; do
  "$compiler" --version | head -1
  "$compiler" -std=c++23 -O3 -pthread -ffunction-sections -fdata-sections -Wl,--gc-sections -Iruntime/generated/public -Iruntime/generated/private -Iruntime/src/numeric -Iruntime/src/hash -Iruntime/src/sequence -Iruntime/src/boxed -Iruntime/src/ownership measure.cpp generated/units/*.cpp runtime/generated/src/{runtime,hash}.cpp runtime/src/mt/segments.cpp runtime/src/numeric/arithmetic.cpp -o "bench-$compiler"
done
