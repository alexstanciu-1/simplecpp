import itertools,os,subprocess,time,random
print("epoch,compiler,policy,layout,workers,steps,sample,ms",flush=True)
for epoch in range(8):
    configs=list(itertools.product(('clang++','g++'),('sleep','active'),('vector','hash','holes'),(1,2,4,8),(1,365)))
    random.Random(2711+epoch).shuffle(configs)
    for compiler,policy,layout,n,k in configs:
        r=subprocess.run(['nice','-n','5','taskset','-c','0-7','./bench-'+compiler,layout,str(n),str(k),str(7 if k==1 else 3)],
                         text=True,capture_output=True,timeout=60,env=dict(os.environ,SCPP_MT_WAIT=policy),check=True)
        for line in r.stdout.splitlines():
            print(f'{epoch},{compiler},{policy},{layout},{n},{k},{line}',flush=True)
