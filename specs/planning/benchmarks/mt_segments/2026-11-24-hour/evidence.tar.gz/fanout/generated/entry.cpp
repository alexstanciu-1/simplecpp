// Generated adapter for the explicitly selected entry.
namespace App {
int scpp_entry_body();
}

#include <scpp/entry.hpp>
int main() { return ::scpp::run_entry_with_exceptions(::App::scpp_entry_body); }
