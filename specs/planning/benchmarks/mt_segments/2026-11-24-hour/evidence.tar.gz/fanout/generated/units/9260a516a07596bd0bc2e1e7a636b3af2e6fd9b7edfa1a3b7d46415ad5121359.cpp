// Generated from completed source-owned bodies.
#include <scpp/entry.hpp>
SCPP_REQUIRE_ENTRY_TARGET(31);

namespace App {
int scpp_entry_body()
{
	return 0;
}
}
