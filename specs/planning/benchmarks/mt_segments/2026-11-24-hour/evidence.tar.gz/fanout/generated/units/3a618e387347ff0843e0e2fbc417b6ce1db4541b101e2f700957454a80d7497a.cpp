// Generated from completed source-owned bodies.
#include <scpp/core/scalars.hpp>
#include <scpp/hashes.hpp>
#include <scpp/mt_segment.hpp>
#include <scpp/mt_segments.hpp>
#include <scpp/vectors.hpp>
#include <stdexcept>
#include <vector>
namespace App {
::scpp::vector_int64 hash_pass_([[maybe_unused]] ::scpp::hash_int64_int64 &var_data_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_cap_2);
::scpp::vector_int64 vector_pass_([[maybe_unused]] ::scpp::vector_int64 &var_data_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_cap_2);
::scpp::vector_int64 vector_pass_([[maybe_unused]] ::scpp::vector_int64 &var_data_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_cap_2)
{
	[[maybe_unused]] scpp::int64 var_n_3 = (var_data_0).size();
	return ([&]() { const auto workers = var_cap_2; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = var_parts_1; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_p_4 = 0; var_p_4 < count_0; ++var_p_4) values_list_0.push_back({var_p_4, ::scpp::mt::balanced_range(var_n_3, var_parts_1, var_p_4)}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[1]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow(var_data_0, snapshot_0.range1.offset, snapshot_0.range1.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_p_0, [[maybe_unused]] ::scpp::mt::segment var_s_1) -> ::scpp::int64 {
	[[maybe_unused]] scpp::int64 var_i_2 = 0;
	while (([&]() -> scpp::bool_t { const auto binary_left = var_i_2; const auto binary_right = (var_s_1).count(); return (binary_left < binary_right); }())) {
		{ auto& slot = (*static_cast<scpp::int64*>((var_s_1).at(var_i_2)));  slot = static_cast<scpp::int64>(((*static_cast<scpp::int64*>((var_s_1).at(var_i_2))) + 1LL)); }
		var_i_2 += 1LL;
	}
	return var_i_2;
}(static_cast<const values_0*>(context)->v0, inputs[0]); }}); } ::scpp::mt::join(jobs.data(), jobs.size(), workers); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}

::scpp::vector_int64 hash_pass_([[maybe_unused]] ::scpp::hash_int64_int64 &var_data_0, [[maybe_unused]] ::scpp::int64 var_parts_1, [[maybe_unused]] ::scpp::int64 var_cap_2)
{
	[[maybe_unused]] scpp::int64 var_n_3 = (var_data_0).size();
	return ([&]() { const auto workers = var_cap_2; if (workers <= 0) throw std::invalid_argument("Group workers must be positive"); const auto count_0 = var_parts_1; if (count_0 < 0) throw std::invalid_argument("each bound must be nonnegative"); struct values_0 { scpp::int64 v0; ::scpp::mt::segment_range range1; }; std::vector<values_0> values_list_0; values_list_0.reserve(count_0); for (::scpp::int64 var_p_4 = 0; var_p_4 < count_0; ++var_p_4) values_list_0.push_back({var_p_4, ::scpp::mt::balanced_range(var_n_3, var_parts_1, var_p_4)}); std::vector<::scpp::mt::job> jobs; struct grants_0 { ::scpp::mt::segment slots[1]; }; std::vector<grants_0> grants_list_0; grants_list_0.reserve(values_list_0.size()); for (const auto& snapshot_0 : values_list_0) { grants_list_0.push_back({::scpp::mt::job::borrow_hash(var_data_0, snapshot_0.range1.offset, snapshot_0.range1.length)}); jobs.push_back({grants_list_0.back().slots, snapshot_0, [](const ::scpp::mt::segment* inputs, const void* context) { return []([[maybe_unused]] ::scpp::int64 var_p_0, [[maybe_unused]] ::scpp::mt::segment var_s_1) -> ::scpp::int64 {
{ const auto hash_view = var_s_1; int64_t hash_cursor = 0; while (hash_view.next(hash_cursor)) {
[[maybe_unused]] auto& var_v_2 = *static_cast<scpp::int64*>(hash_view.writable_value(hash_cursor));
	var_v_2 = (var_v_2 + 1LL);
} }
	return (var_s_1).count();
}(static_cast<const values_0*>(context)->v0, inputs[0]); }}); } ::scpp::mt::join(jobs.data(), jobs.size(), workers); scpp::vector_int64 results; for (const auto& job : jobs) results.append(static_cast<::scpp::int64>(job.result)); return results; }());
}
}
