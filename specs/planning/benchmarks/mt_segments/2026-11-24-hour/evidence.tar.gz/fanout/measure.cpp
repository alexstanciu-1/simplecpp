#include <scpp/vectors.hpp>
#include <scpp/hashes.hpp>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <string_view>
using I=scpp::int64;
namespace App {
scpp::vector_int64 vector_pass_(scpp::vector_int64&,I,I);
scpp::vector_int64 hash_pass_(scpp::hash_int64_int64&,I,I);
}
int main(int argc,char**argv){
    if(argc!=4)return 1;
    bool hashed=std::string_view(argv[1])=="hash";
    const I parts=std::atoi(argv[2]),cap=std::atoi(argv[3]),n=65536;
    scpp::vector_int64 vec; scpp::hash_int64_int64 h;
    for(I i=0;i<n;++i){if(hashed)h.set(i,i);else vec.append(i);}
    for(int rep=-1;rep<9;++rep){
        auto begin=std::chrono::steady_clock::now();
        auto result=hashed?App::hash_pass_(h,parts,cap):App::vector_pass_(vec,parts,cap);
        double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-begin).count();
        if(result.size()!=parts)return 2;
        for(I p=0;p<parts;++p)if(result.at(p)!=n/parts)return 3;
        if(rep>=0)std::printf("%d,%.3f\n",rep,us);
    }
    for(I i=0;i<n;++i)if((hashed?h.at(i):vec.at(i))!=i+10)return 4;
}
