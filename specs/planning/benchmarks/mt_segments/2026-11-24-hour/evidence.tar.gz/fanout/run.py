import itertools,random,subprocess,os
print('round,compiler,layout,partitions,cap,sample,us',flush=True)
for trial in range(10):
    matrix=list(itertools.product(('clang++','g++'),('vector','hash'),(8,64,256,1024),(1,8)))
    random.Random(200+trial).shuffle(matrix)
    for c,layout,parts,cap in matrix:
        r=subprocess.run(['nice','-n','5','taskset','-c','0-7','./bench-'+c,layout,str(parts),str(cap)],text=True,capture_output=True,
                         env=dict(os.environ,SCPP_MT_WAIT='sleep'),check=True,timeout=30)
        for line in r.stdout.splitlines():
            print(f'{trial},{c},{layout},{parts},{cap},{line}',flush=True)
