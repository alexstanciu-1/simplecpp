function vector_pass(vector<int> &$data, int $parts, int $cap): vector<int> {
    $n = count($data);
    return parallel (workers: $cap) {
        job (each: $p in 0 ..< $parts, write: $s = segment($data,balanced_range($n,$parts,$p))) {
            $i = 0;
            while ($i < count($s)) {
                $s[$i] = $s[$i]+1;
                $i += 1;
            }
            return $i;
        }
    };
}
function hash_pass(hash<int,int> &$data, int $parts, int $cap): vector<int> {
    $n = count($data);
    return parallel (workers: $cap) {
        job (each: $p in 0 ..< $parts, write: $s = segment($data,balanced_range($n,$parts,$p))) {
            foreach ($s as $v) { $v = $v+1; }
            return count($s);
        }
    };
}
