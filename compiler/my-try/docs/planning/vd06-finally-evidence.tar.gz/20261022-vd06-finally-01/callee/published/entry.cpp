#include "specializations/runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "callables/n6661696c.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
try {
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { return function_fail(); }()))).address());
}
catch (...) {
scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b local_e = scpp::internal::runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b();
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto receiver_0 = local_e;
return receiver_0.message_string(); }()))).address());
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
