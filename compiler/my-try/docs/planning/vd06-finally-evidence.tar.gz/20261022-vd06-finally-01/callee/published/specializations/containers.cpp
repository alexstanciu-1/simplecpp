#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
using native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b = ::scpp::shared_p<scpp::Exception>;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b) == sizeof(native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b));
static_assert(alignof(concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b) == alignof(native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b));
native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& unwrap(concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& value) { return *std::launder(static_cast<native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b*>(value.address())); }
const native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& unwrap(const concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& value) { return *std::launder(static_cast<const native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b*>(value.address())); }
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_default
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b() noexcept(SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_default_nothrow) { ::new(address()) native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(); }
#endif
#if SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_copy
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(const concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& other) noexcept(SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_copy_nothrow) { ::new(address()) native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_move
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b&& other) noexcept(SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_move_nothrow) { ::new(address()) native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_copy_assign
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::operator=(const concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& other) noexcept(SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_move_assign
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b& concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::operator=(concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b&& other) noexcept(SCPP_LAYOUT_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
static_assert(std::is_nothrow_destructible_v<native_concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b>);
concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::~concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "scpp/int_t.hpp"
using native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 = scpp::int_t<>;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == sizeof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
static_assert(alignof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == alignof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(int64_t value) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(value); }
int64_t concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::native_value() const noexcept { return unwrap(*this).native_value(); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>);
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::~concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "scpp/support/string_representation.hpp"
using native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 = scpp::string_t;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == sizeof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
static_assert(alignof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == alignof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const char* bytes, size_t size) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(scpp::string_representation::construct(bytes, size)); }
const char* concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_data() const noexcept { return scpp::string_representation::data(unwrap(*this)); }
size_t concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_size() const noexcept { return scpp::string_representation::size(unwrap(*this)); }
void concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::append(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { scpp::string_representation::append(unwrap(*this), unwrap(value)); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>);
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::~concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "scpp/support/string_representation.hpp"
#include <memory>
#include <utility>
#include <type_traits>
#include <new>
namespace scpp::internal {
scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::message_string() { auto operation = [&]() -> decltype(auto) { return (*std::launder(static_cast<::scpp::shared_p<scpp::Exception>*>(address())))->message_string(); }; return []<class Operation>(const Operation& operation) -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { using Result = std::remove_cvref_t<decltype(operation())>; if constexpr (std::is_same_v<Result, scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>) { return operation(); } else { static_assert(std::is_same_v<Result, scpp::string_t>); return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operation_result{}, +[](void* destination, const void* input) { const auto& invoke = *static_cast<const Operation*>(input); ::new(destination) scpp::string_t(invoke()); }, &operation); } }(operation); }
}

#include "specializations/runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b() { const void* addresses[] = {nullptr}; return scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::operation_result{}, +[](void* destination, const void* input) { auto addresses = static_cast<const void* const*>(input); ::new(destination) ::scpp::shared_p<scpp::Exception>(([]() { try { throw; } catch (const ::scpp::php::thrown_object& caught) { auto value = ::scpp::php::catch_as<scpp::Exception>(caught); if (!value) { throw; } return value; } }())); }, addresses); } }

#include "specializations/runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include <memory>
#include <new>
namespace scpp::internal { [[noreturn]] void runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184(const void* p0) { auto& a0 = *std::launder(static_cast<const ::scpp::shared_p<scpp::Exception>*>(p0)); throw ::scpp::php::make_thrown(a0); } }

#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/support/php_string.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); ::scpp::php::echo_one(a0); } }

#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); ::scpp::php::echo_one(a0); } }

#include "specializations/runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "type_traits"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); auto operation = [&]() -> decltype(auto) { return scpp::Exception::make(a0); }; return []<class Operation>(const Operation& operation) -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { using Result = std::remove_cvref_t<decltype(operation())>; if constexpr (std::is_same_v<Result, scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b>) { return operation(); } else { static_assert(std::is_same_v<Result, ::scpp::shared_p<scpp::Exception>>); return scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b(scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b::operation_result{}, +[](void* destination, const void* input) { const auto& invoke = *static_cast<const Operation*>(input); ::new(destination) ::scpp::shared_p<scpp::Exception>(invoke()); }, &operation); } }(operation); } }

