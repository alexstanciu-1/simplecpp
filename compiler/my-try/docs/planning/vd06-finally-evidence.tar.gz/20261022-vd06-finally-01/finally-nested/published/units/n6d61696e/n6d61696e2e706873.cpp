#include "callables/n66.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 function_f()
{
{
scpp::internal::runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
{
scpp::internal::runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f finally_exception_1;
bool finally_return_1 = false;
try { [&]() -> void {
{
finally_exception_1.emplace(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("saved", 5));
finally_return_1 = true;
return;
}
}(); }
catch (...) { finally_exception_1.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("i", 1))).address());
}
finally_exception_1.rethrow_if_exception();
if (finally_return_1) {
finally_exception_0.emplace(finally_exception_1.value());
finally_return_0 = true;
return;
}
finally_exception_1.unreachable(); // unreachable: prepared finally region cannot fall through
}
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("o", 1))).address());
}
finally_exception_0.rethrow_if_exception();
if (finally_return_0) {
return finally_exception_0.value();
}
finally_exception_0.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

