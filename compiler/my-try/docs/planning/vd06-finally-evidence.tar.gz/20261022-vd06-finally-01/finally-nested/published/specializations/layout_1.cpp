#include <cstdio>
#include <type_traits>
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include <exception>
#include <optional>
struct native_runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f { std::exception_ptr exception; std::optional<scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80> value; };
int main() { std::printf("// scpp-native-layout-v1\n");
std::printf("#define SCPP_LAYOUT_runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f_SIZE %zu\n#define SCPP_LAYOUT_runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f_ALIGN %zu\n", sizeof(native_runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f), alignof(native_runtime_finally_storage_bba4520b0ea2b48e5d166aaf903ab0eb4c4731eced30d4374b214129f2171b0f));
}
