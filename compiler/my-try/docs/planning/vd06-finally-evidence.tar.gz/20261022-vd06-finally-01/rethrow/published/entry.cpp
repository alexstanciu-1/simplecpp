#include "specializations/runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b.hpp"
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d.hpp"
#include "specializations/runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
try {
try {
{ scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b throw_value_0 = ([&]() -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { 	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("same", 4);
return scpp::internal::runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d((argument_1).address()); }()); scpp::internal::runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184((throw_value_0).address()); }
}
catch (...) {
scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b local_e = scpp::internal::runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b();
{ scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b throw_value_2 = local_e; scpp::internal::runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184((throw_value_2).address()); }
}
}
catch (...) {
scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b local_e = scpp::internal::runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b();
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto receiver_3 = local_e;
return receiver_3.message_string(); }()))).address());
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
