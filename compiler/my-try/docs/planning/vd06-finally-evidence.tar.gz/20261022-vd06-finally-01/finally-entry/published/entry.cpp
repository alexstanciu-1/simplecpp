#include "specializations/runtime_finally_storage_84be9c474f8f41fa28b27cb08dc2c04e937739908860e42a654cf5908008e435.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
{
scpp::internal::runtime_finally_storage_84be9c474f8f41fa28b27cb08dc2c04e937739908860e42a654cf5908008e435 finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_exception_0.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL)).native_value()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("entry", 5))).address());
}
finally_exception_0.rethrow_if_exception();
if (finally_return_0) {
return finally_exception_0.value();
}
finally_exception_0.unreachable(); // unreachable: prepared finally region cannot fall through
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
