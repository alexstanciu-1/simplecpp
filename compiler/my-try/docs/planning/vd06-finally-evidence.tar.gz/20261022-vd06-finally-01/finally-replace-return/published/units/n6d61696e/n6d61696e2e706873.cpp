#include "callables/n66.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681.hpp"
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d.hpp"
#include "specializations/runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184.hpp"
scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 function_f()
{
{
scpp::internal::runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681 finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_exception_0.emplace(static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
{ scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b throw_value_1 = ([&]() -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { 	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_2 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("new", 3);
return scpp::internal::runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d((argument_2).address()); }()); scpp::internal::runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184((throw_value_1).address()); }
}
finally_exception_0.rethrow_if_exception();
if (finally_return_0) {
return finally_exception_0.value();
}
finally_exception_0.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

