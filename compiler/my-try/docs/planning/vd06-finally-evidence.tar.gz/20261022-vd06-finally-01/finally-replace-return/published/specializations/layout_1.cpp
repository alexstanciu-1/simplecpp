#include <cstdio>
#include <type_traits>
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include <exception>
#include <optional>
struct native_runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681 { std::exception_ptr exception; std::optional<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421> value; };
int main() { std::printf("// scpp-native-layout-v1\n");
std::printf("#define SCPP_LAYOUT_runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681_SIZE %zu\n#define SCPP_LAYOUT_runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681_ALIGN %zu\n", sizeof(native_runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681), alignof(native_runtime_finally_storage_8dc05d30634f524323c31a6d9386af3a51d778225eb93df0ad3ac48984380681));
}
