#include "specializations/runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b.hpp"
#include "specializations/runtime_finally_storage_78a9de4b5d1f1f020300bc3f5403562519fb1d32c088e374ce58f92e09ae6792.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_binary_c25312d661c81f64ccf96c86d4c2cad235e95fea1ee17d7eab174dedd4e659da.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/base.hpp"

static int application_body()
{
try {
{
scpp::internal::runtime_finally_storage_78a9de4b5d1f1f020300bc3f5403562519fb1d32c088e374ce58f92e09ae6792 finally_exception_0;
try { [&]() -> void {
{
	auto local_z = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL);
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL); auto operand_2 = local_z; return scpp::internal::runtime_binary_c25312d661c81f64ccf96c86d4c2cad235e95fea1ee17d7eab174dedd4e659da((operand_1).address(), (operand_2).address()); }()))).address());
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("cleanup", 7))).address());
}
finally_exception_0.rethrow_if_exception();
}
}
catch (...) {
scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b local_e = scpp::internal::runtime_exception_catch_13cb7a1a009d6b72602aae25688424d7847dedf713e47f9a3a1c3aaaaf0d8b8b();
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("wrong", 5))).address());
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
