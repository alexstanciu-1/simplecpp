#pragma once
namespace scpp::internal { [[noreturn]] void runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184(const void* p0); }
