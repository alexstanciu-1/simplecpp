#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d.hpp"
#include "specializations/runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184.hpp"
#include "specializations/base.hpp"

static int application_body()
{
{ scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b throw_value_0 = ([&]() -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { 	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("unhandled", 9);
return scpp::internal::runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d((argument_1).address()); }()); scpp::internal::runtime_exception_throw_ff821eb4eb98357970290f3ee4c063a06f7b3eb2da38043676d3bc6ba70b1184((throw_value_0).address()); }
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
