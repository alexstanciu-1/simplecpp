#include "callables/n66.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	([&]() -> void { return function_f(); }());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
