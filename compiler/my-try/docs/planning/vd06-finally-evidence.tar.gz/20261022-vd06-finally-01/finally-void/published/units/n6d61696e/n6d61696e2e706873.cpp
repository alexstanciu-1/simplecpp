#include "callables/n66.hpp"
#include "specializations/runtime_finally_storage_3a475608ea11da5a365fe920f802b718f944242bb652006eb5d756768b8850d3.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
void function_f()
{
{
scpp::internal::runtime_finally_storage_3a475608ea11da5a365fe920f802b718f944242bb652006eb5d756768b8850d3 finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("f", 1))).address());
}
finally_exception_0.rethrow_if_exception();
if (finally_return_0) {
return;
}
finally_exception_0.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

