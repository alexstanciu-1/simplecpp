#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_binary_64064a09a7e8a889ee4af8589a8881d7193fa76065e4a6252d16273047b51eb1.hpp"
#include "specializations/runtime_finally_storage_78a9de4b5d1f1f020300bc3f5403562519fb1d32c088e374ce58f92e09ae6792.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
{
	auto local_n = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL);
for (; (([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_0 = local_n; auto operand_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); return scpp::internal::runtime_binary_64064a09a7e8a889ee4af8589a8881d7193fa76065e4a6252d16273047b51eb1((operand_0).address(), (operand_1).address()); }())).native_value(); (void)(static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(++local_n))) {
switch ((local_n).native_value()) {
case 0LL:
{
{
scpp::internal::runtime_finally_storage_78a9de4b5d1f1f020300bc3f5403562519fb1d32c088e374ce58f92e09ae6792 finally_exception_2;
int finally_transfer_2 = 0;
try { [&]() -> void {
{
finally_transfer_2 = 2;
return;
}
}(); }
catch (...) { finally_exception_2.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("c", 1))).address());
}
finally_exception_2.rethrow_if_exception();
if (finally_transfer_2 == 2) {
continue;
}
finally_exception_2.unreachable(); // unreachable: prepared finally region cannot fall through
}
break;
}
default:
{
{
scpp::internal::runtime_finally_storage_78a9de4b5d1f1f020300bc3f5403562519fb1d32c088e374ce58f92e09ae6792 finally_exception_3;
int finally_transfer_3 = 0;
try { [&]() -> void {
{
finally_transfer_3 = 1;
return;
}
}(); }
catch (...) { finally_exception_3.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("b", 1))).address());
}
finally_exception_3.rethrow_if_exception();
if (finally_transfer_3 == 1) {
break;
}
finally_exception_3.unreachable(); // unreachable: prepared finally region cannot fall through
}
}
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("x", 1))).address());
}
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
