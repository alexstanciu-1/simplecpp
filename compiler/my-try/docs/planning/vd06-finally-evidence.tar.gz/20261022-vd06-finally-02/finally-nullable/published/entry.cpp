#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7.hpp"
#include "callables/n66.hpp"
#include "specializations/runtime_conversion_065e331fe9f97610623d540f25437cff91cdf17e4f16704ebeb2522ad0fb08e2.hpp"
#include "specializations/runtime_wrapper_presence_73276750c2d932a87fc9ea1952a04876ed967c50a88828499d314bd70eb654d0.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { scpp::internal::concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7 coalesce_0 = ([&]() -> scpp::internal::concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7 { return function_f(); }()); if ((scpp::internal::runtime_wrapper_presence_73276750c2d932a87fc9ea1952a04876ed967c50a88828499d314bd70eb654d0((coalesce_0).address())).native_value()) { return ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { const auto& runtime_input_1 = coalesce_0; return scpp::internal::runtime_conversion_065e331fe9f97610623d540f25437cff91cdf17e4f16704ebeb2522ad0fb08e2((runtime_input_1).address()); }()); } return static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); }()))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
