#include "callables/n66.hpp"
#include "specializations/concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7.hpp"
#include "specializations/runtime_finally_storage_22798a2bcfae95a5a5c34a6463fe6ef1cadbf2d029ef4621467560f6927712dc.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_conversion_276fa04346cdc404094eb8564fd36cdb3895d6ad084673cc7cd8545538fe4461.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
scpp::internal::concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7 function_f()
{
{
scpp::internal::runtime_finally_storage_22798a2bcfae95a5a5c34a6463fe6ef1cadbf2d029ef4621467560f6927712dc finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_exception_0.emplace(([&]() -> scpp::internal::concrete_n_nullable_int__005a26a90fcdee81982f3beb8288a1e76e95d86b394fc75507f008c7bbe518e7 { const auto& runtime_input_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL); return scpp::internal::runtime_conversion_276fa04346cdc404094eb8564fd36cdb3895d6ad084673cc7cd8545538fe4461((runtime_input_1).address()); }()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0.capture_exception(); }
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("f", 1))).address());
}
finally_exception_0.rethrow_if_exception();
if (finally_return_0) {
return finally_exception_0.value();
}
finally_exception_0.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

