#pragma once
struct record_P;
record_P function_f();
