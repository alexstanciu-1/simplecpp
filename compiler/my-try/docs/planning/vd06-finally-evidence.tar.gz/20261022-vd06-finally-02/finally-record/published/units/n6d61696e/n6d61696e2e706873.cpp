#include "callables/n66.hpp"
#include "types/n50.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc.hpp"
record_P function_f()
{
	record_P local_p = ([&]() -> record_P { scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 record_input_0 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL);
return record_P(record_P::scpp_data_tag{}, static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&&>(record_input_0)); }());
{
scpp::internal::runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc finally_exception_1;
bool finally_return_1 = false;
try { [&]() -> void {
{
finally_exception_1.emplace(local_p);
finally_return_1 = true;
return;
}
}(); }
catch (...) { finally_exception_1.capture_exception(); }
{
	(local_p).field_x = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(9LL);
}
finally_exception_1.rethrow_if_exception();
if (finally_return_1) {
return finally_exception_1.value();
}
finally_exception_1.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

