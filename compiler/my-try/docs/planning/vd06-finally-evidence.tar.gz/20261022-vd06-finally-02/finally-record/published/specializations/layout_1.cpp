#include <cstdio>
#include <type_traits>
#include "types/n50.hpp"
#include <exception>
#include <optional>
struct native_runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc { std::exception_ptr exception; std::optional<record_P> value; };
int main() { std::printf("// scpp-native-layout-v1\n");
std::printf("#define SCPP_LAYOUT_runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc_SIZE %zu\n#define SCPP_LAYOUT_runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc_ALIGN %zu\n", sizeof(native_runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc), alignof(native_runtime_finally_storage_af7cf636e96b593730b8f3787937ab0df4de15e14b04e40a7b2eb7a360da9edc));
}
