#pragma once
namespace scpp::internal { void runtime_write_key_44f52003ddfcce8d1dcdf32d43bfae59165f600d8934059b70234dcf3c095295(const void* p0); }
