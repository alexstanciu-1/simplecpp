#include "callables/n66.hpp"
#include "specializations/concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7.hpp"
#include "specializations/runtime_initialize_buffer_2da929b8af395161052c898f696ff85d4597ab82b137c93f09cb98d8f1a70ac1.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_finally_storage_c1427c717abde75114c344623f8e021b2108779bc87cb7c6daf245087ae988fd.hpp"
#include "specializations/runtime_concrete_index_8ece81904a7f30496530d1dfe061e5c4317bfb9189d61a3bdcc291c2df279e81.hpp"
#include "specializations/runtime_write_key_44f52003ddfcce8d1dcdf32d43bfae59165f600d8934059b70234dcf3c095295.hpp"
scpp::internal::concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7 function_f()
{
	scpp::internal::concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7 local_v = ([&]() -> scpp::internal::concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7 { scpp::internal::runtime_initialize_buffer_2da929b8af395161052c898f696ff85d4597ab82b137c93f09cb98d8f1a70ac1 initializer_0(1);
{
scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 initializer_value_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL);
initializer_0.append(&(initializer_value_1));
}
return initializer_0.finish(); }());
{
scpp::internal::runtime_finally_storage_c1427c717abde75114c344623f8e021b2108779bc87cb7c6daf245087ae988fd finally_exception_2;
bool finally_return_2 = false;
try { [&]() -> void {
{
finally_exception_2.emplace(local_v);
finally_return_2 = true;
return;
}
}(); }
catch (...) { finally_exception_2.capture_exception(); }
{
	{ auto& write_receiver_3 = local_v; scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 write_key_3 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); scpp::internal::runtime_write_key_44f52003ddfcce8d1dcdf32d43bfae59165f600d8934059b70234dcf3c095295((write_key_3).address()); scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 write_value_3 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(9LL); scpp::index_store(write_receiver_3, write_key_3, write_value_3); }
}
finally_exception_2.rethrow_if_exception();
if (finally_return_2) {
return finally_exception_2.value();
}
finally_exception_2.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

