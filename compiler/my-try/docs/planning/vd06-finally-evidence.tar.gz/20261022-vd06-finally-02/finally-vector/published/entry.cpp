#include "specializations/concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7.hpp"
#include "callables/n66.hpp"
#include "specializations/runtime_concrete_index_58b4bc137bacc66289f36750bcb9144ff9d1f7c37e8c92dcd6fb766493e5eaec.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	auto local_r = ([&]() -> scpp::internal::concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7 { return function_f(); }());
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { const auto& index_receiver_0 = local_r; scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 index_key_0 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); return scpp::checked_index_read(index_receiver_0, index_key_0); }()))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
