#include "callables/n66.hpp"
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d.hpp"
#include "specializations/runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575.hpp"
#include "scpp/null_t.hpp"
#include "specializations/runtime_conversion_542cc481165a040705c26a0476d570f024441ea7699dabe9d26e5ab4ca2239b2.hpp"
scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b function_f()
{
	auto local_e = ([&]() -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { 	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_0 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("saved", 5);
return scpp::internal::runtime_runtime_call_d5bd2803abb23dabf5529703bc3828a642d2d99e4eb236f2491179b1049da03d((argument_0).address()); }());
{
scpp::internal::runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575 finally_exception_1;
bool finally_return_1 = false;
try { [&]() -> void {
{
finally_exception_1.emplace(local_e);
finally_return_1 = true;
return;
}
}(); }
catch (...) { finally_exception_1.capture_exception(); }
{
	local_e = ([&]() -> scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b { const auto& runtime_input_2 = scpp::null; return scpp::internal::runtime_conversion_542cc481165a040705c26a0476d570f024441ea7699dabe9d26e5ab4ca2239b2(&(runtime_input_2)); }());
}
finally_exception_1.rethrow_if_exception();
if (finally_return_1) {
return finally_exception_1.value();
}
finally_exception_1.unreachable(); // unreachable: prepared finally region cannot fall through
}
}

