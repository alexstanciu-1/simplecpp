#include <cstdio>
#include <type_traits>
#include "specializations/concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b.hpp"
#include <exception>
#include <optional>
struct native_runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575 { std::exception_ptr exception; std::optional<scpp::internal::concrete_n_Exception_1c4f1a185ff085ada11978b100e09d2298581fa1a71188dcf4dd446f09fd2d0b> value; };
int main() { std::printf("// scpp-native-layout-v1\n");
std::printf("#define SCPP_LAYOUT_runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575_SIZE %zu\n#define SCPP_LAYOUT_runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575_ALIGN %zu\n", sizeof(native_runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575), alignof(native_runtime_finally_storage_4d5272700d588032ec9c038f5eee8b90912d375b3c5824632f0ebb09c940f575));
}
