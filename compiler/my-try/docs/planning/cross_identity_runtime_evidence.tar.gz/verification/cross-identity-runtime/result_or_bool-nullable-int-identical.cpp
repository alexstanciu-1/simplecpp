#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result_or_bool<scpp::int_t<>>& a,const scpp::nullable<scpp::int_t<>>& b) { return scpp::php::identical(a,b); }
