#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result_or_false<scpp::int_t<>>& a,const scpp::result<scpp::int_t<>>& b) { return scpp::php::identical(a,b); }
