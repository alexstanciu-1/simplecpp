#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::nullable<scpp::string_t>& a,const scpp::result_or_false<scpp::string_t>& b) { return scpp::php::identical(a,b); }
