#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::nullable<scpp::float_t>& a,const scpp::result_or_bool<scpp::float_t>& b) { return scpp::php::identical(a,b); }
