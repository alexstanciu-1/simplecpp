#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result<scpp::float_t>& a,const scpp::result_or_false<scpp::float_t>& b) { return scpp::php::identical(a,b); }
