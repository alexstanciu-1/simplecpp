#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result<scpp::string_t>& a,const scpp::nullable<scpp::string_t>& b) { return scpp::php::identical(a,b); }
