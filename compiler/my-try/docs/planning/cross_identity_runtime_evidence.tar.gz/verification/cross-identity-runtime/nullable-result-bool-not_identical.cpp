#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::nullable<scpp::bool_t>& a,const scpp::result<scpp::bool_t>& b) { return scpp::php::not_identical(a,b); }
