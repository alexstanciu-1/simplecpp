#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result_or_bool<scpp::bool_t>& a,const scpp::result<scpp::bool_t>& b) { return scpp::php::identical(a,b); }
