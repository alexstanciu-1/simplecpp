#include "scpp/null_t.hpp"
#include "specializations/concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9.hpp"
#include "specializations/runtime_conversion_d7fcd2a33e6c28a1b7df22a3e6a14350612f07ea1a8bb32ba77bdbbe37380f3c.hpp"
#include "specializations/concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4.hpp"
#include "specializations/runtime_conversion_d95bc99abfadc134cbf518750f703b4ac119905814e46333de787604342c8d36.hpp"
#include "specializations/concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882.hpp"
#include "specializations/runtime_conversion_200cac392cc0e80b99b20399aadd552dd64a6a4e9f8ad802e5d12890aef8a4bb.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_finally_storage_84be9c474f8f41fa28b27cb08dc2c04e937739908860e42a654cf5908008e435.hpp"
#include "specializations/runtime_observation_0f28efb0fee9f7100a237988c11e8dbfaa2c977217c9bc731db46f64df7e3930.hpp"
#include "specializations/runtime_take_c4ae7d5571163feceabb960de9b1fdfc4a42adca369fd2eaae52a812fd2c2a55.hpp"
#include "specializations/concrete_n_result_ui_app__a9cc784a5c29ecf36df6a4f35c47c5452b4cfb522e2672005d93b660b7774ba7.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_result_ui_window__eff62ae11af1191b46318003b8b6af3f621cf414c30b9aaece30a61b6204cee6.hpp"
#include "specializations/runtime_runtime_call_4b3cb3ee6ae8340762f32f5246e5e6a13198004743add934ba419181d825f05b.hpp"
#include "specializations/runtime_take_57bc2db173aec2f70059220529872c72b6e197c8cbed417da6189ee506fc6fb1.hpp"
#include "specializations/concrete_n_result_webview__a7df8dc202e61b49dcc9bbe731b5c9ba76bdfbf4ef1e013fad33ad5950246451.hpp"
#include "specializations/runtime_runtime_call_54dbb86c04c3a5a1e57f424eb2afff25d26b7da01bc0455afd3200b686d83128.hpp"
#include "specializations/runtime_take_ccaeb2dcf57638110202d95924280310c8bd4d1f3cf8b47f5181cbd779b1f824.hpp"
#include "specializations/concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21.hpp"
#include "specializations/runtime_runtime_call_da0833cd507d2b826db7ff87e35d8ef22cf6e9dc8446530a86c21fdda8061f35.hpp"
#include "specializations/runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b.hpp"
#include "specializations/runtime_runtime_call_93fa10c21ac7a2d1c4f2bd2daf36ade5593f48cd06f716b68b4341e58ab8618e.hpp"
#include "callables/n636c6561725f76696577.hpp"
#include "specializations/runtime_runtime_call_fd0f866cb576240618910bb159ca2932340e561a4b29d048783e18ac49cc8760.hpp"
#include "specializations/runtime_binary_64064a09a7e8a889ee4af8589a8881d7193fa76065e4a6252d16273047b51eb1.hpp"
#include "specializations/runtime_runtime_call_ed1eafeda6c604246b4927cb2baf7ef2b00760d8fb003564e9610daedf81c17c.hpp"
#include "specializations/concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66.hpp"
#include "specializations/runtime_runtime_call_c5666b203323c2054564216924e51a03a8ef1178a3f1a06c6649ad4d6f98cbc0.hpp"
#include "specializations/runtime_runtime_call_5db660cf59dace1a517bf0974926ffda4f288359483d999bef267eef018aadbb.hpp"
#include "specializations/runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d.hpp"
#include "specializations/runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7.hpp"
#include "specializations/runtime_runtime_call_0b31eb3634003c821e5226a705a06363a93333ad3a83ca99acf1c5c3c4304ddc.hpp"
#include "specializations/runtime_runtime_call_ea05b091b50142cee69943e5acfe93f12dcf007fe0d1a8cd45592ce7614419fb.hpp"
#include "specializations/runtime_runtime_call_db8f987fa2f1a1ca17119508c755dd81f5832ee19f035b46e3b8611899db7acb.hpp"
#include "specializations/runtime_runtime_call_5fc7d6047dac375b54c1d37f437bf8f033876f9c517bd240d249b63a5857232d.hpp"
#include "specializations/runtime_runtime_call_ab216dc6d0fe8cef77a40dbb56a296bbbefed6526461790f26c8b2ad8d172f32.hpp"
#include "specializations/runtime_runtime_call_9b5e9872bd78468c159398b7367f8aef583e3882a49310bd0a468ad58cafefec.hpp"
#include "specializations/runtime_runtime_call_4e5de4bcb4246867f576e7950dd80a30fdace03845332a5a1edacde316b5f89d.hpp"
#include "specializations/runtime_binary_c13eff332ac846c73458a6024117ba459c41ac2644cef64b8bd0a934360f7fe9.hpp"
#include "specializations/runtime_runtime_call_f25063939d49231c8736b27cf5a9daf4c94a7a26203f34823d1e2f9d94d8d64b.hpp"
#include "specializations/runtime_runtime_call_8fa66cb6966f1490772a1d783a775eb4293bfeb060d5619d48fd00c78f705c46.hpp"
#include "specializations/runtime_runtime_call_3c4baec3debe9be6a108d370b56d102c53b786c6837f48e2dbb84bba32b4e0d6.hpp"
#include "specializations/runtime_runtime_call_e1bf46da21711835e6789dceaec03adeee4d7b647e27ac7ecad8c90883e93126.hpp"
#include "specializations/runtime_runtime_call_4dcf94bf31b7b860f26a7670e16de89e6407705e007f371c230807e9c74ac5bc.hpp"
#include "specializations/runtime_runtime_call_19407e4a952a017cd4c1d72c3b83a95222203e6930d5e8789ade6f7188cd601c.hpp"
#include "specializations/runtime_runtime_call_f78d1efe6ecc0dc503b47387d5e16090c9f61531c0f7862b54fdef071d15e224.hpp"
#include "specializations/runtime_runtime_call_fec9b47cb09959852e331d07726a050fb8d6641ab53ddab069f68e97a4817e99.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 local_app = ([&]() -> scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 { const auto& runtime_input_0 = scpp::null; return scpp::internal::runtime_conversion_d7fcd2a33e6c28a1b7df22a3e6a14350612f07ea1a8bb32ba77bdbbe37380f3c(&(runtime_input_0)); }());
	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 local_window = ([&]() -> scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 { const auto& runtime_input_1 = scpp::null; return scpp::internal::runtime_conversion_d95bc99abfadc134cbf518750f703b4ac119905814e46333de787604342c8d36(&(runtime_input_1)); }());
	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 local_view = ([&]() -> scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 { const auto& runtime_input_2 = scpp::null; return scpp::internal::runtime_conversion_200cac392cc0e80b99b20399aadd552dd64a6a4e9f8ad802e5d12890aef8a4bb(&(runtime_input_2)); }());
	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 local_keptU_app = ([&]() -> scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 { const auto& runtime_input_3 = scpp::null; return scpp::internal::runtime_conversion_d7fcd2a33e6c28a1b7df22a3e6a14350612f07ea1a8bb32ba77bdbbe37380f3c(&(runtime_input_3)); }());
	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 local_keptU_window = ([&]() -> scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 { const auto& runtime_input_4 = scpp::null; return scpp::internal::runtime_conversion_d95bc99abfadc134cbf518750f703b4ac119905814e46333de787604342c8d36(&(runtime_input_4)); }());
	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 local_keptU_view = ([&]() -> scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 { const auto& runtime_input_5 = scpp::null; return scpp::internal::runtime_conversion_200cac392cc0e80b99b20399aadd552dd64a6a4e9f8ad802e5d12890aef8a4bb(&(runtime_input_5)); }());
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_error;
	auto local_value = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
{
scpp::internal::runtime_finally_storage_84be9c474f8f41fa28b27cb08dc2c04e937739908860e42a654cf5908008e435 finally_exception_6;
bool finally_return_6 = false;
try { [&]() -> void {
{
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_7 = scpp::internal::runtime_observation_0f28efb0fee9f7100a237988c11e8dbfaa2c977217c9bc731db46f64df7e3930(); return scpp::internal::runtime_take_c4ae7d5571163feceabb960de9b1fdfc4a42adca369fd2eaae52a812fd2c2a55(&(local_app), (local_error).address(), (take_source_7).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto& receiver_8 = local_error;
return receiver_8.get_message(); }()))).address());
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)).native_value()));
finally_return_6 = true;
return;
}
	local_keptU_app = local_app;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_13 = ([&]() -> scpp::internal::concrete_n_result_ui_window__eff62ae11af1191b46318003b8b6af3f621cf414c30b9aaece30a61b6204cee6 { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_9 = local_app;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_10 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("V-R08 acceptance", 16);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_11 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(400LL);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_12 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(300LL);
return scpp::internal::runtime_runtime_call_4b3cb3ee6ae8340762f32f5246e5e6a13198004743add934ba419181d825f05b((argument_9).address(), (argument_10).address(), (argument_11).address(), (argument_12).address()); }()); return scpp::internal::runtime_take_57bc2db173aec2f70059220529872c72b6e197c8cbed417da6189ee506fc6fb1(&(local_window), (local_error).address(), (take_source_13).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL)).native_value()));
finally_return_6 = true;
return;
}
	local_keptU_window = local_window;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_15 = ([&]() -> scpp::internal::concrete_n_result_webview__a7df8dc202e61b49dcc9bbe731b5c9ba76bdfbf4ef1e013fad33ad5950246451 { 	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 argument_14 = local_window;
return scpp::internal::runtime_runtime_call_54dbb86c04c3a5a1e57f424eb2afff25d26b7da01bc0455afd3200b686d83128((argument_14).address()); }()); return scpp::internal::runtime_take_ccaeb2dcf57638110202d95924280310c8bd4d1f3cf8b47f5181cbd779b1f824(&(local_view), (local_error).address(), (take_source_15).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL)).native_value()));
finally_return_6 = true;
return;
}
	local_keptU_view = local_view;
	local_app = ([&]() -> scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 { const auto& runtime_input_16 = scpp::null; return scpp::internal::runtime_conversion_d7fcd2a33e6c28a1b7df22a3e6a14350612f07ea1a8bb32ba77bdbbe37380f3c(&(runtime_input_16)); }());
	local_window = ([&]() -> scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 { const auto& runtime_input_17 = scpp::null; return scpp::internal::runtime_conversion_d95bc99abfadc134cbf518750f703b4ac119905814e46333de787604342c8d36(&(runtime_input_17)); }());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_19 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 argument_18 = local_keptU_window;
return scpp::internal::runtime_runtime_call_da0833cd507d2b826db7ff87e35d8ef22cf6e9dc8446530a86c21fdda8061f35((argument_18).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_19).address()); }())).native_value())) || static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(local_value).native_value())))).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(4LL)).native_value()));
finally_return_6 = true;
return;
}
	local_value = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_22 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_20 = local_view;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_21 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("missing-app", 11);
return scpp::internal::runtime_runtime_call_93fa10c21ac7a2d1c4f2bd2daf36ade5593f48cd06f716b68b4341e58ab8618e((argument_20).address(), (argument_21).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_22).address()); }())) || static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(local_value).native_value())))).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(5LL)).native_value()));
finally_return_6 = true;
return;
}
	auto local_result = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_23 = local_view;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_26 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882& argument_24 = local_view;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_25 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("<!doctype html><html><head><title>V-R08</title></head><body>local acceptance<script>\x0A" "window.scpp.invoke('ok',{probe:7}).then(function(value){\x0A" "    return window.scpp.invoke(value.answer===42?'ack-ok':'bad',null);\x0A" "});\x0A" "window.scpp.invoke('error',null).then(function(){window.scpp.invoke('bad',null);},function(error){\x0A" "    window.scpp.invoke(error.code==='expected'&&error.message==='expected failure'?'ack-error':'bad',null);\x0A" "});\x0A" "</script></body></html>", 450);
return function_clearU_view(argument_24, argument_25); }());
return scpp::internal::runtime_runtime_call_fd0f866cb576240618910bb159ca2932340e561a4b29d048783e18ac49cc8760((argument_23).address(), (argument_26).address()); }());
if (((local_view).has_value()).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(20LL)).native_value()));
finally_return_6 = true;
return;
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_27 = local_result; return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_27).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(21LL)).native_value()));
finally_return_6 = true;
return;
}
	auto local_ready = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_started = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_finished = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_failed = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_okU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_errorU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_evalU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	auto local_sentU_eval = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
{
	auto local_turn = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL);
for (; (([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_28 = local_turn; auto operand_29 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(600LL); return scpp::internal::runtime_binary_64064a09a7e8a889ee4af8589a8881d7193fa76065e4a6252d16273047b51eb1((operand_28).address(), (operand_29).address()); }())).native_value(); (void)(static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(local_turn++))) {
	([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_30 = local_keptU_app;
return scpp::internal::runtime_runtime_call_ed1eafeda6c604246b4927cb2baf7ef2b00760d8fb003564e9610daedf81c17c((argument_30).address()); }());
	auto local_event = ([&]() -> scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_31 = local_keptU_app;
return scpp::internal::runtime_runtime_call_c5666b203323c2054564216924e51a03a8ef1178a3f1a06c6649ad4d6f98cbc0((argument_31).address()); }());
	auto local_type = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_32 = local_event;
return scpp::internal::runtime_runtime_call_5db660cf59dace1a517bf0974926ffda4f288359483d999bef267eef018aadbb((argument_32).address()); }());
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_33 = local_type; auto operand_34 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("webview_ready", 13); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_33).address(), (operand_34).address()); }())).native_value()) {
	local_ready = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_35 = local_type; auto operand_36 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("webview_navigation_started", 26); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_35).address(), (operand_36).address()); }())).native_value()) {
	local_started = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_37 = local_type; auto operand_38 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("webview_navigation_finished", 27); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_37).address(), (operand_38).address()); }())).native_value()) {
	local_finished = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_39 = local_type; auto operand_40 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("webview_load_failed", 19); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_39).address(), (operand_40).address()); }())).native_value()) {
	local_failed = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_41 = local_type; auto operand_42 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0); return scpp::internal::runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7((operand_41).address(), (operand_42).address()); }())).native_value()) {
	([&]() -> scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_43 = local_event;
return scpp::internal::runtime_runtime_call_0b31eb3634003c821e5226a705a06363a93333ad3a83ca99acf1c5c3c4304ddc((argument_43).address()); }());
	([&]() -> scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_44 = local_event;
return scpp::internal::runtime_runtime_call_ea05b091b50142cee69943e5acfe93f12dcf007fe0d1a8cd45592ce7614419fb((argument_44).address()); }());
	([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_45 = local_event;
return scpp::internal::runtime_runtime_call_db8f987fa2f1a1ca17119508c755dd81f5832ee19f035b46e3b8611899db7acb((argument_45).address()); }());
	([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_46 = local_event;
return scpp::internal::runtime_runtime_call_5fc7d6047dac375b54c1d37f437bf8f033876f9c517bd240d249b63a5857232d((argument_46).address()); }());
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_47 = local_type; auto operand_48 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("webview_message", 15); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_47).address(), (operand_48).address()); }())).native_value()) {
	auto local_id = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_49 = local_event;
return scpp::internal::runtime_runtime_call_ab216dc6d0fe8cef77a40dbb56a296bbbefed6526461790f26c8b2ad8d172f32((argument_49).address()); }());
	auto local_command = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_50 = local_event;
return scpp::internal::runtime_runtime_call_9b5e9872bd78468c159398b7367f8aef583e3882a49310bd0a468ad58cafefec((argument_50).address()); }());
	auto local_payload = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_51 = local_event;
return scpp::internal::runtime_runtime_call_4e5de4bcb4246867f576e7950dd80a30fdace03845332a5a1edacde316b5f89d((argument_51).address()); }());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_52 = local_id; auto operand_53 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); return scpp::internal::runtime_binary_c13eff332ac846c73458a6024117ba459c41ac2644cef64b8bd0a934360f7fe9((operand_52).address(), (operand_53).address()); }())) || static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_55 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { 	scpp::internal::concrete_n_ui_event_a620598c468bbefd30bc65da6cdfb8a0d007997e567e61e057b652bbf28e4f66 argument_54 = local_event;
return scpp::internal::runtime_runtime_call_f25063939d49231c8736b27cf5a9daf4c94a7a26203f34823d1e2f9d94d8d64b((argument_54).address()); }()); auto operand_56 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_55).address(), (operand_56).address()); }())))).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(6LL)).native_value()));
finally_return_6 = true;
return;
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_57 = local_command; auto operand_58 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("ok", 2); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_57).address(), (operand_58).address()); }())).native_value()) {
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_59 = local_payload; auto operand_60 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("{\"probe\":7}", 11); return scpp::internal::runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7((operand_59).address(), (operand_60).address()); }())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL)).native_value()));
finally_return_6 = true;
return;
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_64 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_61 = local_keptU_view;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_62 = local_id;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_63 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("{\"answer\":42}", 13);
return scpp::internal::runtime_runtime_call_8fa66cb6966f1490772a1d783a775eb4293bfeb060d5619d48fd00c78f705c46((argument_61).address(), (argument_62).address(), (argument_63).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_64).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(8LL)).native_value()));
finally_return_6 = true;
return;
}
}
else if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_65 = local_command; auto operand_66 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("error", 5); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_65).address(), (operand_66).address()); }())).native_value()) {
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_71 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_67 = local_keptU_view;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_68 = local_id;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_69 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("expected", 8);
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_70 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("expected failure", 16);
return scpp::internal::runtime_runtime_call_3c4baec3debe9be6a108d370b56d102c53b786c6837f48e2dbb84bba32b4e0d6((argument_67).address(), (argument_68).address(), (argument_69).address(), (argument_70).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_71).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(9LL)).native_value()));
finally_return_6 = true;
return;
}
}
else {
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_72 = local_command; auto operand_73 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("ack-ok", 6); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_72).address(), (operand_73).address()); }())).native_value()) {
	local_okU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_74 = local_command; auto operand_75 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("ack-error", 9); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_74).address(), (operand_75).address()); }())).native_value()) {
	local_errorU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_76 = local_command; auto operand_77 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("ack-eval", 8); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_76).address(), (operand_77).address()); }())).native_value()) {
	local_evalU_ack = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_78 = local_command; auto operand_79 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("bad", 3); return scpp::internal::runtime_binary_a420abdebf502877e3833c45330b98a1c4c07d15d121cac996fdba50875f923d((operand_78).address(), (operand_79).address()); }())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(10LL)).native_value()));
finally_return_6 = true;
return;
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_83 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_80 = local_keptU_view;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_81 = local_id;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_82 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("null", 4);
return scpp::internal::runtime_runtime_call_8fa66cb6966f1490772a1d783a775eb4293bfeb060d5619d48fd00c78f705c46((argument_80).address(), (argument_81).address(), (argument_82).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_83).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(11LL)).native_value()));
finally_return_6 = true;
return;
}
}
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(local_finished) && static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(local_sentU_eval).native_value())))).native_value()) {
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_86 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_84 = local_keptU_view;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_85 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("window.scpp.invoke('ack-eval',null);", 36);
return scpp::internal::runtime_runtime_call_e1bf46da21711835e6789dceaec03adeee4d7b647e27ac7ecad8c90883e93126((argument_84).address(), (argument_85).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_86).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(12LL)).native_value()));
finally_return_6 = true;
return;
}
	local_sentU_eval = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(local_ready) && static_cast<bool>(local_started))) && static_cast<bool>(local_finished))) && static_cast<bool>(local_okU_ack))) && static_cast<bool>(local_errorU_ack))) && static_cast<bool>(local_evalU_ack))).native_value()) {
break;
}
	([&]() -> void { 	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_87 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(20LL);
return scpp::internal::runtime_runtime_call_4dcf94bf31b7b860f26a7670e16de89e6407705e007f371c230807e9c74ac5bc((argument_87).address()); }());
}
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(local_ready) && static_cast<bool>(local_started))) && static_cast<bool>(local_finished))) && static_cast<bool>(local_okU_ack))) && static_cast<bool>(local_errorU_ack))) && static_cast<bool>(local_evalU_ack))).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("incomplete events\x0A" "", 18))).address());
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(13LL)).native_value()));
finally_return_6 = true;
return;
}
	([&]() -> void { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_88 = local_keptU_view;
return scpp::internal::runtime_runtime_call_19407e4a952a017cd4c1d72c3b83a95222203e6930d5e8789ade6f7188cd601c((argument_88).address()); }());
	local_value = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_91 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_89 = local_keptU_view;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_90 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("closed", 6);
return scpp::internal::runtime_runtime_call_fd0f866cb576240618910bb159ca2932340e561a4b29d048783e18ac49cc8760((argument_89).address(), (argument_90).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_91).address()); }())) || static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(local_value).native_value())))).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(14LL)).native_value()));
finally_return_6 = true;
return;
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_93 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 argument_92 = local_keptU_window;
return scpp::internal::runtime_runtime_call_f78d1efe6ecc0dc503b47387d5e16090c9f61531c0f7862b54fdef071d15e224((argument_92).address()); }()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_value), (local_error).address(), (take_source_93).address()); }())).native_value())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(15LL)).native_value()));
finally_return_6 = true;
return;
}
	([&]() -> void { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_94 = local_keptU_app;
return scpp::internal::runtime_runtime_call_fec9b47cb09959852e331d07726a050fb8d6641ab53ddab069f68e97a4817e99((argument_94).address()); }());
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_95 = local_keptU_app;
return scpp::internal::runtime_runtime_call_ed1eafeda6c604246b4927cb2baf7ef2b00760d8fb003564e9610daedf81c17c((argument_95).address()); }())).native_value()) {
finally_exception_6.emplace(static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(16LL)).native_value()));
finally_return_6 = true;
return;
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("enabled-ok\x0A" "", 11))).address());
}
}(); }
catch (...) { finally_exception_6.capture_exception(); }
{
	([&]() -> void { 	scpp::internal::concrete_n_webview_0f49b842221fc204a4d5e122bd9cd3cbf4b3e162152e36de46cab858ffb1c882 argument_96 = local_keptU_view;
return scpp::internal::runtime_runtime_call_19407e4a952a017cd4c1d72c3b83a95222203e6930d5e8789ade6f7188cd601c((argument_96).address()); }());
	([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 { 	scpp::internal::concrete_n_ui_window_d2adc88b69c2402cb798ed5f1b8fbf43dba90b0f3bf89e53aefaf4299534c9a4 argument_97 = local_keptU_window;
return scpp::internal::runtime_runtime_call_f78d1efe6ecc0dc503b47387d5e16090c9f61531c0f7862b54fdef071d15e224((argument_97).address()); }());
	([&]() -> void { 	scpp::internal::concrete_n_ui_app_24500d5b2a941b54da52e4ee33ab166492ee7c77d51db7e20a2722e9dc76d4e9 argument_98 = local_keptU_app;
return scpp::internal::runtime_runtime_call_fec9b47cb09959852e331d07726a050fb8d6641ab53ddab069f68e97a4817e99((argument_98).address()); }());
}
finally_exception_6.rethrow_if_exception();
if (finally_return_6) {
return finally_exception_6.value();
}
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
