#include "callables/n73746f7265.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	if (!(([&]() { scpp::hash_t<scpp::int_t<>> out; out.set(scpp::string_t{"saved"}, scpp::int_t<>{9LL}); scpp::int_t<> n{0LL}; bool caught = false; try { function_store(out, n); } catch (const std::runtime_error& error) { caught = std::string(error.what()) == "data initialization: duplicate key"; } return caught && n.native_value() == 3 && out.size() == 1 && out.at(scpp::string_t{"saved"}).native_value() == 9; }()))) { return 91; }
	return 0;
}
