#include "callables/n6d616b65.hpp"
#include "callables/n6964656e74697479.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "callables/n6964656e74697479.hpp"
#include "callables/n6d616b65.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	auto local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> {
	scpp::vector_t<scpp::int_t<>> argument_3 = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_0(2);
{
scpp::int_t<> initializer_value_1 = static_cast<scpp::int_t<>>(1LL);
initializer_0.append(initializer_value_1);
}
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(2LL);
initializer_0.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_0.view());
}());
	return function_identity(argument_3);
}());
	local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_4(1);
{
scpp::int_t<> initializer_value_5 = static_cast<scpp::int_t<>>(3LL);
initializer_4.append(initializer_value_5);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_4.view());
}());
	auto local_w = ([&]() -> scpp::vector_t<scpp::int_t<>> {
	return function_make();
}());
	if (!(local_v.size() == 1 && local_v.at(0).native_value() == 3 && local_w.at(1).native_value() == 8)) { return 91; }
	return 0;
}
