#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "callables/n6d616b65.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "callables/n6964656e74697479.hpp"
scpp::vector_t<scpp::int_t<>> function_make()
{
	return ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_0(2);
{
scpp::int_t<> initializer_value_1 = static_cast<scpp::int_t<>>(4LL);
initializer_0.append(initializer_value_1);
}
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(8LL);
initializer_0.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_0.view());
}());
}

scpp::vector_t<scpp::int_t<>> function_identity(scpp::vector_t<scpp::int_t<>> local_v)
{
	return local_v;
}

