#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
scpp::vector_t<scpp::int_t<>> function_make();
