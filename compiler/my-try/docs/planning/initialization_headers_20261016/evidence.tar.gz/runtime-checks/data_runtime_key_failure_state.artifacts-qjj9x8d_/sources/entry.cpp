#include "callables/n73746f7265.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	if (!(([&]() { auto out = scpp::data_initializer<scpp::dynamic_t<>>::from_list({}); auto original = out; scpp::int_t<> n{0LL}; bool caught = false; try { function_store(scpp::mixed_t{true}, out, n); } catch (const std::runtime_error&) { caught = true; } return caught && out.table_if() == original.table_if() && n.native_value() == 2; }()))) { return 91; }
	return 0;
}
