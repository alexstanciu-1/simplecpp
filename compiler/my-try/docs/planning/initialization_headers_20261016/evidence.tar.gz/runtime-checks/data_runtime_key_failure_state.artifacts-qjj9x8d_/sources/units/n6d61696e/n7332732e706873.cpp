#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "callables/n73746f7265.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/data_initializer_dynamic.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/string_t.hpp"
void function_store(scpp::mixed_t local_key, scpp::dynamic_t<>& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(2);
{
scpp::mixed_t initializer_key_1 = local_key;
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(local_n++)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
{
scpp::mixed_t initializer_key_3 = scpp::mixed_t{scpp::string_t("last")};
scpp::dynamic_t<> initializer_value_4 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(local_n++)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_3, initializer_value_4});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
}

