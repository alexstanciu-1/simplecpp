#include "callables/n73746f7265.hpp"
#include "scpp/int_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/hash_t.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/generated/operators.hpp"
void function_store(scpp::hash_t<scpp::int_t<>, scpp::string_t>& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::hash_t<scpp::int_t<>, scpp::string_t> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::int_t<>, scpp::string_t>> initializer_0(3);
{
scpp::string_t initializer_key_1 = scpp::string_t("first");
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(local_n++);
initializer_0.append(scpp::initializer_entry<scpp::int_t<>, scpp::string_t>{initializer_key_1, initializer_value_2});
}
{
scpp::string_t initializer_key_3 = scpp::string_t("second");
scpp::int_t<> initializer_value_4 = static_cast<scpp::int_t<>>(local_n++);
initializer_0.append(scpp::initializer_entry<scpp::int_t<>, scpp::string_t>{initializer_key_3, initializer_value_4});
}
{
scpp::string_t initializer_key_5 = scpp::string_t("first");
scpp::int_t<> initializer_value_6 = static_cast<scpp::int_t<>>(local_n++);
initializer_0.append(scpp::initializer_entry<scpp::int_t<>, scpp::string_t>{initializer_key_5, initializer_value_6});
}
return scpp::data_initializer<scpp::hash_t<scpp::int_t<>, scpp::string_t>>::from_key_value(initializer_0.view());
}());
}

