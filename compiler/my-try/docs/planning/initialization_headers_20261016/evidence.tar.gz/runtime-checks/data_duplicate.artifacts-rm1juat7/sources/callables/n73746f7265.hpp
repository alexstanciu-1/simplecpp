#pragma once
#include "scpp/int_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/hash_t.hpp"
void function_store(scpp::hash_t<scpp::int_t<>, scpp::string_t>& local_out, scpp::int_t<>& local_n);
