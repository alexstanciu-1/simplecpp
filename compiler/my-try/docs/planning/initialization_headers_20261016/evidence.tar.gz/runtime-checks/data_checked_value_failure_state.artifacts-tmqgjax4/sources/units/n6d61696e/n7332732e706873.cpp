#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "callables/n73746f7265.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/cast.hpp"
void function_store(scpp::mixed_t local_value, scpp::vector_t<scpp::int_t<>>& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_0(3);
{
scpp::int_t<> initializer_value_1 = static_cast<scpp::int_t<>>(local_n++);
initializer_0.append(initializer_value_1);
}
{
scpp::int_t<> initializer_value_2 = scpp::required_cast<scpp::int_t<>>(local_value);
initializer_0.append(initializer_value_2);
}
{
scpp::int_t<> initializer_value_3 = static_cast<scpp::int_t<>>(local_n++);
initializer_0.append(initializer_value_3);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_0.view());
}());
}

