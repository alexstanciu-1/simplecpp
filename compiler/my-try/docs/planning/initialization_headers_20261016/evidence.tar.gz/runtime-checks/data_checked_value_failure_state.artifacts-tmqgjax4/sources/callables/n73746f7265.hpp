#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
void function_store(scpp::mixed_t local_value, scpp::vector_t<scpp::int_t<>>& local_out, scpp::int_t<>& local_n);
