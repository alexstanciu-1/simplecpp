#include "callables/n73746f7265.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	if (!(([&]() { scpp::vector_t<scpp::int_t<>> out; out.append(scpp::int_t<>{9LL}); scpp::int_t<> n{0LL}; bool caught = false; try { function_store(scpp::mixed_t{scpp::string_t{"bad"}}, out, n); } catch (const std::runtime_error&) { caught = true; } return caught && out.size() == 1 && out.at(0).native_value() == 9 && n.native_value() == 1; }()))) { return 91; }
	return 0;
}
