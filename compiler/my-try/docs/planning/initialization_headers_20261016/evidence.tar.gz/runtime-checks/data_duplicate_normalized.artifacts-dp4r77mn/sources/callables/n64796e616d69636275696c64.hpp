#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_dynamicbuild();
