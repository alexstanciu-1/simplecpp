#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_mixedbuild();
