#include "callables/n6d697865646275696c64.hpp"
#include "callables/n64796e616d69636275696c64.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	return 0;
}
