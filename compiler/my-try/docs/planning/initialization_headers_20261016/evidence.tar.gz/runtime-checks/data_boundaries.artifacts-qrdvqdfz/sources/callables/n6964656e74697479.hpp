#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
scpp::vector_t<scpp::int_t<>> function_identity(scpp::vector_t<scpp::int_t<>> local_v);
