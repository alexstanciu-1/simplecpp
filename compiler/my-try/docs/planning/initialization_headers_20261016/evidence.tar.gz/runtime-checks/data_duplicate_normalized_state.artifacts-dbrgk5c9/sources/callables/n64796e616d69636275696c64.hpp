#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_dynamicbuild();
