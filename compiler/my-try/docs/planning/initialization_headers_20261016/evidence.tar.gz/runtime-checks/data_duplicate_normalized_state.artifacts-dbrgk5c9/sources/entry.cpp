#include "callables/n6d697865646275696c64.hpp"
#include "callables/n64796e616d69636275696c64.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	if (!(([&]() { int caught = 0; try { (void)function_mixedbuild(); } catch (const std::runtime_error& error) { if (std::string(error.what()) == "data initialization: duplicate key") ++caught; } try { (void)function_dynamicbuild(); } catch (const std::runtime_error& error) { if (std::string(error.what()) == "data initialization: duplicate key") ++caught; } return caught == 2; }()))) { return 91; }
	return 0;
}
