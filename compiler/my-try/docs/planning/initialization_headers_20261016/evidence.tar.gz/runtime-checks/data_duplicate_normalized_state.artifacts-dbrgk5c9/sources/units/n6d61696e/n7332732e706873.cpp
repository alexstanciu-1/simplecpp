#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "callables/n6d697865646275696c64.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/data_initializer_mixed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/string_t.hpp"
#include "scpp/null_t.hpp"
#include "scpp/int_t.hpp"
#include "callables/n64796e616d69636275696c64.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/data_initializer_dynamic.hpp"
#include "scpp/bool_t.hpp"
scpp::mixed_t function_mixedbuild()
{
	return ([&]() -> scpp::mixed_t {
scpp::initializer_buffer<scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>> initializer_0(2);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("10")};
scpp::mixed_t initializer_value_2 = scpp::mixed_t{scpp::null};
initializer_0.append(scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
{
scpp::mixed_t initializer_key_3 = scpp::mixed_t{static_cast<scpp::int_t<>>(10LL)};
scpp::mixed_t initializer_value_4 = scpp::mixed_t{static_cast<scpp::int_t<>>(2LL)};
initializer_0.append(scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>{initializer_key_3, initializer_value_4});
}
return scpp::data_initializer<scpp::mixed_t>::from_key_value(initializer_0.view());
}());
}

scpp::dynamic_t<> function_dynamicbuild()
{
	return ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(2);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("10")};
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::bool_t>(false)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
{
scpp::mixed_t initializer_key_3 = scpp::mixed_t{static_cast<scpp::int_t<>>(10LL)};
scpp::dynamic_t<> initializer_value_4 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_3, initializer_value_4});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
}

