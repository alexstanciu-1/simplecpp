#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_mixedbuild();
