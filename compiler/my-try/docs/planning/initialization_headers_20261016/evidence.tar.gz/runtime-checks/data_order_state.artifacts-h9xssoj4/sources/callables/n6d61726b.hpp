#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_mark(scpp::int_t<>& local_n, scpp::int_t<> local_digit);
