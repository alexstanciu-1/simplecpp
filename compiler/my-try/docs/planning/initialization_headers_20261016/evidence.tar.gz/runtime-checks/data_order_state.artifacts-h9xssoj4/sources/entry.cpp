#include "callables/n6d61726b.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "scpp/int_t.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/hash_t.hpp"
#include "scpp/data_initializer_input.hpp"
#include "callables/n6d61726b.hpp"
#include "lang/php/cli_context.hpp"

int main(int argc, char** argv)
{
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
	scpp::hash_t<scpp::int_t<>, scpp::int_t<>> local_v = ([&]() -> scpp::hash_t<scpp::int_t<>, scpp::int_t<>> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::int_t<>, scpp::int_t<>>> initializer_0(2);
{
scpp::int_t<> initializer_key_1 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_2 = local_n;
	scpp::int_t<> argument_3 = static_cast<scpp::int_t<>>(1LL);
	return function_mark(argument_2, argument_3);
}());
scpp::int_t<> initializer_value_4 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_5 = local_n;
	scpp::int_t<> argument_6 = static_cast<scpp::int_t<>>(2LL);
	return function_mark(argument_5, argument_6);
}());
initializer_0.append(scpp::initializer_entry<scpp::int_t<>, scpp::int_t<>>{initializer_key_1, initializer_value_4});
}
{
scpp::int_t<> initializer_key_7 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_8 = local_n;
	scpp::int_t<> argument_9 = static_cast<scpp::int_t<>>(3LL);
	return function_mark(argument_8, argument_9);
}());
scpp::int_t<> initializer_value_10 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_11 = local_n;
	scpp::int_t<> argument_12 = static_cast<scpp::int_t<>>(4LL);
	return function_mark(argument_11, argument_12);
}());
initializer_0.append(scpp::initializer_entry<scpp::int_t<>, scpp::int_t<>>{initializer_key_7, initializer_value_10});
}
return scpp::data_initializer<scpp::hash_t<scpp::int_t<>, scpp::int_t<>>>::from_key_value(initializer_0.view());
}());
	if (!(local_n.native_value() == 1234 && local_v.at(scpp::int_t<>{1LL}).native_value() == 2 && local_v.at(scpp::int_t<>{3LL}).native_value() == 4)) { return 91; }
	return 0;
}
