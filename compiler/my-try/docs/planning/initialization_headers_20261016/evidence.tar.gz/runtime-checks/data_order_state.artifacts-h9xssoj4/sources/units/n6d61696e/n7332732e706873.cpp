#include "scpp/data_initializer.hpp"
#include "scpp/memory.hpp"
#include "callables/n6d61726b.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> function_mark(scpp::int_t<>& local_n, scpp::int_t<> local_digit)
{
	local_n = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_n; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = local_digit; return (operand_2 + operand_3); }());
	return local_digit;
}

