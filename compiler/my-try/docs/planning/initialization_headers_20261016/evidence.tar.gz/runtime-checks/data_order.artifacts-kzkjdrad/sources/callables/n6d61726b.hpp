#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_mark(scpp::int_t<>& local_n, scpp::int_t<> local_digit);
