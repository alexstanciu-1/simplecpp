#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
void function_store(scpp::mixed_t local_key, scpp::dynamic_t<>& local_out, scpp::int_t<>& local_n);
