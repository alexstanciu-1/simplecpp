#include "data_construction.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t cpp_initialization_adapter::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_initialization_adapter::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_initialization_adapter::cpp_initialization_adapter(shared_p<scpp::compiler::type_definition_i> semantic_definition, const string_t& template_name, const string_t& required_header) {
	SCPP_CALL_DEPTH_GUARD("cpp_initialization_adapter::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 6);
	this->semantic_definition = semantic_definition;
	this->template_name = template_name;
	this->required_header = required_header;
}

shared_p<scpp::compiler::type_definition_i> cpp_initialization_adapter::__scpp_return_definition(std::type_identity<shared_p<scpp::compiler::type_definition_i>>) {
	SCPP_CALL_DEPTH_GUARD("cpp_initialization_adapter::definition", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 9);
	return this->semantic_definition;
}

string_t cpp_initialization_adapter::name() {
	SCPP_CALL_DEPTH_GUARD("cpp_initialization_adapter::name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 10);
	return this->template_name;
}

string_t cpp_initialization_adapter::header() {
	SCPP_CALL_DEPTH_GUARD("cpp_initialization_adapter::header", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 11);
	return this->required_header;
}

bool_t CPP_Initialization_Registration::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Initialization_Registration::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

void CPP_Initialization_Registration::install() {
	SCPP_CALL_DEPTH_GUARD("CPP_Initialization_Registration::install", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 16);
	auto contracts = Model::initialization_contracts;
	Model::cpp_type_bindings->bind_definition(contracts->sequence(), string_t("scpp::initializer_list"), string_t("scpp/data_initializer_input.hpp"));
	Model::cpp_type_bindings->bind_definition(contracts->entry(), string_t("scpp::initializer_entry"), string_t("scpp/data_initializer_input.hpp"));
	auto __scpp_foreach_source_20 = mixed_t{shared_table_(table_item_(string_t("mixed")), table_item_(string_t("dynamic")))};
	for (auto __scpp_foreach_entry_20 : foreach_range(__scpp_foreach_source_20)) {
		auto name = __scpp_foreach_entry_20.value_copy();
		Model::cpp_callable_bindings->bind_initialization_definition(Model::type_catalog->definition(name), string_t("scpp::data_initializer"), (string_t("scpp/data_initializer_") + cast<string_t>(name) + string_t(".hpp")));
	}
	auto __scpp_foreach_source_24 = Model::runtime_metadata->modules;
	for (auto __scpp_foreach_entry_24 : foreach_range(__scpp_foreach_source_24)) {
		auto module = __scpp_foreach_entry_24.value_copy();
		::scpp::compiler::Keyed_Storage<runtime_cpp_spec> bindings = required_cast<::scpp::compiler::Keyed_Storage<runtime_cpp_spec>>(module->cpp_initialization);
		auto __scpp_foreach_source_26 = module->types;
		for (auto __scpp_foreach_entry_26 : foreach_range(__scpp_foreach_source_26)) {
			auto spec = __scpp_foreach_entry_26.value_copy();
			::scpp::compiler::Storage<runtime_initialization_spec> initializations = required_cast<::scpp::compiler::Storage<runtime_initialization_spec>>(spec->initialization);
			if (static_cast<bool>(php::condition_truthy(bool_t(initializations.is_empty())))) {
				continue;
			}
			auto binding = bindings.read(spec->identity);
			Model::cpp_callable_bindings->bind_initialization_definition(Model::type_catalog->definition(spec->name), binding->symbol, binding->header);
		}
	}
}

bool_t CPP_Record_Construction::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Record_Construction::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

bool_t CPP_Record_Construction::keyed(shared_p<scpp::compiler::collected_method> method) {
	SCPP_CALL_DEPTH_GUARD("CPP_Record_Construction::keyed", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 40);
	return (php::identical(method->name, string_t("__construct")) && php::not_identical(method->callable_syntax()->require_preparation()->visibility, member_visibility::public_access));
}

string_t CPP_Record_Construction::key(shared_p<scpp::compiler::collected_method> method) {
	SCPP_CALL_DEPTH_GUARD("CPP_Record_Construction::key", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 45);
	if (static_cast<bool>((!CPP_Record_Construction::keyed(method)))) {
		return string_t("");
	}
	return (cast<string_t>(CPP_Generator::source_name(string_t("record"), method->declaring_type()->qualified_name())) + string_t("::scpp_constructor_key()"));
}

string_t CPP_Record_Construction::key_declaration(shared_p<scpp::compiler::collected_method> method) {
	SCPP_CALL_DEPTH_GUARD("CPP_Record_Construction::key_declaration", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 50);
	if (static_cast<bool>((!CPP_Record_Construction::keyed(method)))) {
		return string_t("");
	}
	auto name = CPP_Generator::source_name(string_t("record"), method->declaring_type()->qualified_name());
	return (string_t("public:\n\tclass scpp_construction_key { friend class ") + cast<string_t>(name) + string_t("; scpp_construction_key() {} };\n") + cast<string_t>(CPP_Declarations::visibility(method->callable_syntax()->require_preparation()->visibility)) + string_t("\tstatic scpp_construction_key scpp_constructor_key() { return scpp_construction_key(); }\n"));
}

string_t CPP_Record_Construction::allocation(shared_p<scpp::compiler::canonical_type_use> type, shared_p<scpp::compiler::canonical_type_use> payload_type, scpp::compiler::record_storage_kind storage, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Record_Construction::allocation", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 60);
	if (static_cast<bool>(php::identical(storage, record_storage_kind::inline_value))) {
		return CPP_Declarations::type(type, context);
	}
	auto payload = CPP_Types::payload(payload_type);
	CPP_Types::record_dependencies(payload, context);
	if (static_cast<bool>(php::identical(storage, record_storage_kind::shared))) {
		auto source_record = Type_Queries::source_record(payload_type);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(source_record, null)))) {
			shared_p<collected_record> record = source_record;
			auto allocation_name = record->qualified_name();
			if (static_cast<bool>(php::condition_truthy(php::isset(context->outlined_shared_allocations, allocation_name)))) {
				return CPP_Shared_Allocations::name(record);
			}
		}
	}
	context->headers[string_t("scpp/memory.hpp")] = static_cast<bool_t>(true);
	auto helper = php::ternary_eval([&]() -> decltype(auto) { return php::identical(storage, record_storage_kind::unique); }, [&]() -> decltype(auto) { return string_t("unique"); }, [&]() -> decltype(auto) { return string_t("shared"); });
	return (string_t("::scpp::") + cast<string_t>(helper) + string_t("<") + cast<string_t>(payload->spelling) + string_t(">"));
}

string_t CPP_Record_Construction::object(shared_p<scpp::compiler::prepared_object_construction> facts, ::scpp::compiler::Storage<scpp::compiler::expression_node> arguments, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Record_Construction::object", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 80);
	auto callee = CPP_Record_Construction::allocation(facts->type, facts->constructed_type, facts->storage, context);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(facts->constructor_call, null)))) {
		return CPP_Declarations::selected_call(facts->constructor_call, arguments, context, callee, facts->type, string_t(""));
	}
	return (cast<string_t>(callee) + cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::identical(facts->storage, record_storage_kind::inline_value); }, [&]() -> decltype(auto) { return string_t("{}"); }, [&]() -> decltype(auto) { return string_t("()"); })));
}

bool_t CPP_Data_Construction::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Data_Construction::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

string_t CPP_Data_Construction::reference(shared_p<scpp::compiler::initialization_binding> binding, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Data_Construction::reference", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 91);
	auto factory = ::scpp::checked_object_cast<registered_static_factory>(binding->factory());
	auto catalog = Model::cpp_callable_bindings;
	if (static_cast<bool>((!catalog->contains(factory)))) {
		auto definition = Type_Queries::canonical(binding->target())->definition();
		auto adapter = catalog->initialization_adapter(definition);
		auto member = php::ternary_eval([&]() -> decltype(auto) { return binding->is_keyed(); }, [&]() -> decltype(auto) { return string_t("from_key_value"); }, [&]() -> decltype(auto) { return string_t("from_list"); });
		catalog->bind_adapter(factory, adapter->name(), member, adapter->header());
	}
	return CPP_Callables::reference(factory, context);
}

string_t CPP_Data_Construction::generate(shared_p<scpp::compiler::data_construction_node> node, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Data_Construction::generate", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 104);
	auto prepared = node->require_data_preparation();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_record_construction>(prepared)))) {
		return CPP_Data_Construction::record(node, ::scpp::checked_object_cast<prepared_record_construction>(prepared), context);
	}
	auto binding = ::scpp::checked_object_cast<prepared_sequence_construction>(prepared)->binding;
	auto factory = CPP_Data_Construction::reference(binding, context);
	::scpp::compiler::Storage<data_entry_node> entries = required_cast<::scpp::compiler::Storage<data_entry_node>>(node->entries);
	auto signature = binding->factory()->signature();
	::scpp::compiler::Storage<callable_parameter> parameters = required_cast<::scpp::compiler::Storage<callable_parameter>>(signature->parameters);
	auto input_type = CPP_Declarations::type(parameters.read(static_cast<int_t<> >(0))->type, context);
	if (static_cast<bool>(php::condition_truthy(bool_t(entries.is_empty())))) {
		return (cast<string_t>(factory) + string_t("(") + cast<string_t>(input_type) + string_t("{})"));
	}
	auto input = ::scpp::checked_object_cast<applied_template_type>(Type_Queries::canonical(parameters.read(static_cast<int_t<> >(0))->type));
	auto element = CPP_Declarations::type(input->arguments()[static_cast<int_t<> >(0)], context);
	auto buffer = (string_t("initializer_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto text = (string_t("([&]() -> ") + cast<string_t>(CPP_Declarations::type(binding->target(), context)) + string_t(" {\n"));
	text = (text + cast<string_t>((string_t("scpp::initializer_buffer<") + cast<string_t>(element) + string_t("> ") + cast<string_t>(buffer) + string_t("(") + cast<string_t>(php::count(entries)) + string_t(");\n"))));
	auto emitter = create<CPP_Syntax>(context);
	auto& __scpp_foreach_source_125 = entries;
	for (auto __scpp_foreach_entry_125 : foreach_range(__scpp_foreach_source_125)) {
		auto entry = __scpp_foreach_entry_125.value_copy();
		auto facts = entry->require_preparation();
		text = (text + string_t("{\n"));
		auto key_name = string_t("");
		if (static_cast<bool>(php::condition_truthy(php::not_identical(entry->key, null)))) {
			shared_p<conversion_decision> key_decision = facts->key_conversion;
			key_name = (string_t("initializer_key_") + cast<string_t>(context->next_temporary));
			(context->next_temporary++);
			auto key = CPP_Declarations::conversion(emitter->expression(entry->key), key_decision, context);
			text = (text + cast<string_t>((cast<string_t>(CPP_Declarations::type(key_decision->target_type, context)) + string_t(" ") + cast<string_t>(key_name) + string_t(" = ") + cast<string_t>(key) + string_t(";\n"))));
		}
		auto value_name = (string_t("initializer_value_") + cast<string_t>(context->next_temporary));
		(context->next_temporary++);
		auto value = CPP_Declarations::conversion(emitter->expression(entry->value), facts->value_conversion, context);
		text = (text + cast<string_t>((cast<string_t>(CPP_Declarations::type(facts->value_conversion->target_type, context)) + string_t(" ") + cast<string_t>(value_name) + string_t(" = ") + cast<string_t>(value) + string_t(";\n"))));
		auto argument = value_name;
		if (static_cast<bool>(php::condition_truthy(php::not_identical(entry->key, null)))) {
			argument = (cast<string_t>(element) + string_t("{") + cast<string_t>(key_name) + string_t(", ") + cast<string_t>(value_name) + string_t("}"));
		}
		text = (text + cast<string_t>((cast<string_t>(buffer) + string_t(".append(") + cast<string_t>(argument) + string_t(");\n}\n"))));
	}
	return (cast<string_t>(text) + string_t("return ") + cast<string_t>(factory) + string_t("(") + cast<string_t>(buffer) + string_t(".view());\n}())"));
}

string_t CPP_Data_Construction::record(shared_p<scpp::compiler::data_construction_node> node, shared_p<scpp::compiler::prepared_record_construction> facts, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Data_Construction::record", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 148);
	context->headers[string_t("utility")] = static_cast<bool_t>(true);
	auto type = CPP_Declarations::type(facts->type, context);
	auto payload = CPP_Types::payload(facts->payload_type);
	CPP_Types::record_dependencies(payload, context);
	auto text = (string_t("([&]() -> ") + cast<string_t>(type) + string_t(" {\n"));
	hash_t<string_t, int_t<>> arguments = {};
	auto emitter = create<CPP_Syntax>(context);
	::scpp::compiler::Storage<data_entry_node> entries = required_cast<::scpp::compiler::Storage<data_entry_node>>(node->entries);
	auto& __scpp_foreach_source_157 = entries;
	for (auto __scpp_foreach_entry_157 : foreach_range(__scpp_foreach_source_157)) {
		auto entry = __scpp_foreach_entry_157.value_copy();
		auto input = entry->require_preparation();
		auto name = (string_t("record_input_") + cast<string_t>(context->next_temporary));
		(context->next_temporary++);
		auto value = CPP_Declarations::conversion(emitter->expression(entry->value), input->value_conversion, context);
		text = (text + cast<string_t>((cast<string_t>(CPP_Declarations::type(input->value_conversion->target_type, context)) + string_t(" ") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(value) + string_t(";\n"))));
		arguments[cast<int_t<>>(input->input_position)] = name;
	}
	vector_t<shared_p<record_initialization_input>> inputs = required_cast<vector_t<shared_p<record_initialization_input>>>(facts->contract->inputs_in_order());
	auto ordered = string_t("");
	if (static_cast<bool>(php::identical(weakref_get(facts->contract->constructor), null))) {
		ordered = (cast<string_t>(payload->spelling) + string_t("::scpp_data_tag{}"));
	}
	else {
		ordered = CPP_Record_Construction::key(weakref_get(facts->contract->constructor));
	}
	auto& __scpp_foreach_source_169 = inputs;
	for (auto __scpp_foreach_entry_169 : foreach_range(__scpp_foreach_source_169)) {
		auto&& position = __scpp_foreach_entry_169.key();
		auto input = __scpp_foreach_entry_169.value_copy();
		auto parameter = input->parameter;
		if (static_cast<bool>((!php::isset(arguments, position)))) {
			auto name = (string_t("record_default_") + cast<string_t>(context->next_temporary));
			(context->next_temporary++);
			auto field_type = CPP_Declarations::type(parameter->type, context);
			shared_p<prepared_parameter_default> default_facts = parameter->default_value;
			auto value = CPP_Declarations::parameter_default(default_facts, context);
			text = (text + cast<string_t>((cast<string_t>(field_type) + string_t(" ") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(value) + string_t(";\n"))));
			arguments[cast<int_t<>>(position)] = name;
		}
		ordered = (ordered + cast<string_t>((cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::identical(ordered, string_t("")); }, [&]() -> decltype(auto) { return string_t(""); }, [&]() -> decltype(auto) { return string_t(", "); })) + string_t("std::move(") + cast<string_t>(arguments.at(cast<int_t<>>(position))) + string_t(")"))));
	}
	auto callee = CPP_Record_Construction::allocation(facts->type, facts->payload_type, facts->storage, context);
	return (cast<string_t>(text) + string_t("return ") + cast<string_t>(callee) + string_t("(") + cast<string_t>(ordered) + string_t(");\n}())"));
}

string_t CPP_Data_Construction::constructor(const string_t& name, shared_p<scpp::compiler::record_initialization_contract> contract, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Data_Construction::constructor", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/initialization-headers-20261016/phpp/05_backend/cpp/data_construction.phs", 187);
	context->headers[string_t("utility")] = static_cast<bool_t>(true);
	auto parameters = string_t("scpp_data_tag");
	auto initializers = string_t("");
	auto base_count = static_cast<int_t<> >(0);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(contract->base_contract, null)))) {
		base_count = php::count(contract->base_contract->inputs_in_order());
		auto base = CPP_Types::payload(contract->base_type);
		CPP_Types::record_dependencies(base, context);
		initializers = (string_t(" : ") + cast<string_t>(base->spelling) + string_t("{") + cast<string_t>(base->spelling) + string_t("::scpp_data_tag{}"));
		for (auto index = static_cast<int_t<> >(0); static_cast<bool>((index < base_count)); (index++)) {
			initializers = (initializers + cast<string_t>((string_t(", std::move(input_") + cast<string_t>(index) + string_t(")"))));
		}
		initializers = (initializers + string_t("}"));
	}
	vector_t<shared_p<record_initialization_input>> inputs = required_cast<vector_t<shared_p<record_initialization_input>>>(contract->inputs_in_order());
	auto& __scpp_foreach_source_203 = inputs;
	for (auto __scpp_foreach_entry_203 : foreach_range(__scpp_foreach_source_203)) {
		auto&& position = __scpp_foreach_entry_203.key();
		auto input = __scpp_foreach_entry_203.value_copy();
		shared_p<prepared_field> field = input->field;
		auto requirement = php::ternary_eval([&]() -> decltype(auto) { return Type_Queries::is_nominal_handle(field->type); }, [&]() -> decltype(auto) { return cpp_type_requirement::declaration; }, [&]() -> decltype(auto) { return cpp_type_requirement::complete; });
		parameters = (parameters + cast<string_t>((string_t(", ") + cast<string_t>(CPP_Declarations::type_for(field->type, context, requirement)) + string_t(" input_") + cast<string_t>(position))));
		if (static_cast<bool>((position < base_count))) {
			continue;
		}
		auto entry = ::scpp::checked_object_cast<collected_name>(weakref_get(field->declaration));
		initializers = (initializers + cast<string_t>((cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::identical(initializers, string_t("")); }, [&]() -> decltype(auto) { return string_t(" : "); }, [&]() -> decltype(auto) { return string_t(", "); })) + cast<string_t>(CPP_Generator::source_name(string_t("field"), entry->name)) + string_t("(std::move(input_") + cast<string_t>(position) + string_t("))"))));
	}
	auto text = (string_t("\tstruct scpp_data_tag {};\n\t") + cast<string_t>(name) + string_t("() = default;\n\t") + cast<string_t>(name) + string_t("(") + cast<string_t>(parameters) + string_t(")") + cast<string_t>(initializers));
	return (cast<string_t>(text) + string_t(" {}\n"));
}

}

