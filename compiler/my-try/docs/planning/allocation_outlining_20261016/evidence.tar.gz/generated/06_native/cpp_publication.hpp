#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class Native_CPP_Publication;
class runtime_cpp_build_spec;

class Native_CPP_Publication : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static void require_policy(shared_p<::scpp::scpp::Json_View> document, int_t<> optimization);
	static shared_p<scpp::compiler::runtime_cpp_build_spec> runtime_inputs(shared_p<::scpp::scpp::Json_View> view);
};

}

