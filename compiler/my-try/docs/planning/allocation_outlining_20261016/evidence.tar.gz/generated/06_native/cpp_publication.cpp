#include "cpp_publication.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t Native_CPP_Publication::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::Native_CPP_Publication::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

void Native_CPP_Publication::require_policy(shared_p<::scpp::scpp::Json_View> document, int_t<> optimization) {
	SCPP_CALL_DEPTH_GUARD("Native_CPP_Publication::require_policy", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/06_native/cpp_publication.phs", 6);
	auto policy = create<cpp_lowering_policy>(optimization);
	if (static_cast<bool>((!document->has(string_t("cpp_policy"))))) {
		return;
	}
	auto identity = document->member(string_t("cpp_policy"))->text();
	if (static_cast<bool>(php::identical(identity, string_t("cpp-lowering-v1:execution")))) {
		return;
	}
	if (static_cast<bool>(((php::identical(identity, string_t("cpp-lowering-v1:latency")) || php::identical(identity, string_t("cpp-lowering-v2:latency"))) && policy->outline_defaults()))) {
		return;
	}
	throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ lowering policy is incompatible with native optimization; regenerate output")));
}

shared_p<scpp::compiler::runtime_cpp_build_spec> Native_CPP_Publication::runtime_inputs(shared_p<::scpp::scpp::Json_View> view) {
	SCPP_CALL_DEPTH_GUARD("Native_CPP_Publication::runtime_inputs", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/06_native/cpp_publication.phs", 16);
	if (static_cast<bool>((php::not_identical(view->kind(), string_t("object")) || php::not_identical(view->size(), static_cast<int_t<> >(3))))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("Invalid runtime build publication")));
	}
	auto result = create<runtime_cpp_build_spec>();
	auto __scpp_foreach_source_21 = mixed_t{shared_table_(table_item_(string_t("sources")), table_item_(string_t("libraries")), table_item_(string_t("definitions")))};
	for (auto __scpp_foreach_entry_21 : foreach_range(__scpp_foreach_source_21)) {
		auto name = __scpp_foreach_entry_21.value_copy();
		auto items = view->member(name);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(items->kind(), string_t("array"))))) {
			throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("Runtime build entries require arrays")));
		}
		vector_t<string_t> values = {};
		for (auto index = static_cast<int_t<> >(0); static_cast<bool>((index < items->size())); (index++)) {
			{
			auto __append_value_1 = items->at(index)->text();
			(void) values.push_back(__append_value_1);
			}
		}
		if (static_cast<bool>(php::identical(name, string_t("sources")))) {
			result->sources = values;
		}
		else if (static_cast<bool>(php::identical(name, string_t("libraries")))) {
			result->libraries = values;
		}
		else {
			result->definitions = values;
		}
	}
	Runtime_Build_Contract::validate(result);
	return result;
}

}

