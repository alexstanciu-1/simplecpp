#include "generate.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t CPP_Generator::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Generator::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

CPP_Generator::CPP_Generator(nullable<shared_p<scpp::compiler::cpp_program>> program, nullable<shared_p<scpp::compiler::cpp_lowering_policy>> policy) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 10);
	this->program = php::coalesce_eval([&]() -> decltype(auto) { return program; }, [&]() -> decltype(auto) { return create<cpp_program>(); });
	this->policy = php::coalesce_eval([&]() -> decltype(auto) { return policy; }, [&]() -> decltype(auto) { return create<cpp_lowering_policy>(); });
}

::scpp::compiler::Storage<scpp::compiler::cpp_artifact> CPP_Generator::generate(shared_p<scpp::compiler::prepared_file> prepared) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 16);
	::scpp::compiler::Storage<prepared_file> files = required_cast<::scpp::compiler::Storage<prepared_file>>(::scpp::compiler::Storage<scpp::compiler::prepared_file>());
	int_t<>(files.append(prepared));
	return this->generate_program(files, prepared);
}

::scpp::compiler::Storage<scpp::compiler::cpp_artifact> CPP_Generator::generate_program(::scpp::compiler::Storage<scpp::compiler::prepared_file> files, shared_p<scpp::compiler::prepared_file> entry_file) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_program", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 23);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(this->program->policy_identity, this->policy->identity())))) {
		this->program->fragments = hash_t<shared_p<scpp::compiler::cpp_fragment>, shared_p<scpp::compiler::preparation_owner>>{};
		this->program->policy_identity = this->policy->identity();
	}
	::scpp::compiler::Storage<preparation_owner> ordered = required_cast<::scpp::compiler::Storage<preparation_owner>>(::scpp::compiler::Storage<scpp::compiler::preparation_owner>());
	auto found_entry = static_cast<bool_t>(false);
	auto& __scpp_foreach_source_31 = files;
	for (auto __scpp_foreach_entry_31 : foreach_range(__scpp_foreach_source_31)) {
		auto prepared = __scpp_foreach_entry_31.value_copy();
		auto source = prepared->source;
		if (static_cast<bool>((!Preparation_Status::imports_current(source)))) {
			throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires preparation after import changes")));
		}
		::scpp::compiler::Storage<namespace_body_node> namespace_bodies = required_cast<::scpp::compiler::Storage<namespace_body_node>>(source->root->namespace_bodies);
		auto& __scpp_foreach_source_37 = namespace_bodies;
		for (auto __scpp_foreach_entry_37 : foreach_range(__scpp_foreach_source_37)) {
			auto namespace_body = __scpp_foreach_entry_37.value_copy();
			::scpp::compiler::Storage<declaration_node> nodes = required_cast<::scpp::compiler::Storage<declaration_node>>(namespace_body->declarations);
			auto& __scpp_foreach_source_39 = nodes;
			for (auto __scpp_foreach_entry_39 : foreach_range(__scpp_foreach_source_39)) {
				auto node = __scpp_foreach_entry_39.value_copy();
				auto definition = node->occurrence();
				if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_trait>(definition)))) {
					continue;
				}
				if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_member_owner>(definition)))) {
					auto type_owner = ::scpp::checked_object_cast<collected_member_owner>(definition);
					auto relationships = type_owner->relationship_work;
					if (static_cast<bool>(php::identical(relationships, null))) {
						throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed relationships")));
					}
					if (static_cast<bool>((!Preparation_Status::complete(relationships)))) {
						throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed relationships")));
					}
					auto contracts = type_owner->contract_work;
					if (static_cast<bool>(php::identical(contracts, null))) {
						throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed type contracts")));
					}
					if (static_cast<bool>((!Preparation_Status::complete(contracts)))) {
						throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed type contracts")));
					}
				}
				if (static_cast<bool>(php::condition_truthy(::scpp::object_is<namespace_constant_node>(node)))) {
					if (static_cast<bool>((!Preparation_Status::complete(::scpp::checked_object_cast<preparation_owner>(definition->preparation_work_owner()))))) {
						throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed constant preparation")));
					}
					continue;
				}
				if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_interface>(definition)))) {
					int_t<>(ordered.append(::scpp::checked_object_cast<type_contract_work>(::scpp::checked_object_cast<collected_interface>(definition)->contract_work)));
				}
				else {
					int_t<>(ordered.append(::scpp::checked_object_cast<preparation_owner>(definition->preparation_work_owner())));
				}
				if (static_cast<bool>(php::condition_truthy(::scpp::object_is<callable_declaration_node>(node)))) {
					int_t<>(ordered.append(::scpp::checked_object_cast<preparation_owner>(::scpp::checked_object_cast<callable_declaration_node>(node)->require_body()->work())));
				}
				else if (static_cast<bool>(php::condition_truthy(::scpp::object_is<type_declaration_node>(node)))) {
					::scpp::compiler::Storage<method_node> methods = required_cast<::scpp::compiler::Storage<method_node>>(CPP_Callables::implementations(::scpp::checked_object_cast<collected_member_owner>(definition)));
					auto& __scpp_foreach_source_67 = methods;
					for (auto __scpp_foreach_entry_67 : foreach_range(__scpp_foreach_source_67)) {
						auto method = __scpp_foreach_entry_67.value_copy();
						int_t<>(ordered.append(::scpp::checked_object_cast<preparation_owner>(method->occurrence()->preparation_work_owner())));
						if (static_cast<bool>(php::condition_truthy(method->has_parsed_body()))) {
							int_t<>(ordered.append(::scpp::checked_object_cast<preparation_owner>(method->require_body()->work())));
						}
					}
				}
			}
			if (static_cast<bool>((!Preparation_Status::complete(::scpp::checked_object_cast<preparation_owner>(namespace_body->body->work()))))) {
				throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed preparation")));
			}
		}
		if (static_cast<bool>(php::identical(prepared, entry_file))) {
			found_entry = bool_t(static_cast<bool_t>(true));
		}
		auto __scpp_foreach_source_79 = source->preparation_changes;
		for (auto __scpp_foreach_entry_79 : foreach_range(__scpp_foreach_source_79)) {
			auto&& retired = __scpp_foreach_entry_79.key();
			auto __scpp_object_value_1 = __scpp_foreach_entry_79.value_copy();
			if (static_cast<bool>(php::identical(retired->change_status, change_state::deleted))) {
				this->program->fragments.remove(retired);
			}
		}
	}
	if (static_cast<bool>((!found_entry))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("Prepared entry is outside the program")));
	}
	int_t<>(ordered.append(::scpp::checked_object_cast<preparation_owner>(entry_file->executable_body()->work())));
	auto allocations = CPP_Shared_Allocations::select(ordered, this->policy);
	if (static_cast<bool>(php::condition_truthy(CPP_Shared_Allocations::changed(this->program->outlined_shared_allocations, allocations)))) {
		this->program->fragments = hash_t<shared_p<scpp::compiler::cpp_fragment>, shared_p<scpp::compiler::preparation_owner>>{};
	}
	this->program->outlined_shared_allocations = allocations;
	::scpp::compiler::Storage<preparation_owner> definitions = required_cast<::scpp::compiler::Storage<preparation_owner>>(::scpp::compiler::Storage<scpp::compiler::preparation_owner>());
	::scpp::compiler::Storage<preparation_owner> bodies = required_cast<::scpp::compiler::Storage<preparation_owner>>(::scpp::compiler::Storage<scpp::compiler::preparation_owner>());
	auto& __scpp_foreach_source_94 = ordered;
	for (auto __scpp_foreach_entry_94 : foreach_range(__scpp_foreach_source_94)) {
		auto owner = __scpp_foreach_entry_94.value_copy();
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<body_work>(owner)))) {
			auto __scpp_foreach_source_99 = owner->source->preparation_changes;
			for (auto __scpp_foreach_entry_99 : foreach_range(__scpp_foreach_source_99)) {
				auto&& changed = __scpp_foreach_entry_99.key();
				auto __scpp_object_value_2 = __scpp_foreach_entry_99.value_copy();
				if (static_cast<bool>((::scpp::object_is<anonymous_body_work>(changed) || ::scpp::object_is<anonymous_signature_work>(changed)))) {
					if (static_cast<bool>(php::condition_truthy(php::isset(this->program->fragments, owner)))) {
						this->program->fragments[owner]->change_status = change_state::changed;
					}
				}
			}
		}
		if (static_cast<bool>((!Preparation_Status::complete(owner)))) {
			throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ generation requires completed preparation")));
		}
		if (static_cast<bool>((!php::isset(this->program->fragments, owner)))) {
			this->program->fragments[owner] = create<cpp_fragment>();
		}
		auto fragment = this->program->fragments[owner];
		if (static_cast<bool>((php::not_identical(fragment->version, owner->version) || php::not_identical(fragment->change_status, change_state::unchanged)))) {
			fragment->change_status = change_state::changed;
			if (static_cast<bool>(php::identical(owner->kind(), preparation_kind::declaration))) {
				int_t<>(definitions.append(owner));
			}
			else {
				int_t<>(bodies.append(owner));
			}
		}
	}
	auto& __scpp_foreach_source_123 = definitions;
	for (auto __scpp_foreach_entry_123 : foreach_range(__scpp_foreach_source_123)) {
		auto owner = __scpp_foreach_entry_123.value_copy();
		this->render(owner);
	}
	auto& __scpp_foreach_source_126 = bodies;
	for (auto __scpp_foreach_entry_126 : foreach_range(__scpp_foreach_source_126)) {
		auto owner = __scpp_foreach_entry_126.value_copy();
		this->render(owner);
	}
	::scpp::compiler::Storage<cpp_artifact> result = required_cast<::scpp::compiler::Storage<cpp_artifact>>(::scpp::compiler::Storage<scpp::compiler::cpp_artifact>());
	auto record_context = create<cpp_generation_context>();
	auto& __scpp_foreach_source_132 = ordered;
	for (auto __scpp_foreach_entry_132 : foreach_range(__scpp_foreach_source_132)) {
		auto owner = __scpp_foreach_entry_132.value_copy();
		Preparation_Status::require_active(owner);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(owner->kind(), preparation_kind::declaration)))) {
			continue;
		}
		auto fragment = this->program->fragments[owner];
		auto definition = ::scpp::checked_object_cast<collected_definition>(owner->declaration());
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_method>(definition)))) {
			continue;
		}
		hash_t<bool_t> artifact_headers = required_cast<hash_t<bool_t>>(fragment->headers);
		hash_t<bool_t> artifact_declarations = required_cast<hash_t<bool_t>>(fragment->forward_declarations);
		auto path = string_t("");
		auto identity = string_t("");
		auto text = string_t("");
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_member_owner>(definition)))) {
			if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_record>(definition)))) {
				this->validate_record_dependencies(::scpp::checked_object_cast<collected_record>(definition), record_context);
			}
			path = CPP_Artifacts::type_header(definition->qualified_name());
			identity = (string_t("type:") + cast<string_t>(definition->qualified_name()));
			auto record = ::scpp::checked_object_cast<collected_member_owner>(definition);
			auto bridge_context = create<cpp_generation_context>();
			text = (cast<string_t>(CPP_Declarations::type_opening(record, bridge_context)) + cast<string_t>(fragment->text));
			auto contract = record->contract_work->require_facts();
			::scpp::compiler::Keyed_Storage<prepared_method_contract> dispatch = required_cast<::scpp::compiler::Keyed_Storage<prepared_method_contract>>(contract->methods);
			::scpp::compiler::Storage<method_node> methods = required_cast<::scpp::compiler::Storage<method_node>>(CPP_Callables::implementations(record));
			auto& __scpp_foreach_source_155 = methods;
			for (auto __scpp_foreach_entry_155 : foreach_range(__scpp_foreach_source_155)) {
				auto method = __scpp_foreach_entry_155.value_copy();
				shared_p<preparation_owner> member_owner = method->occurrence()->preparation_work_owner();
				auto member_fragment = this->program->fragments[member_owner];
				auto decision = dispatch.read(method->name);
				auto ordinary_instance = (((!method->require_preparation()->static_member) && php::not_identical(method->name, string_t("__construct"))) && php::not_identical(method->name, string_t("__destruct")));
				auto virtual_method = (php::identical(method->name, string_t("__destruct")) && contract->polymorphic);
				auto visibility = php::ternary_eval([&]() -> decltype(auto) { return php::identical(method->name, string_t("__construct")); }, [&]() -> decltype(auto) { return member_visibility::public_access; }, [&]() -> decltype(auto) { return method->require_preparation()->visibility; });
				text = (text + cast<string_t>(CPP_Record_Construction::key_declaration(::scpp::checked_object_cast<collected_method>(method->occurrence()))));
				text = (text + cast<string_t>(CPP_Declarations::visibility(visibility)));
				if (static_cast<bool>((!decision->abstract_method))) {
					text = (text + cast<string_t>((string_t("\t") + cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return virtual_method; }, [&]() -> decltype(auto) { return string_t("virtual "); }, [&]() -> decltype(auto) { return string_t(""); })) + cast<string_t>(member_fragment->prototype_text) + string_t(";\n"))));
				}
				if (static_cast<bool>(php::condition_truthy(ordinary_instance))) {
					text = (text + cast<string_t>(CPP_Dispatch::method(decision, bridge_context, static_cast<bool_t>(true))));
				}
				auto __scpp_foreach_source_169 = member_fragment->headers;
				for (auto __scpp_foreach_entry_169 : foreach_range(__scpp_foreach_source_169)) {
					auto&& header = __scpp_foreach_entry_169.key();
					auto used = __scpp_foreach_entry_169.value_copy();
					artifact_headers[cast<string_t>(header)] = static_cast<bool_t>(true);
				}
				auto __scpp_foreach_source_170 = member_fragment->forward_declarations;
				for (auto __scpp_foreach_entry_170 : foreach_range(__scpp_foreach_source_170)) {
					auto&& name = __scpp_foreach_entry_170.key();
					auto used = __scpp_foreach_entry_170.value_copy();
					artifact_declarations[cast<string_t>(name)] = static_cast<bool_t>(true);
				}
			}
			text = (text + cast<string_t>(CPP_Dispatch::bridges(contract, record, bridge_context, static_cast<bool_t>(true))));
			auto __scpp_foreach_source_173 = bridge_context->headers;
			for (auto __scpp_foreach_entry_173 : foreach_range(__scpp_foreach_source_173)) {
				auto&& header = __scpp_foreach_entry_173.key();
				auto used = __scpp_foreach_entry_173.value_copy();
				artifact_headers[cast<string_t>(header)] = static_cast<bool_t>(true);
			}
			auto __scpp_foreach_source_174 = bridge_context->forward_declarations;
			for (auto __scpp_foreach_entry_174 : foreach_range(__scpp_foreach_source_174)) {
				auto&& name = __scpp_foreach_entry_174.key();
				auto used = __scpp_foreach_entry_174.value_copy();
				artifact_declarations[cast<string_t>(name)] = static_cast<bool_t>(true);
			}
			if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_record>(record)))) {
				text = (text + cast<string_t>(CPP_Declarations::lifecycle_special_members(::scpp::checked_object_cast<collected_record>(record), contract)));
			}
			else {
				text = (text + cast<string_t>((string_t("public:\n\tvirtual ~") + cast<string_t>(CPP_Generator::source_name(string_t("record"), record->qualified_name())) + string_t("() noexcept = default;\n"))));
			}
			text = (text + cast<string_t>((string_t("};\n\n") + cast<string_t>(fragment->allocation_declaration_text))));
		}
		else if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_enum>(definition)))) {
			path = CPP_Artifacts::type_header(definition->qualified_name());
			identity = (string_t("type:") + cast<string_t>(definition->qualified_name()));
			text = fragment->text;
		}
		else {
			path = CPP_Artifacts::callable_header(definition->qualified_name());
			identity = (string_t("callable:") + cast<string_t>(definition->qualified_name()));
			text = (cast<string_t>(fragment->prototype_text) + string_t(";\n"));
		}
		int_t<>(result.append(CPP_Artifacts::described(identity, cpp_artifact_kind::header, path, (string_t("#pragma once\n") + cast<string_t>(CPP_Artifacts::preamble(artifact_headers, artifact_declarations, path)) + cast<string_t>(text)), artifact_headers)));
	}
	::scpp::compiler::Storage<cpp_implementation_group> groups = required_cast<::scpp::compiler::Storage<cpp_implementation_group>>(CPP_Implementation_Groups::assemble(files, ordered, this->program));
	auto& __scpp_foreach_source_195 = groups;
	for (auto __scpp_foreach_entry_195 : foreach_range(__scpp_foreach_source_195)) {
		auto group = __scpp_foreach_entry_195.value_copy();
		int_t<>(result.append(CPP_Artifacts::implementation(group)));
	}
	auto entry_owner = ::scpp::checked_object_cast<preparation_owner>(entry_file->executable_body()->work());
	auto entry_fragment = this->program->fragments[entry_owner];
	hash_t<bool_t> entry_headers = required_cast<hash_t<bool_t>>(entry_fragment->headers);
	entry_headers[cast<string_t>(string_t("lang/php/cli_context.hpp"))] = static_cast<bool_t>(true);
	int_t<>(result.append(CPP_Artifacts::described(string_t("entry"), cpp_artifact_kind::translation_unit, string_t("entry.cpp"), (cast<string_t>(CPP_Artifacts::preamble(entry_headers, entry_fragment->forward_declarations, string_t(""))) + string_t("\nint main(int argc, char** argv)\n{\n") + string_t("\tscpp::php::set_cli_args(argc, argv);\n") + cast<string_t>(entry_fragment->text) + string_t("\treturn 0;\n}\n")), entry_headers)));
	hash_t<shared_p<prepared_compiler_call>> helpers = {};
	auto& __scpp_foreach_source_208 = ordered;
	for (auto __scpp_foreach_entry_208 : foreach_range(__scpp_foreach_source_208)) {
		auto owner = __scpp_foreach_entry_208.value_copy();
		auto __scpp_foreach_source_209 = this->program->fragments[owner]->compiler_helpers;
		for (auto __scpp_foreach_entry_209 : foreach_range(__scpp_foreach_source_209)) {
			auto&& key = __scpp_foreach_entry_209.key();
			auto request = __scpp_foreach_entry_209.value_copy();
			helpers[cast<string_t>(key)] = request;
		}
	}
	auto& __scpp_foreach_source_213 = helpers;
	for (auto __scpp_foreach_entry_213 : foreach_range(__scpp_foreach_source_213)) {
		auto request = __scpp_foreach_entry_213.value_copy();
		CPP_Compiler_Functions::append_artifacts(request, result);
	}
	return result;
}

void CPP_Generator::discard_deleted(shared_p<scpp::compiler::cpp_program> program) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::discard_deleted", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 218);
	::scpp::compiler::Storage<preparation_owner> removed = required_cast<::scpp::compiler::Storage<preparation_owner>>(::scpp::compiler::Storage<scpp::compiler::preparation_owner>());
	auto __scpp_foreach_source_220 = program->fragments;
	for (auto __scpp_foreach_entry_220 : foreach_range(__scpp_foreach_source_220)) {
		auto&& owner = __scpp_foreach_entry_220.key();
		auto __scpp_object_value_3 = __scpp_foreach_entry_220.value_copy();
		if (static_cast<bool>((php::identical(owner->change_status, change_state::deleted) || owner->source->deleted))) {
			int_t<>(removed.append(owner));
		}
	}
	auto& __scpp_foreach_source_225 = removed;
	for (auto __scpp_foreach_entry_225 : foreach_range(__scpp_foreach_source_225)) {
		auto owner = __scpp_foreach_entry_225.value_copy();
		program->fragments.remove(owner);
	}
}

void CPP_Generator::render(shared_p<scpp::compiler::preparation_owner> owner) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::render", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 231);
	Preparation_Status::require_active(owner);
	if (static_cast<bool>((php::not_identical(owner->state, preparation_state::ready) || owner->failed))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("C++ generation requires successfully prepared work")));
	}
	auto context = create<cpp_generation_context>();
	context->outlined_shared_allocations = this->program->outlined_shared_allocations;
	auto next = create<cpp_fragment>();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<body_work>(owner)))) {
		auto body_owner = ::scpp::checked_object_cast<body_work>(owner);
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<source_callable_body_work>(body_owner)))) {
			auto function = ::scpp::checked_object_cast<source_callable_body_work>(body_owner)->callable_definition()->callable_syntax();
			context->return_type = function->require_preparation()->signature->return_type;
			auto definition = ::scpp::checked_object_cast<source_callable_body_work>(body_owner)->callable_definition();
			if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_method>(definition)))) {
				next->initializer_text = CPP_Declarations::constructor_initializers(::scpp::checked_object_cast<collected_method>(definition), context);
			}
		}
		next->text = CPP_Generator::generate_statements(body_owner->executable_body(), context);
	}
	else {
		auto entry = ::scpp::checked_object_cast<collected_name>(owner->declaration());
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_source_callable>(entry)))) {
			auto function_syntax = ::scpp::checked_object_cast<collected_source_callable>(entry)->callable_syntax();
			auto definition_context = create<cpp_generation_context>();
			definition_context->outlined_shared_allocations = this->program->outlined_shared_allocations;
			next->text = CPP_Declarations::signature(function_syntax, definition_context, static_cast<bool_t>(false));
			next->definition_headers = definition_context->headers;
			next->prototype_text = CPP_Declarations::signature(function_syntax, context, static_cast<bool_t>(true));
		}
		else if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_enum>(entry)))) {
			next->text = CPP_Enums::declaration(::scpp::checked_object_cast<collected_enum>(entry)->enum_syntax(), context);
		}
		else if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_interface>(entry)))) {
			next->text = string_t("");
		}
		else {
			auto syntax = ::scpp::checked_object_cast<collected_record>(entry)->syntax();
			auto outline = CPP_Default_Constructors::eligible(::scpp::checked_object_cast<collected_record>(entry), this->policy);
			CPP_Declarations::generate_record(syntax, context, outline);
			next->text = context->records;
			auto definition_context = create<cpp_generation_context>();
			definition_context->outlined_shared_allocations = this->program->outlined_shared_allocations;
			next->record_definition_text = CPP_Declarations::static_definitions(::scpp::checked_object_cast<collected_record>(entry), definition_context);
			if (static_cast<bool>(php::condition_truthy(outline))) {
				next->record_definition_text = (next->record_definition_text + cast<string_t>(CPP_Default_Constructors::definition(::scpp::checked_object_cast<collected_record>(entry), definition_context)));
			}
			auto allocation_record = ::scpp::checked_object_cast<collected_record>(entry);
			auto allocation_name = allocation_record->qualified_name();
			if (static_cast<bool>(php::condition_truthy(php::isset(this->program->outlined_shared_allocations, allocation_name)))) {
				next->allocation_declaration_text = (cast<string_t>(CPP_Shared_Allocations::signature(allocation_record)) + string_t(";\n\n"));
				context->headers[string_t("scpp/shared_p.hpp")] = static_cast<bool_t>(true);
				next->record_definition_text = (next->record_definition_text + cast<string_t>(CPP_Shared_Allocations::definition(allocation_record, definition_context)));
			}
			next->definition_headers = definition_context->headers;
			::scpp::compiler::Key_Storage_List<prepared_field> fields = required_cast<::scpp::compiler::Key_Storage_List<prepared_field>>(syntax->require_preparation()->fields);
			::scpp::compiler::Storage<collected_record> records = required_cast<::scpp::compiler::Storage<collected_record>>(next->records);
			auto __scpp_foreach_source_291 = fields.items();
			for (auto __scpp_foreach_entry_291 : foreach_range(__scpp_foreach_source_291)) {
				auto field = __scpp_foreach_entry_291.value_copy();
				if (static_cast<bool>(php::condition_truthy(Type_Queries::is_nominal_handle(field->type)))) {
					continue;
				}
				auto source_record = Type_Queries::source_record(field->type);
				if (static_cast<bool>(php::condition_truthy(php::not_identical(source_record, null)))) {
					shared_p<collected_record> record = source_record;
					int_t<>(records.append(record));
				}
			}
		}
	}
	next->headers = context->headers;
	next->compiler_helpers = context->compiler_helpers;
	next->forward_declarations = context->forward_declarations;
	next->version = owner->version;
	next->change_status = change_state::unchanged;
	this->program->fragments[owner] = next;
}

void CPP_Generator::validate_record_dependencies(shared_p<scpp::compiler::collected_record> entry, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::validate_record_dependencies", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 312);
	auto key = entry->qualified_name();
	if (static_cast<bool>(php::condition_truthy(php::isset(context->record_states, key)))) {
		if (static_cast<bool>(php::identical(context->record_states[key], cpp_record_state::visiting))) {
			throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("Cyclic C++ record assembly dependency")));
		}
		return;
	}
	context->record_states[key] = cpp_record_state::visiting;
	auto owner = ::scpp::checked_object_cast<preparation_owner>(entry->preparation_work_owner());
	auto fragment = this->program->fragments[owner];
	::scpp::compiler::Storage<collected_record> records = required_cast<::scpp::compiler::Storage<collected_record>>(fragment->records);
	auto& __scpp_foreach_source_324 = records;
	for (auto __scpp_foreach_entry_324 : foreach_range(__scpp_foreach_source_324)) {
		auto dependency = __scpp_foreach_entry_324.value_copy();
		this->validate_record_dependencies(dependency, context);
	}
	context->record_states[key] = cpp_record_state::complete;
}

string_t CPP_Generator::generate_statements(shared_p<scpp::compiler::statement_body_node> body, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_statements", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 331);
	auto text = string_t("");
	::scpp::compiler::Storage<statement_node> statements = required_cast<::scpp::compiler::Storage<statement_node>>(body->statements);
	auto worker = create<CPP_Syntax>(context);
	auto skip_first = static_cast<bool_t>(false);
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<function_body_node>(body)))) {
		auto initialization = ::scpp::checked_object_cast<function_body_node>(body)->base_initialization;
		if (static_cast<bool>(php::condition_truthy(php::not_identical(initialization, null)))) {
			skip_first = php::not_identical(weakref_get(initialization->source_call), null);
		}
	}
	auto& __scpp_foreach_source_340 = statements;
	for (auto __scpp_foreach_entry_340 : foreach_range(__scpp_foreach_source_340)) {
		auto&& index = __scpp_foreach_entry_340.key();
		auto node = __scpp_foreach_entry_340.value_copy();
		if (static_cast<bool>((skip_first && php::identical(index, static_cast<int_t<> >(0))))) {
			continue;
		}
		text = (text + cast<string_t>(worker->statement(node)));
	}
	return text;
}

string_t CPP_Generator::generate_storage(shared_p<scpp::compiler::prepared_binding> binding, nullable<shared_p<scpp::compiler::assignable_expression_node>> target, nullable<shared_p<scpp::compiler::expression_node>> initializer, bool_t explicit_type, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_storage", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 348);
	auto name = CPP_Generator::storage_name(binding, target, context);
	if (static_cast<bool>(php::identical(initializer, null))) {
		return (cast<string_t>(CPP_Declarations::type_for(binding->type, context, cpp_type_requirement::stored_value)) + string_t(" ") + cast<string_t>(name));
	}
	initializer = initializer;
	auto value = create<CPP_Syntax>(context)->expression(initializer);
	return CPP_Generator::generate_storage_value(binding, name, value, bool_t(explicit_type), context);
}

string_t CPP_Generator::storage_name(shared_p<scpp::compiler::prepared_binding> binding, nullable<shared_p<scpp::compiler::assignable_expression_node>> target, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::storage_name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 362);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(target, null)))) {
		shared_p<assignable_expression_node> target_node = target;
		return create<CPP_Syntax>(context)->expression(target_node);
	}
	auto declaration = ::scpp::checked_object_cast<collected_name>(weakref_get(binding->declaration));
	return CPP_Generator::local_name(declaration);
}

string_t CPP_Generator::generate_storage_value(shared_p<scpp::compiler::prepared_binding> binding, const string_t& name, string_t value, bool_t explicit_type, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_storage_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 372);
	auto requirement = php::ternary_eval([&]() -> decltype(auto) { return php::not_identical(binding->alias_target, null); }, [&]() -> decltype(auto) { return cpp_type_requirement::declaration; }, [&]() -> decltype(auto) { return cpp_type_requirement::stored_value; });
	auto type_name = string_t("auto");
	if (static_cast<bool>((!::scpp::object_is<closure_type_definition>(Type_Queries::canonical(binding->type)->definition())))) {
		type_name = CPP_Declarations::type_for(binding->type, context, requirement);
	}
	auto prefix = string_t("");
	if (static_cast<bool>(php::identical(binding->resolved_kind, binding_kind::declaration))) {
		prefix = php::ternary_eval([&]() -> decltype(auto) { return explicit_type; }, [&]() -> decltype(auto) { return (cast<string_t>(type_name) + string_t(" ")); }, [&]() -> decltype(auto) { return string_t("auto "); });
		if (static_cast<bool>(php::condition_truthy(php::not_identical(binding->alias_target, null)))) {
			shared_p<prepared_place> place = binding->alias_target;
			auto qualifier = php::ternary_eval([&]() -> decltype(auto) { return php::identical(place->access(), storage_access::read_only); }, [&]() -> decltype(auto) { return string_t("const "); }, [&]() -> decltype(auto) { return string_t(""); });
			prefix = (cast<string_t>(qualifier) + cast<string_t>(type_name) + string_t("& "));
		}
	}
	if (static_cast<bool>(php::condition_truthy(php::not_identical(binding->conversion, null)))) {
		value = CPP_Declarations::conversion(value, binding->conversion, context);
	}
	return (cast<string_t>(prefix) + cast<string_t>(name) + string_t(" = ") + cast<string_t>(value));
}

string_t CPP_Generator::generate_return(shared_p<scpp::compiler::return_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_return", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 395);
	if (static_cast<bool>(php::identical(syntax->expression, null))) {
		return php::ternary_eval([&]() -> decltype(auto) { return php::identical(context->return_type, null); }, [&]() -> decltype(auto) { return string_t("\treturn 0;\n"); }, [&]() -> decltype(auto) { return string_t("\treturn;\n"); });
	}
	shared_p<expression_node> expression = syntax->expression;
	auto value = create<CPP_Syntax>(context)->expression(expression);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(context->return_type, null)))) {
		if (static_cast<bool>(php::condition_truthy(php::not_identical(syntax->require_preparation()->reference_target, null)))) {
			return (string_t("\treturn ") + cast<string_t>(value) + string_t(";\n"));
		}
		auto decision = syntax->require_preparation()->require_conversion();
		return (string_t("\treturn ") + cast<string_t>(CPP_Declarations::conversion(value, decision, context)) + string_t(";\n"));
	}
	return (string_t("\treturn static_cast<int>((") + cast<string_t>(value) + string_t(").native_value());\n"));
}

string_t CPP_Generator::generate_expression_statement(shared_p<scpp::compiler::expression_statement_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_expression_statement", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 412);
	auto expression = syntax->expression;
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<assignment_expression_node>(expression)))) {
		return CPP_Generator::generate_assignment_statement(::scpp::checked_object_cast<assignment_expression_node>(expression), context);
	}
	return (string_t("\t") + cast<string_t>(create<CPP_Syntax>(context)->expression(expression)) + string_t(";\n"));
}

string_t CPP_Generator::generate_cast(shared_p<scpp::compiler::cast_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_cast", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 421);
	auto value = create<CPP_Syntax>(context)->expression(syntax->operand);
	return CPP_Declarations::conversion(value, syntax->require_cast_preparation()->conversion, context);
}

string_t CPP_Generator::generate_assignment_expression(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_assignment_expression", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 428);
	auto facts = syntax->require_write_preparation();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_index_assignment>(facts)))) {
		return CPP_Index_Write::generate(syntax, ::scpp::checked_object_cast<prepared_index_assignment>(facts), context);
	}
	auto binding = syntax->require_assignment_preparation()->binding;
	if (static_cast<bool>((php::not_identical(binding->resolved_kind, binding_kind::assignment) || (!::scpp::object_is<variable_reference_node>(syntax->target))))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("Nested assignment requires prepared existing local storage")));
	}
	auto name = CPP_Generator::storage_name(binding, null, context);
	auto value = create<CPP_Syntax>(context)->expression(syntax->value);
	auto write = CPP_Generator::generate_storage_value(binding, name, value, bool_t(static_cast<bool_t>(false)), context);
	auto result_type = CPP_Declarations::type(facts->destination_type(), context);
	return (string_t("([&]() -> ") + cast<string_t>(result_type) + string_t(" { ") + cast<string_t>(write) + string_t("; return ") + cast<string_t>(name) + string_t("; }())"));
}

string_t CPP_Generator::generate_assignment_statement(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_assignment_statement", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 446);
	auto facts = syntax->require_write_preparation();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_index_assignment>(facts)))) {
		return (string_t("\t") + cast<string_t>(CPP_Index_Write::generate(syntax, ::scpp::checked_object_cast<prepared_index_assignment>(facts), context, static_cast<bool_t>(false))) + string_t("\n"));
	}
	if (static_cast<bool>((::scpp::object_is<prepared_property_assignment>(facts) && ::scpp::object_is<field_access_node>(syntax->target)))) {
		auto field = ::scpp::checked_object_cast<field_access_node>(syntax->target);
		if (static_cast<bool>((!field->require_preparation()->addressable()))) {
			return (string_t("\t") + cast<string_t>(CPP_Generator::generate_retained_property_write(field, ::scpp::checked_object_cast<prepared_property_assignment>(facts), create<CPP_Syntax>(context)->expression(syntax->value), context)) + string_t(";\n"));
		}
	}
	return CPP_Generator::generate_assignment_sequence(syntax, context)->statements;
}

string_t CPP_Generator::generate_retained_property_write(shared_p<scpp::compiler::field_access_node> target, shared_p<scpp::compiler::prepared_property_assignment> facts, const string_t& value, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_retained_property_write", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 462);
	auto receiver = CPP_Declarations::bind_storage_receiver(target, context);
	auto name = (string_t("property_target_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	return (string_t("([&]() -> ") + cast<string_t>(CPP_Declarations::type(facts->destination_type(), context)) + string_t(" { ") + cast<string_t>(receiver->statements) + string_t("auto& ") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(receiver->value) + string_t("; ") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(CPP_Declarations::conversion(value, facts->conversion, context)) + string_t("; return ") + cast<string_t>(name) + string_t("; }())"));
}

shared_p<scpp::compiler::cpp_assignment_sequence> CPP_Generator::generate_assignment_sequence(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_assignment_sequence", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 473);
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_index_assignment>(syntax->require_write_preparation())))) {
		auto result = create<cpp_assignment_sequence>();
		auto name = (string_t("write_result_") + cast<string_t>(context->next_temporary));
		(context->next_temporary++);
		result->statements = (string_t("\t") + cast<string_t>(CPP_Declarations::type(syntax->require_preparation()->type, context)) + string_t(" ") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(CPP_Generator::generate_assignment_expression(syntax, context)) + string_t(";\n"));
		result->value = name;
		return result;
	}
	auto value_node = syntax->value;
	auto source = create<cpp_assignment_sequence>();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<assignment_expression_node>(value_node)))) {
		source = CPP_Generator::generate_assignment_sequence(::scpp::checked_object_cast<assignment_expression_node>(value_node), context);
	}
	else {
		source->value = create<CPP_Syntax>(context)->expression(value_node);
	}
	nullable<shared_p<assignable_expression_node>> target = syntax->target;
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<variable_reference_node>(target)))) {
		target = null;
	}
	auto name = string_t("");
	auto statements = string_t("");
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<static_member_reference_node>(target)))) {
		auto member = ::scpp::checked_object_cast<static_member_reference_node>(target);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(member->qualifier, null)))) {
			statements = CPP_Declarations::qualifier_evaluation(member->qualifier, context);
		}
		name = CPP_Declarations::static_property(::scpp::checked_object_cast<prepared_static_property>(member->require_preparation()), context);
	}
	else if (static_cast<bool>(php::condition_truthy(php::not_identical(target, null)))) {
		if (static_cast<bool>(php::condition_truthy(target->require_preparation()->addressable()))) {
			name = create<CPP_Syntax>(context)->expression(target);
		}
	}
	else {
		name = CPP_Generator::storage_name(syntax->require_assignment_preparation()->binding, null, context);
	}
	statements = (statements + cast<string_t>(source->statements));
	auto write_facts = syntax->require_write_preparation();
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_property_assignment>(write_facts)))) {
		auto property_write = ::scpp::checked_object_cast<prepared_property_assignment>(write_facts);
		CPP_Declarations::type(property_write->destination_type(), context);
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<field_access_node>(target)))) {
			auto field_target = ::scpp::checked_object_cast<field_access_node>(target);
			if (static_cast<bool>((!field_target->require_preparation()->addressable()))) {
				auto result_name = (string_t("property_result_") + cast<string_t>(context->next_temporary));
				(context->next_temporary++);
				auto result = create<cpp_assignment_sequence>();
				result->statements = (string_t("\tauto ") + cast<string_t>(result_name) + string_t(" = ") + cast<string_t>(CPP_Generator::generate_retained_property_write(field_target, property_write, source->value, context)) + string_t(";\n"));
				result->value = result_name;
				return result;
			}
		}
		statements = (statements + cast<string_t>((string_t("\t") + cast<string_t>(name) + string_t(" = ") + cast<string_t>(CPP_Declarations::conversion(source->value, property_write->conversion, context)) + string_t(";\n"))));
	}
	else {
		auto binding = syntax->require_assignment_preparation()->binding;
		statements = (statements + cast<string_t>((string_t("\t") + cast<string_t>(CPP_Generator::generate_storage_value(binding, name, source->value, bool_t(static_cast<bool_t>(false)), context)) + string_t(";\n"))));
	}
	auto result = create<cpp_assignment_sequence>();
	result->statements = statements;
	result->value = name;
	return result;
}

string_t CPP_Generator::generate_integer(shared_p<scpp::compiler::prepared_integer_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_integer", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 546);
	return CPP_Generator::generate_integer_value(literal->type, literal->decimal, context);
}

string_t CPP_Generator::generate_integer_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& decimal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_integer_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 551);
	auto mapping = CPP_Types::representation(type);
	CPP_Types::record_dependencies(mapping, context);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(mapping->literal, cpp_literal_kind::signed_integer)))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ literal emission is not implemented for this type")));
	}
	return (string_t("static_cast<") + cast<string_t>(mapping->spelling) + string_t(">(") + cast<string_t>(CPP_Integer_Literals::constant(decimal)) + string_t(")"));
}

string_t CPP_Generator::generate_constant(shared_p<scpp::compiler::prepared_constant_reference> reference, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_constant", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 562);
	return CPP_Generator::generate_constant_value(reference->value, context);
}

string_t CPP_Generator::generate_constant_value(shared_p<scpp::compiler::constant_value> value, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_constant_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 567);
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<enum_constant_value>(value)))) {
		auto enum_value = ::scpp::checked_object_cast<enum_constant_value>(value);
		return (cast<string_t>(CPP_Declarations::type(enum_value->type, context)) + string_t("::") + cast<string_t>(CPP_Generator::source_name(string_t("case"), enum_value->selected_case->name)));
	}
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<no_error_constant_value>(value)))) {
		return (cast<string_t>(CPP_Declarations::type(value->type, context)) + string_t("::no_error"));
	}
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<sentinel_constant_value>(value)))) {
		if (static_cast<bool>(php::condition_truthy(value->type->matches(Model::type_catalog->null_type())))) {
			context->headers[string_t("scpp/null_t.hpp")] = static_cast<bool_t>(true);
			return string_t("scpp::null");
		}
		if (static_cast<bool>(php::condition_truthy(value->type->matches(Model::type_catalog->boolean_sentinel_type(static_cast<bool_t>(false)))))) {
			context->headers[string_t("scpp/false_sentinel_t.hpp")] = static_cast<bool_t>(true);
			return string_t("scpp::false_sentinel");
		}
		if (static_cast<bool>(php::condition_truthy(value->type->matches(Model::type_catalog->boolean_sentinel_type(static_cast<bool_t>(true)))))) {
			context->headers[string_t("scpp/true_sentinel_t.hpp")] = static_cast<bool_t>(true);
			return string_t("scpp::true_sentinel");
		}
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("Unknown canonical sentinel constant")));
	}
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<float_constant_value>(value)))) {
		auto floating = ::scpp::checked_object_cast<float_constant_value>(value);
		return CPP_Generator::generate_float_value(floating->type, floating->decimal, context);
	}
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<boolean_constant_value>(value)))) {
		auto boolean = ::scpp::checked_object_cast<boolean_constant_value>(value);
		return CPP_Generator::generate_boolean_value(boolean->type, boolean->value, context);
	}
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<string_constant_value>(value)))) {
		auto string = ::scpp::checked_object_cast<string_constant_value>(value);
		return CPP_Generator::generate_string_value(string->type, string->value, context);
	}
	if (static_cast<bool>((!::scpp::object_is<integer_constant_value>(value)))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ constant emission is not implemented for this value")));
	}
	auto integer = ::scpp::checked_object_cast<integer_constant_value>(value);
	return CPP_Generator::generate_integer_value(integer->type, integer->decimal, context);
}

string_t CPP_Generator::generate_compound_assignment(shared_p<scpp::compiler::compound_assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_compound_assignment", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 612);
	auto facts = syntax->require_compound_assignment_preparation();
	if (static_cast<bool>(php::condition_truthy(php::not_identical(facts->indexed_target, null)))) {
		return CPP_Index_Write::generate_compound(syntax, facts, context);
	}
	auto target = CPP_Declarations::bind_storage_receiver(syntax->target, context);
	auto place = (string_t("target_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto previous = (string_t("previous_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto prefix = (cast<string_t>(target->statements) + string_t("auto& ") + cast<string_t>(place) + string_t(" = ") + cast<string_t>(target->value) + string_t("; "));
	prefix = (prefix + cast<string_t>((string_t("auto ") + cast<string_t>(previous) + string_t(" = ") + cast<string_t>(place) + string_t("; "))));
	auto right = create<CPP_Syntax>(context)->expression(syntax->value);
	prefix = (prefix + cast<string_t>(CPP_Generator::compute_compound(facts, previous, right, context)));
	auto result_type = CPP_Declarations::type(facts->type, context);
	return (string_t("([&]() -> ") + cast<string_t>(result_type) + string_t(" { ") + cast<string_t>(prefix) + cast<string_t>(place) + string_t(" = ") + cast<string_t>(previous) + string_t("; return ") + cast<string_t>(place) + string_t("; }())"));
}

string_t CPP_Generator::compute_compound(shared_p<scpp::compiler::prepared_compound_assignment_expression> facts, const string_t& previous, const string_t& right, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::compute_compound", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 632);
	auto value = CPP_Generator::render_binary_decision(facts->decision, previous, right, context);
	value = CPP_Declarations::conversion(value, facts->write_back, context);
	if (static_cast<bool>(php::identical(facts->write_back_mode, compound_write_back::boxed_stored_kind))) {
		context->headers[string_t("operators/arithmetic/boxed_numeric.hpp")] = static_cast<bool_t>(true);
		return (string_t("scpp::detail::assign_numeric_result(") + cast<string_t>(previous) + string_t(", ") + cast<string_t>(value) + string_t("); "));
	}
	return (cast<string_t>(previous) + string_t(" = ") + cast<string_t>(value) + string_t("; "));
}

string_t CPP_Generator::generate_mutation(shared_p<scpp::compiler::mutation_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_mutation", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 643);
	auto decision = syntax->require_mutation_preparation()->decision;
	CPP_Generator::record_operator_headers(decision, context);
	auto prefix = string_t("");
	auto suffix = string_t("");
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_pre_increment) || php::identical(decision->operation, operator_operation::boxed_pre_increment)))) {
		prefix = string_t("++");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_pre_decrement) || php::identical(decision->operation, operator_operation::boxed_pre_decrement)))) {
		prefix = string_t("--");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_post_increment) || php::identical(decision->operation, operator_operation::boxed_post_increment)))) {
		suffix = string_t("++");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_post_decrement) || php::identical(decision->operation, operator_operation::boxed_post_decrement)))) {
		suffix = string_t("--");
	}
	else {
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("Unsupported prepared mutation operation")));
	}
	auto target = create<CPP_Syntax>(context)->expression(syntax->target);
	auto result_type = CPP_Declarations::type(decision->result_type, context);
	context->headers[string_t("scpp/generated/operators.hpp")] = static_cast<bool_t>(true);
	return (string_t("static_cast<") + cast<string_t>(result_type) + string_t(">(") + cast<string_t>(prefix) + cast<string_t>(target) + cast<string_t>(suffix) + string_t(")"));
}

string_t CPP_Generator::generate_unary(shared_p<scpp::compiler::unary_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_unary", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 674);
	auto decision = syntax->require_unary_preparation()->decision;
	CPP_Generator::record_operator_headers(decision, context);
	if (static_cast<bool>(php::identical(decision->operation, operator_operation::condition_not))) {
		context->headers[string_t("scpp/bool_t.hpp")] = static_cast<bool_t>(true);
		shared_p<truthiness_decision> truthiness = decision->truthiness;
		auto operand = create<CPP_Syntax>(context)->expression(syntax->operand);
		return (string_t("scpp::bool_t(!(") + cast<string_t>(CPP_Declarations::truthiness(operand, truthiness, context)) + string_t("))"));
	}
	auto spelling = string_t("");
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_positive) || php::identical(decision->operation, operator_operation::boxed_positive)))) {
		spelling = string_t("+");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_negative) || php::identical(decision->operation, operator_operation::boxed_negative)))) {
		spelling = string_t("-");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_complement))) {
		spelling = string_t("~");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::boolean_not))) {
		spelling = string_t("!");
	}
	else {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ unary operation is not supported")));
	}
	auto worker = create<CPP_Syntax>(context);
	auto operand = CPP_Declarations::conversion(worker->expression(syntax->operand), decision->operands[static_cast<int_t<> >(0)], context);
	context->headers[string_t("scpp/generated/operators.hpp")] = static_cast<bool_t>(true);
	return (string_t("(") + cast<string_t>(spelling) + cast<string_t>(operand) + string_t(")"));
}

string_t CPP_Generator::generate_binary(shared_p<scpp::compiler::binary_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_binary", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 710);
	auto decision = syntax->require_binary_preparation()->decision;
	auto worker = create<CPP_Syntax>(context);
	auto left = worker->expression(syntax->left);
	auto right = worker->expression(syntax->right);
	return CPP_Generator::render_binary_decision(decision, left, right, context);
}

string_t CPP_Generator::render_binary_decision(shared_p<scpp::compiler::operator_decision> decision, string_t left, string_t right, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::render_binary_decision", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 719);
	CPP_Generator::record_operator_headers(decision, context);
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::condition_and) || php::identical(decision->operation, operator_operation::condition_or)))) {
		auto logical_spelling = php::ternary_eval([&]() -> decltype(auto) { return php::identical(decision->operation, operator_operation::condition_and); }, [&]() -> decltype(auto) { return string_t("&&"); }, [&]() -> decltype(auto) { return string_t("||"); });
		auto logical_left = CPP_Declarations::truthiness(left, decision->operand_truthiness[static_cast<int_t<> >(0)], context);
		auto logical_right = CPP_Declarations::truthiness(right, decision->operand_truthiness[static_cast<int_t<> >(1)], context);
		context->headers[string_t("scpp/bool_t.hpp")] = static_cast<bool_t>(true);
		return (string_t("scpp::bool_t((") + cast<string_t>(logical_left) + string_t(") ") + cast<string_t>(logical_spelling) + string_t(" (") + cast<string_t>(logical_right) + string_t("))"));
	}
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::presence_is_null) || php::identical(decision->operation, operator_operation::presence_not_null)))) {
		auto value = left;
		if (static_cast<bool>(php::identical(Type_Queries::canonical(decision->operands[static_cast<int_t<> >(0)]->source_type)->family(), type_family::null_sentinel))) {
			value = right;
		}
		auto presence = (string_t("(") + cast<string_t>(value) + string_t(").has_value()"));
		if (static_cast<bool>(php::identical(decision->operation, operator_operation::presence_is_null))) {
			context->headers[string_t("scpp/generated/operators.hpp")] = static_cast<bool_t>(true);
			return (string_t("(!") + cast<string_t>(presence) + string_t(")"));
		}
		return presence;
	}
	auto spelling = string_t("");
	if (static_cast<bool>(php::identical(decision->operation, operator_operation::boolean_and))) {
		spelling = string_t("&&");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::boolean_or))) {
		spelling = string_t("||");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::boolean_xor))) {
		spelling = string_t("!=");
	}
	else if (static_cast<bool>(((php::identical(decision->operation, operator_operation::integer_addition) || php::identical(decision->operation, operator_operation::boxed_addition)) || php::identical(decision->operation, operator_operation::string_concatenation)))) {
		spelling = string_t("+");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_subtraction) || php::identical(decision->operation, operator_operation::boxed_subtraction)))) {
		spelling = string_t("-");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_power))) {
		spelling = string_t("scpp::pow");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_multiplication) || php::identical(decision->operation, operator_operation::boxed_multiplication)))) {
		spelling = string_t("*");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_division) || php::identical(decision->operation, operator_operation::boxed_division)))) {
		spelling = string_t("/");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_remainder) || php::identical(decision->operation, operator_operation::boxed_remainder)))) {
		spelling = string_t("%");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_bitwise_and))) {
		spelling = string_t("&");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_bitwise_or))) {
		spelling = string_t("|");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_bitwise_xor))) {
		spelling = string_t("^");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_shift_left))) {
		spelling = string_t("<<");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_shift_right))) {
		spelling = string_t(">>");
	}
	else if (static_cast<bool>(((php::identical(decision->operation, operator_operation::integer_equal) || php::identical(decision->operation, operator_operation::enum_equal)) || php::identical(decision->operation, operator_operation::boxed_equal)))) {
		spelling = string_t("==");
	}
	else if (static_cast<bool>(((php::identical(decision->operation, operator_operation::integer_not_equal) || php::identical(decision->operation, operator_operation::enum_not_equal)) || php::identical(decision->operation, operator_operation::boxed_not_equal)))) {
		spelling = string_t("!=");
	}
	else if (static_cast<bool>(((php::identical(decision->operation, operator_operation::integer_identical) || php::identical(decision->operation, operator_operation::scalar_identical)) || php::identical(decision->operation, operator_operation::boxed_identical)))) {
		spelling = string_t("scpp::php::identical");
	}
	else if (static_cast<bool>(((php::identical(decision->operation, operator_operation::integer_not_identical) || php::identical(decision->operation, operator_operation::scalar_not_identical)) || php::identical(decision->operation, operator_operation::boxed_not_identical)))) {
		spelling = string_t("scpp::php::not_identical");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_less) || php::identical(decision->operation, operator_operation::boxed_less)))) {
		spelling = string_t("<");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_less_equal) || php::identical(decision->operation, operator_operation::boxed_less_equal)))) {
		spelling = string_t("<=");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_greater) || php::identical(decision->operation, operator_operation::boxed_greater)))) {
		spelling = string_t(">");
	}
	else if (static_cast<bool>((php::identical(decision->operation, operator_operation::integer_greater_equal) || php::identical(decision->operation, operator_operation::boxed_greater_equal)))) {
		spelling = string_t(">=");
	}
	else if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_three_way))) {
		spelling = string_t("<=>");
	}
	else {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ binary operation is not supported yet")));
	}
	if (static_cast<bool>(php::condition_truthy(php::not_identical(php::count(decision->operands), static_cast<int_t<> >(2))))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("C++ binary operation requires two prepared operands")));
	}
	left = CPP_Declarations::conversion(left, decision->operands[static_cast<int_t<> >(0)], context);
	right = CPP_Declarations::conversion(right, decision->operands[static_cast<int_t<> >(1)], context);
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::boolean_and) || php::identical(decision->operation, operator_operation::boolean_or)))) {
		context->headers[string_t("scpp/bool_t.hpp")] = static_cast<bool_t>(true);
		return (string_t("scpp::bool_t(static_cast<bool>(") + cast<string_t>(left) + string_t(") ") + cast<string_t>(spelling) + string_t(" static_cast<bool>(") + cast<string_t>(right) + string_t("))"));
	}
	auto left_name = (string_t("operand_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto right_name = (string_t("operand_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto result_type = CPP_Declarations::type(decision->result_type, context);
	auto prefix = (string_t("([&]() -> ") + cast<string_t>(result_type) + string_t(" { ") + string_t("auto ") + cast<string_t>(left_name) + string_t(" = ") + cast<string_t>(left) + string_t("; ") + string_t("auto ") + cast<string_t>(right_name) + string_t(" = ") + cast<string_t>(right) + string_t("; return "));
	return (cast<string_t>(prefix) + cast<string_t>(CPP_Generator::render_eager_binary(decision, spelling, left_name, right_name, context)) + string_t("; }())"));
}

string_t CPP_Generator::render_eager_binary(shared_p<scpp::compiler::operator_decision> decision, const string_t& spelling, const string_t& left, const string_t& right, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::render_eager_binary", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 862);
	if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_power))) {
		context->headers[string_t("operators/arithmetic/power.hpp")] = static_cast<bool_t>(true);
		return (cast<string_t>(spelling) + string_t("(") + cast<string_t>(left) + string_t(", ") + cast<string_t>(right) + string_t(")"));
	}
	if (static_cast<bool>(php::identical(decision->operation, operator_operation::boolean_xor))) {
		return (string_t("scpp::bool_t(static_cast<bool>(") + cast<string_t>(left) + string_t(") != static_cast<bool>(") + cast<string_t>(right) + string_t("))"));
	}
	if (static_cast<bool>(php::identical(decision->operation, operator_operation::integer_three_way))) {
		context->headers[string_t("scpp/generated/operators.hpp")] = static_cast<bool_t>(true);
		auto result_type = CPP_Declarations::type(decision->result_type, context);
		return (cast<string_t>(result_type) + string_t("(static_cast<bool>(") + cast<string_t>(left) + string_t(" < ") + cast<string_t>(right) + string_t(") ? -1 : ") + string_t("(static_cast<bool>(") + cast<string_t>(left) + string_t(" > ") + cast<string_t>(right) + string_t(") ? 1 : 0))"));
	}
	if (static_cast<bool>((((((php::identical(decision->operation, operator_operation::integer_identical) || php::identical(decision->operation, operator_operation::scalar_identical)) || php::identical(decision->operation, operator_operation::scalar_not_identical)) || php::identical(decision->operation, operator_operation::integer_not_identical)) || php::identical(decision->operation, operator_operation::boxed_identical)) || php::identical(decision->operation, operator_operation::boxed_not_identical)))) {
		context->headers[string_t("lang/php/operators/identity/strict_identity.hpp")] = static_cast<bool_t>(true);
		return (cast<string_t>(spelling) + string_t("(") + cast<string_t>(left) + string_t(", ") + cast<string_t>(right) + string_t(")"));
	}
	if (static_cast<bool>((php::identical(decision->operation, operator_operation::enum_equal) || php::identical(decision->operation, operator_operation::enum_not_equal)))) {
		context->headers[string_t("scpp/bool_t.hpp")] = static_cast<bool_t>(true);
		return (string_t("scpp::bool_t(") + cast<string_t>(left) + string_t(" ") + cast<string_t>(spelling) + string_t(" ") + cast<string_t>(right) + string_t(")"));
	}
	context->headers[string_t("scpp/generated/operators.hpp")] = static_cast<bool_t>(true);
	return (string_t("(") + cast<string_t>(left) + string_t(" ") + cast<string_t>(spelling) + string_t(" ") + cast<string_t>(right) + string_t(")"));
}

void CPP_Generator::record_operator_headers(shared_p<scpp::compiler::operator_decision> decision, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::record_operator_headers", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 895);
	operator_operation operation = required_cast<operator_operation>(decision->operation);
	switch (operation) {
		case operator_operation::boxed_pre_increment:
		case operator_operation::boxed_post_increment:
		case operator_operation::boxed_pre_decrement:
		case operator_operation::boxed_post_decrement:
		case operator_operation::boxed_positive:
		case operator_operation::boxed_negative:
		case operator_operation::boxed_addition:
		case operator_operation::boxed_subtraction:
		case operator_operation::boxed_multiplication:
		case operator_operation::boxed_division:
		case operator_operation::boxed_remainder:
		context->headers[string_t("operators/arithmetic/boxed_numeric.hpp")] = static_cast<bool_t>(true);
		return;
		case operator_operation::boxed_equal:
		case operator_operation::boxed_not_equal:
		context->headers[string_t("operators/identity/boxed_scalar_equality.hpp")] = static_cast<bool_t>(true);
		return;
		case operator_operation::boxed_less:
		case operator_operation::boxed_less_equal:
		case operator_operation::boxed_greater:
		case operator_operation::boxed_greater_equal:
		context->headers[string_t("operators/identity/boxed_ordering.hpp")] = static_cast<bool_t>(true);
		return;
		default:
		return;
	}
}

string_t CPP_Generator::generate_float(shared_p<scpp::compiler::prepared_float_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_float", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 927);
	return CPP_Generator::generate_float_value(literal->type, literal->decimal, context);
}

string_t CPP_Generator::generate_float_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& decimal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_float_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 931);
	auto mapping = CPP_Types::representation(type);
	CPP_Types::record_dependencies(mapping, context);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(mapping->literal, cpp_literal_kind::floating)))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ literal emission is not implemented for this type")));
	}
	return (string_t("static_cast<") + cast<string_t>(mapping->spelling) + string_t(">(") + cast<string_t>(decimal) + string_t(")"));
}

string_t CPP_Generator::generate_boolean(shared_p<scpp::compiler::prepared_boolean_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_boolean", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 942);
	return CPP_Generator::generate_boolean_value(literal->type, literal->value, context);
}

string_t CPP_Generator::generate_boolean_value(shared_p<scpp::compiler::canonical_type_use> type, bool_t value, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_boolean_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 946);
	auto mapping = CPP_Types::representation(type);
	CPP_Types::record_dependencies(mapping, context);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(mapping->literal, cpp_literal_kind::boolean)))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ literal emission is not implemented for this type")));
	}
	auto spelling = php::ternary_eval([&]() -> decltype(auto) { return value; }, [&]() -> decltype(auto) { return string_t("true"); }, [&]() -> decltype(auto) { return string_t("false"); });
	return (string_t("static_cast<") + cast<string_t>(mapping->spelling) + string_t(">(") + cast<string_t>(spelling) + string_t(")"));
}

string_t CPP_Generator::generate_interpolated_string(shared_p<scpp::compiler::interpolated_string_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_interpolated_string", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 959);
	auto type = CPP_Declarations::type(syntax->require_preparation()->type, context);
	auto name = (string_t("interpolation_") + cast<string_t>(context->next_temporary));
	(context->next_temporary++);
	auto text = (string_t("([&]() -> ") + cast<string_t>(type) + string_t(" { ") + cast<string_t>(type) + string_t(" ") + cast<string_t>(name) + string_t("; "));
	auto worker = create<CPP_Syntax>(context);
	::scpp::compiler::Storage<interpolation_part_node> parts = required_cast<::scpp::compiler::Storage<interpolation_part_node>>(syntax->parts);
	auto& __scpp_foreach_source_966 = parts;
	for (auto __scpp_foreach_entry_966 : foreach_range(__scpp_foreach_source_966)) {
		auto part = __scpp_foreach_entry_966.value_copy();
		text = (text + cast<string_t>((cast<string_t>(name) + string_t(".append(") + cast<string_t>(worker->interpolation_part(part)) + string_t("); "))));
	}
	return (cast<string_t>(text) + string_t("return ") + cast<string_t>(name) + string_t("; }())"));
}

string_t CPP_Generator::generate_string(shared_p<scpp::compiler::prepared_string_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_string", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 973);
	return CPP_Generator::generate_string_value(literal->type, literal->value, context);
}

string_t CPP_Generator::generate_string_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& value, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_string_value", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 977);
	auto mapping = CPP_Types::representation(type);
	CPP_Types::record_dependencies(mapping, context);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(mapping->literal, cpp_literal_kind::string_value)))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("C++ string literal emission requires the canonical string type")));
	}
	auto spelling = CPP_Generator::cpp_string_literal(value);
	if (static_cast<bool>((!CPP_Generator::contains_zero_byte(value)))) {
		return (cast<string_t>(mapping->spelling) + string_t("(") + cast<string_t>(spelling) + string_t(")"));
	}
	return (cast<string_t>(mapping->spelling) + string_t("(std::string(") + cast<string_t>(spelling) + string_t(", ") + cast<string_t>(str::byte_length(value)) + string_t("))"));
}

string_t CPP_Generator::cpp_string_literal(const string_t& value) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::cpp_string_literal", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 992);
	auto result = string_t("\"");
	auto hex = string_t("0123456789ABCDEF");
	auto length = str::byte_length(value);
	for (auto index = static_cast<int_t<> >(0); static_cast<bool>((index < length)); (index++)) {
		auto byte = php::string_byte_at(value, index);
		if (static_cast<bool>(php::identical(byte, static_cast<int_t<> >(34)))) {
			result = (result + string_t("\\\""));
		}
		else if (static_cast<bool>(php::identical(byte, static_cast<int_t<> >(92)))) {
			result = (result + string_t("\\\\"));
		}
		else if (static_cast<bool>(((byte >= static_cast<int_t<> >(32)) && (byte < static_cast<int_t<> >(127))))) {
			result = (result + cast<string_t>(scpp_portability_byte_from_int(byte)));
		}
		else {
			result = (result + cast<string_t>((string_t("\\x") + cast<string_t>(str::byte_slice(hex, cast<int_t<>>((byte / static_cast<int_t<> >(16))), static_cast<int_t<> >(1))) + cast<string_t>(str::byte_slice(hex, (byte % static_cast<int_t<> >(16)), static_cast<int_t<> >(1))) + string_t("\" \""))));
		}
	}
	return (cast<string_t>(result) + string_t("\""));
}

bool_t CPP_Generator::contains_zero_byte(const string_t& value) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::contains_zero_byte", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 1017);
	for (auto index = static_cast<int_t<> >(0); static_cast<bool>((index < str::byte_length(value))); (index++)) {
		if (static_cast<bool>(php::identical(php::string_byte_at(value, index), static_cast<int_t<> >(0)))) {
			return bool_t(static_cast<bool_t>(true));
		}
	}
	return bool_t(static_cast<bool_t>(false));
}

string_t CPP_Generator::generate_reference(shared_p<scpp::compiler::prepared_variable_reference> reference, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::generate_reference", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 1026);
	auto target = ::scpp::checked_object_cast<collected_name>(weakref_get(reference->declaration));
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_method>(target)))) {
		return string_t("this");
	}
	return CPP_Generator::local_name(target);
}

string_t CPP_Generator::source_name(const string_t& role, const string_t& name) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::source_name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 1033);
	auto suffix = string_t("");
	for (auto index = static_cast<int_t<> >(0); static_cast<bool>((index < str::byte_length(name))); (index++)) {
		auto byte = php::string_byte_at(name, index);
		if (static_cast<bool>(php::identical(byte, static_cast<int_t<> >(85)))) {
			suffix = (suffix + string_t("UU"));
		}
		else if (static_cast<bool>(php::identical(byte, static_cast<int_t<> >(95)))) {
			suffix = (suffix + string_t("U_"));
		}
		else if (static_cast<bool>(php::identical(byte, static_cast<int_t<> >(92)))) {
			suffix = (suffix + string_t("Uq"));
		}
		else {
			suffix = (suffix + cast<string_t>(scpp_portability_byte_from_int(byte)));
		}
	}
	return (cast<string_t>(role) + string_t("_") + cast<string_t>(suffix));
}

string_t CPP_Generator::local_name(shared_p<scpp::compiler::collected_name> declaration) {
	SCPP_CALL_DEPTH_GUARD("CPP_Generator::local_name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/generate.phs", 1054);
	return CPP_Generator::source_name(string_t("local"), declaration->name);
}

}

