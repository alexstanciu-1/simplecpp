#include "structures.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t cpp_type::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_type::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

bool_t cpp_assignment_sequence::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_assignment_sequence::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

bool_t cpp_artifact::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_artifact::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_artifact::cpp_artifact(const string_t& identity, scpp::compiler::cpp_artifact_kind artifact_kind, const string_t& file_name, const string_t& text) {
	SCPP_CALL_DEPTH_GUARD("cpp_artifact::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 49);
	if (static_cast<bool>((php::identical(identity, string_t("")) || php::identical(file_name, string_t(""))))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_invalid_argument_exception>(string_t("C++ artifact identity and path must not be empty")));
	}
	this->identity = identity;
	this->artifact_kind = artifact_kind;
	this->file_name = file_name;
	this->text = text;
}

string_t cpp_artifact::kind_name() {
	SCPP_CALL_DEPTH_GUARD("cpp_artifact::kind_name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 59);
	return php::ternary_eval([&]() -> decltype(auto) { return php::identical(this->artifact_kind, cpp_artifact_kind::header); }, [&]() -> decltype(auto) { return string_t("header"); }, [&]() -> decltype(auto) { return string_t("translation_unit"); });
}

scpp::compiler::cpp_artifact_kind cpp_artifact::kind() {
	SCPP_CALL_DEPTH_GUARD("cpp_artifact::kind", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 63);
	return this->artifact_kind;
}

bool_t cpp_implementation_group::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_implementation_group::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_implementation_group::cpp_implementation_group(const string_t& identity, const string_t& file_name) {
	SCPP_CALL_DEPTH_GUARD("cpp_implementation_group::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 74);
	this->identity = identity;
	this->file_name = file_name;
}

bool_t cpp_generation_context::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_generation_context::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

bool_t cpp_fragment::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_fragment::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_fragment::cpp_fragment() {
	SCPP_CALL_DEPTH_GUARD("cpp_fragment::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 127);
	this->records = ::scpp::compiler::Storage<scpp::compiler::collected_record>();
}

bool_t cpp_program::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_program::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_program::cpp_program() {
	SCPP_CALL_DEPTH_GUARD("cpp_program::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/allocation-policy-20261016/phpp/05_backend/cpp/structures.phs", 138);
	this->fragments = hash_t<shared_p<scpp::compiler::cpp_fragment>, shared_p<scpp::compiler::preparation_owner>>{};
}

}

