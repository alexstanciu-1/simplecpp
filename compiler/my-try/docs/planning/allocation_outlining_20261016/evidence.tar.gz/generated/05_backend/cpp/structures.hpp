#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class breakable_node;
class canonical_type_use;
class collected_record;
class cpp_artifact;
class cpp_assignment_sequence;
class cpp_fragment;
class cpp_generation_context;
class cpp_implementation_group;
class cpp_program;
class cpp_type;
class loop_node;
class preparation_owner;
class prepared_compiler_call;

enum class cpp_literal_kind : std::uint8_t {
	signed_integer,
	boolean,
	floating,
	string_value,
	none
};

enum class cpp_type_requirement : std::uint8_t {
	declaration,
	stored_value,
	complete
};

class cpp_type : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	string_t spelling;
	hash_t<bool_t> headers = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<bool_t> forward_declarations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	scpp::compiler::cpp_literal_kind literal;
};

class cpp_assignment_sequence : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	string_t statements = string_t("");
	string_t value;
};

enum class cpp_artifact_kind : std::uint8_t {
	translation_unit,
	header
};

class cpp_artifact : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	string_t identity;
private:
	scpp::compiler::cpp_artifact_kind artifact_kind;
public:
	string_t file_name;
	string_t text;
	vector_t<string_t> includes = vector_t<string_t>{};
	bool_t includes_complete = bool_t(static_cast<bool_t>(false));
	cpp_artifact(const string_t& identity, scpp::compiler::cpp_artifact_kind artifact_kind, const string_t& file_name, const string_t& text);
	virtual string_t kind_name();
	virtual scpp::compiler::cpp_artifact_kind kind();
};

class cpp_implementation_group : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	string_t text = string_t("");
	hash_t<bool_t> headers = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<bool_t> forward_declarations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	string_t identity;
	string_t file_name;
	cpp_implementation_group(const string_t& identity, const string_t& file_name);
};

enum class cpp_record_state : std::uint8_t {
	visiting,
	complete
};

class cpp_generation_context : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	hash_t<bool_t> outlined_shared_allocations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<shared_p<scpp::compiler::prepared_compiler_call>> compiler_helpers = [&]() -> hash_t<shared_p<prepared_compiler_call>> {
	hash_t<shared_p<prepared_compiler_call>> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	nullable<shared_p<scpp::compiler::breakable_node>> break_target = null;
	nullable<shared_p<scpp::compiler::loop_node>> continue_target = null;
	hash_t<bool_t> headers = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<bool_t> forward_declarations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<scpp::compiler::cpp_record_state> record_states = [&]() -> hash_t<cpp_record_state> {
	hash_t<cpp_record_state> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	string_t records = string_t("");
	nullable<shared_p<scpp::compiler::canonical_type_use>> return_type = null;
	int_t<> next_temporary = static_cast<int_t<> >(0);
};

class cpp_fragment : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	hash_t<shared_p<scpp::compiler::prepared_compiler_call>> compiler_helpers = [&]() -> hash_t<shared_p<prepared_compiler_call>> {
	hash_t<shared_p<prepared_compiler_call>> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	scpp::compiler::change_state change_status = change_state::added;
	int_t<> version = static_cast<int_t<> >(0);
	string_t text = string_t("");
	string_t prototype_text = string_t("");
	string_t initializer_text = string_t("");
	string_t record_definition_text = string_t("");
	string_t allocation_declaration_text = string_t("");
	hash_t<bool_t> headers = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<bool_t> forward_declarations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<bool_t> definition_headers = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	::scpp::compiler::Storage<scpp::compiler::collected_record> records;
	cpp_fragment();
};

class cpp_program : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	string_t policy_identity = string_t("");
	hash_t<bool_t> outlined_shared_allocations = [&]() -> hash_t<bool_t> {
	hash_t<bool_t> __scpp_hash_value{};
	return __scpp_hash_value;
}();
	hash_t<shared_p<scpp::compiler::cpp_fragment>, shared_p<scpp::compiler::preparation_owner>> fragments;
	cpp_program();
};

}

