#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class CPP_Generator;
class assignable_expression_node;
class assignment_expression_node;
class binary_expression_node;
class canonical_type_use;
class cast_expression_node;
class collected_name;
class collected_record;
class compound_assignment_expression_node;
class constant_value;
class cpp_artifact;
class cpp_assignment_sequence;
class cpp_generation_context;
class cpp_lowering_policy;
class cpp_program;
class expression_node;
class expression_statement_node;
class field_access_node;
class interpolated_string_node;
class mutation_expression_node;
class operator_decision;
class preparation_owner;
class prepared_binding;
class prepared_boolean_literal;
class prepared_compound_assignment_expression;
class prepared_constant_reference;
class prepared_file;
class prepared_float_literal;
class prepared_integer_literal;
class prepared_property_assignment;
class prepared_string_literal;
class prepared_variable_reference;
class return_node;
class statement_body_node;
class unary_expression_node;

class CPP_Generator : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
private:
	shared_p<scpp::compiler::cpp_program> program;
	shared_p<scpp::compiler::cpp_lowering_policy> policy;
public:
	CPP_Generator(nullable<shared_p<scpp::compiler::cpp_program>> program = null, nullable<shared_p<scpp::compiler::cpp_lowering_policy>> policy = null);
	virtual ::scpp::compiler::Storage<scpp::compiler::cpp_artifact> generate(shared_p<scpp::compiler::prepared_file> prepared);
	virtual ::scpp::compiler::Storage<scpp::compiler::cpp_artifact> generate_program(::scpp::compiler::Storage<scpp::compiler::prepared_file> files, shared_p<scpp::compiler::prepared_file> entry_file);
	static void discard_deleted(shared_p<scpp::compiler::cpp_program> program);
private:
	virtual void render(shared_p<scpp::compiler::preparation_owner> owner);
	virtual void validate_record_dependencies(shared_p<scpp::compiler::collected_record> entry, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate_statements(shared_p<scpp::compiler::statement_body_node> body, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_storage(shared_p<scpp::compiler::prepared_binding> binding, nullable<shared_p<scpp::compiler::assignable_expression_node>> target, nullable<shared_p<scpp::compiler::expression_node>> initializer, bool_t explicit_type, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t storage_name(shared_p<scpp::compiler::prepared_binding> binding, nullable<shared_p<scpp::compiler::assignable_expression_node>> target, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate_storage_value(shared_p<scpp::compiler::prepared_binding> binding, const string_t& name, string_t value, bool_t explicit_type, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_return(shared_p<scpp::compiler::return_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_expression_statement(shared_p<scpp::compiler::expression_statement_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_cast(shared_p<scpp::compiler::cast_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_assignment_expression(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t generate_assignment_statement(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_retained_property_write(shared_p<scpp::compiler::field_access_node> target, shared_p<scpp::compiler::prepared_property_assignment> facts, const string_t& value, shared_p<scpp::compiler::cpp_generation_context> context);
	static shared_p<scpp::compiler::cpp_assignment_sequence> generate_assignment_sequence(shared_p<scpp::compiler::assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate_integer(shared_p<scpp::compiler::prepared_integer_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t generate_integer_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& decimal, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate_constant(shared_p<scpp::compiler::prepared_constant_reference> reference, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_constant_value(shared_p<scpp::compiler::constant_value> value, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_compound_assignment(shared_p<scpp::compiler::compound_assignment_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t compute_compound(shared_p<scpp::compiler::prepared_compound_assignment_expression> facts, const string_t& previous, const string_t& right, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_mutation(shared_p<scpp::compiler::mutation_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_unary(shared_p<scpp::compiler::unary_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_binary(shared_p<scpp::compiler::binary_expression_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t render_binary_decision(shared_p<scpp::compiler::operator_decision> decision, string_t left, string_t right, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t render_eager_binary(shared_p<scpp::compiler::operator_decision> decision, const string_t& spelling, const string_t& left, const string_t& right, shared_p<scpp::compiler::cpp_generation_context> context);
	static void record_operator_headers(shared_p<scpp::compiler::operator_decision> decision, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate_float(shared_p<scpp::compiler::prepared_float_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_float_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& decimal, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_boolean(shared_p<scpp::compiler::prepared_boolean_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_boolean_value(shared_p<scpp::compiler::canonical_type_use> type, bool_t value, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_interpolated_string(shared_p<scpp::compiler::interpolated_string_node> syntax, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_string(shared_p<scpp::compiler::prepared_string_literal> literal, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t generate_string_value(shared_p<scpp::compiler::canonical_type_use> type, const string_t& value, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t cpp_string_literal(const string_t& value);
	static bool_t contains_zero_byte(const string_t& value);
public:
	static string_t generate_reference(shared_p<scpp::compiler::prepared_variable_reference> reference, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t source_name(const string_t& role, const string_t& name);
	static string_t local_name(shared_p<scpp::compiler::collected_name> declaration);
};

}

