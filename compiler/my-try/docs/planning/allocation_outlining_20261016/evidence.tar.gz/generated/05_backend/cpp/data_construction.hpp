#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class CPP_Data_Construction;
class CPP_Initialization_Registration;
class CPP_Record_Construction;
class canonical_type_use;
class collected_method;
class cpp_generation_context;
class cpp_initialization_adapter;
class data_construction_node;
class expression_node;
class initialization_binding;
class prepared_object_construction;
class prepared_record_construction;
class record_initialization_contract;
class type_definition_i;

class cpp_initialization_adapter : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
private:
	shared_p<scpp::compiler::type_definition_i> semantic_definition;
	string_t template_name;
	string_t required_header;
public:
	cpp_initialization_adapter(shared_p<scpp::compiler::type_definition_i> semantic_definition, const string_t& template_name, const string_t& required_header);
	shared_p<scpp::compiler::type_definition_i> definition() { return __scpp_return_definition(std::type_identity<shared_p<scpp::compiler::type_definition_i>>{}); }
	virtual shared_p<scpp::compiler::type_definition_i> __scpp_return_definition(std::type_identity<shared_p<scpp::compiler::type_definition_i>>);
	virtual string_t name();
	virtual string_t header();
};

class CPP_Initialization_Registration : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static void install();
};

class CPP_Record_Construction : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static bool_t keyed(shared_p<scpp::compiler::collected_method> method);
	static string_t key(shared_p<scpp::compiler::collected_method> method);
	static string_t key_declaration(shared_p<scpp::compiler::collected_method> method);
	static string_t allocation(shared_p<scpp::compiler::canonical_type_use> type, shared_p<scpp::compiler::canonical_type_use> payload_type, scpp::compiler::record_storage_kind storage, shared_p<scpp::compiler::cpp_generation_context> context);
	static string_t object(shared_p<scpp::compiler::prepared_object_construction> facts, ::scpp::compiler::Storage<scpp::compiler::expression_node> arguments, shared_p<scpp::compiler::cpp_generation_context> context);
};

class CPP_Data_Construction : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
private:
	static string_t reference(shared_p<scpp::compiler::initialization_binding> binding, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t generate(shared_p<scpp::compiler::data_construction_node> node, shared_p<scpp::compiler::cpp_generation_context> context);
private:
	static string_t record(shared_p<scpp::compiler::data_construction_node> node, shared_p<scpp::compiler::prepared_record_construction> facts, shared_p<scpp::compiler::cpp_generation_context> context);
public:
	static string_t constructor(const string_t& name, shared_p<scpp::compiler::record_initialization_contract> contract, shared_p<scpp::compiler::cpp_generation_context> context);
};

}

