#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp {

int __scpp_main();

}



namespace scpp {
	using namespace ::scpp;

int __scpp_main() {
	int_t<> argc = php::cli_argc();
	mixed_t argv = php::cli_argv();
	SCPP_CALL_DEPTH_GUARD("__scpp_main", "/home/alex-ai/language-verification/20261018/verification/results/strict-04/baseline/tests/php/curl/strict_level_01/strict_curl_001_surface.phs", 0);
	auto root = string_t("strict_curl_test_root");
	auto path = (cast<string_t>(root) + string_t("/payload.bin"));
	string_t payload = required_cast<string_t>(string_t(""));
	int_t<> bytes = required_cast<int_t<>>(static_cast<int_t<> >(0));
	string_t real = required_cast<string_t>(string_t(""));
	error_t err;
	bool_t ok = required_cast<bool_t>(bool_t(static_cast<bool_t>(false)));
	shared_p<curl_handle> ch;
	shared_p<curl_response> resp;
	fs::mkdir(root);
	if (static_cast<bool>((!php::take(payload, php::hex2bin(string_t("4100420A")))))) {
		php::echo_one(string_t("HEX_FAIL\n"));
	}
	else {
		if (static_cast<bool>((!php::take(bytes, err, fs::put(path, payload))))) {
			php::echo_one(string_t("WRITE_FAIL\n"));
		}
		else {
			if (static_cast<bool>((!php::take(real, err, fs::realpath(path))))) {
				php::echo_one(string_t("REAL_FAIL\n"));
			}
			else {
				if (static_cast<bool>((!php::take(ch, err, curl::init((string_t("file://") + cast<string_t>(real))))))) {
					php::echo_one(string_t("INIT_FAIL\n"));
				}
				else {
					vector_t<string_t> headers = {};
					(void) headers.push_back(string_t("X-Test: curl-surface"));
					php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_TIMEOUT, static_cast<int_t<> >(5))); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
					php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_HTTPHEADER, headers)); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
					if (static_cast<bool>((!php::take(resp, err, curl::exec(ch))))) {
						php::echo_one(string_t("EXEC_FAIL\n"));
					}
					else {
						php::echo_one(resp->status_code);
						php::echo_one(string_t("\n"));
						php::echo_one(str::hex_encode(resp->body));
						php::echo_one(string_t("\n"));
						php::echo_one(str::length(resp->body));
						php::echo_one(string_t("\n"));
					}
					php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::close(ch)); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
				}
			}
		}
	}
	fs::remove(path);
	fs::rmdir(root);
	return 0;
}
}

int main(int __scpp_argc, char** __scpp_argv) {
	try {
		::scpp::php::set_cli_args(__scpp_argc, __scpp_argv);
		return scpp::__scpp_main();
	} catch (const std::exception &exception) {
		::scpp::print_runtime_exception(exception);
		return 1;
	}
}

