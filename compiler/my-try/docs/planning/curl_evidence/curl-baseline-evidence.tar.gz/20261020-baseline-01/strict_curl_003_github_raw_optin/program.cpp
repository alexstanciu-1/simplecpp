#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp {

int __scpp_main();

}



namespace scpp {
	using namespace ::scpp;

int __scpp_main() {
	int_t<> argc = php::cli_argc();
	mixed_t argv = php::cli_argv();
	SCPP_CALL_DEPTH_GUARD("__scpp_main", "/home/alex-ai/language-verification/20261018/verification/results/strict-04/baseline/tests/php/curl/strict_level_01/strict_curl_003_github_raw_optin.phs", 0);
	mixed_t url = argv.get(static_cast<int_t<> >(1));
	error_t err;
	bool_t ok = required_cast<bool_t>(bool_t(static_cast<bool_t>(false)));
	shared_p<curl_handle> ch;
	shared_p<curl_response> resp;
	if (static_cast<bool>((!php::take(ch, err, curl::init(url))))) {
		php::echo_one(string_t("INIT_FAIL\n"));
	}
	else {
		vector_t<string_t> headers = {};
		(void) headers.push_back(string_t("X-Test: curl-github-optin"));
		php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_TIMEOUT, static_cast<int_t<> >(15))); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
		php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_FOLLOWLOCATION, static_cast<bool_t>(true))); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
		php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_HTTPHEADER, headers)); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
		php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::setopt(ch, CURLOPT_USERAGENT, string_t("simplecpp-curl-network-test/1.0"))); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
		if (static_cast<bool>((!php::take(resp, err, curl::exec(ch))))) {
			php::echo_one(string_t("EXEC_FAIL\n"));
		}
		else {
			php::echo_one(resp->status_code);
			php::echo_one(string_t("\n"));
			php::echo_one(str::hex_encode(resp->body));
			php::echo_one(string_t("\n"));
			php::echo_one(str::length(resp->body));
			php::echo_one(string_t("\n"));
		}
		php::echo_one(php::ternary_eval([&]() -> decltype(auto) { return php::take(ok, err, curl::close(ch)); }, [&]() -> decltype(auto) { return string_t("T\n"); }, [&]() -> decltype(auto) { return string_t("F\n"); }));
	}
	return 0;
}
}

int main(int __scpp_argc, char** __scpp_argv) {
	try {
		::scpp::php::set_cli_args(__scpp_argc, __scpp_argv);
		return scpp::__scpp_main();
	} catch (const std::exception &exception) {
		::scpp::print_runtime_exception(exception);
		return 1;
	}
}

