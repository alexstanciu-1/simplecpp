#include "specializations/runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806.hpp"
#include "specializations/concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529.hpp"
#include "specializations/runtime_concrete_index_564266376348886871c2a039a45448fb70335e9a5377a1062173481ba789aae9.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386.hpp"
#include "specializations/concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3.hpp"
#include "specializations/concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_conversion_f4b8ca7b63187e0858cf91ed26bc04caec97df753eaf876e9a2b9b4c448b90cc.hpp"
#include "specializations/runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48.hpp"
#include "specializations/runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce.hpp"
#include "specializations/runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836.hpp"
#include "specializations/concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142.hpp"
#include "specializations/runtime_concrete_index_283f55ccb4bdd4b304dc73342536980015ec10a36e7cca81fc5aad234cf404bd.hpp"
#include "specializations/concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21.hpp"
#include "specializations/runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3.hpp"
#include "specializations/runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b.hpp"
#include "specializations/runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce.hpp"
#include "specializations/concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90.hpp"
#include "specializations/runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67.hpp"
#include "specializations/runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669.hpp"
#include "specializations/concrete_n_result_mixed__0debbb0cf6dedba492f40273ba7c594156e2a851ae6e7540fe057d74f3b07b8d.hpp"
#include "specializations/runtime_runtime_call_cd9e1c65f66d9921dd6df25c8d594e93f6d02538004809cf66cc9ef7fb9cc954.hpp"
#include "specializations/runtime_take_9055313aedbaa617b0d4ace36f7767e8dafbfc7f55c34c0cbe5c9a00b1979e90.hpp"
#include "specializations/runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/runtime_output_4bb15b0d2f3614306fd58295c74596b8a29a8377905ed3a2c61fe20ceff2297f.hpp"
#include "specializations/runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3.hpp"
#include "specializations/runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589.hpp"
#include "specializations/runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5.hpp"
#include "specializations/runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	auto local_argv = scpp::internal::runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806();
	auto local_url = ([&]() -> scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 { const auto& index_receiver_0 = local_argv; scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 index_key_0 = scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529{static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)}; return scpp::null_index_read(index_receiver_0, index_key_0); }());
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_err;
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac local_ok = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 local_ch;
	scpp::internal::concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3 local_resp;
	scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 local_info;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_5 = ([&]() -> scpp::internal::concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_4 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto operand_2 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { const auto& runtime_input_1 = local_url; return scpp::internal::runtime_conversion_f4b8ca7b63187e0858cf91ed26bc04caec97df753eaf876e9a2b9b4c448b90cc((runtime_input_1).address()); }()); auto operand_3 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("/payload.txt", 12); return scpp::internal::runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48((operand_2).address(), (operand_3).address()); }());
	return scpp::internal::runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce((argument_4).address());
}()); return scpp::internal::runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(&(local_ch), (local_err).address(), (take_source_5).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("INIT_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 local_headers = scpp::internal::runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836();
	{ auto& write_receiver_6 = local_headers; scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 write_value_6 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("X-Test: curl-http", 17); scpp::index_append(write_receiver_6, write_value_6); }
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_10 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_7 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_8 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_9 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(5LL);
	return scpp::internal::runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3((argument_7).address(), (argument_8).address(), (argument_9).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_10).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_14 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_11 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_12 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL);
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 argument_13 = local_headers;
	return scpp::internal::runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce((argument_11).address(), (argument_12).address(), (argument_13).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_14).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_16 = ([&]() -> scpp::internal::concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_15 = local_ch;
	return scpp::internal::runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67((argument_15).address());
}()); return scpp::internal::runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669(&(local_resp), (local_err).address(), (take_source_16).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("EXEC_FAIL\x0A" "", 10))).address());
}
else if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_19 = ([&]() -> scpp::internal::concrete_n_result_mixed__0debbb0cf6dedba492f40273ba7c594156e2a851ae6e7540fe057d74f3b07b8d {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_17 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_18 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(101LL);
	return scpp::internal::runtime_runtime_call_cd9e1c65f66d9921dd6df25c8d594e93f6d02538004809cf66cc9ef7fb9cc954((argument_17).address(), (argument_18).address());
}()); return scpp::internal::runtime_take_9055313aedbaa617b0d4ace36f7767e8dafbfc7f55c34c0cbe5c9a00b1979e90(&(local_info), (local_err).address(), (take_source_19).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("INFO_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto provider_owner_20 = local_resp; return scpp::internal::runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19((provider_owner_20).address()); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_4bb15b0d2f3614306fd58295c74596b8a29a8377905ed3a2c61fe20ceff2297f((static_cast<const scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529&>(local_info)).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_22 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_21 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_21).address()); }());
	return scpp::internal::runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589((argument_22).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_24 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_23 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_23).address()); }());
	return scpp::internal::runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5((argument_24).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_26 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_25 = local_ch;
	return scpp::internal::runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a((argument_25).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_26).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
