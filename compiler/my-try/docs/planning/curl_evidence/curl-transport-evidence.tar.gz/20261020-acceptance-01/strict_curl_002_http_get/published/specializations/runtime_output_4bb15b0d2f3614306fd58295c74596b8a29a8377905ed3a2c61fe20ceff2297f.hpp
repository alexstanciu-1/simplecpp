#pragma once
namespace scpp::internal { void runtime_output_4bb15b0d2f3614306fd58295c74596b8a29a8377905ed3a2c61fe20ceff2297f(const void* p0); }
