#include "specializations/runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806.hpp"
#include "specializations/concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529.hpp"
#include "specializations/runtime_concrete_index_564266376348886871c2a039a45448fb70335e9a5377a1062173481ba789aae9.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386.hpp"
#include "specializations/concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3.hpp"
#include "specializations/concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082.hpp"
#include "specializations/runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce.hpp"
#include "specializations/runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836.hpp"
#include "specializations/concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142.hpp"
#include "specializations/runtime_concrete_index_283f55ccb4bdd4b304dc73342536980015ec10a36e7cca81fc5aad234cf404bd.hpp"
#include "specializations/concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21.hpp"
#include "specializations/runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3.hpp"
#include "specializations/runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b.hpp"
#include "specializations/runtime_runtime_call_76f35a2fc807c94a9a7b77e2331288167c664c1bad3e35d1688c1fc7d5511405.hpp"
#include "specializations/runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce.hpp"
#include "specializations/runtime_runtime_call_4f14491a45f430d2e1911fed4f5fb18506e67251bd700ab7654513f036a6539d.hpp"
#include "specializations/concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90.hpp"
#include "specializations/runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67.hpp"
#include "specializations/runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669.hpp"
#include "specializations/runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3.hpp"
#include "specializations/runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589.hpp"
#include "specializations/runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5.hpp"
#include "specializations/runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	auto local_argv = scpp::internal::runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806();
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_url = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { const auto& runtime_input_1 = ([&]() -> scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 { const auto& index_receiver_0 = local_argv; scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 index_key_0 = scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529{static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)}; return scpp::null_index_read(index_receiver_0, index_key_0); }()); return scpp::internal::runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613((runtime_input_1).address()); }());
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_err;
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac local_ok = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 local_ch;
	scpp::internal::concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3 local_resp;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_3 = ([&]() -> scpp::internal::concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_2 = local_url;
	return scpp::internal::runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce((argument_2).address());
}()); return scpp::internal::runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(&(local_ch), (local_err).address(), (take_source_3).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("INIT_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 local_headers = scpp::internal::runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836();
	{ auto& write_receiver_4 = local_headers; scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 write_value_4 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("X-Test: curl-github-optin", 25); scpp::index_append(write_receiver_4, write_value_4); }
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_8 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_5 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_6 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_7 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(15LL);
	return scpp::internal::runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3((argument_5).address(), (argument_6).address(), (argument_7).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_8).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_12 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_9 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_10 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(9LL);
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac argument_11 = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
	return scpp::internal::runtime_runtime_call_76f35a2fc807c94a9a7b77e2331288167c664c1bad3e35d1688c1fc7d5511405((argument_9).address(), (argument_10).address(), (argument_11).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_12).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_16 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_13 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_14 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL);
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 argument_15 = local_headers;
	return scpp::internal::runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce((argument_13).address(), (argument_14).address(), (argument_15).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_16).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_20 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_17 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_18 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(10LL);
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_19 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("simplecpp-curl-network-test/1.0", 31);
	return scpp::internal::runtime_runtime_call_4f14491a45f430d2e1911fed4f5fb18506e67251bd700ab7654513f036a6539d((argument_17).address(), (argument_18).address(), (argument_19).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_20).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_22 = ([&]() -> scpp::internal::concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_21 = local_ch;
	return scpp::internal::runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67((argument_21).address());
}()); return scpp::internal::runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669(&(local_resp), (local_err).address(), (take_source_22).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("EXEC_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto provider_owner_23 = local_resp; return scpp::internal::runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19((provider_owner_23).address()); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_25 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_24 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_24).address()); }());
	return scpp::internal::runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589((argument_25).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_27 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_26 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_26).address()); }());
	return scpp::internal::runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5((argument_27).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_29 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_28 = local_ch;
	return scpp::internal::runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a((argument_28).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_29).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
}
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
