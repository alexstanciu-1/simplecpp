#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386.hpp"
#include "specializations/concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3.hpp"
#include "specializations/runtime_runtime_call_4a1676a41be691d50625bd1db635f6848a7fe2eec71a90e09f9888c34a6334ab.hpp"
#include "specializations/concrete_n_result_or_false_string__c5abd9d2949feda472f68672e2b74c06147b4ce16f53378fb9938f68ffeadd7b.hpp"
#include "specializations/runtime_runtime_call_57475ac543e5c550bc9c5f7a8758074141ffe8399e24874abafc461d26d1ad17.hpp"
#include "specializations/runtime_take_cc4378b8d67694c7c3dce43050e802a21a2845059845e914908b135bc7868945.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/concrete_n_result_int__75d7faf352e5ae8b13255b9baf45c9c222f26b9e77bb8df782f66ba60ee55220.hpp"
#include "specializations/runtime_runtime_call_6d8531a705588abd6fa709e0afa3a0f2e6a275ea39ddfd04bab2d80a54383030.hpp"
#include "specializations/runtime_take_af883fa9b963e453d8ed16217dc2136e64e5a31282500993376a15ccf45fd42a.hpp"
#include "specializations/concrete_n_result_string__f542cbfe6a6cb4f895c02c651233c91610a2a3e776c971218b81eb18f341185c.hpp"
#include "specializations/runtime_runtime_call_db492fbeb59add571b53376ecf0bbe00e27bde29fdd47d7ad474420f48c345e3.hpp"
#include "specializations/runtime_take_3a7e6469e613a46059cf2f1fd5b809b6006a0743a3f00b4d748ac05dc7d83ed1.hpp"
#include "specializations/concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082.hpp"
#include "specializations/runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce.hpp"
#include "specializations/runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8.hpp"
#include "specializations/runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836.hpp"
#include "specializations/concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142.hpp"
#include "specializations/runtime_concrete_index_283f55ccb4bdd4b304dc73342536980015ec10a36e7cca81fc5aad234cf404bd.hpp"
#include "specializations/concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21.hpp"
#include "specializations/runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3.hpp"
#include "specializations/runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b.hpp"
#include "specializations/runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce.hpp"
#include "specializations/concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90.hpp"
#include "specializations/runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67.hpp"
#include "specializations/runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669.hpp"
#include "specializations/runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3.hpp"
#include "specializations/runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589.hpp"
#include "specializations/runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5.hpp"
#include "specializations/runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a.hpp"
#include "specializations/runtime_runtime_call_f3f763b1ca4667774c44e4ba8fe33b05ba632a423180c7c7a978c123b99c686a.hpp"
#include "specializations/runtime_runtime_call_8ee86ee679980e77f8563789da58f10ab0dc79ed6470a9350736b78b6bd3ce05.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	auto local_root = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("strict_curl_test_root", 21);
	auto local_path = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto operand_0 = local_root; auto operand_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("/payload.bin", 12); return scpp::internal::runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48((operand_0).address(), (operand_1).address()); }());
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_payload = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 local_bytes = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL);
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_real = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0);
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_err;
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac local_ok = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 local_ch;
	scpp::internal::concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3 local_resp;
	([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_2 = local_root;
	return scpp::internal::runtime_runtime_call_4a1676a41be691d50625bd1db635f6848a7fe2eec71a90e09f9888c34a6334ab((argument_2).address());
}());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_4 = ([&]() -> scpp::internal::concrete_n_result_or_false_string__c5abd9d2949feda472f68672e2b74c06147b4ce16f53378fb9938f68ffeadd7b {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_3 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("4100420A", 8);
	return scpp::internal::runtime_runtime_call_57475ac543e5c550bc9c5f7a8758074141ffe8399e24874abafc461d26d1ad17((argument_3).address());
}()); return scpp::internal::runtime_take_cc4378b8d67694c7c3dce43050e802a21a2845059845e914908b135bc7868945(&(local_payload), (take_source_4).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("HEX_FAIL\x0A" "", 9))).address());
}
else if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_7 = ([&]() -> scpp::internal::concrete_n_result_int__75d7faf352e5ae8b13255b9baf45c9c222f26b9e77bb8df782f66ba60ee55220 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_5 = local_path;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_6 = local_payload;
	return scpp::internal::runtime_runtime_call_6d8531a705588abd6fa709e0afa3a0f2e6a275ea39ddfd04bab2d80a54383030((argument_5).address(), (argument_6).address());
}()); return scpp::internal::runtime_take_af883fa9b963e453d8ed16217dc2136e64e5a31282500993376a15ccf45fd42a(&(local_bytes), (local_err).address(), (take_source_7).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("WRITE_FAIL\x0A" "", 11))).address());
}
else if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_9 = ([&]() -> scpp::internal::concrete_n_result_string__f542cbfe6a6cb4f895c02c651233c91610a2a3e776c971218b81eb18f341185c {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_8 = local_path;
	return scpp::internal::runtime_runtime_call_db492fbeb59add571b53376ecf0bbe00e27bde29fdd47d7ad474420f48c345e3((argument_8).address());
}()); return scpp::internal::runtime_take_3a7e6469e613a46059cf2f1fd5b809b6006a0743a3f00b4d748ac05dc7d83ed1(&(local_real), (local_err).address(), (take_source_9).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("REAL_FAIL\x0A" "", 10))).address());
}
else if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_13 = ([&]() -> scpp::internal::concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_12 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto operand_10 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("file://", 7); auto operand_11 = local_real; return scpp::internal::runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48((operand_10).address(), (operand_11).address()); }());
	return scpp::internal::runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce((argument_12).address());
}()); return scpp::internal::runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(&(local_ch), (local_err).address(), (take_source_13).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("INIT_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 local_headers = scpp::internal::runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836();
	{ auto& write_receiver_14 = local_headers; scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 write_value_14 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("X-Test: curl-surface", 20); scpp::index_append(write_receiver_14, write_value_14); }
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_18 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_15 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_16 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(7LL);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_17 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(5LL);
	return scpp::internal::runtime_runtime_call_18eded2c2ea488f0a9423abf07b2e39d2fe366fddcc4fa3b879f755c811f27d3((argument_15).address(), (argument_16).address(), (argument_17).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_18).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_22 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_19 = local_ch;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_20 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL);
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 argument_21 = local_headers;
	return scpp::internal::runtime_runtime_call_217fd1effbb08651358138298078b8fa1564e2f3cdeb3467464fcf0586ad50ce((argument_19).address(), (argument_20).address(), (argument_21).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_22).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_24 = ([&]() -> scpp::internal::concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_23 = local_ch;
	return scpp::internal::runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67((argument_23).address());
}()); return scpp::internal::runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669(&(local_resp), (local_err).address(), (take_source_24).address()); }())).native_value())).native_value()) {
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("EXEC_FAIL\x0A" "", 10))).address());
}
else {
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto provider_owner_25 = local_resp; return scpp::internal::runtime_property_read_1f69eff80b42537447871d1952fc09e428155c7a78a4c2fbe0ac7d5d73e99e19((provider_owner_25).address()); }()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_27 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_26 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_26).address()); }());
	return scpp::internal::runtime_runtime_call_1a6eb384625c8b3e353d6753667de897b21d9f2b82ce38418effc62397ec3589((argument_27).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>(([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_29 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_28 = local_resp; return scpp::internal::runtime_property_read_e0c38e35f723f4dc2b6b1b2865b192cbaa39b92f026813ad6bffa5586d340ad3((provider_owner_28).address()); }());
	return scpp::internal::runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5((argument_29).address());
}()))).address());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("\x0A" "", 1))).address());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_31 = ([&]() -> scpp::internal::concrete_n_result_bool__32524e1de422745a1caace41b042e6ef1f5fbaba951e1af8096a670edfe4ca21 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_30 = local_ch;
	return scpp::internal::runtime_runtime_call_d019c3b5720787221f903bea6d435c55d543cf79bbd7e578e5551a48a8b6d83a((argument_30).address());
}()); return scpp::internal::runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(&(local_ok), (local_err).address(), (take_source_31).address()); }())).native_value()) { return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("T\x0A" "", 2); } return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("F\x0A" "", 2); }()))).address());
}
	([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_32 = local_path;
	return scpp::internal::runtime_runtime_call_f3f763b1ca4667774c44e4ba8fe33b05ba632a423180c7c7a978c123b99c686a((argument_32).address());
}());
	([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_33 = local_root;
	return scpp::internal::runtime_runtime_call_8ee86ee679980e77f8563789da58f10ab0dc79ed6470a9350736b78b6bd3ce05((argument_33).address());
}());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
