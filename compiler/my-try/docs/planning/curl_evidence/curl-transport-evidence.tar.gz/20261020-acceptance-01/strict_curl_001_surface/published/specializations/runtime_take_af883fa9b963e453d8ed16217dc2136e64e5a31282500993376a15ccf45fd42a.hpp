#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_af883fa9b963e453d8ed16217dc2136e64e5a31282500993376a15ccf45fd42a(void* p0, void* p1, const void* p2); }
