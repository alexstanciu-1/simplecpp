#pragma once
namespace scpp::internal { struct concrete_n_result_int__75d7faf352e5ae8b13255b9baf45c9c222f26b9e77bb8df782f66ba60ee55220; }
