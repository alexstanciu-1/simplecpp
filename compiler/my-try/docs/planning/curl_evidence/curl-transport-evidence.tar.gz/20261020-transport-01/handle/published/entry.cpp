#include "specializations/concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/runtime_observation_2b0d150a6cb1806e00e9a3a15acf335fa0a97cd64fae70b2eae60ca932e5e560.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8.hpp"
#include "specializations/concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 local_h;
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_e;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_0 = scpp::internal::runtime_observation_2b0d150a6cb1806e00e9a3a15acf335fa0a97cd64fae70b2eae60ca932e5e560(); return scpp::internal::runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(&(local_h), (local_e).address(), (take_source_0).address()); }())).native_value())).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)).native_value());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("handle\x0A" "", 7))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
