#pragma once
namespace scpp::internal { struct concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b; }
