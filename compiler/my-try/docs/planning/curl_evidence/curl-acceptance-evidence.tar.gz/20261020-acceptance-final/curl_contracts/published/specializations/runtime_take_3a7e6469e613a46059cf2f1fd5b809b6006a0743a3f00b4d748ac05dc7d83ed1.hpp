#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_3a7e6469e613a46059cf2f1fd5b809b6006a0743a3f00b4d748ac05dc7d83ed1(void* p0, void* p1, const void* p2); }
