#pragma once
namespace scpp::internal { struct concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386; }
