#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_9055313aedbaa617b0d4ace36f7767e8dafbfc7f55c34c0cbe5c9a00b1979e90(void* p0, void* p1, const void* p2); }
