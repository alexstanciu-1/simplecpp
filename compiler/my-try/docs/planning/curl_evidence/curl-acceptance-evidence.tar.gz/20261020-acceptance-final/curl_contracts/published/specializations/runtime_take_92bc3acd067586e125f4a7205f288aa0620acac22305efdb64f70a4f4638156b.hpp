#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_92bc3acd067586e125f4a7205f288aa0620acac22305efdb64f70a4f4638156b(void* p0, void* p1, const void* p2); }
