#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669(void* p0, void* p1, const void* p2); }
