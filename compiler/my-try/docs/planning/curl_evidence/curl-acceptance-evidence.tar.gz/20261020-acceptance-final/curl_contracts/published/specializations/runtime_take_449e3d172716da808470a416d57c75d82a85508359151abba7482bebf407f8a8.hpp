#pragma once
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
namespace scpp::internal { scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(void* p0, void* p1, const void* p2); }
