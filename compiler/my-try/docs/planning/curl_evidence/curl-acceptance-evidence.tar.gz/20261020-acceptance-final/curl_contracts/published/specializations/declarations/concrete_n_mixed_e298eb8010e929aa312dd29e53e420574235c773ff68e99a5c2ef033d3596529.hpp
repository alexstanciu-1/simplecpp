#pragma once
namespace scpp::internal { struct concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529; }
