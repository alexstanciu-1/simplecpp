#include "specializations/runtime_initialize_buffer_c658494c4c215d1d0b5aaafc9262c60a9a8c6fb8c1b1e12fa8c97775597e75b0.hpp"
#include "specializations/concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_ce0860e8457444d9217356c81dca0798d6c69dd177bf80744ac069ad5b5c2d20.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7.hpp"
#include "specializations/runtime_observation_31a13ec124bc52b96b984f942304f2e67a1b6126cc2b6780a2617e51481b18ad.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_binary_0ae0ad3101200cca097ef5a546ed9ce5568e5a6a7c74fd8eacb1e7ef34c17a35.hpp"
#include "specializations/runtime_concrete_index_884d8544c7858212f5b6f37d022bfcddcaca4b6f06c9e0ea3a67c49eb05459eb.hpp"
#include "specializations/runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 local_headers = ([&]() -> scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142 {
scpp::internal::runtime_initialize_buffer_c658494c4c215d1d0b5aaafc9262c60a9a8c6fb8c1b1e12fa8c97775597e75b0 initializer_0(2);
{
scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 initializer_value_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("a\x00" "b", 3);
initializer_0.append(&(initializer_value_1));
}
{
scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 initializer_value_2 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("tail", 4);
initializer_0.append(&(initializer_value_2));
}
return initializer_0.finish();
}());
	auto local_text = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	const scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142& argument_3 = local_headers;
	return scpp::internal::runtime_runtime_call_ce0860e8457444d9217356c81dca0798d6c69dd177bf80744ac069ad5b5c2d20((argument_3).address());
}());
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_4 = local_text; auto operand_5 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("a\x00" "b|tail|", 9); return scpp::internal::runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7((operand_4).address(), (operand_5).address()); }())) || static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_6 = scpp::internal::runtime_observation_31a13ec124bc52b96b984f942304f2e67a1b6126cc2b6780a2617e51481b18ad((static_cast<const scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142&>(local_headers)).address()); auto operand_7 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); return scpp::internal::runtime_binary_0ae0ad3101200cca097ef5a546ed9ce5568e5a6a7c74fd8eacb1e7ef34c17a35((operand_6).address(), (operand_7).address()); }())))) || static_cast<bool>(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_9 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { const auto& index_receiver_8 = local_headers; scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 index_key_8 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); return scpp::checked_index_read(index_receiver_8, index_key_8); }()); auto operand_10 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("a\x00" "b", 3); return scpp::internal::runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7((operand_9).address(), (operand_10).address()); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)).native_value());
}
	local_headers = scpp::internal::runtime_initialize_empty_65c90fc1f1235883964567a8613aa1c03458bbe0851569c51104f6846dc49836();
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_12 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	const scpp::internal::concrete_n_vector_string__27f3c3e8a5ca274709c96b128cfd9697c92c144385ac86f43efdc76009048142& argument_11 = local_headers;
	return scpp::internal::runtime_runtime_call_ce0860e8457444d9217356c81dca0798d6c69dd177bf80744ac069ad5b5c2d20((argument_11).address());
}()); auto operand_13 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0); return scpp::internal::runtime_binary_e1cae3dfaf8a356573a2e7fd62291a6880716cfad95db2e261f461464ddaf2c7((operand_12).address(), (operand_13).address()); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL)).native_value());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("read-only native header vectors\x0A" "", 32))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
