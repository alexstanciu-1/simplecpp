#pragma once
#include "scpp/vector_t.hpp"
#include "scpp/string_t.hpp"
namespace curl_probe {
inline scpp::string_t probe_headers(const scpp::vector_t<scpp::string_t>& headers) {
    std::string result; for (std::size_t i=0;i<headers.size();++i) { result += headers.at(i).native_value(); result += "|"; }
    return scpp::string_t(result);
}
inline scpp::string_t probe_mutable_headers(scpp::vector_t<scpp::string_t>& headers) {
    headers.clear(); return scpp::string_t("must not execute");
}
}
