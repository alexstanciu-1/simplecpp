#include "specializations/concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386.hpp"
#include "specializations/concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3.hpp"
#include "specializations/concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529.hpp"
#include "specializations/concrete_n_result_string__f542cbfe6a6cb4f895c02c651233c91610a2a3e776c971218b81eb18f341185c.hpp"
#include "specializations/runtime_runtime_call_db492fbeb59add571b53376ecf0bbe00e27bde29fdd47d7ad474420f48c345e3.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_take_3a7e6469e613a46059cf2f1fd5b809b6006a0743a3f00b4d748ac05dc7d83ed1.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082.hpp"
#include "specializations/runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48.hpp"
#include "specializations/runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce.hpp"
#include "specializations/runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8.hpp"
#include "specializations/concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90.hpp"
#include "specializations/runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67.hpp"
#include "specializations/runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669.hpp"
#include "specializations/concrete_n_result_mixed__0debbb0cf6dedba492f40273ba7c594156e2a851ae6e7540fe057d74f3b07b8d.hpp"
#include "specializations/runtime_runtime_call_cd9e1c65f66d9921dd6df25c8d594e93f6d02538004809cf66cc9ef7fb9cc954.hpp"
#include "specializations/runtime_take_9055313aedbaa617b0d4ace36f7767e8dafbfc7f55c34c0cbe5c9a00b1979e90.hpp"
#include "specializations/runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806.hpp"
#include "specializations/runtime_concrete_index_564266376348886871c2a039a45448fb70335e9a5377a1062173481ba789aae9.hpp"
#include "specializations/runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613.hpp"
#include "specializations/runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5.hpp"
#include "specializations/runtime_binary_c9c630f4e6a0b80102f7254be4a48bdb3f4a59bb9904862b23424db425cbee34.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 local_h;
	scpp::internal::concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3 local_r;
	scpp::internal::concrete_n_error_20ce0bcb3b6e7324a99bb6001bbf815f5121bf25cde1d76f233cce9764b62b9b local_e;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_path = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("", 0);
	scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 local_key;
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_1 = ([&]() -> scpp::internal::concrete_n_result_string__f542cbfe6a6cb4f895c02c651233c91610a2a3e776c971218b81eb18f341185c {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_0 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("payload.txt", 11);
	return scpp::internal::runtime_runtime_call_db492fbeb59add571b53376ecf0bbe00e27bde29fdd47d7ad474420f48c345e3((argument_0).address());
}()); return scpp::internal::runtime_take_3a7e6469e613a46059cf2f1fd5b809b6006a0743a3f00b4d748ac05dc7d83ed1(&(local_path), (local_e).address(), (take_source_1).address()); }())).native_value())).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL)).native_value());
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_5 = ([&]() -> scpp::internal::concrete_n_result_curl_handle__ea64726ee663b37d63331ea6028eb61d2fb07f94e32e3c73f212c2bfa6f8d082 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_4 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto operand_2 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("file://", 7); auto operand_3 = local_path; return scpp::internal::runtime_binary_b504b469e9c28a36d02ad90b3ce2cc602653a0abcae20c46c88e80cffceb8c48((operand_2).address(), (operand_3).address()); }());
	return scpp::internal::runtime_runtime_call_5810507feb21a854d65b878d0eb66b40751622b5d6cd4d6a1af617e418522fce((argument_4).address());
}()); return scpp::internal::runtime_take_449e3d172716da808470a416d57c75d82a85508359151abba7482bebf407f8a8(&(local_h), (local_e).address(), (take_source_5).address()); }())).native_value())) || static_cast<bool>(scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_7 = ([&]() -> scpp::internal::concrete_n_result_curl_response__76a945bf87f265ac3f2b3b3709644aad05b85b50a34f330bc3fb83f3ddaf6e90 {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_6 = local_h;
	return scpp::internal::runtime_runtime_call_fd69a30577d214261cff5361b47d45f2f4ab108073e7f50a3e7a5f2474177b67((argument_6).address());
}()); return scpp::internal::runtime_take_9aeac7657f0aed961fbe029e32a052cb48b40894c9f5dcd9350a91bf30eb5669(&(local_r), (local_e).address(), (take_source_7).address()); }())).native_value())))).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL)).native_value());
}
if ((scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac(!(([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto take_source_10 = ([&]() -> scpp::internal::concrete_n_result_mixed__0debbb0cf6dedba492f40273ba7c594156e2a851ae6e7540fe057d74f3b07b8d {
	scpp::internal::concrete_n_curl_handle_61ff90a1750ae2476663c217caf27a9b6a88863dd29668a0a87141010729c386 argument_8 = local_h;
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_9 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(101LL);
	return scpp::internal::runtime_runtime_call_cd9e1c65f66d9921dd6df25c8d594e93f6d02538004809cf66cc9ef7fb9cc954((argument_8).address(), (argument_9).address());
}()); return scpp::internal::runtime_take_9055313aedbaa617b0d4ace36f7767e8dafbfc7f55c34c0cbe5c9a00b1979e90(&(local_key), (local_e).address(), (take_source_10).address()); }())).native_value())).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(4LL)).native_value());
}
	auto local_args = scpp::internal::runtime_observation_fa673829078fb30e28d26ac49ae208fb6f8f6b0cd534913a5fa47803f3f04806();
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_text = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { const auto& runtime_input_12 = ([&]() -> scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 { const auto& index_receiver_11 = local_args; scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 index_key_11 = local_key; return scpp::null_index_read(index_receiver_11, index_key_11); }()); return scpp::internal::runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613((runtime_input_12).address()); }());
if ((([&]() -> scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac { auto operand_14 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_13 = local_text;
	return scpp::internal::runtime_runtime_call_ced22ad6a5b9e94c84510ea5e3255273ce7fa730d4090692a57a44020f984ea5((argument_13).address());
}()); auto operand_15 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); return scpp::internal::runtime_binary_c9c630f4e6a0b80102f7254be4a48bdb3f4a59bb9904862b23424db425cbee34((operand_14).address(), (operand_15).address()); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(5LL)).native_value());
}
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("mixed indexing\x0A" "", 15))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
