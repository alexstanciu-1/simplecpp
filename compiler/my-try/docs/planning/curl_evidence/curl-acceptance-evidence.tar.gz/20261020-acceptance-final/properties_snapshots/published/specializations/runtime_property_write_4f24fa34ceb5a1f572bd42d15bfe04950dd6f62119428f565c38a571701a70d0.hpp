#pragma once
namespace scpp::internal { void runtime_property_write_4f24fa34ceb5a1f572bd42d15bfe04950dd6f62119428f565c38a571701a70d0(const void* p0, const void* p1); }
