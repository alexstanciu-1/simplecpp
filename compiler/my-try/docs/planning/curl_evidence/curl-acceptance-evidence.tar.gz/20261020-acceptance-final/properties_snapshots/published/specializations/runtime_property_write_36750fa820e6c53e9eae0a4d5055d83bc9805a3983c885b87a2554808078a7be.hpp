#pragma once
namespace scpp::internal { void runtime_property_write_36750fa820e6c53e9eae0a4d5055d83bc9805a3983c885b87a2554808078a7be(const void* p0, const void* p1); }
