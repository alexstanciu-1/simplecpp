#pragma once
namespace scpp::internal { void runtime_property_write_b7033aa0a23865d8e398c519d2a001ce9fa7ce65971d02f309238a2ddc7d740a(const void* p0, const void* p1); }
