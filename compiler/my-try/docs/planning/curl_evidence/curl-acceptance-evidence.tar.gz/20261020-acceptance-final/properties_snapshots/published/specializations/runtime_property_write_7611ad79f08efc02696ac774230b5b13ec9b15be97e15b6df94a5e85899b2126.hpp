#pragma once
namespace scpp::internal { void runtime_property_write_7611ad79f08efc02696ac774230b5b13ec9b15be97e15b6df94a5e85899b2126(const void* p0, const void* p1); }
