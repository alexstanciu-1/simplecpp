#pragma once
namespace scpp::internal { void runtime_property_write_96305854184b4f15f7a389765e254130957790b0d8def967382d8bbb264adc51(const void* p0, const void* p1); }
