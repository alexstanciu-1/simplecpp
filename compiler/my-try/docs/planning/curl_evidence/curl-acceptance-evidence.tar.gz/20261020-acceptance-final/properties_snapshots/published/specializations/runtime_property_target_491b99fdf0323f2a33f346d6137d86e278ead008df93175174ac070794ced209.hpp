#pragma once
namespace scpp::internal { void runtime_property_target_491b99fdf0323f2a33f346d6137d86e278ead008df93175174ac070794ced209(const void* p0); }
