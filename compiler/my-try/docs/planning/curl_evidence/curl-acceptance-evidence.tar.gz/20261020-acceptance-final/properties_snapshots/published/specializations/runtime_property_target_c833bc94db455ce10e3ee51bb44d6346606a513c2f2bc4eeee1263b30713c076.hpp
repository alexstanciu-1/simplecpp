#pragma once
namespace scpp::internal { void runtime_property_target_c833bc94db455ce10e3ee51bb44d6346606a513c2f2bc4eeee1263b30713c076(const void* p0); }
