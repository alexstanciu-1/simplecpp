#pragma once
namespace scpp::internal { void runtime_property_write_9b1a4853c5ce1daff210212d598be1cc73deec5c6aae369c23edb9caeaa6cffd(const void* p0, const void* p1); }
