#pragma once
namespace scpp::internal { void runtime_property_target_30cf18e6c0c61aacf4183d92c563eb7728822dc675d34f78def9740e5694e442(const void* p0); }
