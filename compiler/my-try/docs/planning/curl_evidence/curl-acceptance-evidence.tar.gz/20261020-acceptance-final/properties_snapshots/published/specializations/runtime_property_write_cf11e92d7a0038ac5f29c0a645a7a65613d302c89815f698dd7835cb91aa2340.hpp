#pragma once
namespace scpp::internal { void runtime_property_write_cf11e92d7a0038ac5f29c0a645a7a65613d302c89815f698dd7835cb91aa2340(const void* p0, const void* p1); }
