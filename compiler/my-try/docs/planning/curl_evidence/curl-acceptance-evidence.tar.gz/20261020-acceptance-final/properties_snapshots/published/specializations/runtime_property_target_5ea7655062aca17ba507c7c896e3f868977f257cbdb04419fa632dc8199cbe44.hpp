#pragma once
namespace scpp::internal { void runtime_property_target_5ea7655062aca17ba507c7c896e3f868977f257cbdb04419fa632dc8199cbe44(const void* p0); }
