#pragma once
namespace scpp::internal { void runtime_property_target_8eac7fedb91fed751d910773666e8b74da9073c09f9d292c1c8d6b522334369c(const void* p0); }
