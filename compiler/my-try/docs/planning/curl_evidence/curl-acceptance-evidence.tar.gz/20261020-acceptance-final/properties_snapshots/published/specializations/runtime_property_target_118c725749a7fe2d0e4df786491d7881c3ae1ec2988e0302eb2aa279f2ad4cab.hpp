#pragma once
namespace scpp::internal { void runtime_property_target_118c725749a7fe2d0e4df786491d7881c3ae1ec2988e0302eb2aa279f2ad4cab(const void* p0); }
