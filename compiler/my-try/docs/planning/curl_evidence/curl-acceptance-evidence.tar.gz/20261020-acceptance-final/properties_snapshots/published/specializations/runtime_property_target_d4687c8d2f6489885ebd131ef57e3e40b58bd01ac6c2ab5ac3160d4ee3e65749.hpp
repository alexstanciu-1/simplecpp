#pragma once
namespace scpp::internal { void runtime_property_target_d4687c8d2f6489885ebd131ef57e3e40b58bd01ac6c2ab5ac3160d4ee3e65749(const void* p0); }
