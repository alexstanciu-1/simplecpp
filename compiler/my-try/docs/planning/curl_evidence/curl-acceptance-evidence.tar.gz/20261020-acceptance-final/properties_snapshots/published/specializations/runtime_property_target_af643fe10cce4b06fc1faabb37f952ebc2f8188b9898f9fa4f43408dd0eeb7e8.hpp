#pragma once
namespace scpp::internal { void runtime_property_target_af643fe10cce4b06fc1faabb37f952ebc2f8188b9898f9fa4f43408dd0eeb7e8(const void* p0); }
