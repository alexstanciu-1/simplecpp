#pragma once
namespace scpp::internal { void runtime_property_write_837ea10362cc9c1f6814970272a71f0ae4c8cfb0a8ec2ce81cc96beced2ea785(const void* p0, const void* p1); }
