#include "callables/n7265636569766572.hpp"
#include "specializations/concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529.hpp"
#include "specializations/declarations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_binary_77b9e7b7b47099ba81dc136c4585fa01fb12094afe0afbde5f3aca94603e65c7.hpp"
#include "specializations/runtime_binary_bd2bf20d9bab1d2b41cecbe8fb098b597a65ab0b55b18381256b025c093b85bc.hpp"
#include "callables/n6b6579.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 function_receiver(scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 local_value, scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& local_trace)
{
	local_trace = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_2 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_0 = local_trace; auto operand_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(10LL); return scpp::internal::runtime_binary_77b9e7b7b47099ba81dc136c4585fa01fb12094afe0afbde5f3aca94603e65c7((operand_0).address(), (operand_1).address()); }()); auto operand_3 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL); return scpp::internal::runtime_binary_bd2bf20d9bab1d2b41cecbe8fb098b597a65ab0b55b18381256b025c093b85bc((operand_2).address(), (operand_3).address()); }());
	return local_value;
}

scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 function_key(scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& local_trace)
{
	local_trace = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_2 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_0 = local_trace; auto operand_1 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(10LL); return scpp::internal::runtime_binary_77b9e7b7b47099ba81dc136c4585fa01fb12094afe0afbde5f3aca94603e65c7((operand_0).address(), (operand_1).address()); }()); auto operand_3 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); return scpp::internal::runtime_binary_bd2bf20d9bab1d2b41cecbe8fb098b597a65ab0b55b18381256b025c093b85bc((operand_2).address(), (operand_3).address()); }());
	return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("nested", 6);
}

