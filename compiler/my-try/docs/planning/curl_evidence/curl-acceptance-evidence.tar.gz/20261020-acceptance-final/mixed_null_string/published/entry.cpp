#include "specializations/concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_mixed_e298eb8010e929aa312dd29e53e420574235c773ff68e99a5c2ef033d3596529 local_m;
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 local_n = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { const auto& runtime_input_0 = local_m; return scpp::internal::runtime_conversion_4ea1294b95a31ce3bc990d7f8ebb016e4e324fad6378c99363e98863980ed613((runtime_input_0).address()); }());
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>(scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("UNREACHABLE", 11))).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
