#pragma once
namespace scpp::internal { void runtime_property_target_b83f819ef41f76c89689530008e31ed5c2a2bda70c22471431e287dbaa00788c(const void* p0); }
