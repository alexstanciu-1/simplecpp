#include "specializations/concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "callables/n726873.hpp"
#include "specializations/runtime_property_target_b83f819ef41f76c89689530008e31ed5c2a2bda70c22471431e287dbaa00788c.hpp"
#include "specializations/runtime_property_write_933c9d16ef9b1eeb39d407beedb5ed6dacc7365f0d8f4b40112ed1bacedb5480.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_curl_response_10d0be758a4002457ec2d9fed21e24f1df433267a94181d2717b83f83ba168f3 local_r;
	([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 { auto provider_owner_0 = local_r; scpp::internal::runtime_property_target_b83f819ef41f76c89689530008e31ed5c2a2bda70c22471431e287dbaa00788c((provider_owner_0).address()); auto provider_value_1 = ([&]() -> scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 {
	return function_rhs();
}()); scpp::internal::runtime_property_write_933c9d16ef9b1eeb39d407beedb5ed6dacc7365f0d8f4b40112ed1bacedb5480((provider_owner_0).address(), (provider_value_1).address()); return provider_value_1; }());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
