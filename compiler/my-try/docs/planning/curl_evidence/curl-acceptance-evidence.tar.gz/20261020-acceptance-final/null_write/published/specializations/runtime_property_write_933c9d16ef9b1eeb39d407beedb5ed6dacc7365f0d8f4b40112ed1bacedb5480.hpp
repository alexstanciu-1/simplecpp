#pragma once
namespace scpp::internal { void runtime_property_write_933c9d16ef9b1eeb39d407beedb5ed6dacc7365f0d8f4b40112ed1bacedb5480(const void* p0, const void* p1); }
