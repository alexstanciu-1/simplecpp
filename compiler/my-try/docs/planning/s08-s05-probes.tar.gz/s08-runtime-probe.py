from pathlib import Path
import sys,json
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True)
sys.path.insert(0,str(root/'compiler/my-try/tools'))
from test_runner import CommandRunner,Task,run_tasks
original=(root/'tests/php/closures/strict_level_02/closures_004_use_reference_capture.phs').read_text()
cases={'s05_original':original,'s05_concrete':original.replace('$f function<int()> =','$f ='),'s05_owned':original.replace('use (&$a)','use ($a)'),'s05_nested_borrow':'$a=1;$inner=function() use (&$a):int{return $a;};$f function<int()> = function() use ($inner):int{return $inner();};echo $f();'}
with CommandRunner(out/'logs',root,jobs=12) as runner:
 def check(name,source):
  folder=out/name;(folder/'source').mkdir(parents=True);(folder/'source/main.phs').write_text(source)
  try:
   runner.run(name+'-publish',['php',root/'compiler/my-try/tests/curl_publish.php',folder],cli_reason='Default prelowering initial closure boundary probe')
   build=json.loads(runner.run(name+'-build',['php',root/'compiler/my-try/tests/fixtures/native_cache_driver.php',folder/'published',folder/'cache',root/'runtime/include','/usr/bin/clang++','--no-pch'],timeout=300,cli_reason='Default prelowering application probe'))
   actual=runner.run(name+'-run',[build['executable']]);result={'status':'executed','stdout':actual.decode()}
  except Exception as e:result={'status':'rejected','detail':str(e)}
  (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 def runtime():
  source=out/'runtime.cpp';source.write_text('''#include "scpp/support/dbg.hpp"
int main(){using namespace scpp;
php::dbg_at("probe.phs",7,string_t("catalog_dbg"),int_t<>(42),int_t<>(DBG_VALUE.native_value()|DBG_DEPTH_0.native_value()));
php::dbg_at("probe.phs",8,bool_t(false));
php::dbg_at("probe.phs",9,float_t(1.5));
php::dbg_at("probe.phs",10,string_t("bytes"));
php::dbg_at("probe.phs",11,int_t<>(1),int_t<>(DBG_DEPTH_0.native_value()|DBG_DEPTH_1.native_value()));
}
''')
  runner.run('runtime-build',['clang++','-std=c++23','-I',root/'runtime/include',source,root/'runtime/include/core/runtime.cpp','-pthread','-o',out/'runtime'],timeout=180)
  runner.run('runtime-run',[out/'runtime'])
 run_tasks([Task('runtime',runtime)])
