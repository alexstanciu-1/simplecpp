#include "scpp/support/dbg.hpp"
int main(){using namespace scpp;
php::dbg_at("probe.phs",7,string_t("catalog_dbg"),int_t<>(42),int_t<>(DBG_VALUE.native_value()|DBG_DEPTH_0.native_value()));
php::dbg_at("probe.phs",8,bool_t(false));
php::dbg_at("probe.phs",9,float_t(1.5));
php::dbg_at("probe.phs",10,string_t("bytes"));
php::dbg_at("probe.phs",11,int_t<>(1),int_t<>(DBG_DEPTH_0.native_value()|DBG_DEPTH_1.native_value()));
}
