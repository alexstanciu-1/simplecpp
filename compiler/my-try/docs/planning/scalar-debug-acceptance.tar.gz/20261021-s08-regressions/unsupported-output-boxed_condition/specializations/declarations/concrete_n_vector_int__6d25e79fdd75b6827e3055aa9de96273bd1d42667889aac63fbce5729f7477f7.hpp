#pragma once
namespace scpp::internal { struct concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7; }
