#include "specializations/runtime_initialize_empty_8f7927b9e4e7e399095a1b7fd6e6f7c9762b00b3ff277d4d706a7b28318bbf5e.hpp"
#include "specializations/concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::concrete_n_vector_int__6d25e79fdd75b6827e3055aa9de96273bd1d42667889aac63fbce5729f7477f7 local_items = scpp::internal::runtime_initialize_empty_8f7927b9e4e7e399095a1b7fd6e6f7c9762b00b3ff277d4d706a7b28318bbf5e();
	auto local_n = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL);
	auto local_ok = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(true);
if ((local_ok).native_value()) {
if (((local_n).native_value() != 0)) {
	return static_cast<int>((([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { const auto match_subject_0 = (local_n).native_value(); if ((match_subject_0 == 1LL)) { return static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL); } return static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL); }())).native_value());
}
}
	return static_cast<int>((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(1LL)).native_value());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
