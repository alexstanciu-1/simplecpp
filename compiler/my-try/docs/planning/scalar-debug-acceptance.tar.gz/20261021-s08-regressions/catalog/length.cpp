#include "scpp/int_t.hpp"
#include "scpp/support/string_representation.hpp"
#include "modules/strings/strings.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_unicode = ([&]() -> scpp::int_t<> {
	scpp::string_t argument_0 = scpp::string_t("\xC3" "\xA9" "\xE4" "\xB8" "\xAD" "\xF0" "\x9F" "\x98" "\x80" "");
	return scpp::str::byte_length(argument_0);
}());
	auto local_empty = ([&]() -> scpp::int_t<> {
	scpp::string_t argument_1 = scpp::string_t("");
	return scpp::str::byte_length(argument_1);
}());
	auto local_ascii = ([&]() -> scpp::int_t<> {
	scpp::string_t argument_2 = scpp::string_t("abc");
	return scpp::str::byte_length(argument_2);
}());
if ((([&]() -> scpp::bool_t { auto operand_3 = local_unicode; auto operand_4 = static_cast<scpp::int_t<>>(9LL); return scpp::php::not_identical(operand_3, operand_4); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
if ((([&]() -> scpp::bool_t { auto operand_5 = local_empty; auto operand_6 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_5, operand_6); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(2LL)).native_value());
}
if ((([&]() -> scpp::bool_t { auto operand_7 = local_ascii; auto operand_8 = static_cast<scpp::int_t<>>(3LL); return scpp::php::not_identical(operand_7, operand_8); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(3LL)).native_value());
}
if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_9 = static_cast<scpp::int_t<>>((-9223372036854775807LL - 1LL)); auto operand_10 = static_cast<scpp::int_t<>>((-9223372036854775807LL - 1LL)); return scpp::php::not_identical(operand_9, operand_10); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_11 = static_cast<scpp::int_t<>>(9223372036854775807LL); auto operand_12 = static_cast<scpp::int_t<>>(9223372036854775807LL); return scpp::php::not_identical(operand_11, operand_12); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(4LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
