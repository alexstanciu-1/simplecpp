// SCPP-ARTIFACT {"id":"callable:strlen","kind":"header","path":"callables\/n7374726c656e.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_strlen(scpp::int_t<> local_value);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n7374726c656e.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_strlen(scpp::int_t<> local_value)
{
	return local_value;
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "callables/n7374726c656e.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return static_cast<int>((([&]() -> scpp::int_t<> {
	scpp::int_t<> argument_0 = static_cast<scpp::int_t<>>(0LL);
	return function_strlen(argument_0);
}())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
