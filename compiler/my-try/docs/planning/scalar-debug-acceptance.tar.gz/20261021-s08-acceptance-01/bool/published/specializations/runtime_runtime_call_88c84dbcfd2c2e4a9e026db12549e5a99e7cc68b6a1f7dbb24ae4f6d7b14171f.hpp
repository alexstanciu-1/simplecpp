#pragma once
namespace scpp::internal { void runtime_runtime_call_88c84dbcfd2c2e4a9e026db12549e5a99e7cc68b6a1f7dbb24ae4f6d7b14171f(const void* p0, const void* p1, const void* p2); }
