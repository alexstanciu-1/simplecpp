#include "specializations/concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac.hpp"
#include "specializations/runtime_runtime_call_c7dca3b1768b6af6a85faf0955d1a9ce13911e024e909237ff4e4b58242b3a8a.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_113d59ef2e7399850736364ac99c7dfb97af2514e5d61a6c7c879dbaa5ec1959.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "specializations/runtime_runtime_call_88c84dbcfd2c2e4a9e026db12549e5a99e7cc68b6a1f7dbb24ae4f6d7b14171f.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	([&]() -> void {
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac argument_0 = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	return scpp::internal::runtime_runtime_call_c7dca3b1768b6af6a85faf0955d1a9ce13911e024e909237ff4e4b58242b3a8a((argument_0).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("label", 5);
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac argument_2 = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	return scpp::internal::runtime_runtime_call_113d59ef2e7399850736364ac99c7dfb97af2514e5d61a6c7c879dbaa5ec1959((argument_1).address(), (argument_2).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_3 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("flags", 5);
	scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac argument_4 = static_cast<scpp::internal::concrete_n_bool_186b6fb4c7e65e0a2d027fe4a8eb785f77810b58584e99fc5cb73047a04b3bac>(false);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_7 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_5 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); auto operand_6 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(65536LL); return scpp::internal::runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5((operand_5).address(), (operand_6).address()); }());
	return scpp::internal::runtime_runtime_call_88c84dbcfd2c2e4a9e026db12549e5a99e7cc68b6a1f7dbb24ae4f6d7b14171f((argument_3).address(), (argument_4).address(), (argument_7).address());
}());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
