#pragma once
namespace scpp::internal { void runtime_runtime_call_113d59ef2e7399850736364ac99c7dfb97af2514e5d61a6c7c879dbaa5ec1959(const void* p0, const void* p1); }
