#pragma once
namespace scpp::internal { void runtime_runtime_call_c7dca3b1768b6af6a85faf0955d1a9ce13911e024e909237ff4e4b58242b3a8a(const void* p0); }
