#pragma once
namespace scpp::internal { void runtime_runtime_call_6f4667c5619d5d0e7411d125e8c990e0aa1c2fedad93274a47bd8b03e902095b(const void* p0, const void* p1, const void* p2); }
