#pragma once
namespace scpp::internal { void runtime_runtime_call_cff4172460064d757bddfe56cdfaf0a87c7bc0144a8e59059c93bc2e7b84a70f(const void* p0); }
