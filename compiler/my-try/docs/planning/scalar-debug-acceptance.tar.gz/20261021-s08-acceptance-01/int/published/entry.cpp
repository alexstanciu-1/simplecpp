#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_runtime_call_cff4172460064d757bddfe56cdfaf0a87c7bc0144a8e59059c93bc2e7b84a70f.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_805fe39a122e98781d6419347f678c8ec66053c246d9358c6a989d28711bcc29.hpp"
#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "specializations/runtime_runtime_call_6f4667c5619d5d0e7411d125e8c990e0aa1c2fedad93274a47bd8b03e902095b.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	([&]() -> void {
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_0 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(42LL);
	return scpp::internal::runtime_runtime_call_cff4172460064d757bddfe56cdfaf0a87c7bc0144a8e59059c93bc2e7b84a70f((argument_0).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("label", 5);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_2 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(42LL);
	return scpp::internal::runtime_runtime_call_805fe39a122e98781d6419347f678c8ec66053c246d9358c6a989d28711bcc29((argument_1).address(), (argument_2).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_3 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("flags", 5);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_4 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(42LL);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_7 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_5 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); auto operand_6 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(65536LL); return scpp::internal::runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5((operand_5).address(), (operand_6).address()); }());
	return scpp::internal::runtime_runtime_call_6f4667c5619d5d0e7411d125e8c990e0aa1c2fedad93274a47bd8b03e902095b((argument_3).address(), (argument_4).address(), (argument_7).address());
}());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
