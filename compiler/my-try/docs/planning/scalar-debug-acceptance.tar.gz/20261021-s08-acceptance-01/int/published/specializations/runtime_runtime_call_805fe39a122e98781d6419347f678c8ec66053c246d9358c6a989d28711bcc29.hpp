#pragma once
namespace scpp::internal { void runtime_runtime_call_805fe39a122e98781d6419347f678c8ec66053c246d9358c6a989d28711bcc29(const void* p0, const void* p1); }
