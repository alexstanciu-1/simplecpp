#pragma once
namespace scpp::internal { void runtime_runtime_call_95362c18e88e85a0b67c5f9ca0af9fbbe7e2b252b54200fcc6b2648b458d9dc3(const void* p0, const void* p1, const void* p2); }
