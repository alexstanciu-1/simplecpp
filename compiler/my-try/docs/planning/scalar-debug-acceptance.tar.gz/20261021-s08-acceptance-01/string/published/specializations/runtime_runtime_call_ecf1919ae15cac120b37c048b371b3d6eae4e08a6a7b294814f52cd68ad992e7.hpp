#pragma once
namespace scpp::internal { void runtime_runtime_call_ecf1919ae15cac120b37c048b371b3d6eae4e08a6a7b294814f52cd68ad992e7(const void* p0, const void* p1, const void* p2); }
