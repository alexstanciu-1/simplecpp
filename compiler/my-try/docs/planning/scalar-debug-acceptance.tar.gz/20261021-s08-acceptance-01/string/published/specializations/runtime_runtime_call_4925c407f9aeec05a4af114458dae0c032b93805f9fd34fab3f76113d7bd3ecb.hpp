#pragma once
namespace scpp::internal { void runtime_runtime_call_4925c407f9aeec05a4af114458dae0c032b93805f9fd34fab3f76113d7bd3ecb(const void* p0, const void* p1); }
