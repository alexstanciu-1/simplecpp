#pragma once
namespace scpp::internal { void runtime_runtime_call_c665eebfcf85329532e28c3db31e7f0fb7cf9aa316282f8f78a75c383d158254(const void* p0); }
