#pragma once
namespace scpp::internal { void runtime_runtime_call_4b0a134d74ae9ef0afdc7811e6fad709ec78aab7eebf812af0047b612d96933d(const void* p0, const void* p1, const void* p2); }
