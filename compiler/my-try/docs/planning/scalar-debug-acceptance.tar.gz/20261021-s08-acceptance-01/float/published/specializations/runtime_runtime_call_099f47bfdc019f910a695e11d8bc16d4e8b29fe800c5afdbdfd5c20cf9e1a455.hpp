#pragma once
namespace scpp::internal { void runtime_runtime_call_099f47bfdc019f910a695e11d8bc16d4e8b29fe800c5afdbdfd5c20cf9e1a455(const void* p0, const void* p1, const void* p2); }
