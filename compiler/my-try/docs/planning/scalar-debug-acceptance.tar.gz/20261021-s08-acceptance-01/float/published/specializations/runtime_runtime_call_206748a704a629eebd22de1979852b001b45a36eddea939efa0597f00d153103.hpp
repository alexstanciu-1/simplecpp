#pragma once
namespace scpp::internal { void runtime_runtime_call_206748a704a629eebd22de1979852b001b45a36eddea939efa0597f00d153103(const void* p0); }
