#include "specializations/concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0.hpp"
#include "specializations/runtime_runtime_call_206748a704a629eebd22de1979852b001b45a36eddea939efa0597f00d153103.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_2663e0019f3e3d3f1e63e9606440a511a17a3b4e0d27f759f007d8d545eb2077.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "specializations/runtime_runtime_call_099f47bfdc019f910a695e11d8bc16d4e8b29fe800c5afdbdfd5c20cf9e1a455.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	([&]() -> void {
	scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0 argument_0 = static_cast<scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0>(1.5);
	return scpp::internal::runtime_runtime_call_206748a704a629eebd22de1979852b001b45a36eddea939efa0597f00d153103((argument_0).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("label", 5);
	scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0 argument_2 = static_cast<scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0>(1.5);
	return scpp::internal::runtime_runtime_call_2663e0019f3e3d3f1e63e9606440a511a17a3b4e0d27f759f007d8d545eb2077((argument_1).address(), (argument_2).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_3 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("flags", 5);
	scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0 argument_4 = static_cast<scpp::internal::concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0>(1.5);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_7 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_5 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); auto operand_6 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(65536LL); return scpp::internal::runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5((operand_5).address(), (operand_6).address()); }());
	return scpp::internal::runtime_runtime_call_099f47bfdc019f910a695e11d8bc16d4e8b29fe800c5afdbdfd5c20cf9e1a455((argument_3).address(), (argument_4).address(), (argument_7).address());
}());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
