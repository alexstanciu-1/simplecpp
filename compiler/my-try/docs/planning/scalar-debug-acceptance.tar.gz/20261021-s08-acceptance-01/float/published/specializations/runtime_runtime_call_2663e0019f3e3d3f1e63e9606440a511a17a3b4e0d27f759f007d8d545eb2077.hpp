#pragma once
namespace scpp::internal { void runtime_runtime_call_2663e0019f3e3d3f1e63e9606440a511a17a3b4e0d27f759f007d8d545eb2077(const void* p0, const void* p1); }
