#pragma once
namespace scpp::internal { struct concrete_n_float_f88d96704fffd4dd3546fa896d9107932559a4d3462a4139cdd5e0df53e905b0; }
