#pragma once
namespace scpp::internal { void runtime_runtime_call_744c5348b05c2fbd0baac2a1460cd25a52f56c0c8ecd874b964e99b0f6db59a2(const void* p0, const void* p1, const void* p2); }
