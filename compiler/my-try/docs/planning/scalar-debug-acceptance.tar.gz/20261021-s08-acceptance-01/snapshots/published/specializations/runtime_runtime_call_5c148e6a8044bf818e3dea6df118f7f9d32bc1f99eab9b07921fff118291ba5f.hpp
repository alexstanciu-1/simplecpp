#pragma once
namespace scpp::internal { void runtime_runtime_call_5c148e6a8044bf818e3dea6df118f7f9d32bc1f99eab9b07921fff118291ba5f(const void* p0, const void* p1, const void* p2); }
