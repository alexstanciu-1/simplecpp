#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "scpp/int_t.hpp"
using native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 = scpp::int_t<>;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == sizeof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
static_assert(alignof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == alignof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(int64_t value) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(value); }
int64_t concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::native_value() const noexcept { return unwrap(*this).native_value(); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>);
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::~concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "scpp/support/string_representation.hpp"
using native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 = scpp::string_t;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == sizeof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
static_assert(alignof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == alignof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const char* bytes, size_t size) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(scpp::string_representation::construct(bytes, size)); }
const char* concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_data() const noexcept { return scpp::string_representation::data(unwrap(*this)); }
size_t concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_size() const noexcept { return scpp::string_representation::size(unwrap(*this)); }
void concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::append(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { scpp::string_representation::append(unwrap(*this), unwrap(value)); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>);
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::~concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/runtime_binary_77b9e7b7b47099ba81dc136c4585fa01fb12094afe0afbde5f3aca94603e65c7.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 runtime_binary_77b9e7b7b47099ba81dc136c4585fa01fb12094afe0afbde5f3aca94603e65c7(const void* p0, const void* p1) { const void* addresses[] = {p0, p1}; return scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operation_result{}, +[](void* destination, const void* input) { auto addresses = static_cast<const void* const*>(input); const void* p0 = addresses[0]; const void* p1 = addresses[1]; auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); ::new(destination) scpp::int_t<>((a0 * a1)); }, addresses); } }

#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5(const void* p0, const void* p1) { const void* addresses[] = {p0, p1}; return scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operation_result{}, +[](void* destination, const void* input) { auto addresses = static_cast<const void* const*>(input); const void* p0 = addresses[0]; const void* p1 = addresses[1]; auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); ::new(destination) scpp::int_t<>((a0 | a1)); }, addresses); } }

#include "specializations/runtime_binary_bd2bf20d9bab1d2b41cecbe8fb098b597a65ab0b55b18381256b025c093b85bc.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 runtime_binary_bd2bf20d9bab1d2b41cecbe8fb098b597a65ab0b55b18381256b025c093b85bc(const void* p0, const void* p1) { const void* addresses[] = {p0, p1}; return scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operation_result{}, +[](void* destination, const void* input) { auto addresses = static_cast<const void* const*>(input); const void* p0 = addresses[0]; const void* p1 = addresses[1]; auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); ::new(destination) scpp::int_t<>((a0 + a1)); }, addresses); } }

#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/support/php_string.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); ::scpp::php::echo_one(a0); } }

#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); ::scpp::php::echo_one(a0); } }

#include "specializations/runtime_runtime_call_5c148e6a8044bf818e3dea6df118f7f9d32bc1f99eab9b07921fff118291ba5f.hpp"
#include "scpp/support/string_representation.hpp"
#include "scpp/int_t.hpp"
#include "scpp/support/dbg.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_runtime_call_5c148e6a8044bf818e3dea6df118f7f9d32bc1f99eab9b07921fff118291ba5f(const void* p0, const void* p1, const void* p2) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); auto& a2 = *std::launder(static_cast<const scpp::int_t<>*>(p2)); scpp::php::dbg_at("main.phs", 5, a0, a1, a2); } }

