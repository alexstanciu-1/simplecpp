#pragma once
namespace scpp::internal { void runtime_runtime_call_a93c0c28bba17ad852175e0142d26cf35d254f28a3b0bab8154eaef1740f7532(const void* p0, const void* p1, void* p2); }
