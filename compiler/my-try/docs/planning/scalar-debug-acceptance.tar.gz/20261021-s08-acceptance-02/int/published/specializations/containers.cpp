#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "scpp/int_t.hpp"
using native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 = scpp::int_t<>;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == sizeof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
static_assert(alignof(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421) == alignof(native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421));
native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& unwrap(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& value) { return *std::launder(static_cast<const native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421*>(value.address())); }
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_default_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_nothrow) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(const concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421& concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operator=(concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&& other) noexcept(SCPP_LAYOUT_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(int64_t value) { ::new(address()) native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(value); }
int64_t concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::native_value() const noexcept { return unwrap(*this).native_value(); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>);
concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::~concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "scpp/support/string_representation.hpp"
using native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 = scpp::string_t;
#include <memory>
#include <new>
#include <utility>
namespace scpp::internal {
static_assert(sizeof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == sizeof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
static_assert(alignof(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80) == alignof(native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80));
native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& unwrap(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { return *std::launder(static_cast<const native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80*>(value.address())); }
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(operation_result, void (*construct)(void*, const void*), const void* input) { construct(address(), input); }
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_default_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(unwrap(other)); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_nothrow) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(std::move(unwrap(other))); }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_copy_assign_nothrow) { unwrap(*this) = unwrap(other); return *this; }
#endif
#if SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::operator=(concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&& other) noexcept(SCPP_LAYOUT_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80_move_assign_nothrow) { unwrap(*this) = std::move(unwrap(other)); return *this; }
#endif
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(const char* bytes, size_t size) { ::new(address()) native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80(scpp::string_representation::construct(bytes, size)); }
const char* concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_data() const noexcept { return scpp::string_representation::data(unwrap(*this)); }
size_t concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::byte_size() const noexcept { return scpp::string_representation::size(unwrap(*this)); }
void concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::append(const concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80& value) { scpp::string_representation::append(unwrap(*this), unwrap(value)); }
static_assert(std::is_nothrow_destructible_v<native_concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>);
concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80::~concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80() noexcept { std::destroy_at(&unwrap(*this)); }
}

#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include <memory>
#include <new>
namespace scpp::internal { scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5(const void* p0, const void* p1) { const void* addresses[] = {p0, p1}; return scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421(scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421::operation_result{}, +[](void* destination, const void* input) { auto addresses = static_cast<const void* const*>(input); const void* p0 = addresses[0]; const void* p1 = addresses[1]; auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); ::new(destination) scpp::int_t<>((a0 | a1)); }, addresses); } }

#include "specializations/runtime_runtime_call_6f4667c5619d5d0e7411d125e8c990e0aa1c2fedad93274a47bd8b03e902095b.hpp"
#include "scpp/support/string_representation.hpp"
#include "scpp/int_t.hpp"
#include "scpp/support/dbg.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_runtime_call_6f4667c5619d5d0e7411d125e8c990e0aa1c2fedad93274a47bd8b03e902095b(const void* p0, const void* p1, const void* p2) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); auto& a2 = *std::launder(static_cast<const scpp::int_t<>*>(p2)); scpp::php::dbg_at("main.phs", 3, a0, a1, a2); } }

#include "specializations/runtime_runtime_call_a7e80849e3e0f9ff9ef9bb204a174832af9245489892ab162e94994d4e9a8e29.hpp"
#include "scpp/support/string_representation.hpp"
#include "scpp/int_t.hpp"
#include "scpp/support/dbg.hpp"
#include "utility"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_runtime_call_a7e80849e3e0f9ff9ef9bb204a174832af9245489892ab162e94994d4e9a8e29(const void* p0, const void* p1, void* p2) { auto& a0 = *std::launder(static_cast<const scpp::string_t*>(p0)); auto& a1 = *std::launder(static_cast<const scpp::int_t<>*>(p1)); auto& a2 = *std::launder(static_cast<scpp::int_t<>*>(p2)); scpp::php::dbg_at("main.phs", 2, a0, a1, std::move(a2)); } }

#include "specializations/runtime_runtime_call_cff4172460064d757bddfe56cdfaf0a87c7bc0144a8e59059c93bc2e7b84a70f.hpp"
#include "scpp/int_t.hpp"
#include "scpp/support/dbg.hpp"
#include <memory>
#include <new>
namespace scpp::internal { void runtime_runtime_call_cff4172460064d757bddfe56cdfaf0a87c7bc0144a8e59059c93bc2e7b84a70f(const void* p0) { auto& a0 = *std::launder(static_cast<const scpp::int_t<>*>(p0)); scpp::php::dbg_at("main.phs", 1, a0); } }

