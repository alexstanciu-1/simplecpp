#pragma once
namespace scpp::internal { void runtime_runtime_call_a7e80849e3e0f9ff9ef9bb204a174832af9245489892ab162e94994d4e9a8e29(const void* p0, const void* p1, void* p2); }
