#pragma once
namespace scpp::internal { void runtime_runtime_call_9357610416ffb0904e400aa9b11815f0a22a8939fde0bdeeea5fe4430fb2ef37(const void* p0, const void* p1, void* p2); }
