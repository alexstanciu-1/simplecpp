#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_runtime_call_c665eebfcf85329532e28c3db31e7f0fb7cf9aa316282f8f78a75c383d158254.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_runtime_call_9357610416ffb0904e400aa9b11815f0a22a8939fde0bdeeea5fe4430fb2ef37.hpp"
#include "specializations/runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5.hpp"
#include "specializations/runtime_runtime_call_ecf1919ae15cac120b37c048b371b3d6eae4e08a6a7b294814f52cd68ad992e7.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_0 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("bytes", 5);
	return scpp::internal::runtime_runtime_call_c665eebfcf85329532e28c3db31e7f0fb7cf9aa316282f8f78a75c383d158254((argument_0).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_1 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("label", 5);
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_2 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("bytes", 5);
scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 default_argument_3 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(262343LL);
	return scpp::internal::runtime_runtime_call_9357610416ffb0904e400aa9b11815f0a22a8939fde0bdeeea5fe4430fb2ef37((argument_1).address(), (argument_2).address(), (default_argument_3).address());
}());
	([&]() -> void {
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_4 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("flags", 5);
	scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80 argument_5 = scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("bytes", 5);
	scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 argument_8 = ([&]() -> scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421 { auto operand_6 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(2LL); auto operand_7 = static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(65536LL); return scpp::internal::runtime_binary_aebed23bf595120a9c147887d15493021be321490c39192b5111e261e0626cf5((operand_6).address(), (operand_7).address()); }());
	return scpp::internal::runtime_runtime_call_ecf1919ae15cac120b37c048b371b3d6eae4e08a6a7b294814f52cd68ad992e7((argument_4).address(), (argument_5).address(), (argument_8).address());
}());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
