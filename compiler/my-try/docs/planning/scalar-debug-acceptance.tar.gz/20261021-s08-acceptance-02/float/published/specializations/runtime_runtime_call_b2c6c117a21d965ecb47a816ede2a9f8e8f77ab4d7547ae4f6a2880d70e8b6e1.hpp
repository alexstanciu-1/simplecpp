#pragma once
namespace scpp::internal { void runtime_runtime_call_b2c6c117a21d965ecb47a816ede2a9f8e8f77ab4d7547ae4f6a2880d70e8b6e1(const void* p0, const void* p1, void* p2); }
