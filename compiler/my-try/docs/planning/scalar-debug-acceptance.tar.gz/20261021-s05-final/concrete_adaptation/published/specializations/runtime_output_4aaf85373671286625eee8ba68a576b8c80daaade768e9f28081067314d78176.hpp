#pragma once
namespace scpp::internal { void runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176(const void* p0); }
