#pragma once
#include <stdint.h>
namespace scpp::internal {
void initialize_cli(int argc, char** argv);
int run_application(int argc, char** argv, int (*body)());
}
