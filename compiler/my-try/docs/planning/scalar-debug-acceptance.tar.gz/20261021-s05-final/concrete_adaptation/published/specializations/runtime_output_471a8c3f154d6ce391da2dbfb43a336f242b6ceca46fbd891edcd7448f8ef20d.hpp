#pragma once
namespace scpp::internal { void runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d(const void* p0); }
