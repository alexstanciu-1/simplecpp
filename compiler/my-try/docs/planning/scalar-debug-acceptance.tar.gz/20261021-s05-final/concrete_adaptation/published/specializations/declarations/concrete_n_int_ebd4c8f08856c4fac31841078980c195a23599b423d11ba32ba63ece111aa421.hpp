#pragma once
namespace scpp::internal { struct concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421; }
