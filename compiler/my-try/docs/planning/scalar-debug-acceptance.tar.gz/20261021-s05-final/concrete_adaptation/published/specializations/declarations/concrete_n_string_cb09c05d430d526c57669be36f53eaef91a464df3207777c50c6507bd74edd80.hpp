#pragma once
namespace scpp::internal { struct concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80; }
