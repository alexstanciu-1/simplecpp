#include "callables/n6368696c64.hpp"
#include "specializations/concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "scpp/async_core.hpp"
#include "new"
#include "utility"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/concrete_n_async_void__dadfd954fdd9b2841230bebaa78d87c41b5be31b9725d14f0f6823d796b5e491.hpp"
scpp::async_core::task<scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80> coroutine_function_child()
{
	(co_await (*static_cast<scpp::async_core::task<void>*>((scpp::internal::concrete_n_async_void__dadfd954fdd9b2841230bebaa78d87c41b5be31b9725d14f0f6823d796b5e491::sleep((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL)).native_value())).address())));
	co_return scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80("new", 3);
}

scpp::internal::concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22 function_child() { auto task = coroutine_function_child(); return scpp::internal::concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22(scpp::internal::concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22::operation_result{}, +[](void* out, const void* in) { ::new(out) scpp::async_core::task<scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>(std::move(*const_cast<scpp::async_core::task<scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>*>(static_cast<const scpp::async_core::task<scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80>*>(in)))); }, &task); }
