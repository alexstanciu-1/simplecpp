#pragma once
namespace scpp::internal { struct concrete_n_async_void__dadfd954fdd9b2841230bebaa78d87c41b5be31b9725d14f0f6823d796b5e491; }
