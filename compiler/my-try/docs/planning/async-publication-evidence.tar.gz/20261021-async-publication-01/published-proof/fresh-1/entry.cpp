#include "specializations/concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22.hpp"
#include "callables/n6368696c64.hpp"
#include "specializations/concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80.hpp"
#include "specializations/runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::runtime_output_4aaf85373671286625eee8ba68a576b8c80daaade768e9f28081067314d78176((static_cast<const scpp::internal::concrete_n_string_cb09c05d430d526c57669be36f53eaef91a464df3207777c50c6507bd74edd80&>((([&]() -> scpp::internal::concrete_n_async_string__fee2134a49498b4018a1acbcda9c6a03fe06afcf16de9d1a570e89497fe04b22 { return function_child(); }())).wait())).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
