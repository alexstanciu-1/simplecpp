#include "specializations/concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795.hpp"
#include "callables/n6368696c64.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "specializations/runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d.hpp"
#include "specializations/base.hpp"

static int application_body()
{
	scpp::internal::runtime_output_471a8c3f154d6ce391da2dbfb43a336f242b6ceca46fbd891edcd7448f8ef20d((static_cast<const scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421&>((([&]() -> scpp::internal::concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795 { return function_child(); }())).wait())).address());
	return 0;
}
int main(int argc, char** argv) { return scpp::internal::run_application(argc, argv, application_body); }
