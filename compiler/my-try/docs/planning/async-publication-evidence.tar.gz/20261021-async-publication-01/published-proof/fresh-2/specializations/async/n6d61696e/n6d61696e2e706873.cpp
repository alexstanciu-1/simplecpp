#include "callables/n6368696c64.hpp"
#include "specializations/concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795.hpp"
#include "specializations/concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421.hpp"
#include "scpp/async_core.hpp"
#include "new"
#include "utility"
#include "specializations/concrete_n_async_void__dadfd954fdd9b2841230bebaa78d87c41b5be31b9725d14f0f6823d796b5e491.hpp"
scpp::async_core::task<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421> coroutine_function_child()
{
	(co_await (*static_cast<scpp::async_core::task<void>*>((scpp::internal::concrete_n_async_void__dadfd954fdd9b2841230bebaa78d87c41b5be31b9725d14f0f6823d796b5e491::sleep((static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(0LL)).native_value())).address())));
	co_return static_cast<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(3LL);
}

scpp::internal::concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795 function_child() { auto task = coroutine_function_child(); return scpp::internal::concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795(scpp::internal::concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795::operation_result{}, +[](void* out, const void* in) { ::new(out) scpp::async_core::task<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>(std::move(*const_cast<scpp::async_core::task<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>*>(static_cast<const scpp::async_core::task<scpp::internal::concrete_n_int_ebd4c8f08856c4fac31841078980c195a23599b423d11ba32ba63ece111aa421>*>(in)))); }, &task); }
