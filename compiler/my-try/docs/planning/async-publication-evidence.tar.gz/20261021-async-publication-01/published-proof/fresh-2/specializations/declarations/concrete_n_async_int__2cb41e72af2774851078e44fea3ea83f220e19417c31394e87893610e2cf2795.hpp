#pragma once
namespace scpp::internal { struct concrete_n_async_int__2cb41e72af2774851078e44fea3ea83f220e19417c31394e87893610e2cf2795; }
