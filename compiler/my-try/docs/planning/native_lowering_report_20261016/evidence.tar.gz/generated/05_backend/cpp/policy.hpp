#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class CPP_Default_Constructors;
class CPP_Shared_Allocations;
class collected_record;
class cpp_generation_context;
class cpp_lowering_policy;
class preparation_owner;

class cpp_lowering_policy : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	int_t<> optimization;
	cpp_lowering_policy(int_t<> optimization = static_cast<int_t<> >(2));
	virtual bool_t outline_defaults();
	virtual string_t identity();
};

class CPP_Default_Constructors : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static bool_t eligible(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_lowering_policy> policy);
	static string_t decision(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_lowering_policy> policy);
	static string_t definition(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_generation_context> context);
};

class CPP_Shared_Allocations : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static hash_t<bool_t> select(::scpp::compiler::Storage<scpp::compiler::preparation_owner> owners, shared_p<scpp::compiler::cpp_lowering_policy> policy);
	static bool_t changed(const hash_t<bool_t>& before, const hash_t<bool_t>& after);
	static string_t name(shared_p<scpp::compiler::collected_record> record);
	static string_t signature(shared_p<scpp::compiler::collected_record> record);
	static string_t definition(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_generation_context> context);
};

}

