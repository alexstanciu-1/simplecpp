#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class CPP_Lowering_Report;
class cpp_artifact;
class cpp_lowering_policy;
class cpp_program;

class CPP_Lowering_Report : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static string_t encode(::scpp::compiler::Storage<scpp::compiler::cpp_artifact> artifacts, shared_p<scpp::compiler::cpp_program> program, shared_p<scpp::compiler::cpp_lowering_policy> policy, bool_t explain = static_cast<bool_t>(false));
private:
	static string_t keys(const hash_t<bool_t>& values);
	static string_t strings(const vector_t<string_t>& values);
};

}

