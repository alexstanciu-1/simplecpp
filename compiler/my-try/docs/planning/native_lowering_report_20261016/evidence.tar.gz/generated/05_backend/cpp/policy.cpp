#include "policy.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t cpp_lowering_policy::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::cpp_lowering_policy::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

cpp_lowering_policy::cpp_lowering_policy(int_t<> optimization) {
	SCPP_CALL_DEPTH_GUARD("cpp_lowering_policy::__construct", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 5);
	this->optimization = optimization;
	if (static_cast<bool>(((optimization < static_cast<int_t<> >(0)) || (optimization > static_cast<int_t<> >(3))))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_invalid_argument_exception>(string_t("C++ optimization must be 0, 1, 2 or 3")));
	}
}

bool_t cpp_lowering_policy::outline_defaults() {
	SCPP_CALL_DEPTH_GUARD("cpp_lowering_policy::outline_defaults", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 11);
	return bool_t((this->optimization < static_cast<int_t<> >(2)));
}

string_t cpp_lowering_policy::identity() {
	SCPP_CALL_DEPTH_GUARD("cpp_lowering_policy::identity", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 12);
	return php::ternary_eval([&]() -> decltype(auto) { return this->outline_defaults(); }, [&]() -> decltype(auto) { return string_t("cpp-lowering-v2:latency"); }, [&]() -> decltype(auto) { return string_t("cpp-lowering-v1:execution"); });
}

bool_t CPP_Default_Constructors::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Default_Constructors::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

bool_t CPP_Default_Constructors::eligible(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_lowering_policy> policy) {
	SCPP_CALL_DEPTH_GUARD("CPP_Default_Constructors::eligible", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 19);
	return bool_t(php::identical(CPP_Default_Constructors::decision(record, policy), string_t("outlined")));
}

string_t CPP_Default_Constructors::decision(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_lowering_policy> policy) {
	SCPP_CALL_DEPTH_GUARD("CPP_Default_Constructors::decision", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 23);
	if (static_cast<bool>((!policy->outline_defaults()))) {
		return string_t("execution-policy");
	}
	auto syntax = record->syntax();
	if (static_cast<bool>(php::condition_truthy(php::not_identical(syntax->declaration_kind, type_declaration_kind::class_type)))) {
		return string_t("not-class");
	}
	auto layout = syntax->require_preparation();
	auto constructor = weakref_get(layout->constructor);
	if (static_cast<bool>(((php::not_identical(layout->base_type, null) || php::not_identical(constructor, null)) || php::not_identical(layout->initialization, null)))) {
		return string_t("constructor-base-or-data-initialization");
	}
	auto contract = record->contract_work->require_facts();
	if (static_cast<bool>((contract->polymorphic || contract->abstract_type))) {
		return string_t("polymorphic-or-abstract");
	}
	::scpp::compiler::Key_Storage_List<collected_method> methods = required_cast<::scpp::compiler::Key_Storage_List<collected_method>>(layout->methods);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(php::count(methods.named(string_t("__destruct"))), static_cast<int_t<> >(0))))) {
		return string_t("authored-destructor");
	}
	auto found_container = static_cast<bool_t>(false);
	::scpp::compiler::Key_Storage_List<prepared_field> fields = required_cast<::scpp::compiler::Key_Storage_List<prepared_field>>(layout->fields);
	auto __scpp_foreach_source_36 = fields.items();
	for (auto __scpp_foreach_entry_36 : foreach_range(__scpp_foreach_source_36)) {
		auto field = __scpp_foreach_entry_36.value_copy();
		auto default_value = field->default_value;
		if (static_cast<bool>(php::identical(default_value, null))) {
			return string_t("field-without-default");
		}
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<prepared_constant_property_default>(default_value)))) {
			continue;
		}
		auto construction = ::scpp::checked_object_cast<prepared_construction_property_default>(default_value)->construction;
		::scpp::compiler::Storage<data_entry_node> entries = required_cast<::scpp::compiler::Storage<data_entry_node>>(construction->entries);
		if (static_cast<bool>((!bool_t(entries.is_empty())))) {
			return string_t("nonempty-container-default");
		}
		if (static_cast<bool>((!::scpp::object_is<prepared_sequence_construction>(construction->require_data_preparation())))) {
			return string_t("nonsequence-default");
		}
		auto definition = Type_Queries::canonical(field->type)->definition();
		if (static_cast<bool>((php::not_identical(definition, Model::type_catalog->definition(string_t("hash"))) && php::not_identical(definition, Model::type_catalog->definition(string_t("vector")))))) {
			return string_t("unsupported-container-default");
		}
		found_container = bool_t(static_cast<bool_t>(true));
	}
	return php::ternary_eval([&]() -> decltype(auto) { return found_container; }, [&]() -> decltype(auto) { return string_t("outlined"); }, [&]() -> decltype(auto) { return string_t("no-container-default"); });
}

string_t CPP_Default_Constructors::definition(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Default_Constructors::definition", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 52);
	auto name = CPP_Generator::source_name(string_t("record"), record->qualified_name());
	auto text = (cast<string_t>(name) + string_t("::") + cast<string_t>(name) + string_t("()"));
	auto separator = string_t(" : ");
	::scpp::compiler::Key_Storage_List<prepared_field> fields = required_cast<::scpp::compiler::Key_Storage_List<prepared_field>>(record->syntax()->require_preparation()->fields);
	auto __scpp_foreach_source_57 = fields.items();
	for (auto __scpp_foreach_entry_57 : foreach_range(__scpp_foreach_source_57)) {
		auto field = __scpp_foreach_entry_57.value_copy();
		auto entry = ::scpp::checked_object_cast<collected_name>(weakref_get(field->declaration));
		text = (text + cast<string_t>((cast<string_t>(separator) + cast<string_t>(CPP_Generator::source_name(string_t("field"), entry->name)) + string_t("(") + cast<string_t>(CPP_Declarations::property_default(field->default_value, context)) + string_t(")"))));
		separator = string_t(", ");
	}
	return (cast<string_t>(text) + string_t("\n{\n}\n\n"));
}

bool_t CPP_Shared_Allocations::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Shared_Allocations::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

hash_t<bool_t> CPP_Shared_Allocations::select(::scpp::compiler::Storage<scpp::compiler::preparation_owner> owners, shared_p<scpp::compiler::cpp_lowering_policy> policy) {
	SCPP_CALL_DEPTH_GUARD("CPP_Shared_Allocations::select", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 69);
	hash_t<bool_t> result = {};
	if (static_cast<bool>((!policy->outline_defaults()))) {
		return result;
	}
	auto& __scpp_foreach_source_72 = owners;
	for (auto __scpp_foreach_entry_72 : foreach_range(__scpp_foreach_source_72)) {
		auto owner = __scpp_foreach_entry_72.value_copy();
		if (static_cast<bool>(php::condition_truthy(php::not_identical(owner->kind(), preparation_kind::declaration)))) {
			continue;
		}
		if (static_cast<bool>((!Preparation_Status::complete(owner)))) {
			throw ::scpp::php::make_thrown(create<scpp_portability_runtime_exception>(string_t("Allocation placement requires completed preparation")));
		}
		auto declaration = owner->declaration();
		if (static_cast<bool>((!::scpp::object_is<collected_record>(declaration)))) {
			continue;
		}
		auto record = ::scpp::checked_object_cast<collected_record>(declaration);
		if (static_cast<bool>(php::condition_truthy(CPP_Default_Constructors::eligible(record, policy)))) {
			result[cast<string_t>(record->qualified_name())] = static_cast<bool_t>(true);
		}
	}
	return result;
}

bool_t CPP_Shared_Allocations::changed(const hash_t<bool_t>& before, const hash_t<bool_t>& after) {
	SCPP_CALL_DEPTH_GUARD("CPP_Shared_Allocations::changed", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 83);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(php::count(before), php::count(after))))) {
		return bool_t(static_cast<bool_t>(true));
	}
	auto& __scpp_foreach_source_85 = after;
	for (auto __scpp_foreach_entry_85 : foreach_range(__scpp_foreach_source_85)) {
		auto&& name = __scpp_foreach_entry_85.key();
		auto selected = __scpp_foreach_entry_85.value_copy();
		if (static_cast<bool>((!php::isset(before, name)))) {
			return bool_t(static_cast<bool_t>(true));
		}
	}
	return bool_t(static_cast<bool_t>(false));
}

string_t CPP_Shared_Allocations::name(shared_p<scpp::compiler::collected_record> record) {
	SCPP_CALL_DEPTH_GUARD("CPP_Shared_Allocations::name", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 89);
	return CPP_Generator::source_name(string_t("allocate_shared"), record->qualified_name());
}

string_t CPP_Shared_Allocations::signature(shared_p<scpp::compiler::collected_record> record) {
	SCPP_CALL_DEPTH_GUARD("CPP_Shared_Allocations::signature", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 93);
	return (string_t("::scpp::shared_p<") + cast<string_t>(CPP_Generator::source_name(string_t("record"), record->qualified_name())) + string_t("> ") + cast<string_t>(CPP_Shared_Allocations::name(record)) + string_t("()"));
}

string_t CPP_Shared_Allocations::definition(shared_p<scpp::compiler::collected_record> record, shared_p<scpp::compiler::cpp_generation_context> context) {
	SCPP_CALL_DEPTH_GUARD("CPP_Shared_Allocations::definition", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/policy.phs", 97);
	context->headers[string_t("scpp/memory.hpp")] = static_cast<bool_t>(true);
	return (cast<string_t>(CPP_Shared_Allocations::signature(record)) + string_t("\n{\n\treturn ::scpp::shared<") + cast<string_t>(CPP_Generator::source_name(string_t("record"), record->qualified_name())) + string_t(">();\n}\n\n"));
}

}

