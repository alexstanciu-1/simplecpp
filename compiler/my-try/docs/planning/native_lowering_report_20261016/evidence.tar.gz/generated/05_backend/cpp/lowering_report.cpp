#include "lowering_report.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t CPP_Lowering_Report::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Lowering_Report::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

string_t CPP_Lowering_Report::encode(::scpp::compiler::Storage<scpp::compiler::cpp_artifact> artifacts, shared_p<scpp::compiler::cpp_program> program, shared_p<scpp::compiler::cpp_lowering_policy> policy, bool_t explain) {
	SCPP_CALL_DEPTH_GUARD("CPP_Lowering_Report::encode", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/lowering_report.phs", 5);
	if (static_cast<bool>(php::condition_truthy(php::not_identical(program->policy_identity, policy->identity())))) {
		throw ::scpp::php::make_thrown(create<scpp_portability_logic_exception>(string_t("Lowering report policy does not match completed output")));
	}
	hash_t<string_t> consumers = {};
	hash_t<bool_t> paths = {};
	auto& __scpp_foreach_source_11 = artifacts;
	for (auto __scpp_foreach_entry_11 : foreach_range(__scpp_foreach_source_11)) {
		auto consumer = __scpp_foreach_entry_11.value_copy();
		paths[cast<string_t>(consumer->file_name)] = static_cast<bool_t>(true);
		auto __scpp_foreach_source_13 = consumer->includes;
		for (auto __scpp_foreach_entry_13 : foreach_range(__scpp_foreach_source_13)) {
			auto header = __scpp_foreach_entry_13.value_copy();
			if (static_cast<bool>((!php::isset(consumers, header)))) {
				consumers[cast<string_t>(header)] = string_t("");
			}
			auto existing = consumers.at(cast<string_t>(header));
			consumers[cast<string_t>(header)] = (cast<string_t>(existing) + cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::identical(existing, string_t("")); }, [&]() -> decltype(auto) { return string_t(""); }, [&]() -> decltype(auto) { return string_t(","); })) + cast<string_t>(scpp_portability_json_quote(consumer->file_name)));
		}
	}
	auto rows = string_t("");
	auto separator = string_t("");
	auto& __scpp_foreach_source_21 = artifacts;
	for (auto __scpp_foreach_entry_21 : foreach_range(__scpp_foreach_source_21)) {
		auto artifact = __scpp_foreach_entry_21.value_copy();
		auto users = string_t("");
		if (static_cast<bool>(php::condition_truthy(php::isset(consumers, artifact->file_name)))) {
			users = consumers.at(cast<string_t>(artifact->file_name));
		}
		rows = (rows + cast<string_t>((cast<string_t>(separator) + string_t("{\"id\":") + cast<string_t>(scpp_portability_json_quote(artifact->identity)) + string_t(",\"path\":") + cast<string_t>(scpp_portability_json_quote(artifact->file_name)) + string_t(",\"kind\":") + cast<string_t>(scpp_portability_json_quote(artifact->kind_name())) + string_t(",\"bytes\":") + cast<string_t>(str::byte_length(artifact->text)) + string_t(",\"direct_includes\":") + cast<string_t>(CPP_Artifacts::includes_json(artifact)) + string_t(",\"direct_generated_consumers\":") + string_t("[") + cast<string_t>(users) + string_t("]") + string_t("}"))));
		separator = string_t(",");
	}
	auto fragments = string_t("");
	separator = string_t("");
	auto __scpp_foreach_source_33 = program->fragments;
	for (auto __scpp_foreach_entry_33 : foreach_range(__scpp_foreach_source_33)) {
		auto&& owner = __scpp_foreach_entry_33.key();
		auto __scpp_object_value_1 = __scpp_foreach_entry_33.value_copy();
		if (static_cast<bool>((php::identical(owner->change_status, change_state::deleted) || owner->source->deleted))) {
			continue;
		}
		auto fragment = program->fragments[owner];
		auto declaration = owner->declaration();
		auto name = string_t("");
		auto kind = string_t("file_body");
		auto unit = string_t("entry.cpp");
		if (static_cast<bool>(php::condition_truthy(php::not_identical(declaration, null)))) {
			shared_p<collected_definition> named = declaration;
			name = named->qualified_name();
			unit = CPP_Artifacts::unit_path(owner->source);
			kind = string_t("declaration");
		}
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_source_callable>(declaration)))) {
			unit = CPP_Artifacts::unit_path(CPP_Implementation_Groups::callable_source(::scpp::checked_object_cast<collected_source_callable>(declaration)));
		}
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<source_callable_body_work>(owner)))) {
			kind = string_t("function_body");
		}
		fragments = (fragments + cast<string_t>((cast<string_t>(separator) + string_t("{\"owner\":") + cast<string_t>(scpp_portability_json_quote(name)) + string_t(",\"kind\":") + cast<string_t>(scpp_portability_json_quote(kind)) + string_t(",\"source\":") + cast<string_t>(scpp_portability_json_quote(owner->source->source_file()->path)) + string_t(",\"implementation_path\":") + cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::isset(paths, unit); }, [&]() -> decltype(auto) { return scpp_portability_json_quote(unit); }, [&]() -> decltype(auto) { return string_t("null"); })) + string_t(",\"fragment_bytes\":") + cast<string_t>(str::byte_length(fragment->text)) + string_t(",\"prototype_bytes\":") + cast<string_t>(str::byte_length(fragment->prototype_text)) + string_t(",\"initializer_bytes\":") + cast<string_t>(str::byte_length(fragment->initializer_text)) + string_t(",\"type_owned_definition_bytes\":") + cast<string_t>(str::byte_length(fragment->record_definition_text)))));
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_record>(declaration)))) {
			fragments = (fragments + cast<string_t>((string_t(",\"default_constructor_decision\":") + cast<string_t>(scpp_portability_json_quote(CPP_Default_Constructors::decision(::scpp::checked_object_cast<collected_record>(declaration), policy))) + string_t(",\"shared_allocation_outlined\":") + cast<string_t>(php::ternary_eval([&]() -> decltype(auto) { return php::isset(program->outlined_shared_allocations, name); }, [&]() -> decltype(auto) { return string_t("true"); }, [&]() -> decltype(auto) { return string_t("false"); })))));
		}
		if (static_cast<bool>(php::condition_truthy(explain))) {
			fragments = (fragments + cast<string_t>((string_t(",\"fragment_headers\":") + cast<string_t>(CPP_Lowering_Report::keys(fragment->headers)) + string_t(",\"definition_headers\":") + cast<string_t>(CPP_Lowering_Report::keys(fragment->definition_headers)) + string_t(",\"forward_declarations\":") + cast<string_t>(CPP_Lowering_Report::keys(fragment->forward_declarations)))));
		}
		fragments = (fragments + string_t("}"));
		separator = string_t(",");
	}
	return (string_t("{\"format\":\"scpp-lowering-report-v1\",\"optimization\":") + cast<string_t>(policy->optimization) + string_t(",\"policy\":") + cast<string_t>(scpp_portability_json_quote(program->policy_identity)) + string_t(",\"explanation_granularity\":\"fragment-contribution\",\"operation_reasons_available\":false") + string_t(",\"artifacts\":[") + cast<string_t>(rows) + string_t("],\"fragments\":[") + cast<string_t>(fragments) + string_t("]}\n"));
}

string_t CPP_Lowering_Report::keys(const hash_t<bool_t>& values) {
	SCPP_CALL_DEPTH_GUARD("CPP_Lowering_Report::keys", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/lowering_report.phs", 77);
	vector_t<string_t> names = {};
	auto& __scpp_foreach_source_79 = values;
	for (auto __scpp_foreach_entry_79 : foreach_range(__scpp_foreach_source_79)) {
		auto&& name = __scpp_foreach_entry_79.key();
		auto present = __scpp_foreach_entry_79.value_copy();
		(void) names.push_back(name);
	}
	return CPP_Lowering_Report::strings(names);
}

string_t CPP_Lowering_Report::strings(const vector_t<string_t>& values) {
	SCPP_CALL_DEPTH_GUARD("CPP_Lowering_Report::strings", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/lowering_report.phs", 83);
	auto text = string_t("[");
	auto separator = string_t("");
	auto& __scpp_foreach_source_86 = values;
	for (auto __scpp_foreach_entry_86 : foreach_range(__scpp_foreach_source_86)) {
		auto value = __scpp_foreach_entry_86.value_copy();
		text = (text + cast<string_t>((cast<string_t>(separator) + cast<string_t>(scpp_portability_json_quote(value)))));
		separator = string_t(",");
	}
	return (cast<string_t>(text) + string_t("]"));
}

}

