#include "implementation_groups.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

bool_t CPP_Implementation_Groups::__scpp_static_accepts(const void* __scpp_token) {
	if (__scpp_token == scpp::compiler::CPP_Implementation_Groups::__scpp_static_token()) {
		return static_cast<bool_t>(true);
	}
	return static_cast<bool_t>(false);
}

shared_p<scpp::compiler::collected_file> CPP_Implementation_Groups::callable_source(shared_p<scpp::compiler::collected_source_callable> definition) {
	SCPP_CALL_DEPTH_GUARD("CPP_Implementation_Groups::callable_source", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/implementation_groups.phs", 6);
	if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_method>(definition)))) {
		return ::scpp::checked_object_cast<collected_method>(definition)->declaring_type()->collection;
	}
	return definition->collection;
}

::scpp::compiler::Storage<scpp::compiler::cpp_implementation_group> CPP_Implementation_Groups::assemble(::scpp::compiler::Storage<scpp::compiler::prepared_file> files, ::scpp::compiler::Storage<scpp::compiler::preparation_owner> ordered, shared_p<scpp::compiler::cpp_program> program) {
	SCPP_CALL_DEPTH_GUARD("CPP_Implementation_Groups::assemble", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/implementation_groups.phs", 14);
	::scpp::compiler::Storage<cpp_implementation_group> groups = required_cast<::scpp::compiler::Storage<cpp_implementation_group>>(::scpp::compiler::Storage<scpp::compiler::cpp_implementation_group>());
	auto& __scpp_foreach_source_16 = files;
	for (auto __scpp_foreach_entry_16 : foreach_range(__scpp_foreach_source_16)) {
		auto prepared = __scpp_foreach_entry_16.value_copy();
		auto group = CPP_Implementation_Groups::source_group(prepared->source, ordered, program);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(group->text, string_t(""))))) {
			int_t<>(groups.append(group));
		}
	}
	return groups;
}

shared_p<scpp::compiler::cpp_implementation_group> CPP_Implementation_Groups::source_group(shared_p<scpp::compiler::collected_file> source, ::scpp::compiler::Storage<scpp::compiler::preparation_owner> ordered, shared_p<scpp::compiler::cpp_program> program) {
	SCPP_CALL_DEPTH_GUARD("CPP_Implementation_Groups::source_group", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/05_backend/cpp/implementation_groups.phs", 24);
	auto path = CPP_Artifacts::unit_path(source);
	auto group = create<cpp_implementation_group>((string_t("implementation:") + cast<string_t>(path)), path);
	auto dispatch_context = create<cpp_generation_context>();
	auto& __scpp_foreach_source_28 = ordered;
	for (auto __scpp_foreach_entry_28 : foreach_range(__scpp_foreach_source_28)) {
		auto callable_owner = __scpp_foreach_entry_28.value_copy();
		if (static_cast<bool>((::scpp::object_is<record_definition_work>(callable_owner) || ::scpp::object_is<type_contract_work>(callable_owner)))) {
			if (static_cast<bool>(php::identical(callable_owner->source, source))) {
				auto dispatch_owner = ::scpp::checked_object_cast<collected_member_owner>(callable_owner->declaration());
				group->text = (group->text + cast<string_t>(CPP_Dispatch::definitions(dispatch_owner, dispatch_context)));
			}
		}
		if (static_cast<bool>((::scpp::object_is<record_definition_work>(callable_owner) && php::identical(callable_owner->source, source)))) {
			auto layout = program->fragments[callable_owner];
			if (static_cast<bool>(php::condition_truthy(php::not_identical(layout->record_definition_text, string_t(""))))) {
				auto record = ::scpp::checked_object_cast<record_definition_work>(callable_owner)->record_definition();
				group->headers[CPP_Artifacts::type_header(record->qualified_name())] = static_cast<bool_t>(true);
				auto __scpp_foreach_source_40 = layout->definition_headers;
				for (auto __scpp_foreach_entry_40 : foreach_range(__scpp_foreach_source_40)) {
					auto&& header = __scpp_foreach_entry_40.key();
					auto used = __scpp_foreach_entry_40.value_copy();
					group->headers[header] = static_cast<bool_t>(true);
				}
				group->text = (group->text + cast<string_t>(layout->record_definition_text));
			}
		}
		if (static_cast<bool>((!::scpp::object_is<source_callable_signature_work>(callable_owner)))) {
			continue;
		}
		auto definition = ::scpp::checked_object_cast<source_callable_signature_work>(callable_owner)->callable_definition();
		auto implementation_source = CPP_Implementation_Groups::callable_source(definition);
		if (static_cast<bool>(php::condition_truthy(php::not_identical(implementation_source, source)))) {
			continue;
		}
		auto function = definition->callable_syntax();
		if (static_cast<bool>((!function->has_parsed_body()))) {
			continue;
		}
		auto signature_owner = ::scpp::checked_object_cast<preparation_owner>(definition->preparation_work_owner());
		auto body_owner = ::scpp::checked_object_cast<preparation_owner>(function->require_body()->work());
		auto signature = program->fragments[signature_owner];
		auto body = program->fragments[body_owner];
		if (static_cast<bool>(php::condition_truthy(::scpp::object_is<collected_method>(definition)))) {
			group->headers[CPP_Artifacts::type_header(::scpp::checked_object_cast<collected_method>(definition)->declaring_type()->qualified_name())] = static_cast<bool_t>(true);
		}
		else {
			group->headers[CPP_Artifacts::callable_header(definition->qualified_name())] = static_cast<bool_t>(true);
		}
		auto __scpp_foreach_source_58 = signature->definition_headers;
		for (auto __scpp_foreach_entry_58 : foreach_range(__scpp_foreach_source_58)) {
			auto&& header = __scpp_foreach_entry_58.key();
			auto used = __scpp_foreach_entry_58.value_copy();
			group->headers[header] = static_cast<bool_t>(true);
		}
		auto __scpp_foreach_source_61 = body->headers;
		for (auto __scpp_foreach_entry_61 : foreach_range(__scpp_foreach_source_61)) {
			auto&& header = __scpp_foreach_entry_61.key();
			auto used = __scpp_foreach_entry_61.value_copy();
			group->headers[header] = static_cast<bool_t>(true);
		}
		auto __scpp_foreach_source_62 = body->forward_declarations;
		for (auto __scpp_foreach_entry_62 : foreach_range(__scpp_foreach_source_62)) {
			auto&& name = __scpp_foreach_entry_62.key();
			auto used = __scpp_foreach_entry_62.value_copy();
			group->forward_declarations[name] = static_cast<bool_t>(true);
		}
		group->text = (group->text + cast<string_t>((cast<string_t>(signature->text) + cast<string_t>(body->initializer_text) + string_t("\n{\n") + cast<string_t>(body->text) + string_t("}\n\n"))));
	}
	auto __scpp_foreach_source_67 = dispatch_context->headers;
	for (auto __scpp_foreach_entry_67 : foreach_range(__scpp_foreach_source_67)) {
		auto&& header = __scpp_foreach_entry_67.key();
		auto used = __scpp_foreach_entry_67.value_copy();
		group->headers[header] = static_cast<bool_t>(true);
	}
	auto __scpp_foreach_source_68 = dispatch_context->forward_declarations;
	for (auto __scpp_foreach_entry_68 : foreach_range(__scpp_foreach_source_68)) {
		auto&& name = __scpp_foreach_entry_68.key();
		auto used = __scpp_foreach_entry_68.value_copy();
		group->forward_declarations[name] = static_cast<bool_t>(true);
	}
	return group;
}

}

