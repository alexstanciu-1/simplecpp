#pragma once

#include <scpp/lang/php.hpp>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace scpp::scpp::compiler {

class CPP_Implementation_Groups;
class collected_file;
class collected_source_callable;
class cpp_implementation_group;
class cpp_program;
class preparation_owner;
class prepared_file;

class CPP_Implementation_Groups : public virtual ::scpp::shared_self {
public:
	static const void* __scpp_static_token() { static int __scpp_token = 0; return &__scpp_token; }
	static bool_t __scpp_static_accepts(const void* __scpp_token);
	static shared_p<scpp::compiler::collected_file> callable_source(shared_p<scpp::compiler::collected_source_callable> definition);
	static ::scpp::compiler::Storage<scpp::compiler::cpp_implementation_group> assemble(::scpp::compiler::Storage<scpp::compiler::prepared_file> files, ::scpp::compiler::Storage<scpp::compiler::preparation_owner> ordered, shared_p<scpp::compiler::cpp_program> program);
private:
	static shared_p<scpp::compiler::cpp_implementation_group> source_group(shared_p<scpp::compiler::collected_file> source, ::scpp::compiler::Storage<scpp::compiler::preparation_owner> ordered, shared_p<scpp::compiler::cpp_program> program);
};

}

