#include "main.hpp"

namespace scpp::scpp::compiler {
	using namespace ::scpp;

int __scpp_main() {
	int_t<> argc = php::cli_argc();
	mixed_t argv = php::cli_argv();
	SCPP_CALL_DEPTH_GUARD("__scpp_main", "/home/alexv/__AI/simple_cpp/simple_cpp_01/sandbox/accounting-recovery-20261016/native-lowering-report-20261016/phpp/main.phs", 0);
	auto request = scpp::json_read(scpp_portability_fs_read_text(string_t("request.json")));
	auto optimization = request->member(string_t("optimization"))->integer();
	auto policy_level = request->member(string_t("policy_level"))->integer();
	auto policy = create<cpp_lowering_policy>(policy_level);
	auto marks = scpp_portability_output_root(request->member(string_t("marks"))->text());
	scpp_portability_output_write(marks, string_t("01-start"), string_t("start"));
	auto publication = create<Output_Publication>(request->member(string_t("published"))->text());
	{
		std::exception_ptr __scpp_pending_exception_1;
		std::optional<int> __scpp_return_value_3;
		bool __scpp_pending_return_2 = false;
		try {
		if (!__scpp_pending_return_2) {
			vector_t<string_t> modules = required_cast<vector_t<string_t>>(vector_t<string_t>{string_t("core"), string_t("strings"), string_t("datetime"), string_t("filesystem"), string_t("json")});
			Compiler_Lifecycle::configure_runtime(Runtime_Catalog_Loader::load(request->member(string_t("catalogs"))->text(), modules));
			auto compiler = create<Compiler>();
			compiler->jobs = static_cast<int_t<> >(12);
			vector_t<string_t> paths = required_cast<vector_t<string_t>>(vector_t<string_t>{request->member(string_t("source"))->text()});
			compiler->init(paths);
			compiler->select_entry(string_t("main"), string_t("main.phs"));
			scpp_portability_output_write(marks, string_t("02-setup"), string_t("setup"));
			vector_t<string_t> changed = {};
			compiler->sync(changed);
			scpp_portability_output_write(marks, string_t("03-sync"), string_t("sync"));
			compiler->prepare(static_cast<bool_t>(true));
			scpp_portability_output_write(marks, string_t("04-prepare"), string_t("prepare"));
			compiler->cpp(publication, policy);
		}
		}
		catch (...) {
			__scpp_pending_exception_1 = std::current_exception();
		}
	
		{
			publication->close();
		}
	
		if (__scpp_pending_exception_1) {
			std::rethrow_exception(__scpp_pending_exception_1);
		}
		if (__scpp_pending_return_2) {
			return *__scpp_return_value_3;
		}
	}
	scpp_portability_output_write(marks, string_t("05-cpp-ready"), string_t("cpp-ready"));
	if (static_cast<bool>(php::condition_truthy(request->member(string_t("report"))->boolean()))) {
		scpp_portability_output_write(marks, string_t("lowering-report.json"), CPP_Lowering_Report::encode(Model::cpp_files, Model::cpp_output_program, policy));
		scpp_portability_output_write(marks, string_t("lowering-explain.json"), CPP_Lowering_Report::encode(Model::cpp_files, Model::cpp_output_program, policy, static_cast<bool_t>(true)));
	}
	scpp_portability_output_write(marks, string_t("artifacts.json"), CPP_Output::encode(Model::cpp_files));
	scpp_portability_output_write(marks, string_t("06-report-done"), string_t("report-done"));
	php::echo_one(string_t("PASS\n"));
	return 0;
}
}

int main(int __scpp_argc, char** __scpp_argv) {
	try {
		::scpp::php::set_cli_args(__scpp_argc, __scpp_argv);
		return scpp::scpp::compiler::__scpp_main();
	} catch (const std::exception &exception) {
		::scpp::print_runtime_exception(exception);
		return 1;
	}
}

