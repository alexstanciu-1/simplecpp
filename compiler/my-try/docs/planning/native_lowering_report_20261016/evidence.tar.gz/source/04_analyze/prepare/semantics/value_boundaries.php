<?php

/* One storage boundary protocol for locals, calls and returns; conversions remain separate. */
namespace scpp\compiler;

final class Value_Boundary_Preparation
{
	/** Local and return value boundaries have no reference-parameter access contract. */
	public static function decide_value(canonical_type_use $target, ?conversion_decision $conversion,
		preparation_context $context, prepared_expression $value): value_boundary_operation
	{
		return self::decide($target, $conversion, $context, $value, passing_mode::value, storage_access::writable);
	}

	/** Select the operation once; emitters must not rediscover ownership from type spellings. */
	public static function decide(canonical_type_use $target, ?conversion_decision $conversion,
		preparation_context $context, prepared_expression $value,
		passing_mode $mode, storage_access $access): value_boundary_operation
	{
		if ($mode === passing_mode::observation)
		{
			if (($access !== storage_access::read_only) || !Type_Preparation::same_storage_type($value->type, $target)) {
				throw new \RuntimeException('Runtime observation requires an exact readonly input');
			}
			// No copyability, stable-place or escaping-reference requirement. The whole
			// expression (including any owner temporary) must survive the observing call.
			return value_boundary_operation::observe_value;
		}
		if ($mode === passing_mode::reference)
		{
			if ((!$value->addressable()) || !Type_Preparation::same_storage_type($value->type, $target)) {
				throw new \RuntimeException('S2S reference arguments require stable storage of the exact parameter type');
			}
			if (!$value->place->borrowable()) {
				throw new \RuntimeException('S2S reference arguments cannot borrow heap-backed properties');
			}
			if ($access === storage_access::writable) {
				Reference_Preparation::require_writable($value->place);
			}
			return value_boundary_operation::bind_reference;
		}
		Type_Lifecycle_Preparation::require_storage($target, $context);
		if ($value->is_owned_temporary() && $value->type->matches($target)) {
			return value_boundary_operation::consume_value;
		}
		if ($conversion !== null) {
			if (($conversion->operation === conversion_operation::unique_upcast) && $value->is_owned_temporary()) {
				return value_boundary_operation::consume_value;
			}
			if (($conversion->operation === conversion_operation::ownership_empty)
				|| ($conversion->operation === conversion_operation::nullable_empty)) {
				return value_boundary_operation::construct_empty;
			}
		}
		Capability_Preparation::require_copy($target, $context);
		return value_boundary_operation::copy_value;
	}
}
