<?php

/* Read-only work validity and source-change queries; never schedule or prepare. */
namespace scpp\compiler;

final class Preparation_Status
{
	/** Import-only edits cannot reuse saved output before body-wide admission completes. */
	public static function imports_current(collected_file $source): bool
	{
		$bodies /** Storage<namespace_body_node> */ = $source->root->namespace_bodies;
		foreach ($bodies as $body) {
			if ($body->imports_changed) { return false; }
		}
		return true;
	}
	/** Source changes remain independent of work state until analysis consumes them. */
	public static function source_changed(preparation_owner $owner): bool
	{
		// Anonymous identities retain immutable syntax; replacement creates fresh work.
		if ($owner instanceof anonymous_signature_work) { return false; }
		if ($owner instanceof type_semantic_work) {
			$type_work = object_cast($owner, type_semantic_work::class);
			return $type_work->source_revision !== (int)$type_work->member_definition()->revision;
		}
		if ($owner instanceof declaration_work) {
			return object_cast($owner, declaration_work::class)->required_declaration()->change_status !== change_state::unchanged;
		}
		if ($owner instanceof source_callable_signature_work) {
			return object_cast($owner, source_callable_signature_work::class)->callable_definition()->change_status !== change_state::unchanged;
		}
		if ($owner instanceof body_work) {
			return object_cast($owner, body_work::class)->executable_body()->syntax_changed;
		}
		throw new \LogicException('Unsupported preparation work role');
	}

	/** Reject stale work at process entry; recursive syntax dispatch needs no per-node flag. */
	public static function require_active(preparation_owner $owner): void
	{
		if ($owner instanceof anonymous_signature_work) {
			if (object_cast($owner, anonymous_signature_work::class)->anonymous_identity()->deleted) { throw new \LogicException('Deleted anonymous contract'); }
		}
		if ($owner instanceof anonymous_body_work) {
			if (object_cast($owner, anonymous_body_work::class)->anonymous_identity()->deleted) { throw new \LogicException('Deleted anonymous body'); }
		}
		if ($owner->source->deleted || ($owner->change_status === change_state::deleted)) {
			throw new \LogicException('Deleted work cannot be prepared or generated');
		}
		$declaration = $owner->declaration();
		if ($declaration !== null) {
			if ($declaration->change_status === change_state::deleted) {
				throw new \LogicException('Deleted declaration cannot be prepared or generated');
			}
		}
		if (!$owner->source->parse_complete) {
			throw new \LogicException('Semantic work requires a completed parse');
		}
	}

	/** Completed facts must match current source, even before analysis selects new work. */
	public static function complete(preparation_owner $owner): bool
	{
		self::require_active($owner);
		if (($owner->state !== preparation_state::ready) || ($owner->change_status !== change_state::unchanged) || $owner->failed) {
			return false;
		}
		return !self::source_changed($owner);
	}
}
