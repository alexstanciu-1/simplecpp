<?php

/*
 * Role: prepare struct layouts and field bindings.
 * Call map: LLVM_Preparation -> LLVM_Struct_Preparation::prepare / fields.
 */
namespace scpp\compiler;

final class LLVM_Struct_Preparation
{
	/** Prepare all definitions before file-local storage, including forward/cross-file types.
	 */
	public function prepare(Storage $files /** Storage<collected_file> */, llvm_policy $policy): \SplObjectStorage /** hash<llvm_struct_type, shared<collected_name>> */
	{
		$result /** hash<llvm_struct_type, shared<collected_name>> */ = new \SplObjectStorage /** hash<llvm_struct_type, shared<collected_name>> */();
		foreach ($files as $file)
		{
			$entries /** Storage<collected_name> */ = $file->entries;
			$tokens /** Storage<token> */ = $file->token_snapshot()->tokens;
			foreach ($file->defined_elements as $index)
			{
				$entry = $entries[$index];
				if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
					continue;
				}
				if ($entry->kind() !== collected_name_kind::record_declaration) {
					continue;
				}
				if (isset($policy->types[$entry->name]) || (q_count(Scope_Lookup::visible(object_cast(weakref_get($entry->scope), scope::class))->source_types_named($entry->name)) !== 1)) {
					throw new \RuntimeException('Conflicting struct type: ' . $entry->name);
				}
				$type = new llvm_struct_type();
				$type->declaration = $entry;
				$type->name = '%' . LLVM_Names::encode($entry->name);
				$fields /** Keyed_Storage<llvm_field> */ = $type->fields;
				$syntax_fields /** Storage<property_node> */ = object_cast($entry, collected_record::class)->syntax()->properties;
				foreach ($syntax_fields as $syntax)
				{
					$spelling = '$' . $syntax->name;
					$name = string_byte_slice($spelling, 1, string_byte_len($spelling) - 1);
					$source_type = $tokens[$syntax->require_type_syntax()->start_token()]->text();
					if (!isset($policy->types[$source_type])) {
						throw new \RuntimeException('Struct proof supports only int fields');
					}
					$field_type = $policy->types[$source_type];
					if ($field_type !== $policy->integer_type) {
						throw new \RuntimeException('Struct proof supports only int fields');
					}
					if (isset($fields[$name])) {
						throw new \RuntimeException('Duplicate struct field: ' . $name);
					}
					$field = new llvm_field();
					$field->index = q_count($fields);
					$field->type = $field_type;
					$fields->add($name, $field);
				}
				if ($fields->is_empty()) {
					throw new \RuntimeException('Empty structs are not supported in this proof');
				}
				$result[$entry] = $type;
			}
		}
		return $result;
	}

	/** Resolve member occurrences once; emission consumes field identities and ordinals. */
	public function fields(llvm_prepared_function $function): void
	{
		$file = $function->file;
		$entries /** Storage<collected_name> */ = $file->source->entries;
		foreach ($file->source->field_references as $index)
		{
			$entry = $entries[$index];
			if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
				continue;
			}
			if (!LLVM_Legacy_Name_Preparation::belongs($function, $entry)) {
				continue;
			}
			$base = object_cast($entry, collected_field_reference::class)->syntax()->base;
			if ($base->kind() !== node_kind::variable_reference) {
				throw new \RuntimeException('Nested aggregate field access is not supported yet');
			}
			$declaration = $file->names->references[$base->start_token()];
			$type = $function->locals[$declaration->local_index]->struct_type;
			if ($type === null) {
				throw new \RuntimeException('Field access requires a struct');
			}
			$fields /** Keyed_Storage<llvm_field> */ = $type->fields;
			if (!isset($fields[$entry->name])) {
				throw new \RuntimeException('Unknown struct field: ' . $entry->name);
			}
			$function->fields[$entry->token_index] = $fields[$entry->name];
		}
	}
}
