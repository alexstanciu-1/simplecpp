<?php

/*
 * Role: resolve token-indexed names for the parked LLVM experiment only.
 * Status: parked; extend File_Preparation/attached facts for new semantics, not this path.
 * Call map: LLVM_Preparation_Run::prepare_program -> LLVM_Legacy_Name_Preparation::prepare.
 */
namespace scpp\compiler;

final class LLVM_Legacy_Name_Preparation
{
	/** Adapt the parked backend to distinct file-body and function-signature scopes. */
	public static function belongs(llvm_prepared_function $function, collected_name $entry): bool
	{
		$entry_scope = object_cast(weakref_get($entry->scope), scope::class);
		$body_scope = object_cast($function->body, function_body_node::class)->local_scope();
		if ($function->is_entry) {
			return !$entry_scope->is_function() && ($entry_scope === $body_scope);
		}
		return ($entry_scope === $body_scope) || (($entry->syntax()->kind() === node_kind::parameter_declaration) && ($entry_scope === $body_scope->parent_scope()));
	}

	/** Prepare only unambiguous explicit variables for the initial LLVM experiment. */
	public function prepare(collected_file $file): llvm_legacy_prepared_names
	{
		$result = new llvm_legacy_prepared_names();
		$entries /** Storage<collected_name> */ = $file->entries;
		foreach ($file->defined_elements as $index)
		{
			$entry = $entries[$index];
			if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
				continue;
			}
			$entry_scope /** scope */ = object_cast(weakref_get($entry->scope), scope::class);
			if (($entry->kind() === collected_name_kind::variable_declaration) && $entry_scope->has_template($entry->name)) {
				throw new \RuntimeException('Variable conflicts with template parameter: ' . $entry->name);
			}
			$result->declarations[$entry->token_index] = $entry;
		}
		$references /** vector<int> */ = $file->variable_references;
		foreach ($file->pending_bindings as $index) {
			$references[] = $index;
		}
		foreach ($references as $index)
		{
			$entry = $entries[$index];
			if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
				continue;
			}
			$entry_scope /** scope */ = object_cast(weakref_get($entry->scope), scope::class);
			$candidates /** vector<collected_name> */ = [];
			$variable_scope = Scope_Lookup::visible($entry_scope);
			while (true)
			{
				$candidates = $variable_scope->variables_named($entry->name);
				$parent = $variable_scope->parent_scope();
				if ((q_count($candidates) !== 0) || ($parent === null)) {
					break;
				}
				$variable_scope = $parent;
			}
			if (q_count($candidates) !== 1) {
				throw new \RuntimeException(("LLVM experiment needs one same-file declaration for " . $entry->name . " at token " . $entry->token_index));
			}
			if ($candidates[0]->collection !== $file) {
				throw new \RuntimeException('LLVM experiment needs one same-file declaration for ' . $entry->name . ' at token ' . $entry->token_index);
			}
			if (($entry->kind() === collected_name_kind::binding) && ($candidates[0]->token_index >= $entry->token_index)) {
				throw new \RuntimeException('Assignment requires an existing declaration');
			}
			$result->references[$entry->token_index] = $candidates[0];
		}
		foreach ($file->call_references as $index)
		{
			$entry = $entries[$index];
			if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
				continue;
			}
			$entry_scope /** scope */ = object_cast(weakref_get($entry->scope), scope::class);
			$current_scope = $entry_scope;
			$function_candidates /** vector<collected_function> */ = [];
			while (true)
			{
				$current_scope = Scope_Lookup::visible($current_scope);
				$function_candidates = [];
				$function_candidates = $current_scope->functions_named($entry->name);
				if (q_count($function_candidates) !== 0) {
					break;
				}
				$parent = $current_scope->parent_scope();
				if ($parent === null) {
					break;
				}
				$parent_scope /** scope */ = $parent;
				$current_scope = $parent_scope;
			}
			if (q_count($function_candidates) !== 1) {
				throw new \RuntimeException(("Expected one function target for " . $entry->name . " at " . $file->source_file()->path . ": token " . $entry->token_index));
			}
			$result->call_references[$entry->token_index] = $function_candidates[0];
		}
		foreach ($file->type_references as $index)
		{
			$entry = $entries[$index];
			if (($entry->changes === \scpp\compiler\SYNC_DELETED) || ($entry->kind() === collected_name_kind::field_declaration)) {
				continue;
			}
			$entry_scope /** scope */ = object_cast(weakref_get($entry->scope), scope::class);
			$current_scope = $entry_scope;
			while (true)
			{
				$current_scope = Scope_Lookup::visible($current_scope);
				if ($current_scope->has_template($entry->name)) {
					$result->template_slots[$entry->token_index] = $current_scope->template_slot($entry->name);
					break;
				}
				$type_candidates /** vector<collected_type_definition> */ = [];
				$type_candidates = $current_scope->source_types_named($entry->name);
				if (q_count($type_candidates) !== 0) {
					if (q_count($type_candidates) !== 1) {
						throw new \RuntimeException('Ambiguous struct type: ' . $entry->name);
					}
					// Parked LLVM retains its record-only admission; general type lookup does not widen it.
					$result->types[$entry->token_index] = object_cast($type_candidates[0], collected_record::class);
					break;
				}
				$parent = $current_scope->parent_scope();
				if ($parent === null) {
					break;
				}
				$parent_scope /** scope */ = $parent;
				$current_scope = $parent_scope;
			}
		}
		return $result;
	}
}
