# Changelog
Doc Status: supporting

This file is the authoritative checked-in source for release notes referenced by:

- `specs/git_workflow_release_procedure.md`

## Unreleased

## 0.1.76 - 2026-09-19

### Fixes

- Fixed `new Struct()` to construct a value for typed and inferred uses, including cross-file and imported declarations, while preserving shared ownership for ordinary classes (#229). Struct construction arguments and ownership-wrapper construction now produce source diagnostics.

### Additions

- No unrelated additions; this patch clarifies and implements no-argument struct value construction.

### Breaking Changes

- Inferred `new Struct()` expressions no longer acquire accidental shared ownership. Copies now follow the documented struct value semantics. Ordinary class construction is unchanged.

### Migration Notes

- Update the compiler and rebuild affected projects to regenerate C++. Use `new Struct()` without arguments; use the existing typed/keyed initializer form to initialize fields explicitly. Custom struct constructors are not supported.
- If shared object identity is required, use an ordinary class rather than relying on the previous struct-lowering bug.
- Existing advisory STAN limitations for imported aliases and ambiguous short names remain; this patch does not change the broader STAN name-resolution model.

## 0.1.75 - 2026-09-09

### Additions

- Added string and ordinary class fields in value structs, plus vector/hash/fixed-array compositions of supported field types. Struct copies preserve string/container values and share referenced class objects; `mixed`, `dynamic`, and managed union payloads remain excluded.
- Added compiler-support runtime APIs for source buffers and byte spans, source line indexes, fixed-width and enum hash keys, enum conversion/name helpers, vector reserve/capacity/compact/resize/fill operations, stable numeric hashes, and microsecond/nanosecond monotonic timers.
- Added explicit byte, UTF-8 codepoint, and grapheme string APIs; string-parts and contiguous text builders; and native row-arena, bitset, work-queue, little-endian binary-codec, and memory-accounting helpers.
- Added typed PHS/JSS runtime tokenizers and a compact token buffer with location accessors, whitespace/newline flags, and extended-length storage. Expanded scanner support for operators, keywords, decimal numbers, and multiline strings.
- Added runtime metadata exports and strict symbol-contract overlays for scalar types, operators, conversions, helpers, containers, and native ABI bridges, including integer/text/string bridges and `vector<int32>` bridge metadata. Metadata distinguishes available runtime support from source-consumption paths that remain blocked.
- Added dependency-scoped project-unit headers, source/dependency summaries, module public-surface validation, and build grouping policies. Grouped compilation is opt-in; module dependency/public API policies support report, warn, and fail modes.
- Added separate debug/release build roots, local object-action caching, reusable build-planner/source-inventory state, Ninja explain provenance, Clang time traces, and build-invalidation benchmarks.
- Added persistent STAN workers, semantic reuse for warm and method-body builds, and separate blocking/advisory analysis phases.
- Added reusable task worker pools, configurable pool sizing, ordered batch publication, publication batch caps, and task timing/lock diagnostics. The tasks module remains opt-in and experimental.
- Added const parameter support and struct member-access usability improvements.

### Fixes

- Fixed the long chained-string-concatenation transpiler hang reported in #214. This fix was already merged into main after v0.1.74 but had not appeared in a published release.
- Made JSON parse and encode failures recoverable through checked results, so a process can reject malformed input and continue with a later request (#226).
- Fixed decoded JSON conversion at required typed boundaries: invalid integer payloads and missing required values are rejected, and decoded arrays can initialize typed vectors recursively. Explicit source casts retain their coercing behavior.
- Restored missing-runtime-module errors in the fast STAN build gate, including JSS curl helpers; cached analysis preserves the same rejection.
- Restored Clang debug runtime-error source locations by preserving header/template debug information through precompiled headers.
- Fixed `scpp runtime-build` to build requested optional module artifacts even when the shared base runtime already exists.
- Corrected compiler-specific diagnostic test expectations and excluded mysqli-dependent native tests when the module is disabled.
- Separated STAN model-incomplete receiver/member findings from confirmed build-blocking source errors (#225), while preserving explicit enum, fixed-width integer, and other supported discipline checks.
- Fixed stale generated artifacts, unstable scoped-header hashes, unnecessary generated timestamp changes, and repeated dependency-summary work that increased rebuild fanout and warm-build cost.
- Fixed Ninja output draining to avoid deadlocks on large build output.
- Guarded the Unix memory-probe header so Windows builds do not require `sys/resource.h`.

### Breaking Changes

- PHP++ strict and legacy profiles now expose `json_decode` as `result<mixed>` and `json_encode` as `result<string>`, replacing their direct dynamic/string returns. JSS `json.decode` and `json.encode` follow the same checked contracts. Callers must unwrap with `take(...)` before consuming the value.
- JSON native decode/encode entry points and return contracts changed. Rebuild runtime artifacts and native consumers; old artifacts cannot satisfy the new checked decode/encode symbols.
- For consumers of earlier unreleased compiler-runtime branch snapshots, native token-buffer storage has changed: kind ids are `uint16`, normal lengths are `uint16` with an extended-length side table, and line/column values are derived from line-start offsets. Native `phs_tokenize_count` and `jss_tokenize_count` convenience functions were removed; use `token_buffer_count` with the corresponding tokenize-buffer call. Direct native field consumers must adapt.

### Migration Notes

- Follow [the JSON migration guide](docs/json_builtins.md#migrating-from-0174) for PHS and JSS examples. Parse/encode failures return the error branch; source `catch(Exception ...)` is not their recovery boundary. Valid JSON `null` and `false` remain successful values, and typed field conversion retains its separate runtime contract.
- Run `scpp run --force` to rebuild each consuming project and its runtime after updating; use `scpp run --mode=release --force` for release builds. Rebuild and deploy matching runtime/module artifacts for native or packaged consumers.
- Prefer token-buffer accessors over native column assumptions. Location accessors now derive positions; review workloads that repeatedly request every token's location.
- Treat build grouping, object caching, module policies, and task diagnostics according to their documented opt-in/default settings. This release does not add remote caching/execution or claim complete source consumption for every exported metadata family.
- Repo-local PHP++ and JSS Agent Skills were reviewed for this release candidate. JSON examples now unwrap checked results; adjacent stale error declarations and helper names were corrected.

### Known Limitations Retained From Earlier Versions

- Explicit top-level `return 0;` still fails compilation; let a successful script complete normally instead.
- Native nullable-integer prefix/postfix increment and result/error-sentinel equality remain incomplete. Extract and update a checked integer, or inspect result state explicitly with `has_error()` / checked `take(...)`.
- Mixed bool/int loose equality remains under contract review because runtime behavior and the native test disagree. Prefer explicit type stabilization or source strict identity (`===`). Namespace-alias imports also remain unsupported.

## 0.1.74 - 2026-07-01

### Additions

- Added compact-layout `struct` source support for PHS and JSS, lowering first-slice value structs as inline generated C++ storage instead of object/reference handles.
- Added fixed-backed enum lowering for compact discriminators such as `enum ExpressionKind : uint16`, with exact generated C++ storage width and range diagnostics.
- Added restricted payload `union` source support for PHS and JSS, including generated C++ unions, STAN/generator diagnostics, and native compile coverage for union-bearing structs.
- Added layout probes for generated type and field inspection: `layout_sizeof`, `layout_alignof`, `layout_offsetof`, and `layout_field_sizeof`.
- Added compact parsed-expression acceptance coverage demonstrating a 32-byte `CompactParsedExpressionRecord`, substantially below the previous 296-byte readable record baseline.

### Fixes

- Fixed cross-file enum and struct declaration-kind lowering so compact value types keep raw storage across project files.
- Fixed fixed-width integer default initializers such as `uint16 $x = 0` so they cast into the exact expected generated storage type.
- Tightened union payload validation to reject non-trivial struct payloads, containers, object/reference fields, methods, constants, defaults, inheritance, and nested union payloads in the V1 slice.

### Breaking Changes

- None

### Migration Notes

- Compact-layout declarations are a first-slice value-layout surface. Restricted unions intentionally exclude strings, vectors, hashes, object/reference types, defaults, methods, constants, inheritance, and nested union payloads.
- Existing class declarations keep the current object/reference-oriented model; use `struct` only for intended inline value storage.
- The compact parsed-expression acceptance fixture proves the language support needed for compiler row compaction, but the compiler's own resident parse model migration remains separate follow-up work.

## 0.1.73 - 2026-06-27

### Additions

- Added the initial developer-preview `ui` runtime module for native application windows across Windows 11, Linux, macOS, iOS, and Android backend boundaries.
- Added the initial developer-preview `webview` runtime module with WebView2, WebKitGTK, WKWebView, and Android WebView backends, including HTML/URL/app-folder loading, fire-and-forget JavaScript evaluation, browser-like events, and JavaScript-to-native message replies.
- Added strict PHP++ `ui_*` and `webview_*` helper surfaces, source-facing event accessors, shallow STAN/runtime symbol coverage, native smoke apps, screenshot artifacts, Android APK smoke packaging, and the golden `strict_webview_bridge` sample.
- Added `scpp docs ui-webview` with the preview API freeze, platform support promise, dependency checklist, diagnostics workflow, golden sample, and release gate.

### Fixes

- Improved WebView dependency diagnostics for Linux WebKitGTK and Windows WebView2 SDK setup, including clearer `scpp explain-build` output for implicit `webview -> ui` enablement and selected WebView backend.
- Stabilized hosted CI smoke behavior for Linux WebKitGTK and Windows WebView2 render/event timing, including screenshot capture and WebView2 readiness/message/title event probes.

### Breaking Changes

- None

### Migration Notes

- This is a developer preview, not a stable UI/WebView API guarantee. Menu bar, system tray, custom schemes, file chooser/download callbacks, rich JavaScript return-value marshalling, and full packaging flows remain future work.
- Strict projects must opt into the `webview` runtime module to use WebView helpers; `ui` is enabled implicitly when `webview` is requested.
- Linux WebView builds require GTK and WebKitGTK development packages. Windows WebView builds require the Microsoft.Web.WebView2 SDK at compile time; app users only need the installed Microsoft Edge WebView2 Runtime.

## 0.1.72 - 2026-06-26

### Additions

- Added fixed-width integer source and runtime support for `int8`, `int16`, `int32`, `int64`, `uint8`/`byte`, `uint16`, `uint32`, and `uint64`, backed by compact `int_t<Rep>` runtime storage.
- Added first-slice `fixed_array<T, N>` support backed by `fixed_array_t<T, N>`, including exact-size positional literals, indexed read/write, `count`, `empty`, `foreach`, function/local/property coverage, zero-size arrays, and nested vector elements.
- Added focused runtime, PHP, STAN, and fresh strict-project coverage for fixed-width integer locals, same-signed widening, signed/unsigned rejection, out-of-range literal blocking, and fixed-array language/runtime behavior.

### Fixes

- Made STAN reject out-of-range fixed-width integer literals and incompatible fixed-width assignments before C++ build while allowing same-signed widening.
- Disabled stale normal-PHP oracle checks for Prism-specific array and nullable tests so those suites validate the Prism runtime expectations directly.
- Updated strict authoring guidance for compact fixed-width integer storage and first-slice fixed-size arrays.

### Breaking Changes

- None

### Migration Notes

- Fixed-width integer signed/unsigned crossings and narrowing require explicit casts; same-signed widening is allowed.
- `fixed_array<T, N>` is for fixed-size sequential storage; append, unset, resize, keyed literals, and mixed/dynamic conversion are not part of this first slice.

## 0.1.71 - 2026-06-22

### Additions

- Added first-pass JSS support to the Simple C++ VS Code extension, including `.jss` language registration, syntax highlighting, snippets, project creation, JSS docs command, and STAN document routing.
- Added JSS-aware static completions for keywords, scalar/container types, visible `let` declarations, typed parameters, declared classes in type positions, and reserved helper families `fs`, `io`, `json`, and `dt`.
- Added JSS extension fixtures, a JSS smoke workspace, and completion tests for helper-family and visible-name completion behavior.

### Fixes

- Made the extension smoke opener prefer the project `entrypoint` from `prism.json`, so JSS smoke projects open the right source file.
- Added a shallow JSS document-symbol fallback for namespace, class, function, and `let` declarations while deeper semantic navigation remains STAN-owned.
- Updated VS Code extension documentation and manual validation notes for JSS build/run/debug expectations and current alpha limits.

### Breaking Changes

- None

### Migration Notes

- JSS extension support is editor and project-workflow support for the typed script-style compiled frontend, not JavaScript compatibility.
- Full debug stepping/source-map parity for original `.jss` lines remains an alpha validation item.

## 0.1.70 - 2026-06-16

### Additions

- Added the stackless async/await alpha core runtime with coroutine tasks, scheduler wakeups, timers, yield support, ready tasks, spawn helpers, and synchronous wait support.
- Added PHS `async function` and `await` source-surface support through pre-tokenizer normalization and async runtime lowering.
- Added JSS `async function` and `await` alpha support through the JSS-to-PHS path, preserving the typed compiled frontend model rather than JavaScript Promise compatibility.
- Added focused async runtime, PHS language, JSS lowering, and cross-surface project validation coverage, including 10 PHS and 10 JSS async test projects.
- Added async/await normative documentation plus release-validation guidance, onboarding updates, planning notes, and VS Code PHS grammar/snippet awareness.

### Fixes

- Added source-level diagnostics for `async_sleep_ms(...)` calls outside async functions.
- Improved STAN handling for direct `async_wait(...)` result unwrapping and JSS async summary extraction.
- Updated JSS and PHS guidance so agents and authors treat async/await as the current stackless alpha surface while fibers remain deferred.

### Breaking Changes

- None

### Migration Notes

- Fibers are not part of this release and remain deferred for later design and implementation.
- The existing `tasks` module remains the thread-backed parallel task surface; async/await is a lighter stackless runtime core and does not replace tasks.
- JSS async/await is not JavaScript Promise or event-loop compatibility mode. It lowers through PHS and `scpp::async_core`.
- `async_sleep_ms(...)` is only valid inside async functions; use `await` with async-producing expressions at the language surface.

## 0.1.69 - 2026-06-15

### Additions

- Added the JSS v1-alpha frontend preview with typed script-style `.jss` project support through the normal `.jss -> PHS -> build/run` path.
- Added JSS authoring documentation, AI-agent skill guidance, samples, and project-level validation coverage for helper-family flows such as `fs`, `io`, `json`, `dt`, `regex`, and `curl`.
- Added the tasks/threading batch API planning and runtime surface work from `codex/threading-batch-api-plan`.

### Fixes

- Stabilized project-wide JSS frontend classification across multi-file and multi-namespace projects, including member access, static access, helper-family lowering, and `take(...)` flows.
- Improved JSS diagnostics and source-first reporting for unsupported syntax, helper module requirements, runtime error paths, and classified frontend expressions.
- Fixed strict JSON dynamic-boundary behavior so `json.decode`/`json_decode` defaults to dynamic for JSS and PHS flows.
- Integrated the latest STAN strict-discipline, visibility, wrapper-boundary, runtime diagnostics, and VS Code extension metadata updates.

### Breaking Changes

- None

### Migration Notes

- JSS is an alpha preview for a typed scripting-looking compiled language, not JavaScript compatibility mode. Dynamic JavaScript semantics such as broad truthiness, `undefined`, optional chaining, and open object-bag behavior remain outside the current supported subset.
- The tasks/threading surface is early and should be treated as release-candidate feedback material until it has broader project validation.
- Agent Skill review completed: `.agents/skills/simple-cpp-jss/SKILL.md` documents the current JSS v1-alpha project authoring and validation flow.

## 0.1.68 - 2026-06-08

### Additions

- Added STAN interface implementation diagnostics for missing methods, return-type mismatches, parameter-count/type/name/default mismatches, and visibility mismatches.
- Added STAN abstract-contract diagnostics so concrete subclasses must implement inherited abstract methods before build.
- Added build-blocking classification for interface and abstract contract violations in strict projects.
- Added planning documentation for the issue #201 STAN strict-discipline close criteria.

### Fixes

- Fixed STAN return-path coverage for additional control-flow shapes.
- Fixed STAN property-initialization analysis across inherited constructor/property patterns.
- Fixed STAN wrapper-boundary and dynamic coalesce guard recognition so explicit guards avoid false positives while unchecked boundary use remains visible.
- Normalized strict STAN diagnostic buckets so strict-discipline and contract failures stop before C++ generation where appropriate.

### Breaking Changes

- Strict projects now reject more invalid interface/abstract implementations during STAN pre-build instead of allowing the generated C++ compiler or runtime behavior to surface the issue later.

### Migration Notes

- Make interface implementations exactly match the declared method contract, including visibility, parameter count, parameter types/names/defaults, and return type.
- Concrete subclasses of abstract classes must implement inherited abstract methods or remain abstract.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/SKILL.md` was updated to reflect STAN interface/abstract contract checks.

## 0.1.67 - 2026-06-07

### Additions

- Added STAN strict-discipline diagnostics for unchecked wrapper/result values assigned directly into required typed locals.
- Added STAN dynamic-shape boundary warnings for JSON/dynamic values assigned directly into required typed locals without an explicit guard.
- Added source-level compile diagnostic polish for typed argument mismatches so common call-site failures are reported in source terms while preserving the raw compiler excerpt.
- Added structured vector bounds runtime diagnostics with source remapping, source snippets, operation details, failing index, and container size.

### Fixes

- Fixed STAN diagnostics-session override accounting so transient override runs no longer overwrite canonical cache state or report dependency-driven reanalysis as extra changed sources.
- Fixed the strict safety edges suite so long runs emit visible progress and avoid repeated runtime rebuild work that could look like a no-output timeout.
- Fixed source-mapped runtime reporting for vector bounds failures so they no longer fall back to generic typed-boundary messages.

### Breaking Changes

- None

### Migration Notes

- Check STAN warnings for direct wrapper/dynamic-to-required typed-boundary assignments and stabilize values with `take(...)`, `isset(...)`, or another explicit guard where appropriate.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/SKILL.md` was updated to reflect the stricter STAN discipline and source-first diagnostics guidance.

## 0.1.66 - 2026-06-07

### Additions

- Added recursive typed vector literal stabilization, including nested `vector<vector<T>>` and deeper vector shapes.
- Added direct decoded JSON array stabilization into typed vectors, including nested typed vectors and explicit typed-boundary failures for incompatible array shapes.
- Added typed `json_encode` support for typed vectors, hashes, and nested vector values through the runtime JSON encode adapter.
- Added STAN detection for obvious direct self-recursive return paths, plus configurable runtime call-depth guard diagnostics when STAN is bypassed.

### Fixes

- Fixed strict required typed-boundary conversions so missing or null dynamic JSON fields no longer silently become default-looking required scalar values.
- Fixed strict required `int` boundaries so dynamic JSON floats and numeric strings no longer silently coerce into integers.
- Fixed missing-return handling so typed functions that may exit without returning stop during STAN pre-build instead of reaching native undefined behavior.
- Fixed strict regex helper use without the regex runtime module so it reports an early source/build diagnostic instead of falling through to an undefined-symbol link failure.
- Fixed Prism++ member visibility alignment so STAN now rejects invalid access to private/protected properties, static properties, methods, and class constants before C++ generation, while preserving valid protected subclass access and avoiding false positives for enum case references.

### Breaking Changes

- Dynamic values assigned into required typed scalar or typed vector boundaries are stricter: absent, null, or incompatible dynamic shapes now fail instead of silently coercing into usable required values.

### Migration Notes

- Use explicit casts when intentionally applying PHP-like scalar coercion; required typed locals/properties now behave as checked stabilization boundaries.
- Add the `regex` runtime module before using strict regex helpers.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/SKILL.md` was updated to reflect the stricter JSON typed-boundary and visibility guidance.

## 0.1.65 - 2026-05-27

### Additions

- Added `scpp stan --help` so the advisory-analysis command now exposes its own minimal CLI guidance instead of failing on the flag.

### Fixes

- Fixed STAN debug-preview follow-up regressions by accepting shorthand dump expressions like `bag` in source-targeted `--dump-before` and `--dump-after` actions, broadening `--call` resolution across practical static-method naming shapes, and smoothing debug startup when a reusable runtime artifact is missing.
- Fixed STAN freshness across dependency-only edits by widening the advisory source fingerprint to include the resolved project dependency graph, storing that fingerprint in STAN workspace state, and refusing to reuse stale per-file summaries when the dependency-visible source surface changes.
- Fixed explicit `scpp stan` runs so they now republish fresh `.prism/cache/stan_status.json` and `.prism/cache/stan_report.json` artifacts for the active fingerprint instead of returning only an in-memory result.
- Fixed the reported dependency-symbol repro path so fresh STAN pre-build checks now stop the build early with `unresolved_call` diagnostics instead of allowing stale ready-state reuse to hide the missing dependency export.

### Breaking Changes

- None

### Migration Notes

- Dependency-only edits may now invalidate STAN advisory reuse more aggressively because the cached workspace state tracks the broader project/dependency source fingerprint instead of only the root project files.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the shipped changes harden debug/STAN workflow behavior without changing the current strict authoring guidance.

## 0.1.64 - 2026-05-27

### Additions

- Added a debug-preview `scpp debug` surface with source-targeted `--break`, `--exit`, `--dump-before`, and `--dump-after` actions that rewrite only the explicitly targeted `file:line` sites for a given debug run.
- Added structured debug-session artifacts and bounded slot-based debug workspaces under `.prism/debug/slots/`, including saved plans, events, rewritten source previews, and rewritten-source line maps for agent/operator inspection.
- Added preview callable and expression execution through `scpp debug --call`, `--call-this`, and `--exec`, backed by a new runtime-owned JSON conversion surface at `runtime/include/scpp/json/from_json.hpp`.
- Added VS Code preview support for inspecting latest/recent debug slots plus a first-pass `simplecpp-debug` DAP scaffold for launch, breakpoints, stop events, restart, and light variable display from saved events.
- Added an agent-facing debug preview testing guide at `docs/debug_preview_agent_guide.md` to make the current preview scope and known limits explicit.

### Fixes

- Fixed debug architecture drift by unifying the active implementation around one source-rewrite path for simple explicit source-site actions instead of keeping parallel generator-hook and rewrite models alive.
- Fixed debug failure reporting so build/runtime failures now emit stronger structured debug events with clearer categories, subcategories, and guidance for common preview failure modes.
- Fixed debug workspace cleanup behavior by replacing the unbounded per-session layout with reusable slot allocation, slot expiry, and stable per-slot metadata/index files.
- Fixed VS Code-side debug inspection ergonomics by adding internal helpers and commands that resolve the current project, discover the latest slot, and open saved debug artifacts from one place.

### Breaking Changes

- None

### Migration Notes

- This release should be treated as a debug preview, not a finished interactive debugger.
- Source-targeted debug events currently report rewritten debug-source line numbers for the active run instead of remapping back to original pre-rewrite line numbers.
- Instance-method `--call-this` only succeeds when the receiver type has a real `from_json<T>` conversion path; otherwise the failure is expected to surface clearly during build/runtime conversion.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the shipped changes add debug-preview CLI/runtime/VS Code support without changing the current strict authoring guidance.

## 0.1.63 - 2026-05-26

### Additions

- Added an opt-in `--timings` flag for `scpp build` and `scpp run` so warm-build investigation can print the internal `execute_build()` timing breakdown without changing normal build output.
- Added focused regression coverage for Windows doctor warnings, Windows temp fallback handling, and the new build/run timings option parsing.

### Fixes

- Fixed Windows doctor output so it now warns when `C:\msys64\mingw64\bin` is present without `C:\msys64\usr\bin`, which can break MinGW compiler frontends with startup or entry-point failures.
- Fixed Windows build/run subprocess handling so bad `TMP` or `TEMP` resolution, especially under `C:\Windows`, is detected and redirected to a writable fallback directory for child compiler/runtime processes when possible.
- Fixed Windows GNU-like runtime linking and Ninja command execution so native Git Bash / MSYS builds can succeed more reliably with the installed `scpp` launcher and shared runtime reuse flow.

### Breaking Changes

- None

### Migration Notes

- Use `scpp build --timings` or `scpp run --timings` when you want the build-stage timing breakdown during performance investigation; normal invocations stay quiet by default.
- On Windows, `scpp --doctor` now reports common MSYS2 PATH and temp-directory misconfigurations that previously surfaced only as downstream compiler failures.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this hotfix to reflect the shipped `--timings` workflow and Windows diagnostics guidance.

## 0.1.62 - 2026-05-25

### Additions

- Added STAN build-worker regression coverage for the live-worker request/heartbeat/status/report handshake used by warm `scpp build` runs.
- Added editor/navigation metadata so STAN hover payloads can surface function, method, and property signatures in the merged VS Code extension workflow.
- Added a bundled multi-file STAN smoke workspace, npm check script, and merged extension-host commands for the repo-local `Simple C++` VS Code extension workspace.

### Fixes

- Fixed `scpp build`/`scpp run` release guidance so the normative build spec and STAN handoff now document the active STAN pre-build check, the `--no-stan` bypass, and the current root-project-only fingerprint limitation.
- Fixed the VS Code extension packaging/layout by consolidating the standalone `tools/vscode-stan-lsp` scaffold into `tools/vscode_phs_extension/extension`, wiring in STAN-backed diagnostics/navigation commands, and removing the obsolete standalone extension tree.
- Fixed STAN editor hover/navigation output so symbol-indexed functions, methods, and properties preserve enough signature/type detail for richer hover results in smoke cases.

### Breaking Changes

- None

### Migration Notes

- `scpp build` and `scpp run` now treat STAN as a normal pre-build check unless `--no-stan` is passed explicitly for that invocation.
- Warm STAN reuse currently fingerprints only the root project's `prism.json` plus root-project `*.phs` / compatible `*.php` sources; dependency-only edits remain a known early-release freshness limitation until a later follow-up expands the fingerprint.
- VS Code smoke/development work should now use `tools/vscode_phs_extension/extension` and the bundled `smoke-workspace.code-workspace` instead of the old standalone `tools/vscode-stan-lsp` folder.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this release to reflect the shipped STAN-backed build workflow and `--no-stan` escape-hatch guidance.

## 0.1.61 - 2026-05-22

### Additions

- Added focused regression coverage for typed vector literal reassignment and const-parameter `foreach` handling.
- Added focused runtime-diagnostics regression coverage for source-mapped runtime failures, compact trace display, and saved trace/report behavior.
- Added stricter authoring guidance for decoded JSON boundaries across the quick-learn, JSON docs, and strict agent skill references.

### Fixes

- Fixed strict typed vector lowering so array-literal reassignment and typed call arguments preserve the intended typed-container path instead of degrading through weaker untyped lowering.
- Fixed runtime `foreach` support for const typed vectors so strict helper-style iteration over typed vector parameters works cleanly.
- Fixed runtime failure presentation so `scpp run` and `scpp error` now prefer a source-first view with remapped file/line, tiny source snippets, and source-backed trace entries instead of leaking generated/runtime trace detail by default.
- Fixed saved runtime diagnostics so compact debug trace data can be preserved and surfaced through `scpp error` while deeper generated/runtime trace detail remains available through `scpp full-error`.

### Breaking Changes

- None

### Migration Notes

- No source migration is required for existing supported code.
- Strict projects now get a quieter, source-first runtime failure experience by default; use `scpp error` for the richer saved summary and `scpp full-error` for full JSON plus deeper generated/runtime trace detail.
- For decoded JSON in strict code, the recommended posture is now documented explicitly: treat `json_decode(...)` as a fat-variable boundary, describe known payload shape locally, and stabilize early into typed locals, properties, objects, or typed containers.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this release to reflect the new runtime-diagnostics guidance and strict JSON-boundary authoring guidance.

## 0.1.60 - 2026-05-21

### Additions

- Added a focused Phase 1 strict regression that covers first-class `dynamic` locals, parameters, returns, properties, aliasing behavior, typed `hash<dynamic>` / `vector<dynamic>` containers, `count(dynamic)`, and null/default helper cases.

### Fixes

- Promoted source-level `dynamic` to a first-class Phase 1 type that now lowers to `dynamic_t<>` instead of collapsing back into `mixed_t`.
- Fixed generator lowering for first-class `dynamic` reads, writes, and typed-boundary propagation so `dynamic` locals, properties, parameters, and returns preserve the intended shared-handle behavior.
- Fixed runtime bridge and helper coverage so `count(dynamic)`, `isset(dynamic[key])`, and `empty(dynamic[key])` work consistently with the shipped Phase 1 contract, including null/default dynamic cases.

### Breaking Changes

- None

### Migration Notes

- Existing `mixed`-based dynamic code continues to work.
- Strict code may now use first-class `dynamic` when the intent is shared mutable object/table state with reference-like aliasing semantics.
- `mixed` remains the broad boxed dynamic value surface; `dynamic` is now the preferred source type for shared dynamic object/table handles.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this release to reflect the first-class `dynamic` authoring guidance.

## 0.1.59 - 2026-05-21

### Additions

- Added a focused strict CLI regression test that builds and runs author-facing `dynamic` local declarations together with `hash<dynamic>` usage.

### Fixes

- Fixed generator type lowering so author-facing `dynamic` now follows the supported dynamic carrier path instead of falling through as a user-defined class-like type during lowering and C++ emission.
- Fixed `hash<dynamic>` lowering so strict code can use the same dynamic carrier behavior already supported by `mixed`, which unblocks the current ORM writer hotfix path.

### Breaking Changes

- None

### Migration Notes

- Existing `mixed`-based dynamic code continues to work unchanged.
- Strict code may now use `dynamic` as an author-facing alias for the existing dynamic carrier path when that spelling is clearer than `mixed`.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this hotfix because the shipped change expands the author-facing strict dynamic-type guidance.

## 0.1.58 - 2026-05-21

### Additions

- Added focused tool/runtime regression coverage for shared release runtime preparation, release-runtime module layout, invalid cached dependency recovery, and reuse-mode build behavior.
- Added a planning anchor for the shared release runtime cache phase-1 rollout so the release/runtime reuse model has a resumable implementation record.

### Fixes

- Fixed runtime cache writes during reuse builds so warm project builds no longer destabilize the reusable runtime state while reusing cached artifacts.
- Fixed reuse-mode dependency validation so stale or invalid cached dependency objects now fail with a first-class recovery message instead of falling through toward less actionable native build failures.
- Fixed shared runtime placement and module artifact composition so release-owned runtime families are prepared and reused through a clearer shared-runtime layout instead of continuing to fan out through fragile local cache identities.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- If a warm `scpp build` reports missing or invalid reusable runtime or dependency artifacts, rerun with `--build-runtime`, `--build-dependencies`, or `scpp runtime-build` to refresh the corresponding cached artifacts explicitly.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the shipped changes restructure runtime/build reuse behavior and diagnostics without changing the current repo-local authoring guidance.

## 0.1.57 - 2026-05-20

### Additions

- Added a strict-mode idioms cookbook to the quick-learn and aligned strict-skill references so common real-project authoring patterns are easier to discover.
- Added focused strict regression coverage for recent repro shapes, including unqualified helper resolution, string/null ternary handling, and vector `unset(...)`.

### Fixes

- Fixed strict build diagnostics so runtime-reuse builds now fail before Ninja with a first-class reusable-runtime-artifact message when the expected shared runtime artifact is missing.
- Fixed the saved diagnostics flow for that preflight path so `scpp error` and `scpp full-error` continue to work even though Ninja never starts.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- If `scpp build` or `scpp run` reports a missing reusable runtime artifact in reuse mode, run `scpp runtime-build` or retry with `--build-runtime` to refresh the runtime cache explicitly.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was reviewed and updated for this release to reflect the new strict-mode cookbook guidance.

## 0.1.56 - 2026-05-19

### Additions

- Added focused pre-tokenizer regression coverage for prefix generic by-reference parameters in strict code.
- Added focused tool/runtime regression coverage for strict `getenv(...)`, condition-visibility diagnostics, and `mysqli_result` exhaustion semantics.
- Added a native runtime mysqli exhaustion regression that verifies result consumption now terminates with `null`.

### Fixes

- Fixed strict pre-tokenizer handling so prefix generic by-reference parameters such as `vector<mixed> &$rows` normalize correctly before parsing.
- Fixed strict builtin routing so `getenv(...)` resolves through a strict-friendly wrapper instead of falling through toward raw C `getenv(...)`.
- Fixed strict block-visibility diagnostics for assignment-in-condition patterns so the generator now points authors toward the canonical explicit rewrite.
- Fixed `mysqli_result::fetch_assoc()` and `fetch_row()` exhaustion behavior so finite result sets now return `null` at end-of-result instead of an empty dynamic row value.

### Breaking Changes

- None

### Migration Notes

- No source migration is required for existing supported code.
- Strict code may now use prefix generic by-reference parameter forms that are normalized by the scanner-owned pre-tokenizer path.
- Strict `getenv(...)` now follows the expected string-or-false wrapper contract.
- Result-consuming mysqli loops that wait for `fetch_assoc() === null` now terminate as expected on finite result sets.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the shipped changes affect generator/runtime behavior, diagnostics, and regression coverage without changing the current repo-local skill instructions.

## 0.1.55 - 2026-05-19

### Additions

- Added exact strict regression coverage for mixed runtime type predicates so `is_bool(...)`, `is_int(...)`, and `is_float(...)` on `mixed` stay pinned in the strict surface.
- Added strict regression coverage for `php::microtime(true)` so PHP helper namespace static calls stay lowered without the invalid `_static<php>` template-argument shape.
- Added a focused shared-runtime concurrency regression check that launches two real `scpp build --build-runtime --build-dependencies` CLI builds in parallel and verifies runtime-reuse behavior without warning leakage.
- Added a strict `mysqli` runtime-link regression test so strict projects with `"modules": ["mysqli"]` keep end-to-end build coverage for the `scpp::mysqli` wrapper family.

### Fixes

- Fixed strict mixed type predicate exposure so `is_bool(...)`, `is_int(...)`, and `is_float(...)` on `mixed` now compile and route through the intended strict helper surface.
- Fixed strict string helper exposure so `str_contains(...)` is available again in strict projects with the expected boolean contract.
- Fixed instance-method override dispatch through base-class methods by restoring virtual dispatch for ordinary generated instance methods, so `$this->method()` inside a base method correctly reaches child overrides.
- Fixed concurrent shared runtime rebuild hardening so parallel `--build-runtime --build-dependencies` activity now stays quiet at the shared runtime directory-creation boundary instead of leaking a benign `mkdir(): File exists` PHP warning.
- Fixed strict `mysqli` runtime linking so strict projects now include the `php_mysqli` wrapper implementation in the composed runtime artifact instead of compiling headers successfully and then failing at final link with unresolved `scpp::mysqli*` symbols.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- Strict projects may use `is_bool`, `is_int`, `is_float`, and `str_contains` directly again under the restored helper surface.
- Strict projects using the `mysqli` runtime module should now be able to build against the `scpp::mysqli` wrapper family without local runtime-composition patching.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the shipped changes affect generator/runtime behavior, build orchestration, and regression coverage without changing the current repo-local skill guidance.

## 0.1.54 - 2026-05-19

### Additions

- Added exact regression coverage for the `0.1.53` late-static repro shapes reported on issue `#135`, including the class-local single-call case and the inherited `B::run(); C::run();` dispatch case.
- Added first-pass file-local authoritative generator catalog rows for late-static property, method, constant, and construction forms, plus aligned class-constant declaration/access rows.

### Fixes

- Fixed PHP-shaped late-static method dispatch so generated `void` helper branches now return after the matched target call instead of falling through to the lexical fallback path.
- Fixed the inherited `static::method(...)` case reported on issue `#135` so `B::run()` and `C::run()` now preserve called-class semantics in the covered file-local flow instead of producing duplicate or fallback calls.
- Fixed the authoritative generator docs so the checked-in normative surface now matches the current first-pass late-static implementation rather than documenting stale `static::` rejections.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- `static::method(...)`, `static::$prop`, `static::CONST`, and `new static(...)` remain first-pass file-local lowering features; cross-source-file late-static rebinding is still out of scope.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the release changes generator/runtime late-static behavior, tests, and authoritative docs without changing the current repo-local skill instructions.

## 0.1.53 - 2026-05-19

### Additions

- Added first-pass support for `static::method(...)` in the PHP S2S generator through a small template-guard late-static scope helper plus generated per-class dispatch helpers.
- Added focused regression coverage for inherited late-static method dispatch so forms like `B::run()` reaching `static::hello()` inside inherited static code now stay pinned by tests.
- Added planning notes for the current template-guard implementation direction and for a possible v2 CRTP-like specialization follow-up.

### Fixes

- Fixed the generator so `static::method(...)` is no longer rejected outright in the covered class-local static-method flow.
- Fixed inherited static dispatch so C++ lowering now preserves the PHP-shaped called-class behavior for the first-pass supported `static::method(...)` cases instead of collapsing to ordinary lexical static lookup.

### Breaking Changes

- None

### Migration Notes

- `static::method(...)` is now supported as a first-pass class feature for the covered static-method flow; `static::$prop`, `new static`, and related late-static forms remain unsupported.
- No source migration is required for existing code that already avoided `static::...`; isolated repros and simple inherited static dispatch patterns can now use `static::method(...)` directly.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this release because the existing repo-local skill guidance does not document or contradict the new first-pass late-static method support.

## 0.1.52 - 2026-05-19

### Additions

- Added focused tool-level regression coverage that checks `scpp build --build-runtime` emits a project-local `build.ninja` in runtime-reuse mode instead of embedding shared-runtime compile/link rules directly.

### Fixes

- Fixed a regression in the reusable runtime build path so `scpp build --build-runtime` once again prebuilds the shared runtime artifact before rendering the project-local Ninja graph.
- Fixed reusable runtime publication so guarded `flock(...)` plus temp-file and atomic-rename publication are restored for shared runtime object/library outputs.
- Fixed the remaining `#126` race shape where concurrent `--build-runtime` calls could still expose transient invalid shared runtime artifacts such as `runtime.o` during parallel builds.
- Fixed the build-reuse integration tests so strict standalone subcases explicitly seed runtime when that is part of the scenario instead of depending on ambient runtime-cache state.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- `scpp build --build-runtime` should again behave as a guarded reusable-runtime refresh rather than embedding direct shared-runtime rebuild steps into each project-local Ninja graph.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix because the change affects build/runtime orchestration and tool validation rather than strict authoring guidance.

## 0.1.51 - 2026-05-19

### Additions

- Added a planning note under `specs/planning/` that records the PHP library contract-alignment policy for shared helper names across `legacy` and `strict`.
- Added focused strict regression coverage for `strpos(...) === false` / `!== false` control flow so issue `#132` stays pinned.

### Fixes

- Fixed shared helper contracts so `legacy` and `strict` now preserve the same visible branch model for common helper names instead of silently diverging through profile-specific carriers.
- Fixed `strpos(...)` and `strrpos(...)` so the shared plain-name calls now expose `result_or_false<int_t>` semantics instead of leaking nullable search behavior into author-facing control flow.
- Fixed `hex2bin(...)` and `shell_exec(...)` so shared falseable helpers now use explicit `result_or_false<string_t>` contracts instead of broad `mixed_t` return shaping.
- Fixed `explode(...)` / `implode(...)` shared-name alignment so `explode(...)` returns `vector_t<string_t>` and `implode(...)` returns `string_t` while still accepting array-like `mixed_t` inputs with a guarded runtime-kind check.
- Fixed strict routing, runtime adapters, docs, examples, and regression coverage so the shared PHP-like helper surface stays contract-first across both profiles.

### Breaking Changes

- None

### Migration Notes

- Shared helper names such as `strpos`, `strrpos`, `hex2bin`, `shell_exec`, `explode`, and `implode` should now be read with the same visible contract in both `legacy` and `strict`.
- For shared falseable helpers, use explicit branch checks rather than nullable expectations; `strpos(...) === false` and `!== false` are now the intended control-flow shape again.
- `explode(...)` should be treated as typed `vector_t<string_t>` output, while `implode(...)` accepts typed vectors, typed hashes, or array-like `mixed_t` values and throws for non-array-like runtime kinds.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix because the existing strict-skill guidance already matches the restored shared-helper authoring posture.

## 0.1.50 - 2026-05-19

### Additions

- Added a planning note under `specs/planning/` that defines the contract-first helper unification policy for shared strict and legacy helper names.
- Added focused strict regression coverage for `shell_exec(...)` so the shared helper contract stays pinned in strict mode.

### Fixes

- Fixed strict shared helper resolution so plain names that also exist in legacy now preserve the same visible branching model instead of silently exposing stricter wrapper-only contracts.
- Fixed strict `strpos(...)` and `strrpos(...)` exposure so shared plain-name calls preserve the expected `int|false` contract instead of leaking internal nullable search semantics into author-facing control flow.
- Fixed strict `hex2bin(...)` exposure so the shared plain-name call preserves the expected `string|false` contract instead of exposing internal structured-error helper behavior.
- Fixed strict `explode(...)` and `implode(...)` shared-name composition so the plain PHP-like helper pair continues to work naturally under the restored contract-first surface.
- Fixed strict onboarding, profile docs, builtin contracts, examples, and checked-in tests so they now teach and enforce the contract-first rule consistently across shared helper names.

### Breaking Changes

- None

### Migration Notes

- Shared helper names such as `strpos`, `strrpos`, `hex2bin`, `explode`, `implode`, and `shell_exec` should now be read with the same visible branch contract in both `legacy` and `strict`.
- In strict projects, if a helper keeps a plain shared name, prefer the same control-flow habit you would use for the legacy PHP-shaped contract.
- Subsystem/domain helper families remain explicitly prefixed in strict mode, including `fs_*`, `io_*`, `regex_*`, `curl_*`, and `dt_*`.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix because the release changes policy/docs/tests/runtime helper routing without changing repo-local skill instructions.
## 0.1.48 - 2026-05-18

### Additions

- Added exact regression coverage for `isset($object->typedHash[$missingKey])` on typed-hash object properties and for literal strict ternary branches that mix `"text"` with `null`.

### Fixes

- Fixed keyed `isset(...)` lowering for typed-hash property paths so forms like `isset($b->items[$missing])` now stay on the keyed runtime helper path and return `false` for missing keys instead of lowering through `hash_t::at(...)` and throwing.
- Fixed strict ternary branch normalization so value-like branch pairs such as `"ok" : null`, `null : "ok"`, and matching `nullable<T>` with `null` normalize through `nullable<T>` in the runtime helper instead of failing with an incomplete `condition_ternary_result<..., null_t>` instantiation.

### Breaking Changes

- None

### Migration Notes

- No source migration is required.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix because the fixes only adjust runtime/helper and generator lowering behavior without changing the authored strict surface.

## 0.1.47 - 2026-05-18

### Additions

- Added a planning note under `specs/planning/` that records the v1 helper-naming simplification direction for strict projects.

### Fixes

- Fixed strict PHP helper resolution so common language-adjacent helpers such as `trim`, `ltrim`, `rtrim`, `substr`, `substr_compare`, `substr_replace`, `explode`, `implode`, `hex2bin`, `bin2hex`, `number_format`, `strlen`, `strpos`, `strrpos`, `strtolower`, `strtoupper`, `lcfirst`, and `ucfirst` resolve by their plain PHP-like names again in strict projects.
- Fixed strict onboarding, profile docs, examples, and checked-in PHP tests so they teach and exercise the restored plain helper surface consistently instead of the old `str_*` variants for those general helpers.
- Fixed repo-local strict Agent Skill guidance so the skill and its references now match the current strict helper naming surface.

## 0.1.46 - 2026-05-18

### Additions

- Added focused regression coverage for `string|null` ternary lowering, indexed `unset()` on `vector<>`, keyed `unset()` on typed `hash<>`, and friendly `.phs` `<?php` source-header diagnostics.

### Fixes

- Fixed `string|null` union lowering so strict typed paths normalize nullable string unions consistently instead of degrading to non-null `string_t` handling.
- Fixed indexed `unset($vector[$i])` so typed `vector<>` values now lower through keyed unset support and compact remaining elements safely.
- Fixed keyed `unset()` coverage for typed `hash<>` containers so the supported keyed-unset path is pinned by regression tests alongside the vector change.
- Fixed `.phs` source diagnostics so files that begin with `<?php` now fail early with a friendly unsupported-source message instead of surfacing an internal parser error.

### Breaking Changes

- None

### Migration Notes

- In strict projects, prefer the restored plain helper names for general language-adjacent helpers such as `trim`, `substr`, `explode`, `implode`, `hex2bin`, `strlen`, and `strtolower`.
- Subsystem/domain helper families remain prefixed in strict mode, including `fs_*`, `io_*`, `json_*`, `dt_*`, and `regex_*`.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was updated for this hotfix to reflect the restored strict helper naming surface.
- No source migration is required.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix because the existing strict-skill guidance already forbids leading `<?php` in `.phs` files and the other fixes do not change authoring workflow guidance.

## 0.1.45 - 2026-05-17

### Additions

- Expanded `scpp explain-build` with focused views for `files-transpiled`, `files-reused`, `outputs-rebuilt`, `entrypoint`, `final-output`, `generated-files`, and `ninja-target`.
- Added direct Ninja target guidance to `scpp explain-build`, including a ready-to-run `ninja -C ... -d explain ...` hint for the current executable target.

### Fixes

- Fixed build-report visibility so `scpp explain-build` now surfaces concrete source-to-generated/object/output mappings instead of only a high-level rebuild summary.
- Fixed explain-build usability so it now warns that path-shaped executable outputs such as `.prism/build/main` are not valid Ninja target names.
- Fixed documentation gaps after `scpp update` by documenting a one-time `scpp clean` plus rebuild troubleshooting step for stale per-project `.prism/` state.

### Breaking Changes

- None

### Migration Notes

- Use the focused `scpp explain-build` views when you need one exact answer instead of the full summary, especially for transpile decisions, final output paths, generated files, or direct Ninja debugging.
- After `scpp update`, if an existing project behaves oddly and the same problem does not reproduce in a fresh project, try `scpp clean` followed by `scpp build` once to refresh stale `.prism/` state.
- Agent Skill review completed: no `.agents/skills/*` updates were required for this hotfix; the release updates `specs/simple_cpp_php_strict_quick_learn.md` and related build/docs guidance only.

## 0.1.44 - 2026-05-17

### Additions

- Added a runtime-chain-safety planning note under `specs/planning/` plus a v2 planning note for future guarded nullable-path evaluation ideas.

### Fixes

- Fixed plain nullable/object-handle chain access so the covered `shared_p`, `unique_p`, and `nullable` operator paths raise a controlled runtime exception instead of crashing natively on null access.
- Fixed general chained `isset(...)` probing so forms like `isset($root->child->name)` lower through a safe runtime probe path instead of forcing ordinary eager chain evaluation.

### Breaking Changes

- None

### Migration Notes

- Prefer `isset($node->child->name)` or `!isset($node->child->name)` for nullable path guards instead of long manual `=== null || ...` chains.
- A direct nullable/object-handle chain like `$root->child->name` now fails with a project-shaped runtime exception where the covered wrappers previously could crash the process.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` and `specs/simple_cpp_php_strict_quick_learn.md` were updated for this hotfix.
## 0.1.43 - 2026-05-16

### Additions

- Added an opt-in `curl` runtime module backed by libcurl, with explicit build-time detection and clear failure messages when the module is enabled but libcurl support is unavailable.
- Added strict `curl_*` authoring support for handle-oriented request flows, including local file transport, local HTTP server flows, and opt-in external HTTPS coverage.
- Added legacy PHP-curl wrapper coverage over the first-pass runtime surface so legacy-profile projects can exercise matching `curl_*` flows for file, HTTP GET, POST, and JSON round-trips.
- Added curl-focused native runtime tests, strict sample projects, strict and legacy PHP test suites, and harness support for per-test runtime modules, local PHP test servers, and opt-in external-network runs.

### Fixes

- Fixed runtime-module propagation so app compilation inherits curl module compile definitions consistently when a project enables `runtime.modules = ["curl"]`.
- Fixed profile-specific runtime symbol loading so legacy PHP generation no longer gets strict runtime symbol mappings merged over legacy entries.
- Fixed PHP test harness project materialization so reruns do not keep stale per-test files that can interfere with HTTP fixture-backed curl tests.

### Breaking Changes

- None

### Migration Notes

- Projects that want curl support must enable the opt-in `curl` runtime module in `prism.json` and have libcurl development headers available at build time.
- Network-backed curl regression coverage is intentionally opt-in; pass `--include-network` to `tests/tools/run_tests.php` when you want the GitHub HTTPS integration test to run.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was updated to reflect curl-capable strict module guidance for this release.

## 0.1.42 - 2026-05-16

### Additions

- Added a planning catalog for typed `hash<>` `foreach` expectation-gap, control, and regression-guard examples under `specs/planning/`.
- Added a generator audit note for the typed `hash<>` `foreach` stabilization work, documenting current causes and possible generator-side solution directions.

### Fixes

- None

### Breaking Changes

- None

### Migration Notes

- These planning notes do not change runtime, generator, or user-facing language semantics; they are working documents intended to support future implementation passes.
- Agent Skill review completed: no `.agents/skills/*` updates are required for this release because the release adds planning documentation only.

## 0.1.41 - 2026-05-16

### Additions

- Added regression coverage for typed `hash<>` `foreach` flows over non-`this` method-call sources and locals initialized from those method calls.

### Fixes

- Fixed typed `hash<>` `foreach` lowering so known typed method-call sources no longer lose their declared return type merely because the source is not `this`.
- Fixed typed `hash<>` `foreach` loop-local binding so unknown non-dynamic sources no longer silently degrade into `mixed_t`, which previously pushed downstream lowering toward dynamic `.get(...)`, keyed field-write fallbacks, and synthetic repair casts.
- Fixed typed `hash<>` `foreach` flows so nullable-string helper boundaries, typed object field access, and typed reindexing continue to lower through the concrete runtime iterator key/value contract.

### Breaking Changes

- None

### Migration Notes

- Re-run typed `hash<>` `foreach` cases that previously needed defensive key/value stabilization or produced dynamic-object fallback lowerings; direct key-helper usage and typed property access should now stay on the typed path for the covered generator flows.
- Agent Skill review completed: no `.agents/skills/*` updates are required for this hotfix because the existing strict authoring guidance already matches the user-facing typed-hash `foreach` behavior after this generator fix.

## 0.1.40 - 2026-05-12

### Additions

- Added a safer browser-test-ui subprocess environment so PHP, Ninja, and compiler runs no longer inherit unrelated Apache or PHP-FPM request variables.

### Fixes

- Fixed the browser test UI so headerless `.phs` manual input is executed through the same PHP-compatibility wrapper used by the real Prism++ loader, instead of being echoed back as raw source text.
- Fixed the browser test UI AST and token debug fixture path so pre-tokenized manual input is parsed through the shared PHP-compatibility adapter instead of a raw headerless parse path.
- Fixed the browser test UI manual-input sandbox flow so a stale legacy `sandbox/src/alt.php` scaffold file no longer poisons unrelated one-file `scpp build` runs.
- Fixed the browser test UI compile/run path so the stable `/simple-cpp/stable/test/` harness successfully builds and executes the generated C++ sample again.

### Breaking Changes

- None

### Migration Notes

- The browser test UI now forwards only a small safe allowlist of environment variables into child PHP, Ninja, and compiler processes; ad hoc CGI-style request variables are no longer part of that subprocess contract.
- Agent Skill review completed: no `.agents/skills/*` updates are required for this hotfix because the existing guidance already matches the current authoring and diagnostics workflow.

## 0.1.39 - 2026-05-12

### Additions

- Added explicit strict-mode philosophy guidance to the strict quick-learn, the strict-mode guidance profile, and the strict Agent Skill.

### Fixes

- Clarified that strict mode is aimed at explicit, durable code for long-lived projects rather than the shortest possible code.
- Clarified that most strict code should stay typed after a small number of well-chosen entry boundaries, instead of framing strict mode as constant stabilization work.
- Clarified the role of `take(...)` as an explicit boundary helper for wrapper-shaped results, absence, and failure states.

### Breaking Changes

- None

### Migration Notes

- Strict docs and Agent Skill guidance now describe strict mode more explicitly as a long-term readability and maintenance posture, with special attention to typed boundaries and explicit wrapper handling.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was updated for this hotfix.

## 0.1.38 - 2026-05-12

### Additions

- Added regression coverage that locks in the reuse-mode dependency hotfix contract for stale dependency artifacts.

### Fixes

- Fixed the build reuse integration regression test so it now expects `scpp build` reuse mode to fail early and clearly when dependency artifacts are stale, instead of asserting the old silent-success behavior.

### Breaking Changes

- None

### Migration Notes

- If dependency sources changed and reusable dependency artifacts are stale, default reuse mode should now be expected to stop early and direct the user to rerun with `--build-dependencies`.
- Agent Skill review completed: no `.agents/skills/*` updates are required for this hotfix because the existing guidance already matches the current reuse-mode behavior.

## 0.1.37 - 2026-05-11

### Additions

- Expanded the strict PHP++ quick-learn with clearer authoring, diagnostics, project composition, and dependency workflow guidance for current strict-profile projects.
- Added a dedicated strict-skill diagnostics reference covering build, run, saved reports, and common validation flows.

### Fixes

- Fixed dependency reuse mode so `scpp build` and `scpp run` now fail clearly when reused dependency artifacts are missing instead of falling through to a later Ninja error.
- Fixed dependency reuse mode so changed dependency sources no longer allow stale dependency objects to be reused silently during `scpp build` and `scpp run`.
- Tightened strict skill and quick-learn guidance to steer users toward current `.phs`, strict typing, dependency, and diagnostics workflows.

### Breaking Changes

- None

### Migration Notes

- If a consumer project reuses dependency artifacts, `scpp build` and `scpp run` now stop early when those artifacts are missing or stale; rerun with `--build-dependencies` to refresh them.
- Strict projects should prefer the updated quick-learn and strict skill guidance for project composition, diagnostics, and typed authoring patterns.
- Agent Skill review completed: `.agents/skills/simple-cpp-php-strict/*` was updated for this hotfix.

## 0.1.35 - 2026-05-11

### Additions

- Added relation-aware generated line maps so generated `.line.tsv` data can describe whether a generated line maps `exact`, `above`, `below`, or `around` the originating source line.
- Added helper-free runtime diagnostics recovery that records generated locations from runtime error traces and remaps them back to original `.phs` lines through `.line.tsv`.
- Added source-facing strict aliases `error`, `resource_handle`, `nullable_resource_handle`, and `falseable_resource_handle` for authoring and examples while preserving the existing runtime lowerings.

### Fixes

- Fixed strict runtime diagnostics so generated cast failures no longer depend on generated helper wrappers and still resolve back to the original authoring line.
- Fixed debug builds used for runtime diagnostics to emit line information needed for generated-frame recovery.
- Fixed strict typed-local shorthand scanning so source-facing alias declarations work for both initialized and uninitialized typed locals.
- Normalized strict docs, examples, and tests to the source-facing `error` and `resource_handle` aliases.

### Breaking Changes

- None

### Migration Notes

- Rebuild strict projects if you rely on runtime source remapping; debug builds now emit relation-aware `.line.tsv` files and runtime reports resolve generated failures through the catch-time trace path.
- Source-facing strict code should prefer `error` and `resource_handle` aliases over the runtime-shaped `error_t` and `resource_handle_t` names.
- Agent Skill review completed: the strict diagnostics reference was updated and no additional `.agents/skills/*` changes are required for this release.

## 0.1.33 - 2026-05-10

### Additions

- None

### Fixes

- Fixed strict `dbg(...)` and `dbg_if(...)` release lowering so generated C++ carries the original `.phs` source path and compiles cleanly against the runtime `dbg_at(const char *, ...)` API.

### Breaking Changes

- None

### Migration Notes

- Retry strict projects that started failing in `v0.1.32` with `Call to undefined method Scpp\\S2S\\Generator\\Generator::cppStringLiteral()`, `Undefined property ... $currentSourcePath`, or a generated `dbg_at(string_t(...), ...)` compile error.
- Agent Skill review completed: no `.agents/skills/*` updates are required for this hotfix because the existing strict debug-helper guidance remains correct.

## 0.1.32 - 2026-05-10

### Additions

- Added regression coverage for strict runtime cast failures remapping back to the original `.phs` file and line through generated `.line.tsv` artifacts.

### Fixes

- Fixed strict runtime cast diagnostics so generated `mixed_t -> typed` cast failures remap back to `original_file` / `original_line` in saved reports when generated location data is available.
- Fixed strict runtime diagnostic summaries and `scpp error` output to prefer the remapped original source location for these failures instead of stopping at generated/runtime context.
- Updated the repo-local strict Agent Skill guidance to reflect that saved runtime reports may now expose remapped `original_file` / `original_line` attribution directly.

### Breaking Changes

- None

### Migration Notes

- Re-run strict projects that previously stopped at `Runtime error while running the built program.` for `cast<...>(mixed_t)` failures; the saved report and short summary should now point back to the original authoring line when generated line maps are available.
- Agent Skill review completed: strict diagnostics guidance was updated for this hotfix.

## 0.1.31 - 2026-05-09

### Additions

- Added strict-safe PHP++ debug helpers: `dbg`, `dbg_if`, `dbg_set`, `dbg_unset`, and `dbg_enabled`.
- Added composable `DBG_*` inspection flags for type, value, shape, fields, keys, length, source, caller, JSON, raw text, pointer identity, compact output, and explicit depth controls.
- Added best-effort runtime inspection for scalars, `mixed_t`, hashes, vectors, wrappers, nullable-like values, pointers, and handles with recursion protection and compact hex pointer IDs.
- Added source-aware lowering for `dbg(...)` and `dbg_if(...)` so debug output can report the originating `.phs` file and line.
- Added strict debug helper guidance to the PHP++ strict quick-learn and repo-local Agent Skill docs.

### Fixes

- None

### Breaking Changes

- None

### Migration Notes

- Strict projects can use `dbg("label", $value, DBG_SHAPE | DBG_DEPTH_2 | DBG_PTR)` for focused runtime shape inspection without ad hoc generated-C++ probes.
- Use `dbg_set("gate", $condition)`, lower-call `dbg_if("gate", ...)`, and `dbg_unset("gate", $condition)` for scoped debugging. Duplicate gate sets and missing unsets intentionally fail loudly.
- Object field reflection remains best-effort and may report unsupported details instead of crashing.

## 0.1.30 - 2026-05-09

### Additions

- Added generated-line `CodeBlock` records so source and header buffers carry source line/column metadata until final render.
- Added regression coverage that verifies generated `.line.tsv` output maps a lowered `php::echo_one(...)` call back to the original `.phs` source line.

### Fixes

- Fixed the PHP flow test harness so `.phs` oracle runs execute a temporary pre-tokenized PHP-compatible copy instead of the raw PHP++ source.
- Fixed runtime config normalization so an already-normalized `runtime.language_profiles.php.profile` value is preserved on later config passes instead of falling back to `legacy`.
- Removed the expression-level `with_runtime_context` runtime diagnostic wrapper from generated C++ and the runtime support header so runtime source attribution can move onto the generated-location plus `.line.tsv` remap path.

### Breaking Changes

- None

### Migration Notes

- Rebuild projects that rely on generated source maps so `.line.tsv` files are regenerated with statement-level source line metadata.
- Agent Skill review completed: strict diagnostics guidance now points agents at saved runtime reports first, then generated C++ and `.line.tsv` artifacts when source attribution is not yet present.

## 0.1.29 - 2026-05-09

### Additions

- Added the default `datetime` runtime module with reusable `scpp::dt` APIs for Unix timestamps, monotonic timing, sleeps, UTC ISO helpers, common local datetime formatting, and common local datetime parsing.
- Added strict PHP++ `dt_*` datetime helpers backed by the shared runtime API, including `dt_now`, `dt_now_ms`, `dt_monotonic_ms`, `dt_sleep_ms`, `dt_format`, `dt_format_now`, `dt_parse`, `dt_format_iso_utc`, and `dt_parse_iso_utc`.
- Added legacy PHP wrapper support for `time()`, `date()`, and `strtotime()` on top of the same runtime implementation.
- Added datetime docs, strict quick-learn guidance, Agent Skill guidance, native runtime tests, and PHP surface regression fixtures.

### Fixes

- None

### Breaking Changes

- None

### Migration Notes

- Strict projects should prefer the `dt_*` helpers over legacy PHP-shaped `date()` and `strtotime()` names.
- Phase 1 intentionally supports common numeric datetime forms only: `YYYY-MM-DD`, `YYYY-MM-DD HH:MM:SS`, `YYYY-MM-DDTHH:MM:SS`, `YYYY-MM-DDTHH:MM:SSZ`, and core format tokens such as `Y-m-d H:i:s`.
- Named timezones, locale names, calendar arithmetic, and natural-language `strtotime` expressions remain deferred.

## 0.1.28 - 2026-05-09

### Additions

- Added regression coverage for strict runtime type failures reporting source-level diagnostics through `scpp run` and `scpp error`.
- Added regression coverage for strict dependency project exports composing before local generated headers after a dependency was previously built standalone.

### Fixes

- Fixed strict runtime cast failures so generated code can attach the original source file, source line, expression, expected type, operation, and actual runtime kind to structured diagnostics.
- Fixed `scpp run` so structured runtime failures are saved to `.prism/last_error.json` and summarized through source-level context instead of leaking only generated/runtime stderr.
- Fixed runtime profile normalization so legacy `runtime.language_profiles.php.profile` config and object-style `runtime.languages.php.profile` config are both resolved before build/run diagnostics record project mode.
- Fixed the remaining strict same-project composition issue from #58 by including dependency project export headers before local generated headers, sorting exported dependency headers with the same base-before-derived rule, and regenerating dependency entrypoints when a standalone project is reused as a dependency.

### Breaking Changes

- None

### Migration Notes

- Re-run failing strict projects and inspect `scpp error` / `scpp full-error`; supported runtime type failures now prefer source `.phs` context when available.
- Rebuild larger strict multi-project graphs that removed same-project generated `.hpp` includes; dependency export headers now participate in the same generated composition ordering used by project unit headers.
- Agent Skill review completed: strict diagnostics and composition guidance were updated for this hotfix.

## 0.1.27 - 2026-05-09

### Additions

- Added the opt-in PCRE2-backed regex runtime module with typed `regex_*` APIs, legacy PHP `preg_*` wrappers, opportunistic JIT use, UTF-8 `/u` coverage, match offsets, named captures, replacement backreferences, practical split/match-all flags, and explicit runtime errors for deferred offset-capture and unmatched-as-null output forms

### Fixes

- Stabilized strict project sample validation so checked runnable samples rebuild required runtime artifacts instead of depending on a warm local runtime cache.
- Normalized the regex sample source files to the current Prism++ `.phs` source format without PHP opening tags or `declare(strict_types=1)`.

### Breaking Changes

- None

### Migration Notes

- Enable the `regex` runtime module explicitly and install PCRE2 development files manually for now; full PHP parity for `PREG_OFFSET_CAPTURE`, `PREG_UNMATCHED_AS_NULL`, and dynamic callable-array handling remains deferred

## 0.1.26 - 2026-05-09

### Additions

- Added regression coverage for strict same-project namespaced units whose generated header order would otherwise reference a later namespace/class.
- Added regression coverage for same-project derived-class headers needing base-class headers before derived headers.

### Fixes

- Fixed generated same-project composition so `__project_units.hpp` includes a project-wide `__project_fwd.hpp` before generated unit headers.
- Fixed same-project generated header ordering so base-class headers are emitted before derived-class headers when both are discovered in the project unit set.
- Updated the repo-local strict Agent Skill guidance to reflect that same-project `.phs` files are composed by `scpp build` and must not include generated `.hpp` files.

### Breaking Changes

- None

### Migration Notes

- Retry removing same-project generated `.hpp` `require` / `include` lines after updating; nested namespaces and common base/derived ordering cases are now covered by generated project composition.
- Keep `/** @lib-export */` for dependency-visible cross-project declarations.

## 0.1.25 - 2026-05-09

### Additions

- Added regression coverage for strict same-project `.phs` files composing without source-level generated `.hpp` includes.

### Fixes

- Fixed strict project builds so same-project generated headers are force-included through an internal `.prism/generated/__project_units.hpp` build artifact.
- Fixed project composition guidance to make generated `.hpp` names an internal build detail rather than a PHP++ source authoring surface.

### Breaking Changes

- None

### Migration Notes

- Remove source-level `require` or `include` statements that point at generated `.hpp` files; same-project `.phs` composition is handled by `scpp build`.
- Agent Skill review completed: strict project composition guidance remains aligned with the existing repo-local skill; no `.agents/skills/*` updates are required.

## 0.1.24 - 2026-05-09

### Additions

- Added focused regression coverage for `scpp run` runtime-library launch environment handling and Linux shared-runtime SONAME emission.

### Fixes

- Fixed `scpp run` for strict projects that built successfully but failed to launch from the project root because `libruntime.so` could not be resolved.
- Fixed Linux reusable runtime linking so `libruntime.so` declares a stable SONAME instead of allowing executables to record a project-relative shared-library path.
- Fixed the `scpp run` launch environment so Unix-like systems prepend the runtime directory through the platform loader path (`LD_LIBRARY_PATH` on Linux/Unix, `DYLD_LIBRARY_PATH` on macOS) while Windows continues to use `PATH`.

### Breaking Changes

- None

### Migration Notes

- Rebuild the reusable runtime or run `scpp run --force` once after updating if an existing project still has a binary linked against the old slash-containing runtime dependency path.
- Agent Skill review completed: no `.agents/skills/*` updates are required because existing `scpp run` validation guidance remains correct.

## 0.1.23 - 2026-05-09

### Additions

- Added regression coverage for top-level PHP++ constants with array initializers so the generator cannot regress to missing constant source-line metadata.

### Fixes

- Fixed PHP++ constant IR construction so top-level constants, class constants, and enum cases carry source-line metadata before header emission.
- Fixed the generator crash on top-level `const` declarations where `ConstantDecl::$line` was missing during header line-map emission.

### Breaking Changes

- None

### Migration Notes

- No migration is required.
- Agent Skill review completed: no `.agents/skills/*` updates are required because this hotfix restores existing documented constant lowering behavior and does not change authoring guidance.

## 0.1.22 - 2026-05-09

### Additions

- Added a repo-local Agent Skill at `.agents/skills/simple-cpp-php-strict/` for strict PHP++ / PHS app authoring, validation, diagnostics, project composition, and common PHP-habit pitfalls
- Added `scpp docs <name>` to print curated local Markdown documentation without requiring web access
- Added local documentation entries for strict authoring, diagnostics, build workflow, profiles, examples, Agent Skill guidance, and AI onboarding
- Added focused regression coverage for the `scpp docs` registry, successful doc lookup, and unknown-doc failure path

### Fixes

- Updated release workflow rules so `.agents/skills/*` must be reviewed and kept current before release publication
- Updated strict PHP++ quick-learn, getting-started, README, and project build docs to surface the new local docs workflow

### Breaking Changes

- None

### Migration Notes

- Use `scpp docs` to list local documentation names.
- Use `scpp docs strict` or `scpp docs diagnostics` when an agent or user needs local strict PHP++ guidance without browsing the web.

## 0.1.18 - 2026-05-08

### Additions

- Added `--entry=<path>` support to `scpp build` and `scpp run` so one invocation can target a project-local source file without editing `prism.json`
- Added persistent `tests/.run-tests/` PHP test workspaces so repeated flow-test runs can reuse warm `.prism` build state instead of recompiling from scratch

### Fixes

- Fixed echo lowering so adjacent exported echo nodes now emit direct sequential `php::echo_one(...)` calls instead of large batched `php::echo_eval(...)` lambda packs
- Fixed the PHP flow test harness to build through `scpp` project mode rather than one-off direct compiler invocations, while preserving per-test result files and cwd-sensitive fixture behavior
- Fixed PHP runtime symbol qualification so generated `echo_one` calls resolve through the runtime symbol registry just like other known PHP helpers

### Breaking Changes

- None

### Migration Notes

- `scpp build --entry=...` and `scpp run --entry=...` override the configured `prism.json` entrypoint for that invocation only
- `tests/.run-tests/` is generated state and should remain ignored; warm reruns of individual PHP flow tests now become much faster after the first build

## 0.1.17 - 2026-05-08

### Additions

- Added scanner regression coverage for allowed inline typed comment slots, including leading/trailing property comments, inline parameter comments, and inline function-like return comments

### Fixes

- Fixed type metadata ownership so params, properties, locals, and function/method/closure return comments are now sourced from pre-tokenizer scanner annotations instead of raw `php-ast` doc-comment attachment
- Fixed the accepted inline type-comment surface so only recognized typed slots are honored, while detached forms such as `/** @var T */` remain non-authoritative
- Fixed closure and arrow-function typed comment handling so it follows the same scanner-owned slot rules as ordinary function-like sites

### Breaking Changes

- None

### Migration Notes

- Inline type comments remain supported, but only in recognized typed slots such as `$x /** T */ = ...`, `function (/** T */ $x)`, `public /** T */ $x`, `public $x /** T */ = ...`, and immediate post-signature return slots
- `TypeCommentExtractor` has been removed from the active pipeline; scanner-owned annotation metadata is now the single type-comment source of truth

## 0.1.16 - 2026-05-08

### Additions

- Added explicit runtime maintenance commands and flags: `scpp runtime-build`, `--build-runtime`, `--build-dependencies`, and `--force`

### Fixes

- Fixed the public `scpp build` and `scpp run` defaults so they now reuse existing runtime and Prism project dependency artifacts unless explicit rebuild flags are requested
- Fixed `scpp update` so a real fast-forward rebuilds the default reusable runtime cache automatically, and `scpp update --force` rebuilds that cache even when the checkout is already current

### Breaking Changes

- `--reuse-runtime` and `--reuse-dependencies` are replaced by `--build-runtime` and `--build-dependencies`

### Migration Notes

- `scpp build` and `scpp run` now default to warm-build reuse for runtime and dependency artifacts
- Use `--build-runtime` and `--build-dependencies` when you explicitly want those heavier rebuild steps
- Use `scpp runtime-build [--debug|--release] [--force]` to rebuild the reusable runtime cache directly
- Use `scpp update --force` to rebuild the default reusable runtime cache even when no Git update is pulled
## 0.1.15 - 2026-05-08

### Additions

- Added a scanner-owned pre-tokenizer path for PHP++ shorthand type syntax across locals, properties, parameters, and function-like return sites
- Added shorthand-type regression fixtures and regression scripts for rewritten-source and annotation-ownership validation
- Added build option coverage and integration coverage for runtime/dependency warm-build reuse behavior
- Added `public_html/test` pre-tokenized AST/PHP execution support so browser-driven test runs can exercise shorthand typed syntax

### Fixes

- Fixed nested closure and arrow return-type ownership so callable annotations no longer depend on raw `php-ast` doc-comment attachment quirks
- Fixed the project build graph so lower-level build-service calls can reuse existing runtime and dependency artifacts without recompiling them unless explicitly requested
- Fixed the `public_html/test` harness so shorthand typed syntax is parsed and executed through the pre-tokenized source path instead of failing in raw PHP parsing

### Breaking Changes

- None

### Migration Notes

- Typed doc-comment forms such as `$count /** int */ = 0;` remain supported, but shorthand surface forms such as `$count int = 0;` are now first-class and normalize through the pre-tokenizer

## 0.1.14 - 2026-05-06

### Additions

- None

### Fixes

- None

### Breaking Changes

- None

### Migration Notes

- None

## 0.1.13 - 2026-05-06

### Additions

- Added targeted PHP regression coverage for typed-hash foreach over a fresh local initialized from a method returning a nullable typed object, preserving direct key usage at a `?string` helper boundary

### Fixes

- Fixed fresh-local generator type capture to reuse namespace-aware return-type recovery, preserving typed hash property shapes across method-return locals
- Fixed the remaining reproduced Open M3 typed-hash foreach-key to nullable-string helper boundary by preventing `assembled->properties` loops from degrading foreach keys to `mixed_t`

### Breaking Changes

- None

### Migration Notes

- Explicit `(string)` stabilization should no longer be required in the reproduced `assemble_path(...): ?model` then `foreach ($assembled->properties as $property_name => ...)` Open M3 flow

## 0.1.12 - 2026-05-05

### Additions

- Added targeted PHP regression coverage for typed `hash<shared_p<T>>` foreach keys passed into method helpers expecting `?string`

### Fixes

- Fixed generator argument wrapping so concrete `T` values passed to `nullable<T>` parameters no longer degrade into synthetic `cast<nullable<T>>(...)` bridges
- Fixed the reproduced typed-hash foreach key to nullable-string helper boundary seen in real Open M3 traversal flows

### Breaking Changes

- None

### Migration Notes

- Explicit `(string)` stabilization should no longer be required at typed `hash<T>` foreach-key to `?string` helper boundaries in the reproduced flow

## 0.1.10 - 2026-05-05

### Additions

- Added regression coverage for `scpp --doctor` best-effort subprocess timeout handling
- Added `foreach` planning/checklist notes for the long-term generator cleanup
- Added targeted PHP regression coverage for typed `hash<shared_p<T>>` `foreach` key/value flows, direct helper-key usage, and direct reindexing into typed hashes

### Fixes

- Fixed `scpp --doctor` so best-effort Git remote and compiler-launcher probes time out instead of hanging indefinitely
- Fixed the PHP test harness `--jobs=1` path so focused debugging runs execute sequentially without the flaky worker subprocess layer
- Fixed typed `hash<shared_p<T>>` generator lowering across direct `foreach` key/helper flows by qualifying declared hash/object types with the active PHP namespace before emission
- Fixed generator forward-declaration collection so imported object types referenced through doc-typed hash params/returns do not degrade into bogus local forward declarations

### Breaking Changes

- None

### Migration Notes

- None

## 0.1.8 - 2026-05-04

### Additions

- Added first-class PHP-surface `hash<T>` support that lowers to runtime `hash_t<T>`
- Added typed hash coverage for keyed literals, keyed access, properties, mixed keyed-plus-append literals, and `foreach` including by-reference forms

### Fixes

- Fixed typed hash lowering across `isset`, `empty`, dim access, append, and typed `foreach` value preservation
- Fixed runtime `foreach` bridge support so typed `hash_t<T>` containers iterate correctly without falling back to mixed-only handling

### Breaking Changes

- None

### Migration Notes

- Replace PHP-surface `hash_t<T>` examples with `hash<T>` in authored code and docs

## 0.1.7 - 2026-05-04

### Additions

- Added project-level Prism dependencies through `dependencies` in `prism.json`
- Added native library configuration through `libraries` in `prism.json`
- Added `/** @lib-export */` support for dependency-visible top-level functions, classes, interfaces, and constants
- Added generated per-project export manifests and composed project export headers for dependency builds
- Added documentation for project dependencies, project exports, and `@lib-export` usage in the build and AI onboarding docs

### Fixes

- Fixed multi-project build planning so dependency projects are scanned, generated, and linked as part of one build graph
- Fixed transitive dependency resolution with deduplication and cycle detection
- Fixed constant export detection for doc-comment based `@lib-export`
- Removed the generated PCH warning caused by emitting `#pragma once` in PCH main files

### Breaking Changes

- None

### Migration Notes

- Projects that want cross-project declaration visibility should mark public dependency surfaces explicitly with `/** @lib-export */`

## 0.1.4 - 2026-04-26

### Additions

- Clarified that the PHP S2S generator is type-blind and not a semantic compiler
- Strengthened AI onboarding guidance to prevent fallback to standard PHP semantics
- Added explicit documentation for generator responsibility boundaries
- Introduced `docs/future_thoughts/` for non-authoritative future ideas

### Fixes

- Removed implicit future promises from active documentation by relocating them to planning docs

### Breaking Changes

- None

### Migration Notes

- None

## 0.1.3 - 2026-04-26

### Additions

- Completed semantic-matrix coverage across the active operator families, including conditional selection, arithmetic, logical, comparison, bitwise, unary, probes, and compound-assignment surfaces
- Added runtime-supported iterable and `take(...)` extraction behavior for `result<T>`, `result_or_false<T>`, and `result_or_bool<T>` wrapper flows used by filesystem-style results

### Fixes

- Fixed wrapper-lifted runtime/operator behavior across arithmetic, logical, bitwise, ordering, equality, identity, and conditional-selection lowering paths
- Fixed matrix semantics and enablement boundaries for mixed-condition truthiness, `unset_*` handling, and remaining elvis / ternary consistency gaps

### Breaking Changes

- None

### Migration Notes

- None

## 0.1.2 - 2026-04-23

### Additions

- None

### Fixes

- Fixed `scpp --doctor` so compiler launcher detection no longer fatals when no launcher command has been resolved yet

### Breaking Changes

- None

### Migration Notes

- None

## 0.1.1 - 2026-04-23

### Additions

- Added AI onboarding documentation under `docs/ai_onboarding/`
- Added repository guidance for coding style, workflows, examples, repo structure, and language-model usage
- Added `AGENTS.md` and linked onboarding guidance from existing docs

### Fixes

- No user-facing fixes recorded in this release beyond documentation/process updates

### Breaking Changes

- None

### Migration Notes

- None
