# Validation And Diagnostics

Use this reference for strict PHP++ project workflow, diagnostics, modules, and project composition.

## Project Setup

Initialize new strict projects explicitly:

```bash
scpp init --php-profile=strict
```

Use `.phs` for new source files and configure the entrypoint in `prism.json`.

Common entrypoints include:

- `main.phs`
- `src/main.phs`
- `app/main.phs`
- `index.phs`

## Build And Run

Use public `scpp` commands first:

```bash
scpp build
scpp run
```

Use a temporary entry override for focused checks:

```bash
scpp build --entry=tests/php/sample.phs
scpp run --entry=tests/php/sample.phs
```

Pass program args after `--`:

```bash
scpp run -- arg1 arg2
```

Use single-file transpile for narrow lowering checks:

```bash
scpp input.phs
```

## Local Documentation Lookup

Use `scpp docs` when local documentation is easier or safer than web access:

```bash
scpp docs
scpp docs strict
scpp docs diagnostics
scpp docs authoring
scpp docs gotchas
```

`scpp docs` lists known names. `scpp docs <name>` prints the resolved local source path and the Markdown content.

## Rebuild Controls

Default `scpp build` and `scpp run` reuse runtime and dependency artifacts.

Use explicit rebuild flags only when they answer the current debugging question:

```bash
scpp build --build-runtime
scpp build --build-dependencies
scpp build --build-runtime --build-dependencies
scpp build --force
scpp clean
```

Use `scpp clean` for a cold project rebuild. It removes generated project state such as `.prism/build`, `.prism/generated`, and `.prism/cache`.

## Diagnostics Workflow

After a failed build or run, inspect saved diagnostics before manually digging into backend output:

```bash
scpp error
scpp full-error
scpp last-run
scpp full-last-run
```

Use these as the normal first pass:

- `scpp error`: compact saved error summary.
- `scpp full-error`: full saved JSON error report.
- `scpp last-run`: compact most recent build/run context.
- `scpp full-last-run`: full saved JSON run report.

Use them for different questions:

- `scpp error`: first compact summary of the failure you just hit
- `scpp full-error`: full structured runtime/build report for field-level inspection
- `scpp last-run`: compact execution/build context, useful when the question is what command or phase actually ran
- `scpp full-last-run`: full run metadata and command context
- `scpp explain-build`: rebuild causality and build orchestration questions, not runtime shape questions

Current runtime-failure presentation is intentionally layered:

- `scpp run`: compact source-first runtime failure view
- `scpp error`: saved source-first summary plus richer saved fields
- `scpp full-error`: full saved JSON, including deeper generated/runtime trace detail when present

The toolchain stores diagnostic artifacts under `.prism/`, including:

- `.prism/last_error.json`
- `.prism/last_run.json`

Compiler diagnostics may be remapped from generated C++ back to original `.phs` / `.php` source lines when line maps are available. Generated `.cpp` and `.hpp` files may have compact sibling line maps:

```text
*.line.tsv
```

Prefer the remapped original source location. Inspect generated C++ only when the source looks valid and the failure suggests a lowering or runtime-boundary issue.

Strict runtime type failures preserve structured runtime details such as the failure code and actual runtime kind. When the runtime report includes a generated location that can be remapped through `.line.tsv`, the saved report should also expose `original_file` / `original_line`; inspect generated C++ and line maps only when the saved report still does not identify the authoring location strongly enough.

When `SCPP_DEBUG_TRACE=1` is enabled, the saved runtime report may also preserve debug-only trace frames. The default `scpp run` / `scpp error` presentation should prefer source-mapped trace entries only; use `scpp full-error` when you need the deeper generated C++ or runtime-internal trace.

For a normal strict runtime-debug loop, use this order:

1. run the failing command with `scpp run`
2. read `scpp error`
3. inspect `original_file`, `original_line`, `expected_type`, `actual_runtime_kind`, and `operation`
4. add `dbg(...)` near the typed boundary if the runtime shape is still unclear
5. use `dbg_set(...)` / `dbg_if(...)` when the interesting value only appears deep in lower calls
6. inspect `.prism/last_error.json`, `.line.tsv`, or generated C++ only when the saved diagnostics still do not answer the question

## Strict Debug Helpers

Use `dbg` when the runtime shape is unclear:

```php
dbg("cell", $cell);
dbg("payload", $payload, DBG_SHAPE | DBG_DEPTH_3 | DBG_PTR);
```

Default `dbg` output is intentionally generous and bounded: source line, caller placeholder, type/kind, value preview, shape, and depth 2. Narrow or deepen it with bit flags such as `DBG_KEYS`, `DBG_LEN`, `DBG_DEPTH_1`, `DBG_DEPTH_3`, `DBG_PTR`, and `DBG_COMPACT`.

For noisy lower-call paths, use gates:

```php
dbg_set("debug_company_12", $company->Id == 12);
run_work($company);
dbg_unset("debug_company_12", $company->Id == 12);
```

Then inside lower calls:

```php
dbg_if("debug_company_12", "row", $row, DBG_SHAPE);
```

`dbg` value inspection is best-effort and non-fatal. Unsupported field/shape details should degrade to a not-inspectable marker. Gate misuse is different: duplicate enabled gates and missing unsets throw intentionally so debug-control mistakes are visible.

## Generated Artifacts

Generated artifacts are inspection evidence:

- `.prism/generated/` contains generated C++.
- `.prism/build/` contains build artifacts and Ninja files.
- `.prism/cache/` contains generation state.

Do not patch generated C++ as the final app fix. Fix PHP++ source, project config, or the owning Simple C++ layer.

## Runtime Modules

Strict app code may require runtime modules in `prism.json`.

Example:

```json
{
  "runtime": {
    "languages": {
      "php": {
        "profile": "strict"
      }
    },
    "modules": [
      "json",
      "filesystem",
      "curl"
    ]
  }
}
```

Use the module set required by the APIs the app calls. For example, strict `curl_*` helpers require the opt-in `curl` module and host libcurl development support. When module ownership is unclear, check the strict examples and local builtin docs first.

## Project Dependencies

Use project-level composition, not PHP file inclusion.

Inside one project, `scpp build` discovers same-project `.phs` files and makes their generated declarations visible through an internal build header. Do not use source-level `require`, `require_once`, `include`, or `include_once` for project composition, and do not name `.prism/generated/*.hpp` files from source.

In `prism.json`:

```json
{
  "dependencies": [
    "../shared"
  ],
  "libraries": [
    "sqlite3"
  ]
}
```

Use:

- `dependencies` for other Simple C++/Prism projects built from source.
- `libraries` for linker-owned native libraries or native artifacts.

Mark dependency-visible declarations with `/** @lib-export */`:

```php
/** @lib-export */
function shared_value(): int {
	return 7;
}
```

Do not activate project dependencies with PHP `require`, `require_once`, `include`, or `include_once`.

## Failure Triage

Use the smallest useful loop:

1. Read the failing source location reported by `scpp error`.
2. Check strict profile and module config.
3. Check for normal-PHP assumptions in the source.
4. Check typed boundaries around `mixed`, wrappers, nullable values, and falseable results.
5. Inspect generated artifacts and line maps if remapped diagnostics point to lowering behavior.
6. Escalate to local specs only when behavior is unclear or appears unsupported.

Runtime-debug example:

```php
$row mixed;
$err error;
if (!take($row, $err, json_decode($text))) {
	echo $err->get_message(), "\n";
	return;
}
echo "name=" . $row["name"] . "\n";
```

If `scpp error` reports a cast failure with `actual_runtime_kind=shared_hash_t`, the normal next step is:

```php
dbg("name", $row["name"], DBG_SHAPE | DBG_TYPE);
```

Then either guard the field or stabilize it intentionally into a typed local:

```php
if (isset($row["name"])) {
	$name string = $row["name"];
	echo "name=" . $name . "\n";
}
```

Useful local docs:

- `scpp docs strict`
- `scpp docs diagnostics`
- `specs/simple_cpp_php_strict_quick_learn.md`
- `docs/examples/php/strict/`
- `docs/getting_started.md`
- `specs/project_build_v1.md`
- `specs/php/library_profiles.md`
- `specs/dynamic_types.md`
- `specs/array_semantics.md`

## Build Cost and Analysis Triage

For unexpectedly long builds or excessive rebuilds, start with `scpp explain-build`, then `rebuild-fanout` and `project-units`. Use the focused `generated-files`, `ninja-explain`, `action-identity`, `object-cache`, `build-planner`, or `modules` views as needed. Report which outputs changed and why; follow `docs/ai_onboarding/workflows.md` before changing cache/grouping settings.

STAN separates confirmed build-blocking source errors from model-incomplete advisory findings. Inspect `scpp stan` for the full report and retain supported discipline checks. A successful native build alone does not prove the analyzer models every receiver or member.

## Reusable Runtime Maintenance

Run `scpp runtime-build` from the consuming project to prepare its configured
reusable runtime. For shared-eligible configurations this includes the base and
requested optional module artifacts, even when the base already exists. Use
`scpp runtime-build --force` after a runtime ABI change; add `--release` when
maintaining release artifacts. Then use the normal `scpp build` / `scpp run` flow.
Custom configurations retain project-local composition.

For typed-argument compile failures, read the error and its notes together: GCC
may explain the mismatch at the call, while Clang supplies the typed explanation
at the parameter declaration. Debug builds preserve full debug information for
source-mapped runtime errors with precompiled headers.
