# Authoring Rules

Use these rules when writing or reviewing strict PHP++ application code.

## Mental Model

PHP++ is PHP-like syntax over the Simple C++ model. It is not PHP compatibility mode.

- `.phs` is the preferred source extension.
- `.php` inputs are compatibility inputs only.
- Generated C++ is useful for inspection, not for authoring fixes.
- Strict mode is selected by `prism.json`, not by PHP `declare(strict_types=1);`.

Strict project shape:

```json
{
  "runtime": {
    "languages": {
      "php": {
        "profile": "strict"
      }
    }
  }
}
```

## Source File Shape

Preferred:

```php
echo "hello\n";
```

Avoid:

```php
<?php
declare(strict_types=1);

echo "hello\n";
```

Prism++ source starts directly with Prism++ declarations or executable code.

## Types

Use explicit types whenever the source shape is known.

Preferred:

```php
function add(int $left, int $right): int {
	return $left + $right;
}

$count int = 0;
$name string = $row["name"];
```

Avoid:

```php
function add($left, $right) {
	return $left + $right;
}

$name = $row["name"];
```

Use shorthand typed syntax in strict code:

```php
$count int = 0;
```

Do not use annotation-style type syntax in strict mode, such as `$count /** int */ = 0;` or `$items /** vector<string> */ = [];`.
Treat it as legacy compatibility syntax that should not appear in new strict examples or new strict code.
Plan for it to become a hard error in a future version.

Explicit parameter `const` is a read-only source contract: `const int $count` or `const vector<int> &$items`. Preserve constness in interface/abstract implementations and do not write through the parameter. This differs from automatic read-only parameter lowering; see `TYPE-PARAM-003F` and `TYPE-PARAM-003G` in `generators/php/specs/rules_catalog.md`.

## Struct Fields And Cross-File Assignments

Strings, ordinary class fields, and typed containers are supported in public
instance struct fields. Use the class name directly; no explicit `shared<T>`
annotation is needed:

`model.phs`:

```php
class Some_Custom_Class {
	public string $name = "";
}

struct Row {
	string $my_string;
	Some_Custom_Class $my_property;
	public $names vector<string>;
	public $by_name hash_t<Some_Custom_Class>;
}
```

The struct itself remains an inline value. Strings copy independently; ordinary
class fields use existing shared handles, so copies still reference the same
object. Vectors and hashes copy their contents using each element's existing
semantics: a container of class handles still shares the referenced objects.
Strings default to empty, vectors/hashes to empty containers, and class fields
to absent handles; assign a class object before dereferencing an absent field.

Container element/value types follow the permitted struct-field types
recursively, including strings, ordinary classes, nested structs, and supported
container compositions. Existing fixed arrays also accept these element types;
existing size and hash-key restrictions remain in force. This does not enable
all source types as struct fields: numeric eligibility remains bool and the
existing fixed-width integer aliases, not plain `int` or `float`.

`mixed` and `dynamic` remain rejected, including inside nested containers.
Nullable fields and explicit ownership-wrapper fields are not added. Strings,
class handles, and containers remain forbidden in union payloads, including
through nested structs. See `specs/compact_layout_types.md` for the contract.

Current compiler limitation: when the struct is declared in another source file,
the generator knows its declaration kind but does not have the field schema in
every literal-assignment path. A direct assignment such as
`$row->names = ["Alice", "Bob"];` can consequently lower the literal as a dynamic
array and fail compilation. This is not an intended language restriction.

Use a typed local to give the literal its expected container type:

`main.phs` (same project):

```php
$row Row = [];
$row->my_string = "team";
$row->my_property = new Some_Custom_Class();

$names vector<string> = ["Alice", "Bob"];
$row->names = $names;

$by_name hash_t<Some_Custom_Class> = ["owner" => $row->my_property];
$row->by_name = $by_name;
```

Apply this workaround where cross-file field metadata is missing; do not require
intermediate locals for every assignment. Project composition discovers the
other source file; do not add PHP includes or generated C++ header references.

## Containers

Use typed containers when the shape is known at compile time.

```php
$items vector<string> = [];
$by_name hash<int> = ["a" => 1, "b" => 2];
$by_id hash<string, int> = [10 => "alex"];
```

Guidance:

- Use `vector<T>` for typed sequential data.
- Use `hash<T>` for typed string-keyed data.
- Use `hash<T, T_KEY>` for typed non-string key families.
- Use dynamic/mixed containers only when the shape is genuinely dynamic, such as decoded JSON before stabilization.

Shared-object upcasts do not imply container covariance: do not assign a
`vector<Derived>` to a `vector<Base>`. If a common-base collection is needed,
construct an explicitly typed result and append the elements individually. If only
a count or membership answer is needed, perform that operation in each branch
instead of selecting differently typed containers with a ternary. The destination
type does not determine the ternary's branch compatibility.

## Dynamic Values

`json_decode(...)` first returns a checked `result<mixed>`. After successful extraction, the decoded value stays dynamic until a typed boundary or narrowing point.

Preferred:

```php
$row mixed;
$err error;
if (!take($row, $err, json_decode($text))) {
	echo $err->get_message(), "\n";
	return;
}
$name string = $row["name"];
$count int = $row["count"];
```

```php
$counts hash<int> = [];
$counts["id"] = $row["id"];
```

```php
$items vector<int> = [];
$items[] = $row["count"];
```

In the examples below, `$row` is the successfully extracted value above. Avoid carrying unresolved dynamic state through the rest of the program:

```php
$count = $row["count"];
echo $count + 1, "\n";
```

Missing-key reads return `null` before typed-boundary conversion is attempted, so guard uncertain data before stabilizing it.

```php
if (isset($row["count"])) {
	$count int = $row["count"];
	echo $count, "\n";
}
```

Treat decoded JSON as a fat-variable boundary, not as the preferred shape for the rest of strict code.

- unwrap `json_decode(...)` with `take` at the ingestion boundary
- when the expected payload shape is known, document it locally near that boundary
- stabilize early into typed locals, typed properties, typed objects, or typed containers
- keep long-lived `mixed` / `dynamic` values only when the flexibility is intentionally needed later

Example:

```php
/** decoded row shape:
 *  - name: string
 *  - active: bool
 */

if (isset($row["name"])) {
	$out->name = $row["name"];
}
if (isset($row["active"])) {
	$out->active = $row["active"];
}
```

## Wrappers

Strict APIs commonly return wrapper-shaped results. Resolve them near a meaningful boundary with `take(...)`. JSON decode returns `result<mixed>` and encode returns `result<string>`; neither is a direct value. `take` returns true for successfully decoded JSON `null` and `false`.

```php
$err error;
$text string = "";

if (!take($text, $err, fs_get($path))) {
	echo "read failed\n";
	return;
}

echo $text, "\n";
```

Common patterns:

```php
if (!take($fh, io_open($path, "rb"))) {
	return;
}

$pos = strpos("banana", "zz") ?? -1;
```

## State Checks

Keep failure, absence, and boolean state separate.

Preferred:

```php
if ($value === false) {
	return;
}

if ($value === null) {
	return;
}
```

Avoid:

```php
if (!$value) {
	return;
}
```

Prefer explicit comparisons:

```php
if ($status === "ready") {
	start_job();
}
```

Avoid direct conditions over arbitrary strings or unresolved `mixed` values.

## Strict Library Surface

Use plain PHP-like names for general language-adjacent helpers and family-prefixed names for subsystem/domain helpers:

- Filesystem: `fs_get`, `fs_put`, `fs_scan`, `fs_exists`, `fs_remove`
- Strings: `strlen`, `str_replace`, `explode`, `implode`, `strpos`
- IO: `io_open`, `io_read`, `io_write`, `io_close`
- JSON: `json_decode`, `json_encode`
- Curl: `curl_init`, `curl_setopt`, `curl_exec`, `curl_getinfo`, `curl_errno`, `curl_error`

Some PHP-owned helpers remain shared where documented, such as:

- `take`
- `count`
- `empty`
- `isset`
- `cli_argc`
- `cli_argv`
- `cli_args`
- `shell_exec`

When unsure, check:

- `specs/simple_cpp_php_strict_quick_learn.md`
- `docs/examples/php/strict/`
- `specs/php/library_profiles.md`
