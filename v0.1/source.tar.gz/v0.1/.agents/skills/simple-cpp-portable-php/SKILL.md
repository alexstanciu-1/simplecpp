---
name: simple-cpp-portable-php
description: Write, review, or adapt executable PHP for this repository's PHP-to-PHP++ portability converter and scpp framework. Use for portable compiler implementation code and its PHP/native behavioral proofs, not direct PHS authoring or arbitrary PHP application conversion.
---

# Simple C++ portable PHP
Doc Status: supporting

Author executable `.php`; PHP++ is generated. Adapt unsuitable PHP deliberately.
The converter is structural: it does not resolve symbols or infer whole-program
types. Direct same-namespace trait indexing is the agreed narrow exception.

Design authored PHP for its Simple C++ shape from the outset: record handles versus
value containers, explicit nullable boundaries, block-local variables, and complete
worker initialization.

Declare a local in the block that owns all its uses: a variable first declared in
an if/else, loop or catch body is not available after that block. Branches that
produce one result must assign a single explicitly typed local declared in their
common enclosing scope; do not ask the converter to recover PHP function scope.
Keep each local name associated with one concept and one type throughout a
function. Avoid reusing names for unrelated values, especially with a different
type. If distinct typed views are needed, use distinct descriptive names (for
example node_ast and node_span); retain the concrete node type when it is known.
These are source-authoring rules, not requests for implicit declaration hoisting.
Do not give a field and a method the same name in a class, including inherited members. PHP permits this, but generated C++ uses a shared member-name space. Give backing fields descriptive names distinct from their accessors (for example parsed_result and result()); do not rely on converter/generator renaming. Also avoid local, parameter, field or method names that hide a type needed in the same C++ lookup scope. Use distinct descriptive names (for example return_statement for a return_node local, lookup_scope for a scope field, and preparation_work_owner() for an accessor returning preparation_owner).

PHP execution checks behavior; successful PHP or conversion
alone does not establish native support. The v0.1 S2S generator is deliberately
type-blind and STAN provides limited assistance; do not rely on either to infer
remote property chains or implicit multi-step conversions.

For nested/cross-file Storage operations, bind the receiver to an explicitly typed
local before append, subscripting, mutation or other collection operations:
`$children /** Storage<ast_node> */ = $body->children;` then
`$children->append($node);`. Use the analogous Keyed_Storage<T> form. Place the local
at its actual lifetime boundary and reuse it while the collection identity remains
stable. These native wrappers alias membership; do not generalize that fact to
vector/hash value containers, where a local copy may change mutation semantics.
See the [two-file native proof](../../../specs/planning/compiler_migration/results/nested-storage-locals-01/README.md).
Try explicit supported source boundaries before extending generator/STAN inference.
Use is_empty() for Storage and count checks for typed vector/hash emptiness; a
comparison with bare [] can become a comparison against a different native container
type. Separate state-dependent key/index reads from mutations in the same expression
(for example capture the key, assign the current position, then increment). PHP and
C++ evaluation order must not determine the compiler's behavior differently.

Narrow typed collections end to end: declaration, initialization, local aliases,
lookup returns, and insertion/removal boundaries. Shared-handle upcasts do not make
`vector<Derived>` interchangeable with `vector<Base>`. When a consumer genuinely
needs a common-base vector, append each element to an explicitly typed result.
If it only needs a count or membership answer, compute that in each typed branch
instead of combining differently typed containers in a ternary. Keep checked casts
at actual base-to-derived boundaries; `instanceof` does not change the native
handle's static type, and a type annotation is not a checked downcast. Do not narrow
heterogeneous storage merely because one consumer uses only a subset of its roles.
For narrowing, a PHP abstract class is not necessarily a polymorphic native base.
Preserve concrete facts through typed accessors or use a truthful narrower family;
see [checked object access](../../../specs/portability/object_casts.md#contract-and-placement).

Read the [authoring guide](../../../specs/portability/authoring_guide.md) before
editing. Follow its feature links as needed. The [function policy](../../../tools/php_portability/function_map.php)
owns bindings and arities; the [constraint summary](../../../specs/portability/debt.md#current-constraint-consolidation)
distinguishes authoring rules, converter gaps and target limitations. Do not treat
an old slice's limits or a feature-catalog proposal as the current support matrix.

- Keep PHP syntax and explicit supported type comments; generated PHS uses native
  type syntax. Use lowercase namespaces and no function imports. The shared bootstrap
  supplies global helpers: plain names for non-PHP facilities, q_ names for existing
  PHP functions (`q_count`, `q_strlen`, `q_is_bool`). Use the fixed function map;
  do not call internal scpp/scpp\compat functions or invent unsupported q_ helpers.
  Avoid C++ keyword identifiers such as operator/template in local names.
  See [global convention](../../../specs/portability/global_functions.md).
- Prefer named typed records and explicit vector/map intent. Ordinary arrays are
  for non-hot setup/read-only data. The writer and behavioral tests own discipline;
  the converter does not infer hotness, ownership or PHP copy-on-write intent.
- Ordinary classes share identity; explicitly marked scalar value records become
  inline structs. Read the [record/alias contract](../../../specs/portability/value_records.md)
  before using `@scpp-struct` or either `&ref` form. Use explicit owner copy operations
  for independent values and snapshots; borrow only stable locals, never container
  elements. PHP object sharing must not accidentally define native value behavior.
- Choose dense vectors versus sparse/keyed hashes by access pattern. Keep stable IDs,
  storage positions and missing sentinels distinct. Normalize compact numeric tags to
  the comparison domain explicitly (for example `(int)` before int-tag `===`); PHP
  success does not prove native fixed-width strict comparisons. Use narrow fields only with known
  bounds; PHP integer annotations do not enforce native ranges. Measure layout and
  memory natively. PHP readonly alone does not establish native immutability.
- Distinguish UTF-8 code-point operations from byte operations for source spans,
  filesystem spelling and binary data. Use explicit JSON schemas at boundaries.
- Keep null, false and present empty/zero values distinct. Check the guide for the
  particular declaration, wrapper, callback or exception form being authored;
  related native language support does not establish converter support.
- Separate nullable extraction from class narrowing. For an already known `?T`
  returned as the same required `T`, the agreed compiler accessor uses `return $value;`,
  not object_cast. Current native nullable conversion checks presence; PHP rejects
  null at the required return boundary. Keep object_cast for actual class narrowing.
  Use existing take_nullable for a branching extraction. `require_non_null` is the
  chosen name for explicit value-or-failure extraction, but is not yet a registered
  portable helper. Read the [decision and tooling status](../../../specs/portability/nullable_parameters.md#nullable-extraction-versus-class-narrowing):
  STAN acceptance of the direct return remains pending. Do not mislabel this analysis
  limitation as a language prohibition, claim native proof from runtime inspection,
  or silently add casts/dummy facts to bypass it. Prepared facts may stay nullable
  before preparation/after cleanup; this does not decide required-field construction.
- For ternary branches with different object types, explicitly upcast each branch
  to the intended common base with `object_cast(value, Base::class)`. A typed
  destination or a cast around the whole ternary does not establish its result
  type. Keep the casts inside the branches to preserve lazy evaluation. This is
  intentional common-base normalization, not nullable extraction; ordinary typed
  assignments still accept upcasts directly. See [the ternary solution](../../../specs/portability/object_casts.md#common-base-ternary-branches).
- On the current target, use nested conditions or early returns when RHS safety,
  errors or side effects depend on `&&`/`||` skipping evaluation, even for boolean
  operands. Independent safe comparisons may stay compound. This is source
  adaptation, not a converter rejection; preserve the algorithm's evaluation order.
- For the `compiler/src` rewrite, read the prototype stage and load the
  [Simple C++ strict skill](../simple-cpp-php-strict/SKILL.md). Follow the
  [stage methodology](../../../specs/planning/compiler_migration/README.md#current-methodology-stage-by-stage-rewrite):
  manifest, paths/discovery, verified reads, tokenizer, parser, then semantic stages.
  Keep `src-runtime-preparation` PHP as-is for now; it is outside conversion scope.
  Reuse suitable existing unit cases; adapt their harness and add portability proofs.
  Keep one implementation; reuse tools and suitable code without preserving incidental
  internals. Define stage inputs/outputs, rejection behavior and ownership first.
- Iterate in PHP with frequent cheap checks/conversion. Prove native behavior for new
  capabilities/representations and completed components, not every small edit. Compare
  meaningful results and clean/incremental agreement; require exact bytes only where
  the contract does. Defer unions/deeper layout tuning unless concretely needed.
- Preserve portability know-how in the owning guide and link it here when it changes
  authoring decisions. Distinguish agreed source/model rules, temporary toolchain
  limitations, and verified behavior. Record the exact candidate revision and any
  overlay changes; a historical native pass with advisories is not a clean STAN proof.
  Do not leave necessary adaptations or their retirement conditions only in chat.
- Consolidate once per component, record major changes/reasons and measured effort,
  and extend conversion only for demonstrated needs. Report cross-owner decisions
  and target defects without silently redesigning contracts or fixing generated C++.

For `compiler/my-try`, follow its [local operating rules](../../../compiler/my-try/AGENTS.md)
and [native validation guide](../../../compiler/my-try/docs/portability/conversion_review.md).
Native compiler runs are on explicit request; that project's legacy STAN bypass is
local policy, not a recommendation to disable STAN for strict applications. Its
harness and retained tests are distinct from the `compiler/src` rewrite ready set.
Do not apply the rewrite's registration or stage-evidence requirements to my-try.
Use its [shared runner](../../../compiler/my-try/docs/testing.md) for focused PHP
checks and supplementary probes too: default FPM/OPcache, CLI fallback on startup
unavailability, and 12 continuously refilled tasks. Keep compile/run dependencies
inside each task; do not infer native compiler proof from generated-program execution.
Its [catalog workflow](../../../compiler/my-try/docs/catalog/README.md) owns positive-pass
scope and explicit debt. Type identity, storage representation and copy capability
are separate concepts; consult the [preparation owner](../../../compiler/my-try/04_analyze/prepare/README.md)
before placing source-derived facts or validation in a registry or emitter.

For the `compiler/src` rewrite, use the [validation workflow](../../../specs/portability/validation_workflow.md).
`python3 tools/php_portability/validate.py --results FRESH` runs the ready-set fast
loop. Add `--native compiler --target-checkout TARGET` for the cumulative native
proof; a PHP-only pass is not native evidence. After the
[rewrite reset](../../../specs/planning/compiler_migration/rewrite_reset.md), the active
ready set grows only with registered stage outcome proofs in `compiler/tests/`.
Old 39-file coverage is historical. Record elapsed time by activity and command in
each stage evidence, including failed attempts, to guide workflow optimization.
Record the first passing PHP-behavior checkpoint (command and source revision/hash):
separate authoring/PHP debugging up to that point from conversion/native stabilization
after it, then regression verification and consolidation. Keep the original checkpoint
if native fixes require PHP rechecks. See the validation workflow for timing boundaries.
Count native attempts to first pass, corrective cycles, and final verification builds
separately; keep checker-only fixes separate. Give framework wrapper types distinctive
names, avoiding case-only variants of target runtime types. The immutable target lives in
[portability_target.json](../../../compiler/tools/portability_target.json), not in
this skill. Host loading belongs outside the converted source tree; assemble native
framework support separately and consume output only after successful conversion.

Prove independent expected values, errors, effects and relevant identity before
adding a file to `compiler/portability.json`. Use affected retained compiler tests.
Actual concurrency/lifetime behavior needs native evidence. Consolidate the owning
contract, focused examples/rejections and saved evidence; keep file counts distinct
from whole-compiler completion. This skill adds no authorization to resume a paused
goal or introduce compiler functionality during migration.
