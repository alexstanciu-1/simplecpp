<?php
declare(strict_types=1);

/* Exact positive decimal range checking; definition validation stays in Integer_Literals. */
namespace check_bodies;
// <scpp-imports>
use function scpp\sequence_require_strings as sequence_require_strings;
use function scpp\fs_is_link as fs_is_link;
use function scpp\fs_is_dir as fs_is_dir;
use function scpp\fs_is_file as fs_is_file;
use function scpp\fs_size as fs_size;
use function scpp\fs_mtime as fs_mtime;
use function scpp\fs_scan as fs_scan;
use function scpp\json_quote as json_quote;
use function scpp\string_byte_from_int as string_byte_from_int;
use function scpp\enum_name as enum_name;
use function scpp\lock_empty as lock_empty;
use function scpp\lock_try as lock_try;
use function scpp\lock_release as lock_release;
use function scpp\lock_transfer as lock_transfer;
use function scpp\process_spawn as process_spawn;
use function scpp\process_poll as process_poll;
use function scpp\process_output as process_output;
use function scpp\process_stop as process_stop;
use function scpp\process_close as process_close;
use function scpp\sequence_map as sequence_map;
use function scpp\sequence_filter as sequence_filter;
use function scpp\keyed_map as keyed_map;
use function scpp\keyed_filter as keyed_filter;
use function scpp\string_byte_len as string_byte_len;
use function scpp\string_byte_starts_with as string_byte_starts_with;
use function scpp\string_byte_ends_with as string_byte_ends_with;
use function scpp\string_utf8_is_valid as string_utf8_is_valid;
use function scpp\string_codepoint_at as string_codepoint_at;
use function scpp\compat\substr as substr;
use function scpp\compat\strpos as strpos;
use function scpp\compat\strrpos as strrpos;
use function scpp\same_exception as same_exception;
use function scpp\string_byte_at as string_byte_at;
use function scpp\take_nullable as take_nullable;
use function scpp\take_false as take_false;
use function scpp\take_bool as take_bool;
use function scpp\compat\str_starts_with as str_starts_with;
use function scpp\compat\str_ends_with as str_ends_with;
use function scpp\compat\strlen as strlen;
use function scpp\string_byte_slice as string_byte_slice;
// </scpp-imports>

class Decimal_Range
{
    /** Normalized nonzero ASCII decimal input; caller owns validation and zero handling. */
    public static function fits_positive(string $value, int $bits): bool
    {
        // Reject huge source literals before repeated division, without parsing a host integer.
        if (string_byte_len($value) > $bits) {
            return false;
        }
        $remaining = $value;
        for ($used = 0; $remaining !== ''; ++$used)
        {
            if ($used >= $bits) {
                return false;
            }
            $quotient = '';
            $carry = 0;
            $length = string_byte_len($remaining);
            for ($i = 0; $i < $length; ++$i)
            {
                $digit = ($carry * 10) + string_byte_at($remaining, $i) - 48;
                // The normalized digit/carry domain is 0..19; this division is exact before truncation.
                $q = (int)($digit / 2);
                if (($q !== 0) || ($quotient !== '')) {
                    $quotient .= string_byte_slice('0123456789', $q, 1);
                }
                $carry = $digit % 2;
            }
            $remaining = $quotient;
        }
        return true;
    }
}
