import gzip, hashlib, json, subprocess
from pathlib import Path
root = Path('/home/alex-ai/closure-batch/20261020-01')
v = root / 'verification'
manifest = json.loads((root/'closure_batch_source_candidate.json').read_text())
initial = json.loads((root/'closure_batch_source_initial.json').read_text())
mismatches = [p for p,h in manifest['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
assert not mismatches, mismatches
changed = [p for p,h in manifest['files'].items() if h != initial['files'].get(p)]
runtime_changed = [p for p in changed if p.startswith('runtime/')]
assert runtime_changed == ['runtime/metadata/modules/core.json'], runtime_changed
compiler_changed = [p for p in changed if p.startswith(('compiler/my-try/04_analyze/', 'compiler/my-try/compiler/'))]
expected_compiler = ['04_analyze/conversions/preparation.php','04_analyze/prepare/semantics/calls.php','04_analyze/prepare/semantics/runtime_calls.php','compiler/callables/catalog.php','compiler/callables/structures.php','compiler/runtime_catalog/patterns.php','compiler/runtime_catalog/reader.php','compiler/runtime_catalog/register.php','compiler/runtime_catalog/structures.php']
assert set(compiler_changed) == {'compiler/my-try/'+p for p in expected_compiler}, compiler_changed
accepted = ['runtime-first','payload-baseline','fixture-baseline','regressions-01','generics-02','json-01','search-01','replace-01','conditionals-01','payload-final-02','vectors-final','fixture-final']
suites = {}
summaries = {}
for name in accepted:
    commands = json.loads((v/name/'logs/commands.json').read_text())
    assert commands and all(c['code']==c['expected'] for c in commands), name
    suites[name] = {'commands':len(commands),'all_expected_exits':True,'command_seconds':round(sum(c['seconds'] for c in commands),2), 'native_executions':sum(c['name'].endswith(('-execute','-run')) for c in commands)}
    if (v/name/'summary.json').exists():
        summary = json.loads((v/name/'summary.json').read_text())
        assert summary['passed'], name
        summaries[name] = summary
payload = summaries['payload-final-02']['checks']
assert payload['original']['compiled'] and len(payload['signatures']) == 16 and payload['recoveries'] == 4
assert payload['original']['sha256'] == summaries['payload-baseline']['checks']['sha256']
vectors = summaries['vectors-final']['checks']
assert all(not row['compiled'] and 'copyable_value' in row['diagnostic'] for row in vectors['move_probes'].values())
assert vectors['recovery_cycles'] == 2
fixture = summaries['fixture-final']['checks']
records = {str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for name in ['closure_batch_source_initial.json','closure_batch_source_candidate.json']:
    records[name] = (root/name).read_text()
records['collector.py'] = Path(__file__).read_text()
toolchain = {n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()}
records['toolchain.json'] = json.dumps(toolchain)
archive = gzip.compress(json.dumps(records).encode())
Path('/tmp/closure-batch-evidence.json.gz').write_bytes(archive)
result = {'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'4416616e','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'source_integrity':{'checked':len(manifest['files']),'mismatches':mismatches,'runtime_changed':runtime_changed,'compiler_changed':compiler_changed},'toolchain':toolchain,'evidence_records':len(records),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'runtime_implementation_changes':False,'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':29,'partial':0,'total':64,'percent':45.3125},'remaining_batch_blockers':[]}
Path('/tmp/closure-batch-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted_commands':sum(s['commands'] for s in suites.values()),'native_executions':sum(s['native_executions'] for s in suites.values()),'source_files':len(manifest['files']),'evidence_records':len(records)}))
