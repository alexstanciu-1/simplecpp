#include "scpp/int_t.hpp"
#include "scpp/callable_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::callable_t<scpp::int_t<>()> local_f = ([&]() { auto callback = ([&]() { auto callback = []() -> scpp::int_t<> {
	return static_cast<scpp::int_t<>>(1LL);
}; bool transferable = true; struct closure_value { decltype(callback) body; bool transferable; bool transfer_allowed() const { return transferable; } scpp::int_t<> operator()() { return this->body(); } }; return closure_value{static_cast<decltype(callback)&&>(callback), transferable}; }()); bool transferable = callback.transfer_allowed(); return scpp::callable_t<scpp::int_t<>()>{static_cast<decltype(callback)&&>(callback), transferable}; }());
	return static_cast<int>((([&]() -> scpp::int_t<> { auto callee_0 = local_f;
return callee_0(); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
