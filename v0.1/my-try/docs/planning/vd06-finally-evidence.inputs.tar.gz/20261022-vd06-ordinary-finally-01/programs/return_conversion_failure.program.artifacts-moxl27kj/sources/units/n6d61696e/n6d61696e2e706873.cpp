#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/error_t.hpp"
#include "scpp/support/string_representation.hpp"
#include "utility"
#include "scpp/result.hpp"
#include "exception"
#include "optional"
#include "lang/php/support/php_string.hpp"
scpp::int_t<> function_f()
{
	scpp::result<scpp::int_t<>> local_r = scpp::result<scpp::int_t<>>{([&]() -> scpp::error_t { 	scpp::string_t argument_0 = scpp::string_t("bad");
scpp::int_t<> default_argument_1 = static_cast<scpp::int_t<>>(0LL);
scpp::string_t default_argument_2 = scpp::string_t("");
return scpp::error_t::make(argument_0, std::move(default_argument_1), std::move(default_argument_2)); }())};
{
std::exception_ptr finally_exception_3;
bool finally_return_3 = false;
std::optional<scpp::int_t<>> finally_value_3;
try { [&]() -> void {
{
finally_value_3.emplace(scpp::int_t<>((local_r).require_value("Result required-value extraction")));
finally_return_3 = true;
return;
}
}(); }
catch (...) { finally_exception_3 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_3) { std::rethrow_exception(finally_exception_3); }
if (finally_return_3) {
return std::move(*finally_value_3);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

