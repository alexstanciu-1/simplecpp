#include "lang/php/php_exceptions.hpp"
#include "exception"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
try {
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_3 = scpp::string_t("old");
return scpp::Exception::make(argument_3); }()));
}
catch (const ::scpp::php::thrown_object& caught_exception_2) {
auto caught_value_2 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_2);
if (!caught_value_2) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_2);
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_4 = scpp::string_t("new");
return scpp::Exception::make(argument_4); }()));
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	auto local_m = ([&]() -> scpp::string_t { auto receiver_5 = local_e;
(void)receiver_5.operator->();
return receiver_5->message_string(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_6 = local_m; auto operand_7 = scpp::string_t("new"); return scpp::php::identical(operand_6, operand_7); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
