#include "types/n4c6f67.hpp"
#include "callables/n6d61726b.hpp"
#include "callables/n66.hpp"
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "types/n4c6f67.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	([&]() -> void { return function_f(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_0 = record_Log::field_n; auto operand_1 = static_cast<scpp::int_t<>>(12LL); return scpp::php::identical(operand_0, operand_1); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
