#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "callables/n6d61726b.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "exception"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
void function_mark()
{
	static_cast<scpp::int_t<>>(record_Log::field_n++);
}

void function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
([&]() -> void { return function_mark(); }());
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_3 = ([&]() -> scpp::int_t<> { auto operand_1 = record_Log::field_n; auto operand_2 = static_cast<scpp::int_t<>>(10LL); return (operand_1 * operand_2); }()); auto operand_4 = static_cast<scpp::int_t<>>(2LL); return (operand_3 + operand_4); }());
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
	record_Log::field_n = static_cast<scpp::int_t<>>(999LL);
}

