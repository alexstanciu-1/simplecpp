#include "exception"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/index_read.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
	scpp::vector_t<scpp::int_t<>> local_v = scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(scpp::initializer_list<scpp::int_t<>>{});
	auto local_n = ([&]() -> scpp::int_t<> { const auto& index_receiver_1 = local_v; scpp::int_t<> index_key_1 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_1, index_key_1); }());
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return static_cast<int>((static_cast<scpp::int_t<>>(8LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
