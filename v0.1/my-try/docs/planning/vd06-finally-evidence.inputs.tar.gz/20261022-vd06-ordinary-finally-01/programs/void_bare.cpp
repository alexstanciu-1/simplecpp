// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
void function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
void function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
	::scpp::php::echo_one(scpp::string_t("BAD"));
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	([&]() -> void { return function_f(); }());
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
