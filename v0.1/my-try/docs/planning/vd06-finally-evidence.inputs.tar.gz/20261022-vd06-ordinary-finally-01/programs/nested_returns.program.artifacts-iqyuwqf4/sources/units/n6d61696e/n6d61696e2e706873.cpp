#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
{
std::exception_ptr finally_exception_1;
bool finally_return_1 = false;
std::optional<scpp::int_t<>> finally_value_1;
try { [&]() -> void {
{
finally_value_1.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_1 = true;
return;
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("inner"));
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
if (finally_return_1) {
finally_value_0.emplace(std::move(*finally_value_1));
finally_return_0 = true;
return;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
	::scpp::php::echo_one(scpp::string_t("BAD"));
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("outer"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

