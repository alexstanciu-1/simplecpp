#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "scpp/bool_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
{
	auto local_i = static_cast<scpp::int_t<>>(0LL);
for (; (([&]() -> scpp::bool_t { auto operand_1 = local_i; auto operand_2 = static_cast<scpp::int_t<>>(3LL); return (operand_1 < operand_2); }())).native_value(); (void)(static_cast<scpp::int_t<>>(record_Log::field_n++))) {
finally_value_0.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_0 = true;
return;
}
}
finally_value_0.emplace(static_cast<scpp::int_t<>>(8LL));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_5 = ([&]() -> scpp::int_t<> { auto operand_3 = record_Log::field_n; auto operand_4 = static_cast<scpp::int_t<>>(10LL); return (operand_3 * operand_4); }()); auto operand_6 = static_cast<scpp::int_t<>>(2LL); return (operand_5 + operand_6); }());
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

