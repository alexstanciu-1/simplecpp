// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
try {
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_2 = scpp::string_t("x");
return scpp::Exception::make(argument_2); }()));
}
catch (const ::scpp::php::thrown_object& caught_exception_1) {
auto caught_value_1 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_1);
if (!caught_value_1) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_1);
finally_value_0.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_0 = ([&]() -> scpp::int_t<> { return function_f(); }()); auto operand_1 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_0, operand_1); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
