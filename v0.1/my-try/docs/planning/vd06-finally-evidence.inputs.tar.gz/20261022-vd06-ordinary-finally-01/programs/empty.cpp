#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
try {
}
catch (const ::scpp::php::thrown_object& caught_exception_2) {
auto caught_value_2 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_2);
if (!caught_value_2) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_2);
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
