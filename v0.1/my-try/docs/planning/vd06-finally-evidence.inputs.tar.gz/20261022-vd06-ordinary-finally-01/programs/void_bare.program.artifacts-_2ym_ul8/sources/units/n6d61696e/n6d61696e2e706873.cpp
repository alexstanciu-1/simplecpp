#include "callables/n66.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
void function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
try { [&]() -> void {
{
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
	::scpp::php::echo_one(scpp::string_t("BAD"));
}

