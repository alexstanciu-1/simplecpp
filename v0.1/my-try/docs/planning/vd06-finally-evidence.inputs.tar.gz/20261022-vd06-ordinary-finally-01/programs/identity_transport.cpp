// SCPP-ARTIFACT {"id":"callable:capture","kind":"header","path":"callables\/n63617074757265.hpp"}
#pragma once
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
::scpp::shared_p<scpp::Exception> function_capture(::scpp::shared_p<scpp::Exception> local_e);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n63617074757265.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
::scpp::shared_p<scpp::Exception> function_capture(::scpp::shared_p<scpp::Exception> local_e)
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
throw ::scpp::php::make_thrown(local_e);
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "callables/n63617074757265.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
auto original = scpp::Exception::make(scpp::string_t("identity")); try { function_capture(original); return 8; } catch (const scpp::php::thrown_object& caught) { if (caught.value().native_value().get() != original.native_value().get()) { return 9; } }
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_e = ([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_0 = scpp::string_t("identity");
return scpp::Exception::make(argument_0); }());
try {
	auto local_out = ([&]() -> ::scpp::shared_p<scpp::Exception> { 	::scpp::shared_p<scpp::Exception> argument_2 = local_e;
return function_capture(argument_2); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_1) {
auto caught_value_1 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_1);
if (!caught_value_1) { throw; }
::scpp::shared_p<scpp::Exception> local_caught = std::move(caught_value_1);
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
