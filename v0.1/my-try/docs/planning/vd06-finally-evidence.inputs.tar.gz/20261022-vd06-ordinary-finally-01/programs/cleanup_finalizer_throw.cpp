// SCPP-ARTIFACT {"id":"type:Log","kind":"header","path":"types\/n4c6f67.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_Log
{
public:
	static scpp::int_t<> field_n;
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Item","kind":"header","path":"types\/n4974656d.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "utility"
struct record_Item
{
public:
	scpp::int_t<> field_id;
public:
	struct scpp_data_tag {};
	record_Item() = default;
	record_Item(scpp_data_tag, scpp::int_t<> input_0) : field_id(std::move(input_0)) {}
public:
	~record_Item() noexcept;
public:
	record_Item(const record_Item&) = default;
	record_Item(record_Item&&) = default;
	record_Item& operator=(const record_Item&) = default;
	record_Item& operator=(record_Item&&) = default;
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
void function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "types/n4974656d.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "utility"
#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
record_Item::~record_Item() noexcept
{
	auto local_id = (this)->field_id;
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = record_Log::field_n; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = local_id; return (operand_2 + operand_3); }());
}

void function_f()
{
	record_Item local_outer = ([&]() -> record_Item { scpp::int_t<> record_input_0 = static_cast<scpp::int_t<>>(9LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_0)); }());
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
{
	record_Item local_a = ([&]() -> record_Item { scpp::int_t<> record_input_2 = static_cast<scpp::int_t<>>(1LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_2)); }());
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_3 = scpp::string_t("old");
return scpp::Exception::make(argument_3); }()));
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	record_Item local_b = ([&]() -> record_Item { scpp::int_t<> record_input_4 = static_cast<scpp::int_t<>>(2LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_4)); }());
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_5 = scpp::string_t("new");
return scpp::Exception::make(argument_5); }()));
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/php_exceptions.hpp"
#include "callables/n66.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "types/n4c6f67.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
	([&]() -> void { return function_f(); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	auto local_m = ([&]() -> scpp::string_t { auto receiver_1 = local_e;
(void)receiver_1.operator->();
return receiver_1->message_string(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_2 = local_m; auto operand_3 = scpp::string_t("new"); return scpp::php::identical(operand_2, operand_3); }())) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_4 = record_Log::field_n; auto operand_5 = static_cast<scpp::int_t<>>(129LL); return scpp::php::identical(operand_4, operand_5); }())))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
