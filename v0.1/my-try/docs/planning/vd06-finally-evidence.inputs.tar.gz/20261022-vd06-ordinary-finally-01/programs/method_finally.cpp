// SCPP-ARTIFACT {"id":"type:C","kind":"header","path":"types\/n43.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_C
{
public:
	scpp::int_t<> field_n = static_cast<scpp::int_t<>>(7LL);
public:
public:
	scpp::int_t<> implementation_C__method_f();
scpp::int_t<> method_f();
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "types/n43.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
scpp::int_t<> record_C::method_f() { return record_C::implementation_C__method_f(); }
scpp::int_t<> record_C::implementation_C__method_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace((this)->field_n);
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	(this)->field_n = static_cast<scpp::int_t<>>(9LL);
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n43.hpp"
#include "scpp/memory.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_c = ::scpp::shared<record_C>();
	auto local_n = ([&]() -> scpp::int_t<> { auto receiver_0 = local_c;
(void)receiver_0.operator->();
return receiver_0->method_f(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_1 = local_n; auto operand_2 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_1, operand_2); }())) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_3 = (local_c)->field_n; auto operand_4 = static_cast<scpp::int_t<>>(9LL); return scpp::php::identical(operand_3, operand_4); }())))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
