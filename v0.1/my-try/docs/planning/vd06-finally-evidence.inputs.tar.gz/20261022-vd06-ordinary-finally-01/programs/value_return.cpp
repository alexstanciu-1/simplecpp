// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
scpp::vector_t<scpp::int_t<>> function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
scpp::vector_t<scpp::int_t<>> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::vector_t<scpp::int_t<>>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(([&]() -> scpp::vector_t<scpp::int_t<>> { scpp::initializer_buffer<scpp::int_t<>> initializer_1(1);
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(7LL);
initializer_1.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_1.view()); }()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "callables/n66.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> { return function_f(); }());
	::scpp::php::echo_one(([&]() -> scpp::int_t<> { const auto& index_receiver_0 = local_v; scpp::int_t<> index_key_0 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_0, index_key_0); }()));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
