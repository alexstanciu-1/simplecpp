#include "scpp/int_t.hpp"
#include "exception"
#include "scpp/bool_t.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
while ((([&]() -> scpp::bool_t { auto operand_1 = local_n; auto operand_2 = static_cast<scpp::int_t<>>(4LL); return (operand_1 < operand_2); }())).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
if ((([&]() -> scpp::bool_t { auto operand_3 = local_n; auto operand_4 = static_cast<scpp::int_t<>>(1LL); return scpp::php::identical(operand_3, operand_4); }())).native_value()) {
continue;
}
break;
}
switch ((local_n).native_value()) {
case 2LL:
{
	local_n = static_cast<scpp::int_t<>>(3LL);
break;
}
default:
{
	local_n = static_cast<scpp::int_t<>>(99LL);
}
}
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
while ((([&]() -> scpp::bool_t { auto operand_5 = local_n; auto operand_6 = static_cast<scpp::int_t<>>(5LL); return (operand_5 < operand_6); }())).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
if ((([&]() -> scpp::bool_t { auto operand_7 = local_n; auto operand_8 = static_cast<scpp::int_t<>>(4LL); return scpp::php::identical(operand_7, operand_8); }())).native_value()) {
continue;
}
break;
}
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_9 = local_n; auto operand_10 = static_cast<scpp::int_t<>>(5LL); return scpp::php::identical(operand_9, operand_10); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
