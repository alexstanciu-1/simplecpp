// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/float_t.hpp"
scpp::float_t function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:b","kind":"header","path":"callables\/n62.hpp"}
#pragma once
#include "scpp/bool_t.hpp"
scpp::bool_t function_b();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "scpp/float_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "callables/n62.hpp"
#include "scpp/bool_t.hpp"
scpp::float_t function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::float_t> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(static_cast<scpp::float_t>(2.5));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

scpp::bool_t function_b()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::bool_t> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(static_cast<scpp::bool_t>(false));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/float_t.hpp"
#include "callables/n66.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n62.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	::scpp::php::echo_one(([&]() -> scpp::float_t { return function_f(); }()));
	return static_cast<int>((([&]() -> scpp::int_t<> { if (((!([&]() -> scpp::bool_t { return function_b(); }()))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
