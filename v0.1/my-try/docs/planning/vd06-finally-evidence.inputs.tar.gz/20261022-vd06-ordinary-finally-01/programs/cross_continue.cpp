#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "scpp/generated/operators.hpp"
#include "exception"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
while ((([&]() -> scpp::bool_t { auto operand_0 = local_n; auto operand_1 = static_cast<scpp::int_t<>>(2LL); return (operand_0 < operand_1); }())).native_value()) {
{
std::exception_ptr finally_exception_2;
int finally_transfer_2 = 0;
try { [&]() -> void {
{
	static_cast<scpp::int_t<>>(++local_n);
finally_transfer_2 = 2;
return;
}
}(); }
catch (...) { finally_exception_2 = std::current_exception(); }
{
	::scpp::php::echo_one(local_n);
}
if (finally_exception_2) { std::rethrow_exception(finally_exception_2); }
if (finally_transfer_2 == 2) {
continue;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
