#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "types/n4974656d.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "utility"
#include "exception"
#include "optional"
#include "lang/php/support/php_string.hpp"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
record_Item::~record_Item() noexcept
{
	auto local_id = (this)->field_id;
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = record_Log::field_n; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = local_id; return (operand_2 + operand_3); }());
}

scpp::int_t<> function_f()
{
	record_Item local_outer = ([&]() -> record_Item { scpp::int_t<> record_input_0 = static_cast<scpp::int_t<>>(9LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_0)); }());
{
std::exception_ptr finally_exception_1;
bool finally_return_1 = false;
std::optional<scpp::int_t<>> finally_value_1;
try { [&]() -> void {
{
	record_Item local_a = ([&]() -> record_Item { scpp::int_t<> record_input_2 = static_cast<scpp::int_t<>>(1LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_2)); }());
	record_Item local_b = ([&]() -> record_Item { scpp::int_t<> record_input_3 = static_cast<scpp::int_t<>>(2LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_3)); }());
finally_value_1.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_1 = true;
return;
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	::scpp::php::echo_one(record_Log::field_n);
	record_Item local_c = ([&]() -> record_Item { scpp::int_t<> record_input_4 = static_cast<scpp::int_t<>>(3LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_4)); }());
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
if (finally_return_1) {
return std::move(*finally_value_1);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

