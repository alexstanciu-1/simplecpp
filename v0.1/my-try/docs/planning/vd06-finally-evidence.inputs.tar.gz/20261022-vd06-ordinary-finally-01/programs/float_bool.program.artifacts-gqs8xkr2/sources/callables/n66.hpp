#pragma once
#include "scpp/float_t.hpp"
scpp::float_t function_f();
