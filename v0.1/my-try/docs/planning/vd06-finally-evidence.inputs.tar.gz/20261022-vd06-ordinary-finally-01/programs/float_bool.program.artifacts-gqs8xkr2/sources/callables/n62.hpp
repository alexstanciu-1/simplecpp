#pragma once
#include "scpp/bool_t.hpp"
scpp::bool_t function_b();
