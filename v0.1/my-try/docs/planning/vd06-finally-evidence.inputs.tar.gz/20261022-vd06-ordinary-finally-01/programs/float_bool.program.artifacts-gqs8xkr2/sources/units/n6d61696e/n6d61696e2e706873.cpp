#include "callables/n66.hpp"
#include "scpp/float_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "callables/n62.hpp"
#include "scpp/bool_t.hpp"
scpp::float_t function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::float_t> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(static_cast<scpp::float_t>(2.5));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

scpp::bool_t function_b()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::bool_t> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(static_cast<scpp::bool_t>(false));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

