#include "callables/n66.hpp"
#include "callables/n62.hpp"
#include "scpp/float_t.hpp"
#include "callables/n66.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n62.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	::scpp::php::echo_one(([&]() -> scpp::float_t { return function_f(); }()));
	return static_cast<int>((([&]() -> scpp::int_t<> { if (((!([&]() -> scpp::bool_t { return function_b(); }()))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
