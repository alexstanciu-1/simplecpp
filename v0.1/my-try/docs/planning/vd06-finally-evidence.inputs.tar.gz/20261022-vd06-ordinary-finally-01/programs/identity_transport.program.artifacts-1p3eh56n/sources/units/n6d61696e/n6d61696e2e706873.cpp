#include "callables/n63617074757265.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
::scpp::shared_p<scpp::Exception> function_capture(::scpp::shared_p<scpp::Exception> local_e)
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
throw ::scpp::php::make_thrown(local_e);
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

