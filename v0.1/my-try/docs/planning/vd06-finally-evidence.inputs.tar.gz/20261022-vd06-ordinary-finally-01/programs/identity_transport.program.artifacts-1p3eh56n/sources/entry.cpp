#include "callables/n63617074757265.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "callables/n63617074757265.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
auto original = scpp::Exception::make(scpp::string_t("identity")); try { function_capture(original); return 8; } catch (const scpp::php::thrown_object& caught) { if (caught.value().native_value().get() != original.native_value().get()) { return 9; } }
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_e = ([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_0 = scpp::string_t("identity");
return scpp::Exception::make(argument_0); }());
try {
	auto local_out = ([&]() -> ::scpp::shared_p<scpp::Exception> { 	::scpp::shared_p<scpp::Exception> argument_2 = local_e;
return function_capture(argument_2); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_1) {
auto caught_value_1 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_1);
if (!caught_value_1) { throw; }
::scpp::shared_p<scpp::Exception> local_caught = std::move(caught_value_1);
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
