#pragma once
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
::scpp::shared_p<scpp::Exception> function_capture(::scpp::shared_p<scpp::Exception> local_e);
