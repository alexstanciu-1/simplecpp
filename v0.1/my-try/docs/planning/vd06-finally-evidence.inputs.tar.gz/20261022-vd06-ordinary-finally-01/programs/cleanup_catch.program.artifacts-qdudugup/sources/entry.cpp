#include "types/n4c6f67.hpp"
#include "types/n4974656d.hpp"
#include "lang/php/php_exceptions.hpp"
#include "exception"
#include "types/n4974656d.hpp"
#include "scpp/int_t.hpp"
#include "utility"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "types/n4c6f67.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
try {
	record_Item local_a = ([&]() -> record_Item { scpp::int_t<> record_input_3 = static_cast<scpp::int_t<>>(1LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_3)); }());
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_4 = scpp::string_t("x");
return scpp::Exception::make(argument_4); }()));
}
catch (const ::scpp::php::thrown_object& caught_exception_2) {
auto caught_value_2 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_2);
if (!caught_value_2) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_2);
	record_Item local_b = ([&]() -> record_Item { scpp::int_t<> record_input_5 = static_cast<scpp::int_t<>>(2LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_5)); }());
throw ::scpp::php::make_thrown(local_e);
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	::scpp::php::echo_one(record_Log::field_n);
	record_Item local_c = ([&]() -> record_Item { scpp::int_t<> record_input_6 = static_cast<scpp::int_t<>>(3LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_6)); }());
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_7 = record_Log::field_n; auto operand_8 = static_cast<scpp::int_t<>>(123LL); return scpp::php::identical(operand_7, operand_8); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
