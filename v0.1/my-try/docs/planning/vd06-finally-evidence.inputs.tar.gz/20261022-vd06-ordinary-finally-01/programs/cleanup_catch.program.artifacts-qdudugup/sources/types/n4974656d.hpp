#pragma once
#include "scpp/int_t.hpp"
#include "utility"
struct record_Item
{
public:
	scpp::int_t<> field_id;
public:
	struct scpp_data_tag {};
	record_Item() = default;
	record_Item(scpp_data_tag, scpp::int_t<> input_0) : field_id(std::move(input_0)) {}
public:
	~record_Item() noexcept;
public:
	record_Item(const record_Item&) = default;
	record_Item(record_Item&&) = default;
	record_Item& operator=(const record_Item&) = default;
	record_Item& operator=(record_Item&&) = default;
};

