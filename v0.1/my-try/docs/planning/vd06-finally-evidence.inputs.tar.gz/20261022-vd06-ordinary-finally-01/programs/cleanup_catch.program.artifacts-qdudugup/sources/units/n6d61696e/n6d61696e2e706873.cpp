#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "types/n4974656d.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
record_Item::~record_Item() noexcept
{
	auto local_id = (this)->field_id;
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = record_Log::field_n; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = local_id; return (operand_2 + operand_3); }());
}

