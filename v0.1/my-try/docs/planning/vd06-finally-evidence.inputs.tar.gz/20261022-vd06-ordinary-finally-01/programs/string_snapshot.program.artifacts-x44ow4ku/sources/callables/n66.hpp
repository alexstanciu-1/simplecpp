#pragma once
#include "scpp/support/string_representation.hpp"
scpp::string_t function_f();
