#include "callables/n66.hpp"
#include "scpp/support/string_representation.hpp"
#include "exception"
#include "optional"
#include "utility"
scpp::string_t function_f()
{
	auto local_s = scpp::string_t("old");
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::string_t> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(local_s);
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	local_s = scpp::string_t("new");
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

