#include "lang/php/php_exceptions.hpp"
#include "exception"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
{
{
std::exception_ptr finally_exception_2;
try { [&]() -> void {
{
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_3 = scpp::string_t("x");
return scpp::Exception::make(argument_3); }()));
}
}(); }
catch (...) { finally_exception_2 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("1"));
}
if (finally_exception_2) { std::rethrow_exception(finally_exception_2); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("2"));
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	::scpp::php::echo_one(scpp::string_t("3"));
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
