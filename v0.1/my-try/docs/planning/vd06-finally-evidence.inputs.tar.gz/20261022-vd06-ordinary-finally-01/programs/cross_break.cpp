#include "scpp/bool_t.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
while ((static_cast<scpp::bool_t>(true)).native_value()) {
{
std::exception_ptr finally_exception_0;
int finally_transfer_0 = 0;
try { [&]() -> void {
{
finally_transfer_0 = 1;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_transfer_0 == 1) {
break;
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
