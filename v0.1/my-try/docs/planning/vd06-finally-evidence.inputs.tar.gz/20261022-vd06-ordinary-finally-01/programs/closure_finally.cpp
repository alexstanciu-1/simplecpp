#include "exception"
#include "scpp/int_t.hpp"
#include "optional"
#include "utility"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_f = ([&]() { auto callback = []() -> scpp::int_t<> {
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}; bool transferable = true; struct closure_value { decltype(callback) body; bool transferable; bool transfer_allowed() const { return transferable; } scpp::int_t<> operator()() { return this->body(); } }; return closure_value{static_cast<decltype(callback)&&>(callback), transferable}; }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_2 = ([&]() -> scpp::int_t<> { auto callee_1 = local_f;
return callee_1(); }()); auto operand_3 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_2, operand_3); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
