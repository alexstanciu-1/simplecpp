#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(7LL);
	scpp::int_t<>& local_alias = ([&]() -> scpp::int_t<>& { 	scpp::int_t<>& argument_0 = local_n;
return function_f(argument_0); }());
	local_alias = static_cast<scpp::int_t<>>(9LL);
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_1 = local_n; auto operand_2 = static_cast<scpp::int_t<>>(9LL); return scpp::php::identical(operand_1, operand_2); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
