#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
scpp::int_t<>& function_f(scpp::int_t<>& local_n)
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return local_n;
}

