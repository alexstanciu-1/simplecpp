#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_1 = scpp::string_t("original");
return scpp::Exception::make(argument_1); }()));
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
{
std::exception_ptr finally_exception_2;
try { [&]() -> void {
{
	::scpp::php::echo_one(scpp::string_t("1"));
}
}(); }
catch (...) { finally_exception_2 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("2"));
}
if (finally_exception_2) { std::rethrow_exception(finally_exception_2); }
}
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
