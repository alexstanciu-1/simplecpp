#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "scpp/generated/operators.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
	auto local_f = ([&]() { auto callback = []() -> scpp::int_t<> {
	return static_cast<scpp::int_t<>>(3LL);
}; bool transferable = true; struct closure_value { decltype(callback) body; bool transferable; bool transfer_allowed() const { return transferable; } scpp::int_t<> operator()() { return this->body(); } }; return closure_value{static_cast<decltype(callback)&&>(callback), transferable}; }());
	local_n = ([&]() -> scpp::int_t<> { auto callee_1 = local_f;
return callee_1(); }());
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	auto local_g = ([&]() { auto callback = []() -> scpp::int_t<> {
{
std::exception_ptr finally_exception_2;
bool finally_return_2 = false;
std::optional<scpp::int_t<>> finally_value_2;
try { [&]() -> void {
{
finally_value_2.emplace(static_cast<scpp::int_t<>>(4LL));
finally_return_2 = true;
return;
}
}(); }
catch (...) { finally_exception_2 = std::current_exception(); }
{
}
if (finally_exception_2) { std::rethrow_exception(finally_exception_2); }
if (finally_return_2) {
return std::move(*finally_value_2);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}; bool transferable = true; struct closure_value { decltype(callback) body; bool transferable; bool transfer_allowed() const { return transferable; } scpp::int_t<> operator()() { return this->body(); } }; return closure_value{static_cast<decltype(callback)&&>(callback), transferable}; }());
	local_n = ([&]() -> scpp::int_t<> { auto operand_4 = local_n; auto operand_5 = ([&]() -> scpp::int_t<> { auto callee_3 = local_g;
return callee_3(); }()); return (operand_4 + operand_5); }());
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_6 = local_n; auto operand_7 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_6, operand_7); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
