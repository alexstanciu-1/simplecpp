#include "types/n43.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
scpp::int_t<> record_C::method_f() { return record_C::implementation_C__method_f(); }
scpp::int_t<> record_C::implementation_C__method_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace((this)->field_n);
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	(this)->field_n = static_cast<scpp::int_t<>>(9LL);
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

