#include "types/n43.hpp"
#include "types/n43.hpp"
#include "scpp/memory.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_c = ::scpp::shared<record_C>();
	auto local_n = ([&]() -> scpp::int_t<> { auto receiver_0 = local_c;
(void)receiver_0.operator->();
return receiver_0->method_f(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_1 = local_n; auto operand_2 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_1, operand_2); }())) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_3 = (local_c)->field_n; auto operand_4 = static_cast<scpp::int_t<>>(9LL); return scpp::php::identical(operand_3, operand_4); }())))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
