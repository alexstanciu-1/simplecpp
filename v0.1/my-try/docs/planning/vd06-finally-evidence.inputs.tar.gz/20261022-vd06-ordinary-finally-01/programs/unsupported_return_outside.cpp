// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
scpp::vector_t<scpp::int_t<>> function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
scpp::vector_t<scpp::int_t<>> function_f()
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return ([&]() -> scpp::vector_t<scpp::int_t<>> { scpp::initializer_buffer<scpp::int_t<>> initializer_1(1);
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(7LL);
initializer_1.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_1.view()); }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "callables/n66.hpp"
#include "scpp/index_read.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> { return function_f(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_1 = ([&]() -> scpp::int_t<> { const auto& index_receiver_0 = local_v; scpp::int_t<> index_key_0 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_0, index_key_0); }()); auto operand_2 = static_cast<scpp::int_t<>>(7LL); return scpp::php::identical(operand_1, operand_2); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
