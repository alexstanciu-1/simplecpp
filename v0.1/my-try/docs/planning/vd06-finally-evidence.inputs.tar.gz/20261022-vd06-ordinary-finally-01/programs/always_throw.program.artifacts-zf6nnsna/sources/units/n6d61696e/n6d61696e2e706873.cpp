#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_1 = scpp::string_t("F");
return scpp::Exception::make(argument_1); }()));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

