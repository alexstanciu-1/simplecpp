#include "callables/n66.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/shared_p.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
	auto local_n = ([&]() -> scpp::int_t<> { return function_f(); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
