#include "callables/n66.hpp"
#include "lang/php/php_exceptions.hpp"
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
	auto local_n = ([&]() -> scpp::int_t<> { return function_f(); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	auto local_m = ([&]() -> scpp::string_t { auto receiver_1 = local_e;
(void)receiver_1.operator->();
return receiver_1->message_string(); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((([&]() -> scpp::bool_t { auto operand_2 = local_m; auto operand_3 = scpp::string_t("new"); return scpp::php::identical(operand_2, operand_3); }())).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(2LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
