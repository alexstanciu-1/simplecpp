#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
try {
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_2 = scpp::string_t("x");
return scpp::Exception::make(argument_2); }()));
}
catch (const ::scpp::php::thrown_object& caught_exception_1) {
auto caught_value_1 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_1);
if (!caught_value_1) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_1);
finally_value_0.emplace(static_cast<scpp::int_t<>>(7LL));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

