// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_f();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
scpp::int_t<> function_f()
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_1 = scpp::string_t("F");
return scpp::Exception::make(argument_1); }()));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/php_exceptions.hpp"
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/shared_p.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
try {
	auto local_n = ([&]() -> scpp::int_t<> { return function_f(); }());
}
catch (const ::scpp::php::thrown_object& caught_exception_0) {
auto caught_value_0 = ::scpp::php::catch_as<scpp::Exception>(caught_exception_0);
if (!caught_value_0) { throw; }
::scpp::shared_p<scpp::Exception> local_e = std::move(caught_value_0);
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
