#include "types/n4c6f67.hpp"
#include "scpp/int_t.hpp"
#include "types/n4974656d.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "utility"
#include "exception"
#include "lang/php/php_exceptions.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/support/string_representation.hpp"
scpp::int_t<> record_Log::field_n = static_cast<scpp::int_t<>>(0LL);
record_Item::~record_Item() noexcept
{
	auto local_id = (this)->field_id;
	record_Log::field_n = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = record_Log::field_n; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = local_id; return (operand_2 + operand_3); }());
}

void function_f()
{
	record_Item local_outer = ([&]() -> record_Item { scpp::int_t<> record_input_0 = static_cast<scpp::int_t<>>(9LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_0)); }());
{
std::exception_ptr finally_exception_1;
try { [&]() -> void {
{
	record_Item local_a = ([&]() -> record_Item { scpp::int_t<> record_input_2 = static_cast<scpp::int_t<>>(1LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_2)); }());
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_3 = scpp::string_t("old");
return scpp::Exception::make(argument_3); }()));
}
}(); }
catch (...) { finally_exception_1 = std::current_exception(); }
{
	record_Item local_b = ([&]() -> record_Item { scpp::int_t<> record_input_4 = static_cast<scpp::int_t<>>(2LL);
return record_Item(record_Item::scpp_data_tag{}, std::move(record_input_4)); }());
throw ::scpp::php::make_thrown(([&]() -> ::scpp::shared_p<scpp::Exception> { 	scpp::string_t argument_5 = scpp::string_t("new");
return scpp::Exception::make(argument_5); }()));
}
if (finally_exception_1) { std::rethrow_exception(finally_exception_1); }
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

