#include "callables/n6e657874.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "exception"
#include "optional"
#include "utility"
scpp::int_t<> function_next(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_n;
}

scpp::int_t<> function_f(scpp::int_t<>& local_n)
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(([&]() -> scpp::int_t<> { 	scpp::int_t<>& argument_1 = local_n;
return function_next(argument_1); }()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	local_n = ([&]() -> scpp::int_t<> { auto operand_4 = ([&]() -> scpp::int_t<> { auto operand_2 = local_n; auto operand_3 = static_cast<scpp::int_t<>>(10LL); return (operand_2 * operand_3); }()); auto operand_5 = static_cast<scpp::int_t<>>(2LL); return (operand_4 + operand_5); }());
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

