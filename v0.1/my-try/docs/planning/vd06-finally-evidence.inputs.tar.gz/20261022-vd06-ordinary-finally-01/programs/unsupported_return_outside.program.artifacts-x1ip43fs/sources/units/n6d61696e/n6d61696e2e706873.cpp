#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "exception"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
scpp::vector_t<scpp::int_t<>> function_f()
{
{
std::exception_ptr finally_exception_0;
try { [&]() -> void {
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
}
	return ([&]() -> scpp::vector_t<scpp::int_t<>> { scpp::initializer_buffer<scpp::int_t<>> initializer_1(1);
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(7LL);
initializer_1.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_1.view()); }());
}

