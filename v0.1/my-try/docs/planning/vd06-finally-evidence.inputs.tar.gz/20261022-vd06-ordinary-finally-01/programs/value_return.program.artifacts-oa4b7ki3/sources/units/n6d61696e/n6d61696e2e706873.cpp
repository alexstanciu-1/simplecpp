#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "exception"
#include "optional"
#include "utility"
#include "scpp/data_initializer_typed.hpp"
#include "scpp/data_initializer_input.hpp"
#include "scpp/support/string_representation.hpp"
#include "lang/php/support/php_string.hpp"
scpp::vector_t<scpp::int_t<>> function_f()
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::vector_t<scpp::int_t<>>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(([&]() -> scpp::vector_t<scpp::int_t<>> { scpp::initializer_buffer<scpp::int_t<>> initializer_1(1);
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(7LL);
initializer_1.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_1.view()); }()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	::scpp::php::echo_one(scpp::string_t("F"));
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

