#include "callables/n66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "callables/n66.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/support/php_string.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> { return function_f(); }());
	::scpp::php::echo_one(([&]() -> scpp::int_t<> { const auto& index_receiver_0 = local_v; scpp::int_t<> index_key_0 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_0, index_key_0); }()));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
