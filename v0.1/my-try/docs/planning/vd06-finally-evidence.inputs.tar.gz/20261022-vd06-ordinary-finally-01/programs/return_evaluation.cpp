// SCPP-ARTIFACT {"id":"callable:next","kind":"header","path":"callables\/n6e657874.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_next(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:f","kind":"header","path":"callables\/n66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_f(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6e657874.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66.hpp"
#include "exception"
#include "optional"
#include "utility"
scpp::int_t<> function_next(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_n;
}

scpp::int_t<> function_f(scpp::int_t<>& local_n)
{
{
std::exception_ptr finally_exception_0;
bool finally_return_0 = false;
std::optional<scpp::int_t<>> finally_value_0;
try { [&]() -> void {
{
finally_value_0.emplace(([&]() -> scpp::int_t<> { 	scpp::int_t<>& argument_1 = local_n;
return function_next(argument_1); }()));
finally_return_0 = true;
return;
}
}(); }
catch (...) { finally_exception_0 = std::current_exception(); }
{
	local_n = ([&]() -> scpp::int_t<> { auto operand_4 = ([&]() -> scpp::int_t<> { auto operand_2 = local_n; auto operand_3 = static_cast<scpp::int_t<>>(10LL); return (operand_2 * operand_3); }()); auto operand_5 = static_cast<scpp::int_t<>>(2LL); return (operand_4 + operand_5); }());
}
if (finally_exception_0) { std::rethrow_exception(finally_exception_0); }
if (finally_return_0) {
return std::move(*finally_value_0);
}
std::terminate(); // unreachable: prepared finally region cannot fall through
}
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "callables/n66.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
	auto local_v = ([&]() -> scpp::int_t<> { 	scpp::int_t<>& argument_0 = local_n;
return function_f(argument_0); }());
	return static_cast<int>((([&]() -> scpp::int_t<> { if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_1 = local_v; auto operand_2 = static_cast<scpp::int_t<>>(1LL); return scpp::php::identical(operand_1, operand_2); }())) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_3 = local_n; auto operand_4 = static_cast<scpp::int_t<>>(12LL); return scpp::php::identical(operand_3, operand_4); }())))).native_value()) { return static_cast<scpp::int_t<>>(0LL); } return static_cast<scpp::int_t<>>(1LL); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
