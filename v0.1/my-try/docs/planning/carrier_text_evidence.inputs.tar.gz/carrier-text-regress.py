import concurrent.futures,subprocess,os,json
from pathlib import Path
os.chdir('/home/alex-ai/carrier-text/20261020-01')
os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=[('adjacent','carrier_text_adjacent',[]),('controls','vl07_controls',[]),('indexed-text','vl07_indexed_text',[]),('eager','eager_binary',[]),('compound','compound_effects',[]),('index-compound','index_compound',[]),('mixed','mixed',['--no-pch']),('runtime-strings','runtime_strings',[])]
def run(row):
 name,script,extra=row
 with open('verification/regression-'+name+'.stdout','w') as out:code=subprocess.call(['python3','compiler/my-try/tests/'+script+'.py','--results','verification/regression-'+name]+extra,stdout=out,stderr=subprocess.STDOUT)
 print(name,code,flush=True);return name,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,suites))
Path('verification/regression-exits.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(results.values()))
