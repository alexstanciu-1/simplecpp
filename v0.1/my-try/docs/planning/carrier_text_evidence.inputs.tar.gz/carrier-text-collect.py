import json,gzip,hashlib,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/alex-ai/carrier-text/20261020-01');v=root/'verification'
m=json.loads((root/'carrier_text_source_final.json').read_text());bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
initial=json.loads((root/'carrier_text_source_initial.json').read_text());runtime=[p for p in m['files'] if p.startswith('runtime/') and p!='runtime/specs/config.json'];assert all(initial['files'].get(p)==m['files'][p] for p in runtime)
reg=json.loads((v/'regression-exits.json').read_text());rep=json.loads((v/'repaired-exits.json').read_text());resolved={**reg,**rep};assert len(resolved)==8 and not any(resolved.values()),resolved
accepted=['runtime-baseline','text-domain-final','text-controls-final']+['repaired-'+k if k in rep else 'regression-'+k for k in reg]
suites={}
for name in accepted:
 commands=[c for p in (v/name).rglob('commands.json') for c in json.loads(p.read_text())];assert commands and all(c['code']==c['expected'] for c in commands),name
 suites[name]={'commands':len(commands),'all_expected_exits':True}
full=json.loads((v/'text-domain-final/summary.json').read_text());assert full['passed'] and full['signatures']==864
control=json.loads((v/'text-controls-final/summary.json').read_text());assert control['passed'] and len(control['signatures'])==60 and len(control['original_findings'])==4
indexed=json.loads((v/'regression-indexed-text/summary.json').read_text());assert all(r['supported'] for r in indexed['rows'].values())
sigs=[r['signature'] for r in full['results'].values()]+control['signatures'];assert len(sigs)==len(set(map(tuple,sigs)))==924
counts={}
for name in accepted:
 for p in (v/name).rglob('*.stdout'):
  found={k:int(n) for k,n in re.findall(r'(composition_states|cases)=(\d+)',p.read_text())}
  if found:counts[str(p.relative_to(root))]=found
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
records['source-integrity.json']=json.dumps({'checked':len(m['files']),'mismatches':bad,'runtime_implementation_files_unchanged':len(runtime),'runtime_contract_metadata_changed':'runtime/specs/config.json'})
records['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
for p in root.glob('carrier-text-*.py'):records[p.name]=p.read_text()
for name in ['delta-01.tar.gz','delta-02.tar.gz','delta-03.tar.gz','carrier-text-delta.tar.gz']:
 with tarfile.open(root/name) as archive:
  records['snapshots/'+name+'.json']=archive.extractfile('carrier_text_source_current.json').read().decode()
archive=gzip.compress(json.dumps(records).encode());Path('/tmp/carrier-text-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'head':'ee3dceb4','signature_counts':{'named_type_concat':729,'named_type_append':135,'literal_null':60,'total':924},'signatures':sorted(sigs),'native_observations':sum(sum(c.values()) for c in counts.values()),'counts':counts,'runtime_probe':json.loads((v/'runtime-baseline/summary.json').read_text()),'controls':control,'indexed_preservation':indexed,'suites':suites,'regression_original_exits':reg,'regression_repair_exits':rep,'regression_resolved_exits':resolved,'source_integrity':json.loads(records['source-integrity.json']),'toolchain':json.loads(records['toolchain.json']),'runtime_implementation_changes':False,'runtime_contract_metadata_changed':True,'full_matrix_run':False,'native_compiler_rebuilt':False,'remaining_blockers_in_scope':[],'deferred_domains':['uint64 text','wrapped fixed widths','nested carriers','object/container text','new boxed combinations','new indexed capabilities','other conversion contexts'],'attempts':{'runtime_first':'188 state/payload compositions pass. Direct float carrier cast differs from plain text formatting; existing state/payload plus scalar text helpers provide the agreed contract without runtime implementation repair.','smoke_01':'Deferred ?int16 rejection fixture initializer failed before concatenation; changed to default empty nullable for a meaningful text rejection.','first_full_run':'All864 named rows passed before final boxed/indexed exclusion guards; final864 rows repeated with final compiler code.','regressions':'Four suites shared the stale string .= ?int rejection. Added its positive check and retained a ?int16 rejection, then reran those four suites.','runtime_scope':'No runtime implementation, operator matrix or native compiler rebuild.'},'evidence_sha256':hashlib.sha256(archive).hexdigest(),'original_issue_closure':{'closed':24,'total':64,'percent':37.5},'vl07_historical_inventory':3376}
Path('/tmp/carrier-text-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'source_files':len(m['files']),'unchanged_runtime_implementation_files':len(runtime),'accepted_suites':len(suites),'accepted_commands':sum(x['commands'] for x in suites.values()),'archive_records':len(records),'observations':r['native_observations']},indent=2))
