from pathlib import Path
import sys,json
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True)
sys.path.insert(0,str(root/'compiler/my-try/tools'))
from test_runner import CommandRunner,Task,run_tasks
with CommandRunner(out/'logs',root,jobs=12) as runner:
 def check(name,script,folder=False):
  args=[]
  if folder:
   target=out/name;target.mkdir();args=[target]
  runner.run(name,['php',root/'compiler/my-try/tests'/script,*args],timeout=120)
 run_tasks([Task('catalog',lambda:check('catalog','runtime_catalog.php',True)),Task('inventory',lambda:check('inventory','runtime_inventory.php')),Task('take',lambda:check('take','take.php')),Task('unsupported',lambda:check('unsupported','prelower_unsupported_boundaries.php',True))])
(out/'summary.json').write_text(json.dumps({'passed':True,'checks':['catalog','inventory','take','unsupported']})+'\n')
