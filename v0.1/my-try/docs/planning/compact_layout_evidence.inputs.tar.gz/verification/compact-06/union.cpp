// SCPP-ARTIFACT {"id":"type:Pair","kind":"header","path":"types\/n50616972.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_Pair
{
public:
	scpp::int_t<std::int32_t> field_first = static_cast<scpp::int_t<std::int32_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
	scpp::int_t<std::int32_t> field_second = static_cast<scpp::int_t<std::int32_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Nested","kind":"header","path":"types\/n4e6573746564.hpp"}
#pragma once
#include "types/n50616972.hpp"
struct record_Nested
{
public:
	record_Pair field_pair;
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Kind","kind":"header","path":"types\/n4b696e64.hpp"}
#pragma once
#include "cstdint"
enum class enum_Kind : std::uint16_t {
	case_One = 1ULL,
	case_Two = 2ULL,
};
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Payload","kind":"header","path":"types\/n5061796c6f6164.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "types/n50616972.hpp"
#include "types/n4b696e64.hpp"
#include "types/n4e6573746564.hpp"
union record_Payload
{
public:
	scpp::int_t<std::int32_t> field_word;
public:
	scpp::bool_t field_flag;
public:
	record_Pair field_pair;
public:
	enum_Kind field_kind;
public:
	record_Nested field_nested;
public:
	record_Payload() noexcept {}
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Row","kind":"header","path":"types\/n526f77.hpp"}
#pragma once
#include "types/n5061796c6f6164.hpp"
struct record_Row
{
public:
	record_Payload field_payload;
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n5061796c6f6164.hpp"
#include "scpp/int_t.hpp"
#include "scpp/cast.hpp"
#include "memory"
#include "lang/php/support/php_string.hpp"
#include "scpp/string_t.hpp"
#include "types/n50616972.hpp"
#include "scpp/bool_t.hpp"
#include "types/n4b696e64.hpp"
#include "helpers/enum_name_n4b696e64.hpp"
#include "types/n526f77.hpp"
#include "types/n4e6573746564.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_u = record_Payload{};
	auto union_payload_0 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_word), union_payload_0);
	::scpp::php::echo_one((local_u).field_word);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto local_p = record_Pair{};
	(local_p).field_first = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(11LL));
	(local_p).field_second = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(13LL));
	auto union_payload_1 = local_p; std::construct_at(std::addressof((local_u).field_pair), union_payload_1);
	auto local_copy = local_u;
	((local_u).field_pair).field_first = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(17LL));
	::scpp::php::echo_one(((local_copy).field_pair).field_first);
	::scpp::php::echo_one(scpp::string_t(":"));
	::scpp::php::echo_one(((local_u).field_pair).field_first);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto union_payload_2 = static_cast<scpp::bool_t>(true); std::construct_at(std::addressof((local_u).field_flag), union_payload_2);
	::scpp::php::echo_one((local_u).field_flag);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto union_payload_3 = enum_Kind::case_Two; std::construct_at(std::addressof((local_u).field_kind), union_payload_3);
	::scpp::php::echo_one(([&]() -> scpp::string_t {
	enum_Kind argument_4 = (local_u).field_kind;
	return enum_name_Kind(argument_4);
}()));
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto local_row = record_Row{};
	(local_row).field_payload = local_copy;
	::scpp::php::echo_one((((local_row).field_payload).field_pair).field_second);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto local_nested = record_Nested{};
	(local_nested).field_pair = local_p;
	auto union_payload_5 = local_nested; std::construct_at(std::addressof((local_u).field_nested), union_payload_5);
	::scpp::php::echo_one((((local_u).field_nested).field_pair).field_first);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"helper:enum_name:Kind:header","kind":"header","path":"helpers\/enum_name_n4b696e64.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "types/n4b696e64.hpp"
scpp::string_t enum_name_Kind(enum_Kind value);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"helper:enum_name:Kind:implementation","kind":"translation_unit","path":"helpers\/enum_name_n4b696e64.cpp"}
#include "scpp/string_t.hpp"
#include "types/n4b696e64.hpp"
#include "stdexcept"
#include "helpers/enum_name_n4b696e64.hpp"
scpp::string_t enum_name_Kind(enum_Kind value) {
	switch (value) {
	case enum_Kind::case_One: return scpp::string_t("One");
	case enum_Kind::case_Two: return scpp::string_t("Two");
	}
	throw std::runtime_error("Invalid value for enum helper");
}
// SCPP-END-ARTIFACT
