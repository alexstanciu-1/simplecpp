#pragma once
#include "types/n50616972.hpp"
struct record_Nested
{
public:
	record_Pair field_pair;
public:
};

