#pragma once
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "types/n50616972.hpp"
#include "types/n4b696e64.hpp"
#include "types/n4e6573746564.hpp"
union record_Payload
{
public:
	scpp::int_t<std::int32_t> field_word;
public:
	scpp::bool_t field_flag;
public:
	record_Pair field_pair;
public:
	enum_Kind field_kind;
public:
	record_Nested field_nested;
public:
	record_Payload() noexcept {}
};

