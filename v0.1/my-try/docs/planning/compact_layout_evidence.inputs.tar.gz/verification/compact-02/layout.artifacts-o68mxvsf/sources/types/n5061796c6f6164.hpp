#pragma once
#include "scpp/int_t.hpp"
#include "types/n50616972.hpp"
union record_Payload
{
public:
	scpp::int_t<std::int32_t> field_word;
public:
	record_Pair field_pair;
public:
	record_Payload() noexcept {}
};

