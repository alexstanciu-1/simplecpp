#include "callables/n706169725f73697a65.hpp"
#include "scpp/int_t.hpp"
#include "types/n50616972.hpp"
#include "callables/n706169725f616c69676e6d656e74.hpp"
#include "callables/n706169725f6f6666736574.hpp"
#include "cstddef"
#include "callables/n706169725f6669656c645f73697a65.hpp"
#include "utility"
#include "callables/n7061796c6f61645f73697a65.hpp"
#include "types/n5061796c6f6164.hpp"
#include "callables/n7061796c6f61645f616c69676e6d656e74.hpp"
#include "callables/n7061796c6f61645f6f6666736574.hpp"
#include "callables/n7061796c6f61645f6669656c645f73697a65.hpp"
#include "callables/n656e756d5f73697a65.hpp"
#include "types/n4b696e64.hpp"
#include "callables/n7363616c61725f73697a65.hpp"
scpp::int_t<> function_pairU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_Pair)); })();
}());
}

scpp::int_t<> function_pairU_alignment()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_Pair)); })();
}());
}

scpp::int_t<> function_pairU_offset()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(offsetof(record_Pair, field_second)); })();
}());
}

scpp::int_t<> function_pairU_fieldU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(std::declval<record_Pair>().field_second)); })();
}());
}

scpp::int_t<> function_payloadU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_Payload)); })();
}());
}

scpp::int_t<> function_payloadU_alignment()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_Payload)); })();
}());
}

scpp::int_t<> function_payloadU_offset()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(offsetof(record_Payload, field_pair)); })();
}());
}

scpp::int_t<> function_payloadU_fieldU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(std::declval<record_Payload>().field_pair)); })();
}());
}

scpp::int_t<> function_enumU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(enum_Kind)); })();
}());
}

scpp::int_t<> function_scalarU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(scpp::int_t<std::int32_t>)); })();
}());
}

