#pragma once
#include "cstdint"
enum class enum_Kind : std::uint16_t {
	case_One = 1ULL,
};
