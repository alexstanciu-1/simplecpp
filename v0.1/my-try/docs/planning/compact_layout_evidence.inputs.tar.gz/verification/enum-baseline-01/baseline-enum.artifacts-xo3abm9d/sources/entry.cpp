#include "scpp/int_t.hpp"
#include "types/n45.hpp"
#include "stdexcept"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return static_cast<int>((([&]() -> scpp::int_t<> { const auto match_subject_0 = (enum_E::case_B); if ((match_subject_0 == enum_E::case_A)) { return static_cast<scpp::int_t<>>(7LL); } throw std::runtime_error("Unhandled match expression"); }())).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
