// SCPP-ARTIFACT {"id":"type:Pair","kind":"header","path":"types\/n50616972.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_Pair
{
public:
	scpp::int_t<std::int32_t> field_first = static_cast<scpp::int_t<std::int32_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
	scpp::int_t<std::uint16_t> field_second = static_cast<scpp::int_t<std::uint16_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Payload","kind":"header","path":"types\/n5061796c6f6164.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "types/n50616972.hpp"
union record_Payload
{
public:
	scpp::int_t<std::int32_t> field_word;
public:
	record_Pair field_pair;
public:
	record_Payload() noexcept {}
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Kind","kind":"header","path":"types\/n4b696e64.hpp"}
#pragma once
#include "cstdint"
enum class enum_Kind : std::uint16_t {
	case_One = 1ULL,
};
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pair_size","kind":"header","path":"callables\/n706169725f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_pairU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pair_alignment","kind":"header","path":"callables\/n706169725f616c69676e6d656e74.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_pairU_alignment();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pair_offset","kind":"header","path":"callables\/n706169725f6f6666736574.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_pairU_offset();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pair_field_size","kind":"header","path":"callables\/n706169725f6669656c645f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_pairU_fieldU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:payload_size","kind":"header","path":"callables\/n7061796c6f61645f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_payloadU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:payload_alignment","kind":"header","path":"callables\/n7061796c6f61645f616c69676e6d656e74.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_payloadU_alignment();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:payload_offset","kind":"header","path":"callables\/n7061796c6f61645f6f6666736574.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_payloadU_offset();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:payload_field_size","kind":"header","path":"callables\/n7061796c6f61645f6669656c645f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_payloadU_fieldU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:enum_size","kind":"header","path":"callables\/n656e756d5f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_enumU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:scalar_size","kind":"header","path":"callables\/n7363616c61725f73697a65.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_scalarU_size();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n706169725f73697a65.hpp"
#include "scpp/int_t.hpp"
#include "types/n50616972.hpp"
#include "callables/n706169725f616c69676e6d656e74.hpp"
#include "callables/n706169725f6f6666736574.hpp"
#include "cstddef"
#include "callables/n706169725f6669656c645f73697a65.hpp"
#include "utility"
#include "callables/n7061796c6f61645f73697a65.hpp"
#include "types/n5061796c6f6164.hpp"
#include "callables/n7061796c6f61645f616c69676e6d656e74.hpp"
#include "callables/n7061796c6f61645f6f6666736574.hpp"
#include "callables/n7061796c6f61645f6669656c645f73697a65.hpp"
#include "callables/n656e756d5f73697a65.hpp"
#include "types/n4b696e64.hpp"
#include "callables/n7363616c61725f73697a65.hpp"
scpp::int_t<> function_pairU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_Pair)); })();
}());
}

scpp::int_t<> function_pairU_alignment()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_Pair)); })();
}());
}

scpp::int_t<> function_pairU_offset()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(offsetof(record_Pair, field_second)); })();
}());
}

scpp::int_t<> function_pairU_fieldU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(std::declval<record_Pair>().field_second)); })();
}());
}

scpp::int_t<> function_payloadU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_Payload)); })();
}());
}

scpp::int_t<> function_payloadU_alignment()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_Payload)); })();
}());
}

scpp::int_t<> function_payloadU_offset()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(offsetof(record_Payload, field_pair)); })();
}());
}

scpp::int_t<> function_payloadU_fieldU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(std::declval<record_Payload>().field_pair)); })();
}());
}

scpp::int_t<> function_enumU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(enum_Kind)); })();
}());
}

scpp::int_t<> function_scalarU_size()
{
	return ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(scpp::int_t<std::int32_t>)); })();
}());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

#include <cassert>
#include <cstddef>
#include <type_traits>
static_assert(std::is_union_v<record_Payload>);
static_assert(std::is_trivially_copyable_v<record_Payload>);
static_assert(std::is_trivially_destructible_v<record_Payload>);
static_assert(std::is_trivially_copyable_v<record_Pair>);
int main() {
	assert(function_pairU_size().native_value() == sizeof(record_Pair));
	assert(function_pairU_alignment().native_value() == alignof(record_Pair));
	assert(function_pairU_offset().native_value() == offsetof(record_Pair, field_second));
	assert(function_pairU_fieldU_size().native_value() == sizeof(scpp::int_t<std::uint16_t>));
	assert(function_payloadU_size().native_value() == sizeof(record_Payload));
	assert(function_payloadU_alignment().native_value() == alignof(record_Payload));
	assert(function_payloadU_offset().native_value() == 0);
	assert(function_payloadU_fieldU_size().native_value() == sizeof(record_Pair));
	assert(function_enumU_size().native_value() == sizeof(std::uint16_t));
	assert(function_scalarU_size().native_value() == sizeof(std::int32_t));
}