// SCPP-ARTIFACT {"id":"type:Widths","kind":"header","path":"types\/n576964746873.hpp"}
#pragma once
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
union record_Widths
{
public:
	scpp::bool_t field_flag;
public:
	scpp::int_t<std::int8_t> field_vint8;
public:
	scpp::int_t<std::int16_t> field_vint16;
public:
	scpp::int_t<std::int32_t> field_vint32;
public:
	scpp::int_t<std::int64_t> field_vint64;
public:
	scpp::int_t<std::uint8_t> field_vuint8;
public:
	scpp::int_t<std::uint8_t> field_vbyte;
public:
	scpp::int_t<std::uint16_t> field_vuint16;
public:
	scpp::int_t<std::uint32_t> field_vuint32;
public:
	scpp::int_t<std::uint64_t> field_vuint64;
public:
	record_Widths() noexcept {}
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n576964746873.hpp"
#include "scpp/int_t.hpp"
#include "scpp/cast.hpp"
#include "memory"
#include "lang/php/support/php_string.hpp"
#include "scpp/string_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_u = record_Widths{};
	auto union_payload_0 = scpp::cast<scpp::int_t<std::int8_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vint8), union_payload_0);
	::scpp::php::echo_one((local_u).field_vint8);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_1 = scpp::cast<scpp::int_t<std::int16_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vint16), union_payload_1);
	::scpp::php::echo_one((local_u).field_vint16);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_2 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vint32), union_payload_2);
	::scpp::php::echo_one((local_u).field_vint32);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_3 = scpp::cast<scpp::int_t<std::int64_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vint64), union_payload_3);
	::scpp::php::echo_one((local_u).field_vint64);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_4 = scpp::cast<scpp::int_t<std::uint8_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vuint8), union_payload_4);
	::scpp::php::echo_one((local_u).field_vuint8);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_5 = scpp::cast<scpp::int_t<std::uint8_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vbyte), union_payload_5);
	::scpp::php::echo_one((local_u).field_vbyte);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_6 = scpp::cast<scpp::int_t<std::uint16_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vuint16), union_payload_6);
	::scpp::php::echo_one((local_u).field_vuint16);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_7 = scpp::cast<scpp::int_t<std::uint32_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vuint32), union_payload_7);
	::scpp::php::echo_one((local_u).field_vuint32);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_8 = scpp::cast<scpp::int_t<std::uint64_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_vuint64), union_payload_8);
	::scpp::php::echo_one((local_u).field_vuint64);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_9 = static_cast<scpp::bool_t>(false); std::construct_at(std::addressof((local_u).field_flag), union_payload_9);
	::scpp::php::echo_one((local_u).field_flag);
	::scpp::php::echo_one(scpp::string_t(" "));
	auto union_payload_10 = static_cast<scpp::bool_t>(true); std::construct_at(std::addressof((local_u).field_flag), union_payload_10);
	::scpp::php::echo_one((local_u).field_flag);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
