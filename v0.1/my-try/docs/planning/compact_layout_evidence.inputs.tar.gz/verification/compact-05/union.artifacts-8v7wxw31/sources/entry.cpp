#include "types/n50616972.hpp"
#include "types/n4b696e64.hpp"
#include "types/n5061796c6f6164.hpp"
#include "types/n526f77.hpp"
#include "helpers/enum_name_n4b696e64.hpp"
#include "types/n5061796c6f6164.hpp"
#include "scpp/int_t.hpp"
#include "scpp/cast.hpp"
#include "memory"
#include "lang/php/support/php_string.hpp"
#include "scpp/string_t.hpp"
#include "types/n50616972.hpp"
#include "scpp/bool_t.hpp"
#include "types/n4b696e64.hpp"
#include "helpers/enum_name_n4b696e64.hpp"
#include "types/n526f77.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_u = record_Payload{};
	auto union_payload_0 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(7LL)); std::construct_at(std::addressof((local_u).field_word), union_payload_0);
	::scpp::php::echo_one((local_u).field_word);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto local_p = record_Pair{};
	(local_p).field_first = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(11LL));
	(local_p).field_second = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(13LL));
	auto union_payload_1 = local_p; std::construct_at(std::addressof((local_u).field_pair), union_payload_1);
	auto local_copy = local_u;
	((local_u).field_pair).field_first = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(17LL));
	::scpp::php::echo_one(((local_copy).field_pair).field_first);
	::scpp::php::echo_one(scpp::string_t(":"));
	::scpp::php::echo_one(((local_u).field_pair).field_first);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto union_payload_2 = static_cast<scpp::bool_t>(true); std::construct_at(std::addressof((local_u).field_flag), union_payload_2);
	::scpp::php::echo_one((local_u).field_flag);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto union_payload_3 = enum_Kind::case_Two; std::construct_at(std::addressof((local_u).field_kind), union_payload_3);
	::scpp::php::echo_one(([&]() -> scpp::string_t {
	enum_Kind argument_4 = (local_u).field_kind;
	return enum_name_Kind(argument_4);
}()));
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	auto local_row = record_Row{};
	(local_row).field_payload = local_copy;
	::scpp::php::echo_one((((local_row).field_payload).field_pair).field_second);
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
