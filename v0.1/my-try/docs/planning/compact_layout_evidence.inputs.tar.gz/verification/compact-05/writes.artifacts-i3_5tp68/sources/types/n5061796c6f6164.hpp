#pragma once
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
union record_Payload
{
public:
	scpp::int_t<std::int32_t> field_word;
public:
	scpp::bool_t field_flag;
public:
	record_Payload() noexcept {}
};

