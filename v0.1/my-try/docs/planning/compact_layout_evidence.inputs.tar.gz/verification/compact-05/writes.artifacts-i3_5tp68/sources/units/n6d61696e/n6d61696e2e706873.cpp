#include "callables/n6661696c6564.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/cast.hpp"
#include "callables/n7265706c616365.hpp"
#include "types/n5061796c6f6164.hpp"
#include "memory"
#include "callables/n6661696c7772697465.hpp"
#include "callables/n7368617265647772697465.hpp"
#include "scpp/memory.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/index_read.hpp"
#include "scpp/bool_t.hpp"
scpp::int_t<std::int32_t> function_failed()
{
	return scpp::cast<scpp::int_t<std::int32_t>>(([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }()));
}

void function_replace(record_Payload& local_u)
{
	auto union_payload_2 = ([&]() -> scpp::int_t<std::int32_t> { auto operand_0 = (local_u).field_word; auto operand_1 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(1LL)); return (operand_0 + operand_1); }()); std::construct_at(std::addressof((local_u).field_word), union_payload_2);
}

void function_failwrite(record_Payload& local_u)
{
	auto union_payload_0 = ([&]() -> scpp::int_t<std::int32_t> {
	return function_failed();
}()); std::construct_at(std::addressof((local_u).field_word), union_payload_0);
}

scpp::int_t<std::int32_t> function_sharedwrite()
{
	scpp::shared_p<record_Payload> local_u = ::scpp::shared<record_Payload>();
	scpp::vector_t<scpp::shared_p<record_Payload>> local_items = ([&]() -> scpp::vector_t<scpp::shared_p<record_Payload>> {
scpp::initializer_buffer<scpp::shared_p<record_Payload>> initializer_0(1);
{
scpp::shared_p<record_Payload> initializer_value_1 = local_u;
initializer_0.append(initializer_value_1);
}
return scpp::data_initializer<scpp::vector_t<scpp::shared_p<record_Payload>>>::from_list(initializer_0.view());
}());
	([&]() -> scpp::int_t<std::int32_t> { auto storage_owner_3 = ([&]() -> scpp::shared_p<record_Payload> { const auto& index_receiver_2 = local_items; scpp::int_t<> index_key_2 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_2, index_key_2); }()); auto& property_target_4 = (storage_owner_3)->field_word; auto union_payload_5 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(19LL)); std::construct_at(std::addressof(property_target_4), union_payload_5); return property_target_4; }());
	([&]() -> scpp::bool_t { auto storage_owner_7 = ([&]() -> scpp::shared_p<record_Payload> { const auto& index_receiver_6 = local_items; scpp::int_t<> index_key_6 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_6, index_key_6); }()); auto& property_target_8 = (storage_owner_7)->field_flag; auto union_payload_9 = static_cast<scpp::bool_t>(true); std::construct_at(std::addressof(property_target_8), union_payload_9); return property_target_8; }());
	([&]() -> scpp::int_t<std::int32_t> { auto storage_owner_11 = ([&]() -> scpp::shared_p<record_Payload> { const auto& index_receiver_10 = local_items; scpp::int_t<> index_key_10 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_10, index_key_10); }()); auto& property_target_12 = (storage_owner_11)->field_word; auto union_payload_13 = scpp::cast<scpp::int_t<std::int32_t>>(static_cast<scpp::int_t<>>(23LL)); std::construct_at(std::addressof(property_target_12), union_payload_13); return property_target_12; }());
	return (local_u)->field_word;
}

