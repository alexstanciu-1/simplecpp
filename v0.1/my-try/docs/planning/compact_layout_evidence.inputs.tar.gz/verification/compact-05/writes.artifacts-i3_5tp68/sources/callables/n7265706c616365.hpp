#pragma once
#include "types/n5061796c6f6164.hpp"
void function_replace(record_Payload& local_u);
