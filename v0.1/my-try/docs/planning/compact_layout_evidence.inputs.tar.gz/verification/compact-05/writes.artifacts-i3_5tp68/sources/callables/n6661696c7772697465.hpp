#pragma once
#include "types/n5061796c6f6164.hpp"
void function_failwrite(record_Payload& local_u);
