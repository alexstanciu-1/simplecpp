#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<std::int32_t> function_failed();
