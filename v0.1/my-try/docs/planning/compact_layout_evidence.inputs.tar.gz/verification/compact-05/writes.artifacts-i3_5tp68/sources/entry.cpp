#include "types/n5061796c6f6164.hpp"
#include "callables/n6661696c6564.hpp"
#include "callables/n7265706c616365.hpp"
#include "callables/n6661696c7772697465.hpp"
#include "callables/n7368617265647772697465.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

#include <cassert>
#include <memory>
int main() {
	record_Payload value;
	std::construct_at(std::addressof(value.field_word), scpp::int_t<std::int32_t>{7});
	function_replace(value);
	assert(value.field_word.native_value() == 8);
	bool caught = false;
	try { function_failwrite(value); } catch (const scpp::runtime_error& error) {
		caught = error.code() == "division_by_zero";
	}
	assert(caught && value.field_word.native_value() == 8);
	assert(function_sharedwrite().native_value() == 23);
}