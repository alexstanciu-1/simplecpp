#include "types/n50616972.hpp"
#include "types/n5061796c6f6164.hpp"
#include "types/n4b696e64.hpp"
#include "callables/n706169725f73697a65.hpp"
#include "callables/n706169725f616c69676e6d656e74.hpp"
#include "callables/n706169725f6f6666736574.hpp"
#include "callables/n706169725f6669656c645f73697a65.hpp"
#include "callables/n7061796c6f61645f73697a65.hpp"
#include "callables/n7061796c6f61645f616c69676e6d656e74.hpp"
#include "callables/n7061796c6f61645f6f6666736574.hpp"
#include "callables/n7061796c6f61645f6669656c645f73697a65.hpp"
#include "callables/n656e756d5f73697a65.hpp"
#include "callables/n7363616c61725f73697a65.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

#include <cassert>
#include <cstddef>
int main() {
	assert(function_pairU_size().native_value() == sizeof(record_Pair));
	assert(function_pairU_alignment().native_value() == alignof(record_Pair));
	assert(function_pairU_offset().native_value() == offsetof(record_Pair, field_second));
	assert(function_pairU_fieldU_size().native_value() == sizeof(scpp::int_t<std::uint16_t>));
	assert(function_payloadU_size().native_value() == sizeof(record_Payload));
	assert(function_payloadU_alignment().native_value() == alignof(record_Payload));
	assert(function_payloadU_offset().native_value() == 0);
	assert(function_payloadU_fieldU_size().native_value() == sizeof(record_Pair));
	assert(function_enumU_size().native_value() == sizeof(std::uint16_t));
	assert(function_scalarU_size().native_value() == sizeof(std::int32_t));
}