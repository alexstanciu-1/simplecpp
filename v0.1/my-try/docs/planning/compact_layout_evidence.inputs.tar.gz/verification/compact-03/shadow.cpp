// SCPP-ARTIFACT {"id":"callable:layout_sizeof","kind":"header","path":"callables\/n6c61796f75745f73697a656f66.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_layoutU_sizeof(scpp::int_t<> local_x);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6c61796f75745f73697a656f66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> function_layoutU_sizeof(scpp::int_t<> local_x)
{
	return ([&]() -> scpp::int_t<> { auto operand_0 = local_x; auto operand_1 = static_cast<scpp::int_t<>>(2LL); return (operand_0 + operand_1); }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "callables/n6c61796f75745f73697a656f66.hpp"
#include "scpp/string_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	::scpp::php::echo_one(([&]() -> scpp::int_t<> {
	scpp::int_t<> argument_0 = static_cast<scpp::int_t<>>(9LL);
	return function_layoutU_sizeof(argument_0);
}()));
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
