#pragma once
#include "scpp/int_t.hpp"
struct record_LayoutUqPair
{
public:
	scpp::int_t<std::int32_t> field_x;
public:
};

