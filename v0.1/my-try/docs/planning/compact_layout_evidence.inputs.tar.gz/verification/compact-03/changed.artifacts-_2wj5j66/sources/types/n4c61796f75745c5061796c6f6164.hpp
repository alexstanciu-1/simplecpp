#pragma once
#include "types/n4c61796f75745c50616972.hpp"
#include "scpp/bool_t.hpp"
union record_LayoutUqPayload
{
public:
	record_LayoutUqPair field_pair;
public:
	scpp::bool_t field_flag;
public:
	record_LayoutUqPayload() noexcept {}
};

