#include "callables/n6c61796f75745f73697a656f66.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> function_layoutU_sizeof(scpp::int_t<> local_x)
{
	return ([&]() -> scpp::int_t<> { auto operand_0 = local_x; auto operand_1 = static_cast<scpp::int_t<>>(2LL); return (operand_0 + operand_1); }());
}

