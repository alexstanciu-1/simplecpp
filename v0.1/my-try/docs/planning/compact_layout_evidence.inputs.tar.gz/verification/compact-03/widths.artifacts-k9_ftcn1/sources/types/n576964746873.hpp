#pragma once
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
union record_Widths
{
public:
	scpp::bool_t field_flag;
public:
	scpp::int_t<std::int8_t> field_vint8;
public:
	scpp::int_t<std::int16_t> field_vint16;
public:
	scpp::int_t<std::int32_t> field_vint32;
public:
	scpp::int_t<std::int64_t> field_vint64;
public:
	scpp::int_t<std::uint8_t> field_vuint8;
public:
	scpp::int_t<std::uint8_t> field_vbyte;
public:
	scpp::int_t<std::uint16_t> field_vuint16;
public:
	scpp::int_t<std::uint32_t> field_vuint32;
public:
	scpp::int_t<std::uint64_t> field_vuint64;
public:
	record_Widths() noexcept {}
};

