// SCPP-ARTIFACT {"id":"type:Layout\\Pair","kind":"header","path":"types\/n4c61796f75745c50616972.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_LayoutUqPair
{
public:
	scpp::int_t<std::int32_t> field_x;
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"type:Layout\\Payload","kind":"header","path":"types\/n4c61796f75745c5061796c6f6164.hpp"}
#pragma once
#include "types/n4c61796f75745c50616972.hpp"
#include "scpp/bool_t.hpp"
union record_LayoutUqPayload
{
public:
	record_LayoutUqPair field_pair;
public:
	scpp::bool_t field_flag;
public:
	record_LayoutUqPayload() noexcept {}
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n4c61796f75745c5061796c6f6164.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/int_t.hpp"
#include "cstddef"
#include "scpp/string_t.hpp"
#include "types/n4c61796f75745c50616972.hpp"
#include "utility"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_u = record_LayoutUqPayload{};
	::scpp::php::echo_one(([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(offsetof(record_LayoutUqPayload, field_pair)); })();
}()));
	::scpp::php::echo_one(scpp::string_t(":"));
	::scpp::php::echo_one(([&]() -> scpp::bool_t { auto operand_0 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(std::declval<record_LayoutUqPair>().field_x)); })();
}()); auto operand_1 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(scpp::int_t<std::int32_t>)); })();
}()); return scpp::php::identical(operand_0, operand_1); }()));
	::scpp::php::echo_one(scpp::string_t(":"));
	::scpp::php::echo_one(([&]() -> scpp::bool_t { auto operand_2 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_LayoutUqPayload)); })();
}()); auto operand_3 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(sizeof(record_LayoutUqPair)); })();
}()); return (operand_2 >= operand_3); }()));
	::scpp::php::echo_one(scpp::string_t(":"));
	::scpp::php::echo_one(([&]() -> scpp::bool_t { auto operand_4 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_LayoutUqPayload)); })();
}()); auto operand_5 = ([&]() -> scpp::int_t<> {
	return ([]() -> scpp::int_t<> { return scpp::int_t<>(alignof(record_LayoutUqPair)); })();
}()); return (operand_4 >= operand_5); }()));
	::scpp::php::echo_one(scpp::string_t("\x0A" ""));
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
