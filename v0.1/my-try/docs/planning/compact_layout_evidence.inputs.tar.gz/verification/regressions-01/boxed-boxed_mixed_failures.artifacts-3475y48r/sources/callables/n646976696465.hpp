#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
void function_divide(scpp::mixed_t& local_v, scpp::mixed_t local_rhs);
