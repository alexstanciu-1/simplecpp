#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
void function_invalid(scpp::dynamic_t<> local_v, scpp::bool_t& local_out);
