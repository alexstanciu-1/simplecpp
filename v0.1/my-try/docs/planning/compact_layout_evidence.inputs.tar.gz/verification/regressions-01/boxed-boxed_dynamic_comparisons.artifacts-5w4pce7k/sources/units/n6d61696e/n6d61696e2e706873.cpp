#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n636865636b.hpp"
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/float_t.hpp"
#include "scpp/null_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "operators/identity/boxed_scalar_equality.hpp"
#include "scpp/generated/operators.hpp"
#include "operators/identity/boxed_ordering.hpp"
#include "callables/n696e76616c6964.hpp"
scpp::bool_t function_check()
{
	scpp::dynamic_t<> local_n = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
	scpp::dynamic_t<> local_s = scpp::dynamic_t<>{scpp::string_t("1")};
	scpp::dynamic_t<> local_f = scpp::dynamic_t<>{static_cast<scpp::float_t>(1.0)};
	scpp::dynamic_t<> local_b = scpp::dynamic_t<>{static_cast<scpp::bool_t>(true)};
	scpp::dynamic_t<> local_nil = scpp::dynamic_t<>{scpp::null};
	return scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_0 = local_n; auto operand_1 = static_cast<scpp::int_t<>>(1LL); return scpp::php::identical(operand_0, operand_1); }())) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_2 = static_cast<scpp::int_t<>>(1LL); auto operand_3 = local_n; return scpp::php::identical(operand_2, operand_3); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_4 = local_n; auto operand_5 = static_cast<scpp::float_t>(1.0); return scpp::php::not_identical(operand_4, operand_5); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_6 = static_cast<scpp::float_t>(1.0); auto operand_7 = local_n; return scpp::php::not_identical(operand_6, operand_7); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_8 = local_s; auto operand_9 = scpp::string_t("1"); return scpp::php::identical(operand_8, operand_9); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_10 = scpp::string_t("1"); auto operand_11 = local_s; return scpp::php::identical(operand_10, operand_11); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_12 = local_f; auto operand_13 = static_cast<scpp::float_t>(1.0); return scpp::php::identical(operand_12, operand_13); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_14 = static_cast<scpp::float_t>(1.0); auto operand_15 = local_f; return scpp::php::identical(operand_14, operand_15); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_16 = local_b; auto operand_17 = static_cast<scpp::bool_t>(true); return scpp::php::identical(operand_16, operand_17); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_18 = static_cast<scpp::bool_t>(true); auto operand_19 = local_b; return scpp::php::identical(operand_18, operand_19); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_20 = local_nil; auto operand_21 = scpp::null; return scpp::php::identical(operand_20, operand_21); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_22 = scpp::null; auto operand_23 = local_nil; return scpp::php::identical(operand_22, operand_23); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_24 = local_n; auto operand_25 = local_s; return (operand_24 == operand_25); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_26 = local_n; auto operand_27 = scpp::dynamic_t<>{static_cast<scpp::float_t>(1.0)}; return (operand_26 == operand_27); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_28 = local_n; auto operand_29 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)}; return (operand_28 != operand_29); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_30 = local_n; auto operand_31 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)}; return (operand_30 < operand_31); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_32 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(0LL)}; auto operand_33 = local_n; return (operand_32 < operand_33); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_34 = local_n; auto operand_35 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)}; return (operand_34 <= operand_35); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_36 = local_n; auto operand_37 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(0LL)}; return (operand_36 > operand_37); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_38 = local_n; auto operand_39 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)}; return (operand_38 >= operand_39); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_40 = local_n; auto operand_41 = local_n; return scpp::php::identical(operand_40, operand_41); }())))) && static_cast<bool>(([&]() -> scpp::bool_t { auto operand_42 = local_n; auto operand_43 = local_s; return scpp::php::not_identical(operand_42, operand_43); }())));
}

void function_invalid(scpp::dynamic_t<> local_v, scpp::bool_t& local_out)
{
	local_out = ([&]() -> scpp::bool_t { auto operand_0 = local_v; auto operand_1 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)}; return (operand_0 < operand_1); }());
}

