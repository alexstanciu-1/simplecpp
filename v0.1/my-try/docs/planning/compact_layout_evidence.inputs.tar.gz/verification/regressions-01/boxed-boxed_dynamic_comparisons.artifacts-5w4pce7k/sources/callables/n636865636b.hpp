#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/bool_t.hpp"
scpp::bool_t function_check();
