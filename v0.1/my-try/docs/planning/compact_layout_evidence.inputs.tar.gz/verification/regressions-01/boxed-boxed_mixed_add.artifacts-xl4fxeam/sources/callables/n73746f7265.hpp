#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
void function_store(scpp::mixed_t& local_a, scpp::mixed_t local_b, scpp::mixed_t& local_out);
