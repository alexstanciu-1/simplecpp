#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_right(scpp::mixed_t local_a, scpp::int_t<> local_b);
