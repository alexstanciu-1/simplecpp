#include "callables/n63616c63756c617465.hpp"
#include "callables/n6c656674.hpp"
#include "callables/n7269676874.hpp"
#include "callables/n757064617465.hpp"
#include "callables/n73746f7265.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using B = scpp::mixed_t; B a{scpp::int_t<>{9LL}}, b{scpp::int_t<>{2LL}}; if (function_calculate(a, b).get_int().native_value() != 1 || function_left(scpp::int_t<>{9LL}, b).get_int().native_value() != 1 || function_right(a, scpp::int_t<>{2LL}).get_int().native_value() != 1) return false; auto old = a; auto result = function_update(a, b); if (old.get_int().native_value() != 9 || a.get_int().native_value() != 1 || result.get_int().native_value() != 1) return false; a = old; B out{scpp::string_t{"old"}}; int caught = 0; for (const auto& bad : {B{scpp::float_t{2.0}}, B{scpp::string_t{"2"}}, B{scpp::bool_t{true}}, B{}}) { try { function_store(a, bad, out); } catch (const std::runtime_error&) { ++caught; } if (a.get_int().native_value() != 9 || out.get_string().native_value() != "old") return false; } return caught == 4 && b.get_int().native_value() == 2; }())) ? 0 : 91; }
