#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
scpp::string_t function_join(scpp::mixed_t local_v);
