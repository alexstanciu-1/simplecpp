#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n617070656e64.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6a6f696e.hpp"
#include "callables/n6661696c757265.hpp"
#include "scpp/int_t.hpp"
#include "callables/n7479706564.hpp"
#include "scpp/cast.hpp"
scpp::mixed_t function_append(scpp::mixed_t& local_v)
{
	return ([&]() -> scpp::mixed_t { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::mixed_t{([&]() -> scpp::string_t { auto operand_2 = scpp::php::to_string(previous_1); auto operand_3 = scpp::string_t("!"); return (operand_2 + operand_3); }())}; target_0 = previous_1; return target_0; }());
}

scpp::string_t function_join(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::string_t { auto operand_2 = ([&]() -> scpp::string_t { auto operand_0 = scpp::string_t("["); auto operand_1 = scpp::php::to_string(local_v); return (operand_0 + operand_1); }()); auto operand_3 = scpp::string_t("]"); return (operand_2 + operand_3); }());
}

void function_failure(scpp::mixed_t& local_v)
{
	([&]() -> scpp::mixed_t { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::mixed_t{([&]() -> scpp::string_t { auto operand_4 = scpp::php::to_string(previous_1); auto operand_5 = scpp::php::to_string(([&]() -> scpp::int_t<> { auto operand_2 = static_cast<scpp::int_t<>>(1LL); auto operand_3 = static_cast<scpp::int_t<>>(0LL); return (operand_2 / operand_3); }())); return (operand_4 + operand_5); }())}; target_0 = previous_1; return target_0; }());
}

scpp::int_t<> function_typed(scpp::mixed_t& local_v)
{
	return scpp::required_cast<scpp::int_t<>>(([&]() -> scpp::mixed_t { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::mixed_t{([&]() -> scpp::string_t { auto operand_2 = scpp::php::to_string(previous_1); auto operand_3 = scpp::string_t("!"); return (operand_2 + operand_3); }())}; target_0 = previous_1; return target_0; }()));
}

