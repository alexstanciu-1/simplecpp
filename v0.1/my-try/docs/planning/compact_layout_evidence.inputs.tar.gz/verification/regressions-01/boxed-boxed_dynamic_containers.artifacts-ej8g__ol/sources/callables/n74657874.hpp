#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/string_t.hpp"
scpp::string_t function_text();
