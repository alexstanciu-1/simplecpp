#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n72656164.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/index_read.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n616c6961736573.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "callables/n696e646570656e64656e74.hpp"
#include "callables/n74657874.hpp"
#include "lang/php/support/php_string.hpp"
scpp::dynamic_t<> function_read()
{
	scpp::dynamic_t<> local_v = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(1);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("n")};
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
	return ([&]() -> scpp::dynamic_t<> { auto operand_4 = ([&]() -> scpp::dynamic_t<> { const auto& index_receiver_3 = local_v; scpp::mixed_t index_key_3 = scpp::mixed_t{scpp::string_t("n")}; return scpp::null_index_read(index_receiver_3, index_key_3); }()); auto operand_5 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)}; return (operand_4 + operand_5); }());
}

scpp::bool_t function_aliases()
{
	scpp::dynamic_t<> local_a = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(1);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("n")};
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
	auto local_b = local_a;
	return ([&]() -> scpp::bool_t { auto operand_3 = local_a; auto operand_4 = local_b; return scpp::php::identical(operand_3, operand_4); }());
}

scpp::bool_t function_independent()
{
	scpp::dynamic_t<> local_a = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(1);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("n")};
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
	scpp::dynamic_t<> local_b = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_3(1);
{
scpp::mixed_t initializer_key_4 = scpp::mixed_t{scpp::string_t("n")};
scpp::dynamic_t<> initializer_value_5 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
initializer_3.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_4, initializer_value_5});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_3.view());
}());
	return ([&]() -> scpp::bool_t { auto operand_6 = local_a; auto operand_7 = local_b; return scpp::php::identical(operand_6, operand_7); }());
}

scpp::string_t function_text()
{
	scpp::dynamic_t<> local_a = scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(scpp::initializer_list<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>>{});
	return ([&]() -> scpp::string_t { auto operand_0 = scpp::php::to_string(local_a); auto operand_1 = scpp::string_t("!"); return (operand_0 + operand_1); }());
}

