#include "callables/n72656164.hpp"
#include "callables/n616c6961736573.hpp"
#include "callables/n696e646570656e64656e74.hpp"
#include "callables/n74657874.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (function_read().get_int().native_value() == 8 && function_aliases().native_value() && function_independent().native_value() == false && function_text().native_value() == "Object!") ? 0 : 91; }
