#include "callables/n736f75726365.hpp"
#include "callables/n706f736974697665.hpp"
#include "callables/n6e65676174697665.hpp"
#include "callables/n707265696e63.hpp"
#include "callables/n706f7374696e63.hpp"
#include "callables/n707265646563.hpp"
#include "callables/n706f7374646563.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using B = scpp::dynamic_t<>; B v{scpp::int_t<>{4LL}}; scpp::int_t<> n{0LL}; if (function_positive(v, n).get_int().native_value() != 4 || function_negative(v, n).get_int().native_value() != -4 || n.native_value() != 2) return false; auto a = function_preinc(v); auto b = function_postinc(v); auto c = function_predec(v); auto d = function_postdec(v); B f{scpp::float_t{1.5}}; auto before = function_postinc(f); return a.get_int().native_value() == 5 && b.get_int().native_value() == 5 && c.get_int().native_value() == 5 && d.get_int().native_value() == 5 && v.get_int().native_value() == 4 && before.get_float().native_value() == 1.5 && f.get_float().native_value() == 2.5; }())) ? 0 : 91; }
