#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n72756e.hpp"
#include "scpp/int_t.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "scpp/index_write.hpp"
#include "scpp/index_read.hpp"
#include "scpp/cast.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n7363616c6172.hpp"
scpp::int_t<> function_run()
{
	scpp::dynamic_t<> local_original = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>> initializer_0(1);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("n")};
scpp::dynamic_t<> initializer_value_2 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
initializer_0.append(scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(initializer_0.view());
}());
	auto local_a = ([&]() -> scpp::dynamic_t<> { if ((static_cast<scpp::bool_t>(true)).native_value()) { return local_original; } return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)}; }());
	auto local_b = ([&]() -> scpp::dynamic_t<> { scpp::dynamic_t<> conditional_3 = local_original; if (scpp::php::condition_truthy(conditional_3).native_value()) { return conditional_3; } return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(8LL)}; }());
	auto local_c = ([&]() -> scpp::dynamic_t<> { scpp::dynamic_t<> coalesce_4 = local_original; if (!coalesce_4.is_null().native_value()) { return coalesce_4; } return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)}; }());
	{ auto& write_receiver_5 = local_a; scpp::mixed_t write_key_5 = scpp::mixed_t{scpp::string_t("n")}; scpp::require_write_key(write_key_5); scpp::dynamic_t<> write_value_5 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(4LL)}; scpp::index_store(write_receiver_5, write_key_5, write_value_5); }
	{ auto& write_receiver_6 = local_b; scpp::mixed_t write_key_6 = scpp::mixed_t{scpp::string_t("extra")}; scpp::require_write_key(write_key_6); scpp::dynamic_t<> write_value_6 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(5LL)}; scpp::index_store(write_receiver_6, write_key_6, write_value_6); }
	{ auto& write_receiver_7 = local_c; scpp::mixed_t write_key_7 = scpp::mixed_t{scpp::string_t("last")}; scpp::require_write_key(write_key_7); scpp::dynamic_t<> write_value_7 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(6LL)}; scpp::index_store(write_receiver_7, write_key_7, write_value_7); }
	local_a = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(99LL)};
	scpp::int_t<> local_n = scpp::required_cast<scpp::int_t<>>(([&]() -> scpp::dynamic_t<> { const auto& index_receiver_8 = local_original; scpp::mixed_t index_key_8 = scpp::mixed_t{scpp::string_t("n")}; return scpp::null_index_read(index_receiver_8, index_key_8); }()));
	scpp::int_t<> local_extra = scpp::required_cast<scpp::int_t<>>(([&]() -> scpp::dynamic_t<> { const auto& index_receiver_9 = local_original; scpp::mixed_t index_key_9 = scpp::mixed_t{scpp::string_t("extra")}; return scpp::null_index_read(index_receiver_9, index_key_9); }()));
	scpp::int_t<> local_last = scpp::required_cast<scpp::int_t<>>(([&]() -> scpp::dynamic_t<> { const auto& index_receiver_10 = local_original; scpp::mixed_t index_key_10 = scpp::mixed_t{scpp::string_t("last")}; return scpp::null_index_read(index_receiver_10, index_key_10); }()));
	return ([&]() -> scpp::int_t<> { auto operand_13 = ([&]() -> scpp::int_t<> { auto operand_11 = local_n; auto operand_12 = local_extra; return (operand_11 + operand_12); }()); auto operand_14 = local_last; return (operand_13 + operand_14); }());
}

scpp::int_t<> function_scalar()
{
	scpp::dynamic_t<> local_a = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)};
	auto local_b = ([&]() -> scpp::dynamic_t<> { scpp::dynamic_t<> coalesce_0 = local_a; if (!coalesce_0.is_null().native_value()) { return coalesce_0; } return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(0LL)}; }());
	local_b = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return scpp::required_cast<scpp::int_t<>>(local_a);
}

