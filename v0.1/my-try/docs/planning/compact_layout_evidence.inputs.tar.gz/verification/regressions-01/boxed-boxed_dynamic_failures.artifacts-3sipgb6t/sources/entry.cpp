#include "callables/n646976696465.hpp"
#include "callables/n6d6f64756c6f.hpp"
#include "callables/n696e6372656d656e74.hpp"
#include "callables/n7479706564.hpp"
#include "callables/n6f7264696e617279.hpp"
#include "callables/n7477696365.hpp"
#include "callables/n7461626c65.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using B = scpp::dynamic_t<>; B v{scpp::int_t<>{4LL}}; int caught = 0; if (function_twice(v).get_int().native_value() != 8) return false; try { function_divide(v, B{scpp::int_t<>{0LL}}); } catch (const std::runtime_error&) { ++caught; } try { function_modulo(v, B{scpp::int_t<>{0LL}}); } catch (const std::runtime_error&) { ++caught; } if (v.get_int().native_value() != 8) return false; B text{scpp::string_t{"2"}}; try { function_increment(text); } catch (const std::runtime_error&) { ++caught; } try { function_table(); } catch (const std::runtime_error&) { ++caught; } function_ordinary(v); try { function_typed(v); } catch (const std::runtime_error&) { ++caught; } return caught == 5 && v.get_float().native_value() == 9.5 && text.get_string().native_value() == "2"; }())) ? 0 : 91; }
