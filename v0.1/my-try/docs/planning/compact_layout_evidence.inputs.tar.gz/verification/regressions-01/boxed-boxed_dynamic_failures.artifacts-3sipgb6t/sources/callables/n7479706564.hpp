#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v);
