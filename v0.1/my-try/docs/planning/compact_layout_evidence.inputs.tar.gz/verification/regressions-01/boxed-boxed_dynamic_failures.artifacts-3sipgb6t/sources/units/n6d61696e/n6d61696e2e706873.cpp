#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n646976696465.hpp"
#include "scpp/dynamic_t.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6d6f64756c6f.hpp"
#include "callables/n696e6372656d656e74.hpp"
#include "callables/n7479706564.hpp"
#include "scpp/int_t.hpp"
#include "scpp/cast.hpp"
#include "callables/n6f7264696e617279.hpp"
#include "scpp/float_t.hpp"
#include "callables/n7477696365.hpp"
#include "callables/n7461626c65.hpp"
#include "scpp/data_initializer.hpp"
void function_divide(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs)
{
	([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_rhs; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_modulo(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs)
{
	([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_rhs; return (operand_2 % operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_increment(scpp::dynamic_t<>& local_v)
{
	static_cast<scpp::dynamic_t<>>(local_v++);
}

scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v)
{
	return scpp::required_cast<scpp::int_t<>>(static_cast<scpp::dynamic_t<>>(++local_v));
}

void function_ordinary(scpp::dynamic_t<>& local_v)
{
	local_v = ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_v; auto operand_1 = scpp::dynamic_t<>{static_cast<scpp::float_t>(0.5)}; return (operand_0 + operand_1); }());
}

scpp::dynamic_t<> function_twice(scpp::dynamic_t<>& local_v)
{
	return ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_v; return (operand_2 + operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_table()
{
	scpp::dynamic_t<> local_v = scpp::data_initializer<scpp::dynamic_t<>>::from_list(scpp::initializer_list<scpp::dynamic_t<>>{});
	static_cast<scpp::dynamic_t<>>(local_v++);
}

