#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
void function_modulo(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs);
