#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
void function_increment(scpp::dynamic_t<>& local_v);
