#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
void function_store(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b, scpp::dynamic_t<>& local_out);
