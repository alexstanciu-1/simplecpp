#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
scpp::dynamic_t<> function_right(scpp::dynamic_t<> local_a, scpp::int_t<> local_b);
