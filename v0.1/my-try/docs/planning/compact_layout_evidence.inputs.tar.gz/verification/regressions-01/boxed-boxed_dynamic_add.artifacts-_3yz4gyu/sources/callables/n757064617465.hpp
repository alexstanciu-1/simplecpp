#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_update(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b);
