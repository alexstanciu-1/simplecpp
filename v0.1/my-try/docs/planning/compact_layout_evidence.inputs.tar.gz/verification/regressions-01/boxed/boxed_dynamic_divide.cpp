#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:calculate","kind":"header","path":"callables\/n63616c63756c617465.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_calculate(scpp::dynamic_t<> local_a, scpp::dynamic_t<> local_b);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:left","kind":"header","path":"callables\/n6c656674.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_left(scpp::int_t<> local_a, scpp::dynamic_t<> local_b);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:right","kind":"header","path":"callables\/n7269676874.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
scpp::dynamic_t<> function_right(scpp::dynamic_t<> local_a, scpp::int_t<> local_b);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:update","kind":"header","path":"callables\/n757064617465.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_update(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:store","kind":"header","path":"callables\/n73746f7265.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_store(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b, scpp::dynamic_t<>& local_out);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n63616c63756c617465.hpp"
#include "scpp/dynamic_t.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6c656674.hpp"
#include "scpp/int_t.hpp"
#include "callables/n7269676874.hpp"
#include "callables/n757064617465.hpp"
#include "callables/n73746f7265.hpp"
scpp::dynamic_t<> function_calculate(scpp::dynamic_t<> local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_a; auto operand_1 = local_b; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_left(scpp::int_t<> local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = scpp::dynamic_t<>{local_a}; auto operand_1 = local_b; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_right(scpp::dynamic_t<> local_a, scpp::int_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_a; auto operand_1 = scpp::dynamic_t<>{local_b}; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_update(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_a; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_b; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_store(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b, scpp::dynamic_t<>& local_out)
{
	local_out = ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_a; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_b; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { using B = scpp::dynamic_t<>; B a{scpp::int_t<>{9LL}}, b{scpp::int_t<>{2LL}}; if (function_calculate(a, b).get_int().native_value() != 4 || function_left(scpp::int_t<>{9LL}, b).get_int().native_value() != 4 || function_right(a, scpp::int_t<>{2LL}).get_int().native_value() != 4) return false; auto old = a; auto result = function_update(a, b); if (old.get_int().native_value() != 9 || a.get_int().native_value() != 4 || result.get_int().native_value() != 4) return false; B fa{scpp::float_t{9.0}}, fb{scpp::float_t{2.0}}; if (function_calculate(old, fb).get_float().native_value() != 4.5 || function_calculate(fa, b).get_float().native_value() != 4.5 || function_update(fa, fb).get_float().native_value() != 4.5) return false; a = old; B out{scpp::string_t{"old"}}; int caught = 0; for (const auto& bad : {B{scpp::float_t{2.0}}, B{scpp::string_t{"2"}}, B{scpp::bool_t{true}}, B{}}) { try { function_store(a, bad, out); } catch (const std::runtime_error&) { ++caught; } if (a.get_int().native_value() != 9 || out.get_string().native_value() != "old") return false; } return caught == 4 && b.get_int().native_value() == 2; }())) ? 0 : 91; }
