#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:append","kind":"header","path":"callables\/n617070656e64.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_append(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:join","kind":"header","path":"callables\/n6a6f696e.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/string_t.hpp"
scpp::string_t function_join(scpp::dynamic_t<> local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:failure","kind":"header","path":"callables\/n6661696c757265.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_failure(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:typed","kind":"header","path":"callables\/n7479706564.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n617070656e64.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/string_t.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6a6f696e.hpp"
#include "callables/n6661696c757265.hpp"
#include "scpp/int_t.hpp"
#include "callables/n7479706564.hpp"
#include "scpp/cast.hpp"
scpp::dynamic_t<> function_append(scpp::dynamic_t<>& local_v)
{
	return ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::dynamic_t<>{([&]() -> scpp::string_t { auto operand_2 = scpp::php::to_string(previous_1); auto operand_3 = scpp::string_t("!"); return (operand_2 + operand_3); }())}; target_0 = previous_1; return target_0; }());
}

scpp::string_t function_join(scpp::dynamic_t<> local_v)
{
	return ([&]() -> scpp::string_t { auto operand_2 = ([&]() -> scpp::string_t { auto operand_0 = scpp::string_t("["); auto operand_1 = scpp::php::to_string(local_v); return (operand_0 + operand_1); }()); auto operand_3 = scpp::string_t("]"); return (operand_2 + operand_3); }());
}

void function_failure(scpp::dynamic_t<>& local_v)
{
	([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::dynamic_t<>{([&]() -> scpp::string_t { auto operand_4 = scpp::php::to_string(previous_1); auto operand_5 = scpp::php::to_string(([&]() -> scpp::int_t<> { auto operand_2 = static_cast<scpp::int_t<>>(1LL); auto operand_3 = static_cast<scpp::int_t<>>(0LL); return (operand_2 / operand_3); }())); return (operand_4 + operand_5); }())}; target_0 = previous_1; return target_0; }());
}

scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v)
{
	return scpp::required_cast<scpp::int_t<>>(([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; previous_1 = scpp::dynamic_t<>{([&]() -> scpp::string_t { auto operand_2 = scpp::php::to_string(previous_1); auto operand_3 = scpp::string_t("!"); return (operand_2 + operand_3); }())}; target_0 = previous_1; return target_0; }()));
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { using B = scpp::dynamic_t<>; B v{scpp::int_t<>{7LL}}; auto copy = v; int caught = 0; if (function_join(v).native_value() != "[7]") return false; try { function_failure(v); } catch (const std::runtime_error&) { ++caught; } if (v.get_int().native_value() != 7) return false; auto old = function_append(v); try { function_typed(v); } catch (const std::runtime_error&) { ++caught; } return caught == 2 && old.get_string().native_value() == "7!" && v.get_string().native_value() == "7!!" && copy.get_int().native_value() == 7; }())) ? 0 : 91; }
