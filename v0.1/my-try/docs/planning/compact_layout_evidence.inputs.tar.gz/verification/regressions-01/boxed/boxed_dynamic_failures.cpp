#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:divide","kind":"header","path":"callables\/n646976696465.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_divide(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:modulo","kind":"header","path":"callables\/n6d6f64756c6f.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_modulo(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:increment","kind":"header","path":"callables\/n696e6372656d656e74.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_increment(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:typed","kind":"header","path":"callables\/n7479706564.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:ordinary","kind":"header","path":"callables\/n6f7264696e617279.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
void function_ordinary(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:twice","kind":"header","path":"callables\/n7477696365.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_twice(scpp::dynamic_t<>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:table","kind":"header","path":"callables\/n7461626c65.hpp"}
#pragma once
void function_table();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n646976696465.hpp"
#include "scpp/dynamic_t.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6d6f64756c6f.hpp"
#include "callables/n696e6372656d656e74.hpp"
#include "callables/n7479706564.hpp"
#include "scpp/int_t.hpp"
#include "scpp/cast.hpp"
#include "callables/n6f7264696e617279.hpp"
#include "scpp/float_t.hpp"
#include "callables/n7477696365.hpp"
#include "callables/n7461626c65.hpp"
#include "scpp/data_initializer.hpp"
void function_divide(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs)
{
	([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_rhs; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_modulo(scpp::dynamic_t<>& local_v, scpp::dynamic_t<> local_rhs)
{
	([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_rhs; return (operand_2 % operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_increment(scpp::dynamic_t<>& local_v)
{
	static_cast<scpp::dynamic_t<>>(local_v++);
}

scpp::int_t<> function_typed(scpp::dynamic_t<>& local_v)
{
	return scpp::required_cast<scpp::int_t<>>(static_cast<scpp::dynamic_t<>>(++local_v));
}

void function_ordinary(scpp::dynamic_t<>& local_v)
{
	local_v = ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_v; auto operand_1 = scpp::dynamic_t<>{static_cast<scpp::float_t>(0.5)}; return (operand_0 + operand_1); }());
}

scpp::dynamic_t<> function_twice(scpp::dynamic_t<>& local_v)
{
	return ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_v; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_v; return (operand_2 + operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_table()
{
	scpp::dynamic_t<> local_v = scpp::data_initializer<scpp::dynamic_t<>>::from_list(scpp::initializer_list<scpp::dynamic_t<>>{});
	static_cast<scpp::dynamic_t<>>(local_v++);
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { using B = scpp::dynamic_t<>; B v{scpp::int_t<>{4LL}}; int caught = 0; if (function_twice(v).get_int().native_value() != 8) return false; try { function_divide(v, B{scpp::int_t<>{0LL}}); } catch (const std::runtime_error&) { ++caught; } try { function_modulo(v, B{scpp::int_t<>{0LL}}); } catch (const std::runtime_error&) { ++caught; } if (v.get_int().native_value() != 8) return false; B text{scpp::string_t{"2"}}; try { function_increment(text); } catch (const std::runtime_error&) { ++caught; } try { function_table(); } catch (const std::runtime_error&) { ++caught; } function_ordinary(v); try { function_typed(v); } catch (const std::runtime_error&) { ++caught; } return caught == 5 && v.get_float().native_value() == 9.5 && text.get_string().native_value() == "2"; }())) ? 0 : 91; }
