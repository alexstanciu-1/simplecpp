#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:fail","kind":"header","path":"callables\/n6661696c.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_fail(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:leftfail","kind":"header","path":"callables\/n6c6566746661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_leftfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:fallbackfail","kind":"header","path":"callables\/n66616c6c6261636b6661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_fallbackfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:elvisfail","kind":"header","path":"callables\/n656c7669736661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_elvisfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:branchfail","kind":"header","path":"callables\/n6272616e63686661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_branchfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6661696c.hpp"
#include "scpp/int_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6c6566746661696c.hpp"
#include "callables/n66616c6c6261636b6661696c.hpp"
#include "scpp/null_t.hpp"
#include "callables/n656c7669736661696c.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "callables/n6272616e63686661696c.hpp"
scpp::mixed_t function_fail(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return scpp::mixed_t{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

void function_leftfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_1 = ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_0 = local_n;
	return function_fail(argument_0);
}()); if (!coalesce_1.is_null().native_value()) { return coalesce_1; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

void function_fallbackfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n)
{
	scpp::mixed_t local_v = scpp::mixed_t{scpp::null};
	local_out = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_1 = local_v; if (!coalesce_1.is_null().native_value()) { return coalesce_1; } return ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_0 = local_n;
	return function_fail(argument_0);
}()); }());
}

void function_elvisfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n)
{
	scpp::mixed_t local_v = scpp::mixed_t{static_cast<scpp::bool_t>(false)};
	local_out = ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_0 = local_v; if (scpp::php::condition_truthy(conditional_0).native_value()) { return conditional_0; } return ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_1 = local_n;
	return function_fail(argument_1);
}()); }());
}

void function_branchfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_0 = local_n;
	return function_fail(argument_0);
}()); } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { scpp::mixed_t out{scpp::string_t{"old"}}; scpp::int_t<> n{0LL}; int caught = 0; try { function_leftfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_fallbackfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_elvisfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_branchfail(out, n); } catch (const std::runtime_error&) { ++caught; } return caught == 4 && n.native_value() == 4 && out.get_string().native_value() == "old"; }())) ? 0 : 91; }
