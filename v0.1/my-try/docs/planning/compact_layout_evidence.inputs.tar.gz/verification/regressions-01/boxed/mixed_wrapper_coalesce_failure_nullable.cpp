#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:fail","kind":"header","path":"callables\/n6661696c.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_fail(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:sourcefail","kind":"header","path":"callables\/n736f757263656661696c.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/nullable.hpp"
scpp::nullable<scpp::int_t<>> function_sourcefail(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:store","kind":"header","path":"callables\/n73746f7265.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/nullable.hpp"
#include "scpp/mixed_t.hpp"
void function_store(scpp::nullable<scpp::int_t<>> local_v, scpp::mixed_t& local_out, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:leftfail","kind":"header","path":"callables\/n6c6566746661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_leftfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n, scpp::int_t<>& local_f);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6661696c.hpp"
#include "scpp/int_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n736f757263656661696c.hpp"
#include "scpp/nullable.hpp"
#include "callables/n73746f7265.hpp"
#include "callables/n6c6566746661696c.hpp"
scpp::mixed_t function_fail(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return scpp::mixed_t{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

scpp::nullable<scpp::int_t<>> function_sourcefail(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return scpp::nullable<scpp::int_t<>>{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

void function_store(scpp::nullable<scpp::int_t<>> local_v, scpp::mixed_t& local_out, scpp::int_t<>& local_n)
{
	local_out = ([&]() -> scpp::mixed_t { scpp::nullable<scpp::int_t<>> coalesce_1 = local_v; if (coalesce_1.has_value().native_value()) { return scpp::mixed_t{scpp::int_t<>((coalesce_1).require_value("nullable required-value extraction"))}; } return ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_0 = local_n;
	return function_fail(argument_0);
}()); }());
}

void function_leftfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n, scpp::int_t<>& local_f)
{
	local_out = ([&]() -> scpp::mixed_t { scpp::nullable<scpp::int_t<>> coalesce_2 = ([&]() -> scpp::nullable<scpp::int_t<>> {
	scpp::int_t<>& argument_0 = local_n;
	return function_sourcefail(argument_0);
}()); if (coalesce_2.has_value().native_value()) { return scpp::mixed_t{scpp::int_t<>((coalesce_2).require_value("nullable required-value extraction"))}; } return ([&]() -> scpp::mixed_t {
	scpp::int_t<>& argument_1 = local_f;
	return function_fail(argument_1);
}()); }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { scpp::nullable<scpp::int_t<>> good{scpp::int_t<>{0LL}}, bad{scpp::null}; scpp::mixed_t out{scpp::string_t{"old"}}; scpp::int_t<> n{0LL}, f{0LL}; function_store(good, out, n); if (out.int_value().native_value() != 0 || n.native_value() != 0) return false; out = scpp::mixed_t{scpp::string_t{"old"}}; int caught = 0; try { function_store(bad, out, n); } catch (const std::runtime_error&) { ++caught; } try { function_leftfail(out, n, f); } catch (const std::runtime_error&) { ++caught; } return caught == 2 && n.native_value() == 2 && f.native_value() == 0 && out.get_string().native_value() == "old"; }())) ? 0 : 91; }
