#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:once","kind":"header","path":"callables\/n6f6e6365.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
#include "scpp/int_t.hpp"
scpp::result_or_false<scpp::string_t> function_once(scpp::result_or_false<scpp::string_t> local_v, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:fallback","kind":"header","path":"callables\/n66616c6c6261636b.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_fallback(scpp::mixed_t local_v, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:choose","kind":"header","path":"callables\/n63686f6f7365.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_choose(scpp::result_or_false<scpp::string_t> local_v, scpp::mixed_t local_other, scpp::int_t<>& local_n, scpp::int_t<>& local_f);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6f6e6365.hpp"
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66616c6c6261636b.hpp"
#include "scpp/mixed_t.hpp"
#include "callables/n63686f6f7365.hpp"
scpp::result_or_false<scpp::string_t> function_once(scpp::result_or_false<scpp::string_t> local_v, scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::mixed_t function_fallback(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::mixed_t function_choose(scpp::result_or_false<scpp::string_t> local_v, scpp::mixed_t local_other, scpp::int_t<>& local_n, scpp::int_t<>& local_f)
{
	return ([&]() -> scpp::mixed_t { scpp::result_or_false<scpp::string_t> coalesce_4 = ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::result_or_false<scpp::string_t> argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_once(argument_0, argument_1);
}()); if (coalesce_4.has_value().native_value()) { return scpp::mixed_t{scpp::string_t((coalesce_4).require_value("Result required-value extraction"))}; } return ([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_2 = local_other;
	scpp::int_t<>& argument_3 = local_f;
	return function_fallback(argument_2, argument_3);
}()); }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { scpp::mixed_t fallback{scpp::string_t{"fallback"}}; { scpp::result_or_false<scpp::string_t> original{scpp::string_t{""}}; scpp::int_t<> n{0LL}, f{0LL}; auto out = function_choose(original, fallback, n, f); if (n.native_value() != 1 || f.native_value() != 0 || !original.has_value().native_value() || out.get_string().native_value() != "") return false; original = scpp::result_or_false<scpp::string_t>{scpp::false_sentinel}; if (out.get_string().native_value() != "") return false; } { scpp::result_or_false<scpp::string_t> original{scpp::string_t{"0"}}; scpp::int_t<> n{0LL}, f{0LL}; auto out = function_choose(original, fallback, n, f); if (n.native_value() != 1 || f.native_value() != 0 || !original.has_value().native_value() || out.get_string().native_value() != "0") return false; original = scpp::result_or_false<scpp::string_t>{scpp::false_sentinel}; if (out.get_string().native_value() != "0") return false; } { scpp::result_or_false<scpp::string_t> original{scpp::string_t{"text"}}; scpp::int_t<> n{0LL}, f{0LL}; auto out = function_choose(original, fallback, n, f); if (n.native_value() != 1 || f.native_value() != 0 || !original.has_value().native_value() || out.get_string().native_value() != "text") return false; original = scpp::result_or_false<scpp::string_t>{scpp::false_sentinel}; if (out.get_string().native_value() != "text") return false; } scpp::result_or_false<scpp::string_t> absent{scpp::false_sentinel}; scpp::int_t<> n{0LL}, f{0LL}; auto text = function_choose(absent, fallback, n, f); fallback = scpp::mixed_t{scpp::string_t{"changed"}}; auto nil = function_choose(absent, scpp::mixed_t{scpp::null}, n, f); auto table = scpp::shared<scpp::hash_t<scpp::mixed_t>>(); scpp::mixed_t object{table}; auto handle = function_choose(absent, object, n, f); return n.native_value() == 3 && f.native_value() == 3 && !absent.has_value().native_value() && text.get_string().native_value() == "fallback" && nil.is_null().native_value() && handle.table_if() == table.get() && object.table_if() == table.get() && table->empty().native_value(); }())) ? 0 : 91; }
