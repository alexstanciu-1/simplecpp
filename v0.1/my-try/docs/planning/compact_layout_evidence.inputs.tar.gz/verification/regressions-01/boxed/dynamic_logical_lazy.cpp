#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:tick","kind":"header","path":"callables\/n7469636b.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_tick(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:run","kind":"header","path":"callables\/n72756e.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_run();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n7469636b.hpp"
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n72756e.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "scpp/float_t.hpp"
scpp::dynamic_t<> function_tick(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return scpp::dynamic_t<>{static_cast<scpp::bool_t>(true)};
}

scpp::int_t<> function_run()
{
	auto local_n = static_cast<scpp::int_t<>>(0LL);
	scpp::dynamic_t<> local_off = scpp::dynamic_t<>{static_cast<scpp::bool_t>(false)};
	scpp::dynamic_t<> local_on = scpp::dynamic_t<>{static_cast<scpp::bool_t>(true)};
	auto local_a = scpp::bool_t((scpp::php::condition_truthy(local_off).native_value()) && (scpp::php::condition_truthy(([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_0 = local_n;
	return function_tick(argument_0);
}())).native_value()));
	auto local_b = scpp::bool_t((scpp::php::condition_truthy(local_on).native_value()) || (scpp::php::condition_truthy(([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_1 = local_n;
	return function_tick(argument_1);
}())).native_value()));
	auto local_c = scpp::bool_t((scpp::php::condition_truthy(local_on).native_value()) && (scpp::php::condition_truthy(([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_2 = local_n;
	return function_tick(argument_2);
}())).native_value()));
	auto local_d = scpp::bool_t((scpp::php::condition_truthy(local_off).native_value()) || (scpp::php::condition_truthy(([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_3 = local_n;
	return function_tick(argument_3);
}())).native_value()));
	auto local_e = scpp::bool_t((scpp::php::condition_truthy(static_cast<scpp::int_t<>>(1LL)).native_value()) && (scpp::php::condition_truthy(local_on).native_value()));
	auto local_f = scpp::bool_t((scpp::php::condition_truthy(local_off).native_value()) || (scpp::php::condition_truthy(static_cast<scpp::float_t>(1.0)).native_value()));
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(local_a) || static_cast<bool>((!local_b)))) || static_cast<bool>((!local_c)))) || static_cast<bool>((!local_d)))) || static_cast<bool>((!local_e)))) || static_cast<bool>((!local_f)))).native_value()) {
	return static_cast<scpp::int_t<>>(99LL);
}
	return local_n;
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (function_run().native_value() == 2) ? 0 : 91; }
