#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:fail","kind":"header","path":"callables\/n6661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_fail();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6661696c.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::mixed_t function_fail()
{
	return scpp::mixed_t{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/null_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
#include "callables/n6661696c.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::mixed_t local_m = scpp::mixed_t{scpp::null};
	auto local_a = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return scpp::mixed_t{static_cast<scpp::int_t<>>(9LL)}; } return local_m; }());
	auto local_b = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(false)).native_value()) { return local_m; } return scpp::mixed_t{static_cast<scpp::int_t<>>(9LL)}; }());
	auto local_c = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_0 = local_m; if (!coalesce_0.is_null().native_value()) { return coalesce_0; } return scpp::mixed_t{static_cast<scpp::int_t<>>(9LL)}; }());
	auto local_d = ([&]() -> scpp::mixed_t { return scpp::mixed_t{static_cast<scpp::int_t<>>(9LL)}; }());
	auto local_e = ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_1 = local_m; if (scpp::php::condition_truthy(conditional_1).native_value()) { return conditional_1; } return scpp::mixed_t{static_cast<scpp::int_t<>>(9LL)}; }());
	auto local_f = ([&]() -> scpp::mixed_t { scpp::int_t<> conditional_2 = static_cast<scpp::int_t<>>(9LL); if (scpp::php::condition_truthy(conditional_2).native_value()) { return scpp::mixed_t{conditional_2}; } return local_m; }());
	if (!(local_a.int_value().native_value() == 9 && local_b.int_value().native_value() == 9 && local_c.int_value().native_value() == 9 && local_d.int_value().native_value() == 9 && local_e.int_value().native_value() == 9 && local_f.int_value().native_value() == 9)) { return 91; }
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
