#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:source","kind":"header","path":"callables\/n736f75726365.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_source(scpp::mixed_t local_v, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:positive","kind":"header","path":"callables\/n706f736974697665.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_positive(scpp::mixed_t local_v, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:negative","kind":"header","path":"callables\/n6e65676174697665.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
scpp::mixed_t function_negative(scpp::mixed_t local_v, scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:preinc","kind":"header","path":"callables\/n707265696e63.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_preinc(scpp::mixed_t& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:postinc","kind":"header","path":"callables\/n706f7374696e63.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_postinc(scpp::mixed_t& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:predec","kind":"header","path":"callables\/n707265646563.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_predec(scpp::mixed_t& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:postdec","kind":"header","path":"callables\/n706f7374646563.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_postdec(scpp::mixed_t& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n736f75726365.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n706f736974697665.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "callables/n6e65676174697665.hpp"
#include "callables/n707265696e63.hpp"
#include "callables/n706f7374696e63.hpp"
#include "callables/n707265646563.hpp"
#include "callables/n706f7374646563.hpp"
scpp::mixed_t function_source(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::mixed_t function_positive(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	return (+([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_source(argument_0, argument_1);
}()));
}

scpp::mixed_t function_negative(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	return (-([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_source(argument_0, argument_1);
}()));
}

scpp::mixed_t function_preinc(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(++local_v);
}

scpp::mixed_t function_postinc(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(local_v++);
}

scpp::mixed_t function_predec(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(--local_v);
}

scpp::mixed_t function_postdec(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(local_v--);
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { using B = scpp::mixed_t; B v{scpp::int_t<>{4LL}}; scpp::int_t<> n{0LL}; if (function_positive(v, n).get_int().native_value() != 4 || function_negative(v, n).get_int().native_value() != -4 || n.native_value() != 2) return false; auto a = function_preinc(v); auto b = function_postinc(v); auto c = function_predec(v); auto d = function_postdec(v); B f{scpp::float_t{1.5}}; auto before = function_postinc(f); return a.get_int().native_value() == 5 && b.get_int().native_value() == 5 && c.get_int().native_value() == 5 && d.get_int().native_value() == 5 && v.get_int().native_value() == 4 && before.get_float().native_value() == 1.5 && f.get_float().native_value() == 2.5; }())) ? 0 : 91; }
