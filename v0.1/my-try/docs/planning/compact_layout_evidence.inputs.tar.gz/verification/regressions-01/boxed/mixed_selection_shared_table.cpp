#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:choose","kind":"header","path":"callables\/n63686f6f7365.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_choose(scpp::mixed_t local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:coalesce","kind":"header","path":"callables\/n636f616c65736365.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_coalesce(scpp::mixed_t local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:elvis","kind":"header","path":"callables\/n656c766973.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_elvis(scpp::mixed_t local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n63686f6f7365.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
#include "callables/n636f616c65736365.hpp"
#include "callables/n656c766973.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
scpp::mixed_t function_choose(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return local_v; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

scpp::mixed_t function_coalesce(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_0 = local_v; if (!coalesce_0.is_null().native_value()) { return coalesce_0; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

scpp::mixed_t function_elvis(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_0 = local_v; if (scpp::php::condition_truthy(conditional_0).native_value()) { return conditional_0; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { auto table = scpp::shared<scpp::hash_t<scpp::mixed_t>>(); scpp::mixed_t object{table}; auto selected = function_choose(object); auto present = function_coalesce(object); bool caught = false; try { (void)function_elvis(object); } catch (const std::runtime_error&) { caught = true; } return caught && selected.table_if() == table.get() && present.table_if() == table.get() && table->empty().native_value(); }())) ? 0 : 91; }
