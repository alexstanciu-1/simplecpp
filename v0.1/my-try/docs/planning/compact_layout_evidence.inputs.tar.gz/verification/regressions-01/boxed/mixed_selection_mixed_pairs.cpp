#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:fail","kind":"header","path":"callables\/n6661696c.hpp"}
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_fail();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6661696c.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::mixed_t function_fail()
{
	return scpp::mixed_t{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/null_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n6661696c.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::mixed_t local_a = scpp::mixed_t{scpp::null};
	scpp::mixed_t local_b = scpp::mixed_t{scpp::null};
	scpp::mixed_t local_c = scpp::mixed_t{scpp::string_t("left")};
	scpp::mixed_t local_d = scpp::mixed_t{static_cast<scpp::int_t<>>(7LL)};
	auto local_nullresult = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_0 = local_a; if (!coalesce_0.is_null().native_value()) { return coalesce_0; } return local_b; }());
	auto local_nullselected = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(false)).native_value()) { return local_c; } return local_a; }());
	auto local_left = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_1 = local_c; if (!coalesce_1.is_null().native_value()) { return coalesce_1; } return ([&]() -> scpp::mixed_t {
	return function_fail();
}()); }());
	auto local_right = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_2 = local_a; if (!coalesce_2.is_null().native_value()) { return coalesce_2; } return local_d; }());
	auto local_elvis = ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_3 = local_a; if (scpp::php::condition_truthy(conditional_3).native_value()) { return conditional_3; } return local_d; }());
	auto local_truthy = ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_4 = local_c; if (scpp::php::condition_truthy(conditional_4).native_value()) { return conditional_4; } return ([&]() -> scpp::mixed_t {
	return function_fail();
}()); }());
	auto local_full = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return local_c; } return ([&]() -> scpp::mixed_t {
	return function_fail();
}()); }());
	local_c = scpp::mixed_t{scpp::string_t("changed")};
	local_d = scpp::mixed_t{static_cast<scpp::int_t<>>(8LL)};
	if (!(local_nullresult.is_null().native_value() && local_nullselected.is_null().native_value() && local_left.get_string().native_value() == "left" && local_right.int_value().native_value() == 7 && local_elvis.int_value().native_value() == 7 && local_truthy.get_string().native_value() == "left" && local_full.get_string().native_value() == "left")) { return 91; }
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
