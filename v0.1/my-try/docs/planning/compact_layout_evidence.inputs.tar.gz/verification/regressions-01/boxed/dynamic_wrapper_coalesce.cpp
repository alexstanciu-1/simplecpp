#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:nullable","kind":"header","path":"callables\/n6e756c6c61626c65.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_nullable();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:present","kind":"header","path":"callables\/n70726573656e74.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_present();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:result","kind":"header","path":"callables\/n726573756c74.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_result();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:reverse","kind":"header","path":"callables\/n72657665727365.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_reverse();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6e756c6c61626c65.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/null_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/nullable.hpp"
#include "callables/n70726573656e74.hpp"
#include "callables/n726573756c74.hpp"
#include "scpp/result.hpp"
#include "callables/n72657665727365.hpp"
scpp::dynamic_t<> function_nullable()
{
	scpp::nullable<scpp::int_t<>> local_v = scpp::nullable<scpp::int_t<>>{scpp::null};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::nullable<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("nullable required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_present()
{
	scpp::nullable<scpp::int_t<>> local_v = scpp::nullable<scpp::int_t<>>{static_cast<scpp::int_t<>>(0LL)};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::nullable<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("nullable required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_result()
{
	scpp::result<scpp::int_t<>> local_v = scpp::result<scpp::int_t<>>{static_cast<scpp::int_t<>>(0LL)};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::result<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("Result required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_reverse()
{
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)}; }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (function_nullable().get_int().native_value() == 9 && function_present().get_int().native_value() == 0 && function_result().get_int().native_value() == 0 && function_reverse().get_int().native_value() == 7) ? 0 : 91; }
