#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
// SCPP-ARTIFACT {"id":"callable:truth","kind":"header","path":"callables\/n7472757468.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
scpp::bool_t function_truth(scpp::dynamic_t<> local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:negate","kind":"header","path":"callables\/n6e6567617465.hpp"}
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
scpp::bool_t function_negate(scpp::dynamic_t<> local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:loops","kind":"header","path":"callables\/n6c6f6f7073.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_loops();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n7472757468.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "callables/n6e6567617465.hpp"
#include "callables/n6c6f6f7073.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/mixed_t.hpp"
scpp::bool_t function_truth(scpp::dynamic_t<> local_v)
{
if (scpp::php::condition_truthy(local_v).native_value()) {
	return static_cast<scpp::bool_t>(true);
}
	return static_cast<scpp::bool_t>(false);
}

scpp::bool_t function_negate(scpp::dynamic_t<> local_v)
{
	return scpp::bool_t(!(scpp::php::condition_truthy(local_v).native_value()));
}

scpp::int_t<> function_loops()
{
	scpp::dynamic_t<> local_v = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)};
	auto local_n = static_cast<scpp::int_t<>>(0LL);
while (scpp::php::condition_truthy(local_v).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
	local_v = scpp::dynamic_t<>{static_cast<scpp::bool_t>(false)};
}
do {
	static_cast<scpp::int_t<>>(local_n++);
}
while (scpp::php::condition_truthy(local_v).native_value());
{
for (; scpp::php::condition_truthy(local_v).native_value(); ) {
	static_cast<scpp::int_t<>>(local_n++);
}
}
if (scpp::php::condition_truthy(local_v).native_value()) {
	return static_cast<scpp::int_t<>>(0LL);
}
else if (scpp::php::condition_truthy(scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(scpp::initializer_list<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>>{})).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
}
	return local_n;
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

int main() { return (([&]() { using D = scpp::dynamic_t<>; for (const auto& v : {D{}, D{scpp::bool_t{false}}, D{scpp::int_t<>{0LL}}, D{scpp::float_t{0.0}}, D{scpp::string_t{""}}, D{scpp::string_t{"0"}}}) if (function_truth(v).native_value() || !function_negate(v).native_value()) return false; for (const auto& v : {D{scpp::bool_t{true}}, D{scpp::int_t<>{1LL}}, D{scpp::float_t{0.5}}, D{scpp::string_t{"false"}}, D::make_container()}) if (!function_truth(v).native_value() || function_negate(v).native_value()) return false; return function_loops().native_value() == 3; }())) ? 0 : 91; }
