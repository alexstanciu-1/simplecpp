#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n736f75726365.hpp"
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66616c6c6261636b.hpp"
#include "callables/n656c766973.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "callables/n636f616c65736365.hpp"
#include "callables/n63686f6f7365.hpp"
#include "scpp/bool_t.hpp"
scpp::dynamic_t<> function_source(scpp::int_t<>& local_n, scpp::dynamic_t<> local_v)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::int_t<> function_fallback(scpp::int_t<>& local_n)
{
	([&]() -> scpp::int_t<> { auto& target_0 = local_n; auto previous_1 = target_0; previous_1 = ([&]() -> scpp::int_t<> { auto operand_2 = previous_1; auto operand_3 = static_cast<scpp::int_t<>>(10LL); return (operand_2 + operand_3); }()); target_0 = previous_1; return target_0; }());
	return static_cast<scpp::int_t<>>(9LL);
}

scpp::dynamic_t<> function_elvis(scpp::dynamic_t<> local_v, scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::dynamic_t<> { scpp::dynamic_t<> conditional_2 = ([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_0 = local_n;
	scpp::dynamic_t<> argument_1 = local_v;
	return function_source(argument_0, argument_1);
}()); if (scpp::php::condition_truthy(conditional_2).native_value()) { return conditional_2; } return scpp::dynamic_t<>{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_3 = local_n;
	return function_fallback(argument_3);
}())}; }());
}

scpp::dynamic_t<> function_coalesce(scpp::dynamic_t<> local_v, scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::dynamic_t<> { scpp::dynamic_t<> coalesce_3 = ([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_0 = local_n;
	scpp::dynamic_t<> argument_1 = local_v;
	return function_source(argument_0, argument_1);
}()); if (!coalesce_3.is_null().native_value()) { return coalesce_3; } return scpp::dynamic_t<>{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_2 = local_n;
	return function_fallback(argument_2);
}())}; }());
}

scpp::dynamic_t<> function_choose(scpp::bool_t local_pick, scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::dynamic_t<> { if ((local_pick).native_value()) { return ([&]() -> scpp::dynamic_t<> {
	scpp::int_t<>& argument_0 = local_n;
	scpp::dynamic_t<> argument_1 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)};
	return function_source(argument_0, argument_1);
}()); } return scpp::dynamic_t<>{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_2 = local_n;
	return function_fallback(argument_2);
}())}; }());
}

