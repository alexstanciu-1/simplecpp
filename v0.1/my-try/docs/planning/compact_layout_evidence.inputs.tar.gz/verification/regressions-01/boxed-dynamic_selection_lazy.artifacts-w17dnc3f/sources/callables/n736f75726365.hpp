#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_source(scpp::int_t<>& local_n, scpp::dynamic_t<> local_v);
