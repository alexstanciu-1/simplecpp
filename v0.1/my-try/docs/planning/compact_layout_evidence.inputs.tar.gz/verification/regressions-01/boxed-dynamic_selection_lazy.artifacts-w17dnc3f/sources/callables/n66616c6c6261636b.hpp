#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_fallback(scpp::int_t<>& local_n);
