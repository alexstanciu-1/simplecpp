#include "callables/n736f75726365.hpp"
#include "callables/n66616c6c6261636b.hpp"
#include "callables/n656c766973.hpp"
#include "callables/n636f616c65736365.hpp"
#include "callables/n63686f6f7365.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using D = scpp::dynamic_t<>; scpp::int_t<> n{0LL}; auto a = function_elvis(D{scpp::int_t<>{0LL}}, n); auto b = function_coalesce(D{scpp::int_t<>{0LL}}, n); auto c = function_coalesce(D{}, n); auto d = function_choose(scpp::bool_t{true}, n); auto e = function_choose(scpp::bool_t{false}, n); return n.native_value() == 34 && a.get_int().native_value() == 9 && b.get_int().native_value() == 0 && c.get_int().native_value() == 9 && d.get_int().native_value() == 7 && e.get_int().native_value() == 9; }())) ? 0 : 91; }
