#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
scpp::dynamic_t<> function_choose(scpp::bool_t local_pick, scpp::int_t<>& local_n);
