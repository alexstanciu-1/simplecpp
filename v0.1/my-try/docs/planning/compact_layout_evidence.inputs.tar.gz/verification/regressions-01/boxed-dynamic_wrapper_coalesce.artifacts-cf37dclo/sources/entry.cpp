#include "callables/n6e756c6c61626c65.hpp"
#include "callables/n70726573656e74.hpp"
#include "callables/n726573756c74.hpp"
#include "callables/n72657665727365.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (function_nullable().get_int().native_value() == 9 && function_present().get_int().native_value() == 0 && function_result().get_int().native_value() == 0 && function_reverse().get_int().native_value() == 7) ? 0 : 91; }
