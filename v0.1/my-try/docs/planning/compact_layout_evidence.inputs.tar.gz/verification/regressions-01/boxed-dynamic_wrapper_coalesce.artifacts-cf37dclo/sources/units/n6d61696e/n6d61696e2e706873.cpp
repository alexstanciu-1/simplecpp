#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n6e756c6c61626c65.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/null_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/nullable.hpp"
#include "callables/n70726573656e74.hpp"
#include "callables/n726573756c74.hpp"
#include "scpp/result.hpp"
#include "callables/n72657665727365.hpp"
scpp::dynamic_t<> function_nullable()
{
	scpp::nullable<scpp::int_t<>> local_v = scpp::nullable<scpp::int_t<>>{scpp::null};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::nullable<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("nullable required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_present()
{
	scpp::nullable<scpp::int_t<>> local_v = scpp::nullable<scpp::int_t<>>{static_cast<scpp::int_t<>>(0LL)};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::nullable<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("nullable required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_result()
{
	scpp::result<scpp::int_t<>> local_v = scpp::result<scpp::int_t<>>{static_cast<scpp::int_t<>>(0LL)};
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { scpp::result<scpp::int_t<>> coalesce_0 = local_v; if (coalesce_0.has_value().native_value()) { return scpp::dynamic_t<>{scpp::int_t<>((coalesce_0).require_value("Result required-value extraction"))}; } return local_fallback; }());
}

scpp::dynamic_t<> function_reverse()
{
	scpp::dynamic_t<> local_fallback = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(9LL)};
	return ([&]() -> scpp::dynamic_t<> { return scpp::dynamic_t<>{static_cast<scpp::int_t<>>(7LL)}; }());
}

