#include "callables/n617070656e64.hpp"
#include "callables/n6a6f696e.hpp"
#include "callables/n6661696c757265.hpp"
#include "callables/n7479706564.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using B = scpp::dynamic_t<>; B v{scpp::int_t<>{7LL}}; auto copy = v; int caught = 0; if (function_join(v).native_value() != "[7]") return false; try { function_failure(v); } catch (const std::runtime_error&) { ++caught; } if (v.get_int().native_value() != 7) return false; auto old = function_append(v); try { function_typed(v); } catch (const std::runtime_error&) { ++caught; } return caught == 2 && old.get_string().native_value() == "7!" && v.get_string().native_value() == "7!!" && copy.get_int().native_value() == 7; }())) ? 0 : 91; }
