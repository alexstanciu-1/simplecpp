#include "callables/n636865636b.hpp"
#include "callables/n696e76616c6964.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using B = scpp::mixed_t; scpp::bool_t out{true}; int caught = 0; try { function_invalid(B{scpp::string_t{"1"}}, out); } catch (const std::runtime_error&) { ++caught; } return function_check().native_value() && caught == 1 && out.native_value(); }())) ? 0 : 91; }
