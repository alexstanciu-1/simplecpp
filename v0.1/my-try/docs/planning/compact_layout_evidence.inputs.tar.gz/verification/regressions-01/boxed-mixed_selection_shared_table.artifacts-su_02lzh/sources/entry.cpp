#include "callables/n63686f6f7365.hpp"
#include "callables/n636f616c65736365.hpp"
#include "callables/n656c766973.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { auto table = scpp::shared<scpp::hash_t<scpp::mixed_t>>(); scpp::mixed_t object{table}; auto selected = function_choose(object); auto present = function_coalesce(object); bool caught = false; try { (void)function_elvis(object); } catch (const std::runtime_error&) { caught = true; } return caught && selected.table_if() == table.get() && present.table_if() == table.get() && table->empty().native_value(); }())) ? 0 : 91; }
