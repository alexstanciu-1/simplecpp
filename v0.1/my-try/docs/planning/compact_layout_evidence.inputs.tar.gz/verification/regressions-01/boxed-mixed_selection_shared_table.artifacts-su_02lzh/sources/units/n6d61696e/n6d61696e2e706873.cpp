#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n63686f6f7365.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/bool_t.hpp"
#include "scpp/int_t.hpp"
#include "callables/n636f616c65736365.hpp"
#include "callables/n656c766973.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
scpp::mixed_t function_choose(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return local_v; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

scpp::mixed_t function_coalesce(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_0 = local_v; if (!coalesce_0.is_null().native_value()) { return coalesce_0; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

scpp::mixed_t function_elvis(scpp::mixed_t local_v)
{
	return ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_0 = local_v; if (scpp::php::condition_truthy(conditional_0).native_value()) { return conditional_0; } return scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)}; }());
}

