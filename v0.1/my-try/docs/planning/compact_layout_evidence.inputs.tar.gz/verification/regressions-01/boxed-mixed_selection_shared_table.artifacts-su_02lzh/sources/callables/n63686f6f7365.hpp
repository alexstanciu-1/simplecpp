#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_choose(scpp::mixed_t local_v);
