#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n736f75726365.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n706f736974697665.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "callables/n6e65676174697665.hpp"
#include "callables/n707265696e63.hpp"
#include "callables/n706f7374696e63.hpp"
#include "callables/n707265646563.hpp"
#include "callables/n706f7374646563.hpp"
scpp::mixed_t function_source(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::mixed_t function_positive(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	return (+([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_source(argument_0, argument_1);
}()));
}

scpp::mixed_t function_negative(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	return (-([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_source(argument_0, argument_1);
}()));
}

scpp::mixed_t function_preinc(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(++local_v);
}

scpp::mixed_t function_postinc(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(local_v++);
}

scpp::mixed_t function_predec(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(--local_v);
}

scpp::mixed_t function_postdec(scpp::mixed_t& local_v)
{
	return static_cast<scpp::mixed_t>(local_v--);
}

