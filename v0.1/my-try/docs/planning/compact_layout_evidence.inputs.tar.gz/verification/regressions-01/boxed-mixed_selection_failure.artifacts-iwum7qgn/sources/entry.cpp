#include "callables/n6661696c.hpp"
#include "callables/n6c6566746661696c.hpp"
#include "callables/n66616c6c6261636b6661696c.hpp"
#include "callables/n656c7669736661696c.hpp"
#include "callables/n6272616e63686661696c.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { scpp::mixed_t out{scpp::string_t{"old"}}; scpp::int_t<> n{0LL}; int caught = 0; try { function_leftfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_fallbackfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_elvisfail(out, n); } catch (const std::runtime_error&) { ++caught; } try { function_branchfail(out, n); } catch (const std::runtime_error&) { ++caught; } return caught == 4 && n.native_value() == 4 && out.get_string().native_value() == "old"; }())) ? 0 : 91; }
