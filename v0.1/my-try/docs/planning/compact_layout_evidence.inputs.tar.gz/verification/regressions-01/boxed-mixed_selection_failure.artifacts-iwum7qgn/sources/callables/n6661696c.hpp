#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/mixed_t.hpp"
scpp::mixed_t function_fail(scpp::int_t<>& local_n);
