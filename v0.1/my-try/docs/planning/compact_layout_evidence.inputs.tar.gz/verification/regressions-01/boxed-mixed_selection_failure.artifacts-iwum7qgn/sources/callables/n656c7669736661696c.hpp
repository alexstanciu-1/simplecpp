#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
void function_elvisfail(scpp::mixed_t& local_out, scpp::int_t<>& local_n);
