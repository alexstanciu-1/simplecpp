#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n63616c63756c617465.hpp"
#include "scpp/dynamic_t.hpp"
#include "operators/arithmetic/boxed_numeric.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6c656674.hpp"
#include "scpp/int_t.hpp"
#include "callables/n7269676874.hpp"
#include "callables/n757064617465.hpp"
#include "callables/n73746f7265.hpp"
scpp::dynamic_t<> function_calculate(scpp::dynamic_t<> local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_a; auto operand_1 = local_b; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_left(scpp::int_t<> local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = scpp::dynamic_t<>{local_a}; auto operand_1 = local_b; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_right(scpp::dynamic_t<> local_a, scpp::int_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto operand_0 = local_a; auto operand_1 = scpp::dynamic_t<>{local_b}; return (operand_0 / operand_1); }());
}

scpp::dynamic_t<> function_update(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b)
{
	return ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_a; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_b; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

void function_store(scpp::dynamic_t<>& local_a, scpp::dynamic_t<> local_b, scpp::dynamic_t<>& local_out)
{
	local_out = ([&]() -> scpp::dynamic_t<> { auto& target_0 = local_a; auto previous_1 = target_0; scpp::detail::assign_numeric_result(previous_1, ([&]() -> scpp::dynamic_t<> { auto operand_2 = previous_1; auto operand_3 = local_b; return (operand_2 / operand_3); }())); target_0 = previous_1; return target_0; }());
}

