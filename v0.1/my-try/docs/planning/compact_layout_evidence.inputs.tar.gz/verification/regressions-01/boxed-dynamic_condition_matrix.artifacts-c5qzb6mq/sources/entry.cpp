#include "callables/n7472757468.hpp"
#include "callables/n6e6567617465.hpp"
#include "callables/n6c6f6f7073.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { return (([&]() { using D = scpp::dynamic_t<>; for (const auto& v : {D{}, D{scpp::bool_t{false}}, D{scpp::int_t<>{0LL}}, D{scpp::float_t{0.0}}, D{scpp::string_t{""}}, D{scpp::string_t{"0"}}}) if (function_truth(v).native_value() || !function_negate(v).native_value()) return false; for (const auto& v : {D{scpp::bool_t{true}}, D{scpp::int_t<>{1LL}}, D{scpp::float_t{0.5}}, D{scpp::string_t{"false"}}, D::make_container()}) if (!function_truth(v).native_value() || function_negate(v).native_value()) return false; return function_loops().native_value() == 3; }())) ? 0 : 91; }
