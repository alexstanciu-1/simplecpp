#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#pragma once
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
scpp::bool_t function_truth(scpp::dynamic_t<> local_v);
