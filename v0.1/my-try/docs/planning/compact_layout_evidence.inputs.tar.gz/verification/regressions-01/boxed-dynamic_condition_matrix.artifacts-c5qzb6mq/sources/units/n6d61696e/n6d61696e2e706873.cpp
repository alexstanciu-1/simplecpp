#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n7472757468.hpp"
#include "scpp/dynamic_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "callables/n6e6567617465.hpp"
#include "callables/n6c6f6f7073.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/data_initializer.hpp"
#include "scpp/mixed_t.hpp"
scpp::bool_t function_truth(scpp::dynamic_t<> local_v)
{
if (scpp::php::condition_truthy(local_v).native_value()) {
	return static_cast<scpp::bool_t>(true);
}
	return static_cast<scpp::bool_t>(false);
}

scpp::bool_t function_negate(scpp::dynamic_t<> local_v)
{
	return scpp::bool_t(!(scpp::php::condition_truthy(local_v).native_value()));
}

scpp::int_t<> function_loops()
{
	scpp::dynamic_t<> local_v = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)};
	auto local_n = static_cast<scpp::int_t<>>(0LL);
while (scpp::php::condition_truthy(local_v).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
	local_v = scpp::dynamic_t<>{static_cast<scpp::bool_t>(false)};
}
do {
	static_cast<scpp::int_t<>>(local_n++);
}
while (scpp::php::condition_truthy(local_v).native_value());
{
for (; scpp::php::condition_truthy(local_v).native_value(); ) {
	static_cast<scpp::int_t<>>(local_n++);
}
}
if (scpp::php::condition_truthy(local_v).native_value()) {
	return static_cast<scpp::int_t<>>(0LL);
}
else if (scpp::php::condition_truthy(scpp::data_initializer<scpp::dynamic_t<>>::from_key_value(scpp::initializer_list<scpp::initializer_entry<scpp::dynamic_t<>, scpp::mixed_t>>{})).native_value()) {
	static_cast<scpp::int_t<>>(local_n++);
}
	return local_n;
}

