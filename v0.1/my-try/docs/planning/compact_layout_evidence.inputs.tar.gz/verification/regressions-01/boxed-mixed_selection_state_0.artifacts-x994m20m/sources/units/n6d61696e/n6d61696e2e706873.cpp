#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n6f6e6365.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n66616c6c6261636b.hpp"
scpp::mixed_t function_once(scpp::mixed_t local_v, scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_v;
}

scpp::int_t<> function_fallback(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return static_cast<scpp::int_t<>>(42LL);
}

