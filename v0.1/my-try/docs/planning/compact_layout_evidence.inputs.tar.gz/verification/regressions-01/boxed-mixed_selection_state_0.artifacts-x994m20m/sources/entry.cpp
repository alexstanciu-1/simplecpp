#include "callables/n6f6e6365.hpp"
#include "callables/n66616c6c6261636b.hpp"
#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "scpp/null_t.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n6f6e6365.hpp"
#include "callables/n66616c6c6261636b.hpp"
#include "lang/php/operators/conditional/condition_truthiness.hpp"
#include "scpp/string_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::mixed_t local_v = scpp::mixed_t{scpp::null};
	auto local_n = static_cast<scpp::int_t<>>(0LL);
	auto local_fallbacks = static_cast<scpp::int_t<>>(0LL);
	auto local_full = ([&]() -> scpp::mixed_t { if ((static_cast<scpp::bool_t>(true)).native_value()) { return ([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_0 = local_v;
	scpp::int_t<>& argument_1 = local_n;
	return function_once(argument_0, argument_1);
}()); } return scpp::mixed_t{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_2 = local_fallbacks;
	return function_fallback(argument_2);
}())}; }());
	auto local_elvis = ([&]() -> scpp::mixed_t { scpp::mixed_t conditional_5 = ([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_3 = local_v;
	scpp::int_t<>& argument_4 = local_n;
	return function_once(argument_3, argument_4);
}()); if (scpp::php::condition_truthy(conditional_5).native_value()) { return conditional_5; } return scpp::mixed_t{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_6 = local_fallbacks;
	return function_fallback(argument_6);
}())}; }());
	auto local_coalesce = ([&]() -> scpp::mixed_t { scpp::mixed_t coalesce_10 = ([&]() -> scpp::mixed_t {
	scpp::mixed_t argument_7 = local_v;
	scpp::int_t<>& argument_8 = local_n;
	return function_once(argument_7, argument_8);
}()); if (!coalesce_10.is_null().native_value()) { return coalesce_10; } return scpp::mixed_t{([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_9 = local_fallbacks;
	return function_fallback(argument_9);
}())}; }());
	local_v = scpp::mixed_t{scpp::string_t("changed")};
	if (!(local_n.native_value() == 3 && local_fallbacks.native_value() == 2 && local_full.is_null().native_value() == true && local_elvis.int_value().native_value() == 42 && local_coalesce.int_value().native_value() == 42)) { return 91; }
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
