#include "scpp/memory.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n6661696c.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::mixed_t function_fail()
{
	return scpp::mixed_t{([&]() -> scpp::int_t<> { auto operand_0 = static_cast<scpp::int_t<>>(1LL); auto operand_1 = static_cast<scpp::int_t<>>(0LL); return (operand_0 / operand_1); }())};
}

