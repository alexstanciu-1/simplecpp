#pragma once
#include "scpp/int_t.hpp"
struct record_Pair
{
public:
	scpp::int_t<std::int32_t> field_first = static_cast<scpp::int_t<std::int32_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
	scpp::int_t<std::int32_t> field_second = static_cast<scpp::int_t<std::int32_t>>((static_cast<scpp::int_t<>>(0LL)).native_value());
public:
};

