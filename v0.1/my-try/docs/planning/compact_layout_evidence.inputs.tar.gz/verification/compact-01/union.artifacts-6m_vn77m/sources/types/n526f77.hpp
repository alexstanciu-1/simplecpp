#pragma once
#include "types/n5061796c6f6164.hpp"
struct record_Row
{
public:
	record_Payload field_payload;
public:
};

