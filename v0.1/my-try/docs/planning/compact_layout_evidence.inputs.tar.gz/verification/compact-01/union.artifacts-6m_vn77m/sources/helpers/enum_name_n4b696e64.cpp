#include "scpp/string_t.hpp"
#include "types/n4b696e64.hpp"
#include "stdexcept"
#include "helpers/enum_name_n4b696e64.hpp"
scpp::string_t enum_name_Kind(enum_Kind value) {
	switch (value) {
	case enum_Kind::case_One: return scpp::string_t("One");
	case enum_Kind::case_Two: return scpp::string_t("Two");
	}
	throw std::runtime_error("Invalid value for enum helper");
}
