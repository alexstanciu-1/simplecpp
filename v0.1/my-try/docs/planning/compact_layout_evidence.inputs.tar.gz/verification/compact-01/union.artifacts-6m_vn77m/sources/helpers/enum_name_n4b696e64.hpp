#pragma once
#include "scpp/string_t.hpp"
#include "types/n4b696e64.hpp"
scpp::string_t enum_name_Kind(enum_Kind value);
