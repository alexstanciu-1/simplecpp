import gzip,json,re,sys
from pathlib import Path
root=Path('/home/alex-ai/simple-repairs/20261019-01')
review=root/'verification/docs-review'
sys.path.insert(0,str(root/'compiler/my-try/tools'))
from test_runner import CommandRunner,Task,run_tasks
D=review/'compiler/my-try/docs/planning'
ledger=json.loads((D/'simple_repairs_03_documentation.json').read_text())
old=json.loads(gzip.decompress((D/'simple_repairs_03_docs_before.json.gz').read_bytes()))
checks=[]
with CommandRunner(review/'logs',review,jobs=12) as runner:
 def check():
  ids=[s['id'] for s in ledger['sections']]
  assert len(ids)==len(set(ids))==141
  for filename,prior in old.items():
   path=review/filename;current=path.read_text()
   assert re.findall(r'^#{1,6} .*$',prior,re.M)==re.findall(r'^#{1,6} .*$',current,re.M),filename
   assert re.findall(r'^```[^\n]*\n.*?^```',prior,re.M|re.S)==re.findall(r'^```[^\n]*\n.*?^```',current,re.M|re.S),filename
   assert current.count('<details>')==current.count('</details>'),filename
   for row in [s for s in ledger['sections'] if s['path']==filename]:
    assert current.count('Current scope — 2026-10-19 ('+row['id']+').')==1,row['id']
    assert row['authority'] and row['evidence'] and row['checks'],row['id']
    for a in row['authority']:
     target=a.split(':',1)[0]
     assert (review/target).exists() or (root/target).exists(),target
   new_links=set(re.findall(r'\]\(([^)]+)\)',current))-set(re.findall(r'\]\(([^)]+)\)',prior))
   for link in new_links:
    target=link.split('#',1)[0]
    if not target or '://' in target:continue
    assert (path.parent/target).exists() or (root/filename).parent.joinpath(target).exists(),(filename,target)
   checks.append({'file':filename,'headings_preserved':True,'code_examples_preserved':True,'new_links_resolve':True})
  (review/'summary.json').write_text(json.dumps({'passed':True,'sections':len(ids),'files':checks,'semantic_execution_claim':'Uses existing scoped evidence; no new feature support inferred'},indent=2))
 run_tasks([Task('documentation-reconciliation',check)])
