import json,sys,time,traceback
from pathlib import Path
root=Path('/home/alex-ai/fixture-repairs/20261019-01');app=root/'compiler/my-try'
sys.path.insert(0,str(app/'tools'))
from test_runner import CommandRunner,Task,run_tasks
from cpp_fixture import CppFixtureCompiler
out=root/'verification/results';out.mkdir(exist_ok=False)
outcomes=[]
with CommandRunner(out/'orchestrator',root,jobs=2) as outer:
 def suite(name):
  try:
   outer.run(name,['python3',app/'tests'/f'{name}.py','--results',out/name])
   result={'name':name,'passed':True}
  except Exception as e:result={'name':name,'passed':False,'error':str(e)}
  (out/f'{name}.outcome.json').write_text(json.dumps(result,indent=2));outcomes.append(result)
 def direct():
  folder=out/'direct';folder.mkdir()
  try:
   with CommandRunner(folder/'logs',root,jobs=12) as runner:
    run_tasks([Task(n,lambda n=n:runner.run(n,['php',app/'tests'/f'{n}.php'])) for n in ['type_catalog','data_construction']],jobs=12)
   result={'name':'direct','passed':True}
  except Exception as e:result={'name':'direct','passed':False,'error':str(e)}
  (out/'direct.outcome.json').write_text(json.dumps(result,indent=2));outcomes.append(result)
 def full_s2s():
  folder=out/'s2s-all';folder.mkdir();programs=folder/'programs';programs.mkdir()
  try:
   with CommandRunner(folder/'logs',root,jobs=12) as runner:
    runner.run('s2s-export',['php',app/'tests/s2s.php',programs])
    cases=json.loads((programs/'executions.json').read_text())
    cpp=CppFixtureCompiler(runner,root,folder,pch=True,return_type_errors=True,runtime=True)
    def execute(case):
     src=Path(case['path']);exe=src.with_suffix('.program');cpp.compile(src.stem+'-build',src,exe);runner.run(src.stem+'-execute',[exe],expected=case['exit_code'])
    run_tasks([Task(Path(c['path']).stem,lambda c=c:execute(c)) for c in cases],jobs=12)
   result={'name':'s2s-all','passed':True,'cases':len(cases)}
  except Exception as e:result={'name':'s2s-all','passed':False,'error':str(e)}
  (out/'s2s-all.outcome.json').write_text(json.dumps(result,indent=2));outcomes.append(result)
 names=['cpp_artifacts','nullable','json_api','runtime_strings','runtime_generics','runtime_source','runtime_handles','control_flow','functions']
 run_tasks([Task('direct',direct),Task('s2s-all',full_s2s)]+[Task(n,lambda n=n:suite(n)) for n in names],jobs=2)
(out/'summary.json').write_text(json.dumps({'passed':all(x['passed'] for x in outcomes),'outcomes':outcomes},indent=2))
print(json.dumps(outcomes),flush=True)
