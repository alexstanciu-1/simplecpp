import json,sys
from pathlib import Path
root=Path('/home/alex-ai/fixture-repairs/20261019-03');sys.path.insert(0,str(root/'compiler/my-try/tools'))
from test_runner import CommandRunner,Task,run_tasks
from cpp_fixture import CppFixtureCompiler
out=root/'verification/h11';out.mkdir();results=[]
with CommandRunner(out/'logs',root,jobs=4) as runner:
 def check(cxx):
  label='gcc' if cxx=='g++' else 'clang';folder=out/label;folder.mkdir()
  runner.run(label+'-version',[cxx,'--version'])
  cpp=CppFixtureCompiler(runner,root,folder,pch=False,runtime=True,cxx=cxx);cpp.flags.extend(['-I',root])
  for meta in sorted((root/'tests/runtime/invariants_compile_fail/level_01').glob('runtime_invariants_compile_fail_00[12]*.test-info.json')):
   data=json.loads(meta.read_text());name=label+'-'+data['id'];source=meta.with_name(meta.name.replace('.test-info.json','.cpp'))
   runner.run(name,[*cpp.flags,'-fsyntax-only',source],expected=1)
   error=(out/'logs'/f'{name}.stderr').read_text()
   assert all(fragment in error for fragment in data['expect']['compile']['error_contains']),(name,error)
   results.append({'compiler':cxx,'case':data['id'],'passed':True,'error_contains':data['expect']['compile']['error_contains']})
  source=root/'tests/runtime/ownership/level_01/runtime_ownership_005_unique_move_release_reset.cpp';exe=folder/'positive'
  cpp.compile(label+'-positive',source,exe);runner.run(label+'-positive-execute',[exe]);results.append({'compiler':cxx,'case':'unique_move_release_reset','passed':True})
 run_tasks([Task(cxx,lambda cxx=cxx:check(cxx)) for cxx in ['g++','clang++']],jobs=2)
(out/'summary.json').write_text(json.dumps({'passed':True,'results':results},indent=2))
