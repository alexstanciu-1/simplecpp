import json,sys
from pathlib import Path
root=Path('/home/alex-ai/fixture-repairs/20261019-03');app=root/'compiler/my-try';sys.path.insert(0,str(app/'tools'))
from test_runner import CommandRunner,Task,run_tasks
out=root/'verification/results';out.mkdir();outcomes=[]
with CommandRunner(out/'orchestrator',root,jobs=2) as runner:
 def suite(name,script,extra):
  try:
   runner.run(name,['python3',app/'tests'/script,*extra,'--results',out/name]);result={'name':name,'passed':True}
  except Exception as e:result={'name':name,'passed':False,'error':str(e)}
  outcomes.append(result);(out/f'{name}.outcome.json').write_text(json.dumps(result,indent=2))
 run_tasks([Task('property_mutations',lambda:suite('property_mutations','records.py',['--suite','property_mutations'])),Task('interpolation',lambda:suite('interpolation','records.py',['--suite','interpolation'])),Task('dynamic_families',lambda:suite('dynamic_families','dynamic_families.py',[]))],jobs=2)
(out/'summary.json').write_text(json.dumps(outcomes,indent=2))
