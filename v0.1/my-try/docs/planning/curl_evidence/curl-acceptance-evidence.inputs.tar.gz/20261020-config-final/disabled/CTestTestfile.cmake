# CMake generated Testfile for 
# Source directory: /home/alex-ai/curl/20261020-work/runtime
# Build directory: /home/alex-ai/curl/20261020-config-final/disabled
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("tests_runtime_native")
