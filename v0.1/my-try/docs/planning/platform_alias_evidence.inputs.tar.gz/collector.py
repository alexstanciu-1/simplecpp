import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/alex-ai/platform-alias/20261020-01');v=root/'verification'
m=json.loads((root/'platform_source_candidate.json').read_text());initial=json.loads((root/'platform_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
changed=[p for p,h in m['files'].items() if h!=initial['files'].get(p)]
accepted=['runtime-baseline','source-baseline','runtime-01','candidate-04','regressions-01']
suites={};summaries={}
for name in accepted:
 records=[]
 for p in (v/name).rglob('commands.json'):records+=json.loads(p.read_text())
 assert records and all(c['code']==c['expected'] for c in records),name
 suites[name]={'commands':len(records),'all_expected_exits':True,'command_seconds':round(sum(c['seconds'] for c in records),2),'native_executions':sum(c['command'][0] == 'env' or c['command'][0].startswith(str(v)+'/') for c in records)}
 summary=json.loads((v/name/'summary.json').read_text());assert summary['passed'];summaries[name]=summary
assert summaries['runtime-baseline']['observations'].endswith('nul_rejected=0\n')
assert summaries['runtime-01']['observations'].endswith('nul_rejected=1\n')
assert len(summaries['candidate-04']['checks']['rejections'])==13
assert len(json.loads((v/'candidate-04/metadata.json').read_text()))==9
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['platform_source_initial.json','platform_source_candidate.json']:records[n]=(root/n).read_text()
records['collector.py']=Path(__file__).read_text()
toolchain={n:subprocess.check_output(cmd,text=True) for n,cmd in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()}
records['toolchain.json']=json.dumps(toolchain)
archive=gzip.compress(json.dumps(records).encode());Path('/tmp/platform-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'d1d1750e','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'source_integrity':{'checked':len(m['files']),'mismatches':bad,'changed':changed},'toolchain':toolchain,'evidence_records':len(records),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':33,'partial':0,'total':64,'percent':51.5625},'remaining_batch_blockers':[],'deferred':['Other production qualified aliases','General namespace changes','Native Windows execution','Broader process and shell semantics']}
Path('/tmp/platform-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'commands':sum(x['commands'] for x in suites.values()),'native_executions':sum(x['native_executions'] for x in suites.values()),'source_files':len(m['files']),'records':len(records)}))
