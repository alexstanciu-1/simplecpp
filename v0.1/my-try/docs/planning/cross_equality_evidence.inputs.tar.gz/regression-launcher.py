import concurrent.futures,subprocess,os,json
from pathlib import Path
os.chdir('/home/alex-ai/cross-equality/20261020-01')
os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=['sentinel_mixed_equality','mixed_equality','sentinel_plain_runtime','string_other_identity','mixed_identity','bool_numeric_identity','cross_identity','mixed_ordering','numeric_xor','float_operators','nonbool_sentinel_equality','bool_sentinel_equality','false_bool_equality','result_equality','nullable_int_equality','nullable_float_equality','nullable_bool_string_equality','guarded_cross','guarded_operators','guarded_float','guarded_bool','guarded_mixed','guarded_string','eager_binary','scalar_admission','string_identity']
def run(name):
 script='mixed_identity' if name in ['bool_numeric_identity','string_other_identity'] else name
 if name=='sentinel_mixed_equality':script='mixed_equality'
 cmd=['python3','compiler/my-try/tests/'+script+'.py','--results','verification/regression-'+name]
 if name=='sentinel_mixed_equality':cmd+=['--group','sentinel']
 if name=='bool_numeric_identity':cmd+=['--group','bool-numeric']
 if name=='string_other_identity':cmd+=['--group','string-other']
 if name=='scalar_admission':cmd+=['--jobs','12']
 with open('verification/regression-'+name+'.stdout','w') as out:
  code=subprocess.call(cmd,stdout=out,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 return name,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=dict(pool.map(run,suites))
Path('verification/regression-exits.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(results.values()))
