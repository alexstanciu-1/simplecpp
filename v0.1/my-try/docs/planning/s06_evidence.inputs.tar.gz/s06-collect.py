import json,gzip,hashlib,subprocess
from pathlib import Path
root=Path('/home/alex-ai/unbraced-conditionals/20261020-01');v=root/'verification'
m=json.loads((root/'s06_source_final.json').read_text());initial=json.loads((root/'s06_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
runtime=[p for p in m['files'] if p.startswith('runtime/')];assert all(m['files'][p]==initial['files'][p] for p in runtime)
accepted=['baseline','candidate-02','control-regression-02'];summaries={n:json.loads((v/n/'summary.json').read_text()) for n in accepted};assert all(s['passed'] for s in summaries.values())
suites={}
for n in accepted:
 # Root journals and logs/commands may describe the same commands; use the runner log journal only.
 commands=json.loads((v/n/'logs/commands.json').read_text());assert commands and all(c['code']==c['expected'] for c in commands),n
 suites[n]={'commands':len(commands),'all_expected_exits':True}
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['s06_source_initial.json','s06_source_candidate.json','s06_source_final.json']:records[n]=(root/n).read_text()
records['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
records['s06-collect.py']=Path(__file__).read_text();archive=gzip.compress(json.dumps(records).encode());Path('/tmp/s06-evidence.json.gz').write_bytes(archive)
checks=summaries['candidate-02']['checks'];original=checks['original'];assert 'strpos' in original['diagnostic'] and "Expected '{'" in summaries['baseline']['checks']['original']['diagnostic']
assert original['sha256']==summaries['baseline']['checks']['original']['sha256']
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'bfa9f25d','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'native_programs':checks['positive_programs']+summaries['control-regression-02']['generated_programs'],'source_integrity':{'checked':len(m['files']),'mismatches':bad,'runtime_files_unchanged':len(runtime)},'toolchain':json.loads(records['toolchain.json']),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'original_fixture_end_to_end_passed':False,'remaining_original_fixture_blocker':'S09: unresolved strpos','remaining_s06_blockers':[],'newly_exposed_implementation_blockers':[],'attempts':{'baseline':'Original and builtin-free source reproduce required-brace parse error.','candidate-01':'All preparation checks passed; two native exception observers lacked the existing test-only entry-boundary marker. The production boundary caught the exceptions, making the observers return92. Corrected only the observers.','candidate-02':'46 native programs, rejection/scope/span checks and recovery passed.','control-regression':'One remaining brace-free if rejection was obsolete. Moved the two old unbraced forms to positive controls and kept malformed/empty-body negatives.','control-regression-02':'All12 PHP suites and137 native programs pass.'},'runtime_changes':False,'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':25,'total':64,'percent':39.0625}}
Path('/tmp/s06-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'source_files':len(m['files']),'runtime_files_unchanged':len(runtime),'native_programs':r['native_programs'],'commands':sum(s['commands'] for s in suites.values()),'evidence_records':len(records),'rejections':len(checks['rejections']),'recovery_cycles':checks['recovery_cycles']},indent=2))
