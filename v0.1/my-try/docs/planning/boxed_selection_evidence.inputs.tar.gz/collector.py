import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/alex-ai/boxed-selection/20261020-01');v=root/'verification'
m=json.loads((root/'boxed_selection_source_candidate.json').read_text());initial=json.loads((root/'boxed_selection_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
changed=[p for p,h in m['files'].items() if h!=initial['files'].get(p)]
runtime=[p for p in changed if p.startswith('runtime/')];assert set(runtime)=={'runtime/include/operators/arithmetic/boxed_numeric.hpp','runtime/include/operators/coalesce/coalesce.hpp'},runtime
accepted=['runtime-03','source-03','regressions-03','shift-boundary'];suites={};summaries={}
for name in accepted:
 commands=json.loads((v/name/'logs/commands.json').read_text());assert commands and all(c['code']==c['expected'] for c in commands),name
 suites[name]={'commands':len(commands),'all_expected_exits':True,'command_seconds':round(sum(c['seconds'] for c in commands),2),'native_executions':sum(c['command'][0]=='env' or c['command'][0].startswith(str(v)+'/') for c in commands)}
 summaries[name]=json.loads((v/name/'summary.json').read_text())
assert all(x['stage']=='passed' for x in summaries['runtime-03']['results'].values())
assert summaries['source-03']['passed'] and summaries['regressions-03']['passed']
assert summaries['source-03']['checks']['recovery_cycles']==2
baseline=json.loads((v/'runtime-01/summary.json').read_text());assert sum(x['stage']=='passed' for x in baseline['results'].values())==6
assert sum(x['stage']=='compile-failed' for x in baseline['results'].values())==18
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['boxed_selection_source_initial.json','boxed_selection_source_candidate.json']:records[n]=(root/n).read_text()
records['collector.py']=Path(__file__).read_text()
toolchain={n:subprocess.check_output(cmd,text=True) for n,cmd in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()};records['toolchain.json']=json.dumps(toolchain)
archive=gzip.compress(json.dumps(records).encode());Path('/tmp/boxed-selection-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'842276aa','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'baseline':baseline,'source_integrity':{'checked':len(m['files']),'mismatches':bad,'runtime_changed':runtime,'changed':changed},'toolchain':toolchain,'evidence_records':len(records),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'runtime_repair_authorized_after_probe':True,'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':35,'partial':0,'total':64,'percent':54.6875},'remaining_batch_blockers':[],'separate_findings':[{'id':'BS-R01','status':'open','finding':summaries['shift-boundary']['finding'],'owner':'shared primitive integer shift-count contract and runtime validation','scope':'Outside the two authorized runtime owners; scalar control reproduces the same gap. No invalid-count behavior is certified.'}],'deferred':['Cross-family boxed and wrapper pairs','Boxed/scalar bitwise peers','Compounds and indexed updates','Payload widening, fixed-width, record and ownership joins']}
Path('/tmp/boxed-selection-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'commands':sum(x['commands'] for x in suites.values()),'native_executions':sum(x['native_executions'] for x in suites.values()),'source_files':len(m['files']),'records':len(records),'source_rejections':len(summaries['source-03']['checks']['rejections']),'regression_programs':summaries['regressions-03']['native_programs']}))
