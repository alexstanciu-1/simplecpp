import json,sys
from pathlib import Path
root=Path('/home/alex-ai/numeric-l05/20261019-01');app=root/'compiler/my-try';sys.path.insert(0,str(app/'tools'))
from test_runner import CommandRunner,Task,run_tasks
from cpp_fixture import CppFixtureCompiler
out=root/'verification/bool-logical';out.mkdir()
items=[x for x in json.loads((root/'verification/mixed/programs/executions.json').read_text()) if Path(x['path']).stem.startswith('logical_')]
assert items
with CommandRunner(out/'logs',root,jobs=12) as runner:
 cpp=CppFixtureCompiler(runner,root,out,pch=True,runtime=True)
 def check(item):
  path=Path(item['path']);exe=out/path.stem;cpp.compile(path.stem+'-build',path,exe);runner.run(path.stem+'-execute',[exe],expected=item['exit_code'])
 run_tasks([Task(Path(x['path']).stem,lambda x=x:check(x)) for x in items],jobs=12)
(out/'summary.json').write_text(json.dumps({'passed':True,'fixtures':[Path(x['path']).stem for x in items]},indent=2))
