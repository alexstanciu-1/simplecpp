#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::nullable<scpp::string_t>& a,const scpp::result_or_bool<scpp::string_t>& b) { return scpp::php::not_identical(a,b); }
