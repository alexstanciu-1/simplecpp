#include "lang/php/operators/identity/strict_identity.hpp"
scpp::bool_t probe(const scpp::result_or_bool<scpp::float_t>& a,const scpp::nullable<scpp::float_t>& b) { return scpp::php::not_identical(a,b); }
