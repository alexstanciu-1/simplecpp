import json,gzip,hashlib,subprocess
from pathlib import Path
root=Path('/home/alex-ai/substr-replace/20261020-01');v=root/'verification'
m=json.loads((root/'s09r_source_candidate.json').read_text());initial=json.loads((root/'s09r_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
changed=[p for p in m['files'] if p.startswith('runtime/') and m['files'][p]!=initial['files'].get(p)]
assert set(changed)=={'runtime/metadata/modules/strings.json','runtime/include/modules/strings/strings.hpp','runtime/specs/catalog.md'}
assert all(m['files'][p]==h for p,h in initial['files'].items() if p.startswith('compiler/my-try/src/'))
accepted=['runtime-baseline','runtime-01','source-baseline','source-01','regression-strings','regression-search'];summaries={n:json.loads((v/n/'summary.json').read_text()) for n in accepted if (v/n/'summary.json').exists()};assert all(s['passed'] for s in summaries.values())
assert json.loads((v/'regression-exits.json').read_text())=={'strings':0,'search':0}
suites={}
for n in accepted:
 commands=json.loads((v/n/'logs/commands.json').read_text());assert commands and all(c['code']==c['expected'] for c in commands),n
 suites[n]={'commands':len(commands),'all_expected_exits':True,'native_executions':sum(c['name'].endswith(('-execute','-run')) for c in commands)}
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['s09r_source_initial.json','s09r_source_candidate.json']:records[n]=(root/n).read_text()
records['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
records['s09r-collect.py']=Path(__file__).read_text();records['s09r-regress.py']=(root/'s09r-regress.py').read_text();archive=gzip.compress(json.dumps(records).encode());Path('/tmp/s09r-evidence.json.gz').write_bytes(archive)
checks=summaries['source-01']['checks'];assert len(checks['rejections'])==11 and checks['recovery_cycles']==2 and checks['original']['compiled']
assert checks['original']['sha256']==summaries['source-baseline']['checks']['sha256']
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'c37e0597','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'source_integrity':{'checked':len(m['files']),'mismatches':bad,'runtime_changed':changed,'compiler_implementation_unchanged':True},'toolchain':json.loads(records['toolchain.json']),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'original_surface_fixture_end_to_end_passed':True,'remaining_replacement_blockers':[],'remaining_s09_blockers':['S09-B1: original false-branch fixture passes result_or_false<int> to substr integer parameter; exact runtime call signature rejects'], 'newly_exposed_implementation_blockers':[],'attempts':{'runtime-baseline':'Reproduces suffix replacement for omitted length and insertion for unusable negative windows.','source-baseline':'Original strict surface stops at unresolved substr_replace.','runtime-01':'3312 replacement checks and existing full native PHP-string suite pass with reconciled expectations under ASan/UBSan.','source-01':'Original unchanged strict surface exact output and 3312 source checks, effects, rejection/recovery pass under ASan/UBSan.','regressions':'String/catalog/generic suite and source search suite pass; search suite independently reruns original surface/edge fixtures and retains S09-B1.'},'runtime_implementation_changes':True,'compiler_implementation_changes':False,'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':26,'partial':1,'total':64,'percent':40.625}}
Path('/tmp/s09r-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'source_files':len(m['files']),'suites':suites,'commands':sum(s['commands'] for s in suites.values()),'native_executions':sum(s['native_executions'] for s in suites.values()),'evidence_records':len(records)},indent=2))
