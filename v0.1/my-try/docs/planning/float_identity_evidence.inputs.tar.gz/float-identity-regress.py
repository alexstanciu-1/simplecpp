import concurrent.futures,subprocess,os,json
from pathlib import Path
os.chdir('/home/alex-ai/float-identity/20261020-01')
os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=[('original-carriers','carrier_equality_reconciliation',[]),('float-operators','float_operators',[]),('nullable-float','nullable_float_equality',[]),('result-equality','result_equality',[]),('nonbool-sentinel','nonbool_sentinel_equality',[]),('mixed-identity','mixed_identity',[]),('scalar-admission','scalar_admission',['--jobs','12']),('string-identity','string_identity',[]),('mixed-equality','mixed_equality',[]),('float-spaceship','vl07_completion',['--group','ordering'])]
def run(row):
 name,script,extra=row
 with open('verification/regression-'+name+'.stdout','w') as out:code=subprocess.call(['python3','compiler/my-try/tests/'+script+'.py','--results','verification/regression-'+name]+extra,stdout=out,stderr=subprocess.STDOUT)
 print(name,code,flush=True);return name,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,suites))
Path('verification/regression-exits.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(results.values()))
