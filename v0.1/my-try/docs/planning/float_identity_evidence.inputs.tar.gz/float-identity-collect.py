import json,gzip,hashlib,re,subprocess
from pathlib import Path
root=Path('/home/alex-ai/float-identity/20261020-01');v=root/'verification'
m=json.loads((root/'float_identity_source_final.json').read_text());bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
initial=json.loads((root/'float_identity_source_initial.json').read_text());runtime=[f for f in m['files'] if f.startswith('runtime/')];assert all(initial['files'].get(f)==m['files'][f] for f in runtime)
reg=json.loads((v/'regression-exits.json').read_text());rep=json.loads((v/'repaired-exits.json').read_text());resolved={**reg,**rep};assert len(resolved)==10 and not any(resolved.values()),resolved
accepted=['runtime-baseline','float-identity-corrected','s04']+['repaired-'+k if k in rep else 'regression-'+k for k in reg]
suites={}
for name in accepted:
 commands=[c for p in (v/name).rglob('commands.json') for c in json.loads(p.read_text())];assert commands and all(c['code']==c['expected'] for c in commands),name
 suites[name]={'commands':len(commands),'all_expected_exits':True}
for name in ['runtime-baseline','float-identity-corrected','s04','regression-original-carriers']:
 assert json.loads((v/name/'summary.json').read_text())['passed']
sigs=json.loads((v/'float-identity-corrected/source/signatures.json').read_text());assert sigs==[['float','===','float','bool'],['float','!==','float','bool']]
counts={}
for name in accepted:
 for p in (v/name).rglob('*.stdout'):
  found={k:int(n) for k,n in re.findall(r'(runtime_pairs|binary_cases|local_cases|property_cases|branch_cases|cases)=(\d+)',p.read_text())}
  if found:counts[str(p.relative_to(root))]=found
e={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
e['source-integrity.json']=json.dumps({'checked':len(m['files']),'mismatches':bad,'runtime_files_unchanged':len(runtime)})
e['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
for p in root.glob('float-identity-*.py'):e[p.name]=p.read_text()
archive=gzip.compress(json.dumps(e).encode());Path('/tmp/float-identity-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'head':'3c17c75e','signatures':sigs,'runtime_probe':json.loads((v/'runtime-baseline/summary.json').read_text()),'carrier_reconciliation':json.loads((v/'regression-original-carriers/summary.json').read_text()),'s04':json.loads((v/'s04/summary.json').read_text()),'counts':counts,'suites':suites,'regression_original_exits':reg,'regression_repair_exits':rep,'regression_resolved_exits':resolved,'source_integrity':json.loads(e['source-integrity.json']),'toolchain':json.loads(e['toolchain.json']),'runtime_changes':False,'full_matrix_run':False,'native_compiler_rebuilt':False,'remaining_blockers_in_scope':[],'newly_exposed_implementation_blockers':[],'attempts':{'runtime_first':'Existing runtime passed all256 pairs before admission change.','float_source_first':'Fixture exclusion helper incorrectly rejected already-supported ordinary float equality; corrected matching-plain pair classification.','wrapper_regressions':'Three suites shared an obsolete scalar float ===/!== rejection; removed only that exclusion, then reran all three.','s04':'Unchanged original source and deterministic controls passed first attempt; no process/provider/output implementation changed.'},'evidence_sha256':hashlib.sha256(archive).hexdigest(),'original_issue_closure':{'closed':22,'total':64,'percent':34.375},'vl07_carrier_signature_count_unchanged':3376}
Path('/tmp/float-identity-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'source_files':len(m['files']),'unchanged_runtime_files':len(runtime),'accepted_suites':len(suites),'accepted_commands':sum(x['commands'] for x in suites.values()),'archive_records':len(e),'observations':sum(sum(c.values()) for c in counts.values())},indent=2))
