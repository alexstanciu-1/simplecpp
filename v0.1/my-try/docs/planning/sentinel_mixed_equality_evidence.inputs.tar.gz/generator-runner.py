import json,sys,re,hashlib,difflib
from pathlib import Path
root=Path('/home/alex-ai/sentinel-mixed-equality/20261020-01');sys.path.insert(0,str(root/'compiler/my-try/tools'))
from test_runner import CommandRunner
out=root/'verification/generator';out.mkdir(exist_ok=False)
header=root/'runtime/include/scpp/generated/operators.hpp'
old=header.read_text()
normalize=lambda s:re.sub(r'^// Generated from runtime/specs/config.json on .*$', '// Generated from runtime/specs/config.json on TIMESTAMP.',s,flags=re.M)
with CommandRunner(out/'logs',root,jobs=12) as runner:
 runner.run('generate-first',['php',root/'runtime/tools/generate_operators.php']);first=header.read_text()
 runner.run('generate-second',['php',root/'runtime/tools/generate_operators.php']);second=header.read_text()
assert normalize(first)==normalize(second)
(out/'diff.stdout').write_text(''.join(difflib.unified_diff(old.splitlines(True),second.splitlines(True),fromfile='before',tofile='generated')))
(out/'summary.json').write_text(json.dumps({'passed':True,'normalized_reproducible':True,'normalization':'Only the existing generated timestamp line','old_sha256':hashlib.sha256(old.encode()).hexdigest(),'generated_sha256':hashlib.sha256(second.encode()).hexdigest()},indent=2)+'\n')
print('Generator repeated output matches apart from the existing timestamp line.')
