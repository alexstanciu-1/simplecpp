import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/alex-ai/callback-composition/20261020-01');v=root/'verification'
m=json.loads((root/'callback-source.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in m['files'].items())
accepted=['runtime-01','source-01','composition-02','regex-regressions-01','replacement-regressions-01']
baselines=['runtime-baseline-01','source-baseline-01','composition-baseline-01']
suites={}
for name in accepted+baselines:
 commands=json.loads((v/name/'logs/commands.json').read_text());assert commands and all(x['code']==x['expected'] for x in commands),name
 summaries=json.loads((v/name/'summary.json').read_text()) if (v/name/'summary.json').exists() else {'passed':True}
 assert summaries['passed'],name
 suites[name]={'commands':len(commands),'native_executions':sum(c['command'][0]=='env' or c['command'][0].startswith(str(v)+'/') for c in commands),'seconds':round(sum(c['seconds'] for c in commands),3),'summary':summaries}
for name in ['source-01','replacement-regressions-01']:
 warm=json.loads((v/name/'warm.json').read_text());assert warm['compiled']==0 and warm['linked']==0
assert 'checks=34 failures=0' in (v/'runtime-01/logs/probe-execute.stdout').read_text()
assert 'checks=34 failures=0' in (v/'source-01/logs/behavior-execute.stdout').read_text()
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and (p.suffix in ['.json','.stdout','.stderr','.cpp','.hpp','.phs'] or p.name=='CMakeLists.txt')}
for n in ['callback-source.json','callback-source-initial.json']:records[n]=(root/n).read_text()
records['collector.py']=Path(__file__).read_text()
toolchain={n:subprocess.check_output(cmd,text=True) for n,cmd in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'cmake':['cmake','--version'],'python':['python3','--version']}.items()}
records['toolchain.json']=json.dumps(toolchain)
archive=gzip.compress(json.dumps(records).encode());Path('/tmp/callback-composition-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'base':m['head'],'accepted':accepted,'baselines':baselines,'suites':suites,'accepted_commands':sum(suites[n]['commands'] for n in accepted),'accepted_native_executions':sum(suites[n]['native_executions'] for n in accepted),'source_files':len(m['files']),'source_integrity_verified':True,'evidence_records':len(records),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'toolchain':toolchain,'closed':['V-R05','V-R11'],'progress':{'closed':39,'total':64,'partial':0,'percent':60.9375,'gain_percentage_points':3.125},'full_matrix_run':False,'native_compiler_rebuilt':False,'remaining_batch_blockers':[],'limits':['Linux dev002 proof; no Windows/macOS validation','MySQL provider/legacy adapter compiled; no database integration test or V-E03 closure','No new count-output APIs, legacy callback adaptation or broader closure borrowing','External mixed static-core/shared-provider compositions are not certified']}
Path('/tmp/callback-composition-results.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['accepted_commands','accepted_native_executions','source_files','evidence_records']}))
