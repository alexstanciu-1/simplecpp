#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "scpp/int_t.hpp"
#include "scpp/hash_t.hpp"
#include "lang/php/support/php_string.hpp"
#include "operators/count/count.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::vector_t<scpp::string_t>> local_rows = scpp::vector_t<scpp::vector_t<scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::vector_t<scpp::string_t>>> {
	scpp::string_t argument_0 = scpp::string_t("/(a)(b)/");
	scpp::string_t argument_1 = scpp::string_t("ab ab");
	return scpp::regex::match_all(argument_0, argument_1);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::vector_t<scpp::string_t>> local_offset = scpp::vector_t<scpp::vector_t<scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::vector_t<scpp::string_t>>> {
	scpp::string_t argument_2 = scpp::string_t("/(a)(b)/");
	scpp::string_t argument_3 = scpp::string_t("ab ab");
	scpp::int_t<> argument_4 = static_cast<scpp::int_t<>>(3LL);
	return scpp::regex::match_all(argument_2, argument_3, argument_4);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::vector_t<scpp::string_t>> local_columns = scpp::vector_t<scpp::vector_t<scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::vector_t<scpp::string_t>>> {
	scpp::string_t argument_5 = scpp::string_t("/(a)(b)/");
	scpp::string_t argument_6 = scpp::string_t("ab ab");
	return scpp::regex::match_all_pattern_order(argument_5, argument_6);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::vector_t<scpp::string_t>> local_offsetU_columns = scpp::vector_t<scpp::vector_t<scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::vector_t<scpp::string_t>>> {
	scpp::string_t argument_7 = scpp::string_t("/(a)(b)/");
	scpp::string_t argument_8 = scpp::string_t("ab ab");
	scpp::int_t<> argument_9 = static_cast<scpp::int_t<>>(3LL);
	return scpp::regex::match_all_pattern_order(argument_7, argument_8, argument_9);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>> local_named = scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>> {
	scpp::string_t argument_10 = scpp::string_t("/(?<word>ab)/");
	scpp::string_t argument_11 = scpp::string_t("ab ab");
	return scpp::regex::match_all_named(argument_10, argument_11);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>> local_offsetU_named = scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>> {
	scpp::string_t argument_12 = scpp::string_t("/(?<word>ab)/");
	scpp::string_t argument_13 = scpp::string_t("ab ab");
	scpp::int_t<> argument_14 = static_cast<scpp::int_t<>>(3LL);
	return scpp::regex::match_all_named(argument_12, argument_13, argument_14);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::vector_t<scpp::string_t>>&>(local_rows)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::vector_t<scpp::string_t>>&>(local_offset)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_15 = ([&]() -> scpp::vector_t<scpp::string_t> { const auto& index_receiver_16 = local_rows; scpp::int_t<> index_key_16 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_16, index_key_16); }()); scpp::int_t<> index_key_15 = static_cast<scpp::int_t<>>(2LL); return scpp::checked_index_read(index_receiver_15, index_key_15); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::vector_t<scpp::string_t>>&>(local_columns)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(([&]() -> scpp::vector_t<scpp::string_t> { const auto& index_receiver_17 = local_columns; scpp::int_t<> index_key_17 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_17, index_key_17); }()))));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(([&]() -> scpp::vector_t<scpp::string_t> { const auto& index_receiver_18 = local_offsetU_columns; scpp::int_t<> index_key_18 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_18, index_key_18); }()))));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>&>(local_named)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_19 = ([&]() -> scpp::hash_t<scpp::string_t, scpp::string_t> { const auto& index_receiver_20 = local_named; scpp::int_t<> index_key_20 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_20, index_key_20); }()); scpp::string_t index_key_19 = scpp::string_t("word"); return scpp::checked_index_read(index_receiver_19, index_key_19); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::hash_t<scpp::string_t, scpp::string_t>>&>(local_offsetU_named)));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
