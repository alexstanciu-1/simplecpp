#include "scpp/data_initializer.hpp"
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "lang/php/support/php_take.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/index_read.hpp"
#include "scpp/generated/operators.hpp"
#include "operators/count/count.hpp"
#include "lang/php/operators/isset/isset.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::string_t> local_value = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_0(1);
{
scpp::string_t initializer_value_1 = scpp::string_t("preserved");
initializer_0.append(initializer_value_1);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_0.view());
}());
if ((([&]() -> scpp::bool_t { auto take_source_4 = ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_2 = scpp::string_t("/unterminated");
	scpp::string_t argument_3 = scpp::string_t("abc");
	return scpp::regex::match(argument_2, argument_3);
}()); return scpp::php::take(local_value, take_source_4); }())).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_5 = local_value; scpp::int_t<> index_key_5 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_5, index_key_5); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
if (((!([&]() -> scpp::bool_t { auto take_source_8 = ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_6 = scpp::string_t("/z/");
	scpp::string_t argument_7 = scpp::string_t("abc");
	return scpp::regex::match(argument_6, argument_7);
}()); return scpp::php::take(local_value, take_source_8); }()))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(2LL)).native_value());
}
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_value)));
	::scpp::php::echo_one(scpp::string_t("|"));
	auto local_bad = ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::vector_t<scpp::string_t>>> {
	scpp::string_t argument_9 = scpp::string_t("/unterminated");
	scpp::string_t argument_10 = scpp::string_t("abc");
	return scpp::regex::match_all(argument_9, argument_10);
}());
	::scpp::php::echo_one(scpp::php::isset(local_bad));
	::scpp::php::echo_one(scpp::string_t("|"));
	scpp::vector_t<scpp::string_t> local_fallback = ([&]() -> scpp::vector_t<scpp::string_t> { scpp::result_or_false<scpp::vector_t<scpp::string_t>> coalesce_15 = ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_11 = scpp::string_t("/unterminated");
	scpp::string_t argument_12 = scpp::string_t("abc");
	return scpp::regex::match(argument_11, argument_12);
}()); if (coalesce_15.has_value().native_value()) { return scpp::vector_t<scpp::string_t>((coalesce_15).require_value("Result required-value extraction")); } return ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_13(1);
{
scpp::string_t initializer_value_14 = scpp::string_t("fallback");
initializer_13.append(initializer_value_14);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_13.view());
}()); }());
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_16 = local_fallback; scpp::int_t<> index_key_16 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_16, index_key_16); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	scpp::vector_t<scpp::string_t> local_empty = ([&]() -> scpp::vector_t<scpp::string_t> { scpp::result_or_false<scpp::vector_t<scpp::string_t>> coalesce_21 = ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_17 = scpp::string_t("/z/");
	scpp::string_t argument_18 = scpp::string_t("abc");
	return scpp::regex::match(argument_17, argument_18);
}()); if (coalesce_21.has_value().native_value()) { return scpp::vector_t<scpp::string_t>((coalesce_21).require_value("Result required-value extraction")); } return ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_19(1);
{
scpp::string_t initializer_value_20 = scpp::string_t("wrong");
initializer_19.append(initializer_value_20);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_19.view());
}()); }());
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_empty)));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
