#include "scpp/int_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(1LL);
	scpp::string_t local_text = scpp::string_t((([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = scpp::string_t("/a/");
	scpp::string_t argument_1 = scpp::string_t("b");
	scpp::string_t argument_2 = scpp::string_t("aa");
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::replace_limited(argument_0, argument_1, argument_2, argument_3);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::string_t> local_rows = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_4 = scpp::string_t("/a/");
	scpp::string_t argument_5 = scpp::string_t("b");
	scpp::vector_t<scpp::string_t> argument_8 = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_6(1);
{
scpp::string_t initializer_value_7 = scpp::string_t("a");
initializer_6.append(initializer_value_7);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_6.view());
}());
	return scpp::regex::filter(argument_4, argument_5, argument_8);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(local_text);
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_9 = local_rows; scpp::int_t<> index_key_9 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_9, index_key_9); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(local_n);
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
