#include "scpp/data_initializer.hpp"
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "lang/php/support/php_string.hpp"
#include "operators/count/count.hpp"
#include "scpp/index_read.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::string_t> local_input = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_0(3);
{
scpp::string_t initializer_value_1 = scpp::string_t("ab");
initializer_0.append(initializer_value_1);
}
{
scpp::string_t initializer_value_2 = scpp::string_t("x");
initializer_0.append(initializer_value_2);
}
{
scpp::string_t initializer_value_3 = scpp::string_t("abb");
initializer_0.append(initializer_value_3);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_0.view());
}());
	scpp::vector_t<scpp::string_t> local_matches = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_4 = scpp::string_t("/ab/");
	scpp::vector_t<scpp::string_t> argument_5 = local_input;
	return scpp::regex::grep(argument_4, argument_5);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_matches)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_6 = local_matches; scpp::int_t<> index_key_6 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_6, index_key_6); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_input)));
	::scpp::php::echo_one(scpp::string_t("|"));
	scpp::string_t local_text = scpp::string_t((([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_7 = scpp::string_t("/(a)(b)/");
	scpp::string_t argument_8 = scpp::string_t("$2$1");
	scpp::string_t argument_9 = scpp::string_t("ab ab");
	return scpp::regex::replace(argument_7, argument_8, argument_9);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(local_text);
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
