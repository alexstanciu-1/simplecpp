// SCPP-ARTIFACT {"id":"callable:change","kind":"header","path":"callables\/n6368616e6765.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_change(scpp::string_t& local_pattern, scpp::int_t<>& local_calls);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n6368616e6765.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::string_t function_change(scpp::string_t& local_pattern, scpp::int_t<>& local_calls)
{
	local_pattern = scpp::string_t("/b/");
	static_cast<scpp::int_t<>>(local_calls++);
	return scpp::string_t("a");
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
#include "callables/n6368616e6765.hpp"
#include "modules/regex/regex.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_pattern = scpp::string_t("/a/");
	auto local_calls = static_cast<scpp::int_t<>>(0LL);
	scpp::vector_t<scpp::string_t> local_matched = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = local_pattern;
	scpp::string_t argument_3 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_1 = local_pattern;
	scpp::int_t<>& argument_2 = local_calls;
	return function_change(argument_1, argument_2);
}());
	return scpp::regex::match(argument_0, argument_3);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_4 = local_matched; scpp::int_t<> index_key_4 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_4, index_key_4); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(local_pattern);
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(local_calls);
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
