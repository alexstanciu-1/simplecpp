#include "scpp/data_initializer.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/hash_t.hpp"
#include "scpp/unique_p.hpp"
#include "operators/count/count.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::hash_t<scpp::string_t, scpp::int_t<>> local_a = ([&]() -> scpp::hash_t<scpp::string_t, scpp::int_t<>> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::string_t, scpp::int_t<>>> initializer_0(2);
{
scpp::int_t<> initializer_key_1 = static_cast<scpp::int_t<>>(10LL);
scpp::string_t initializer_value_2 = scpp::string_t("a");
initializer_0.append(scpp::initializer_entry<scpp::string_t, scpp::int_t<>>{initializer_key_1, initializer_value_2});
}
{
scpp::int_t<> initializer_key_3 = static_cast<scpp::int_t<>>(20LL);
scpp::string_t initializer_value_4 = scpp::string_t("b");
initializer_0.append(scpp::initializer_entry<scpp::string_t, scpp::int_t<>>{initializer_key_3, initializer_value_4});
}
return scpp::data_initializer<scpp::hash_t<scpp::string_t, scpp::int_t<>>>::from_key_value(initializer_0.view());
}());
	scpp::hash_t<scpp::int_t<>, scpp::string_t> local_b = ([&]() -> scpp::hash_t<scpp::int_t<>, scpp::string_t> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::int_t<>, scpp::string_t>> initializer_5(1);
{
scpp::string_t initializer_key_6 = scpp::string_t("x");
scpp::int_t<> initializer_value_7 = static_cast<scpp::int_t<>>(3LL);
initializer_5.append(scpp::initializer_entry<scpp::int_t<>, scpp::string_t>{initializer_key_6, initializer_value_7});
}
return scpp::data_initializer<scpp::hash_t<scpp::int_t<>, scpp::string_t>>::from_key_value(initializer_5.view());
}());
	scpp::hash_t<scpp::unique_p<scpp::int_t<>>, scpp::string_t> local_u;
	auto local_n = scpp::count(static_cast<const scpp::hash_t<scpp::string_t, scpp::int_t<>>&>(local_a));
	auto local_m = scpp::count(static_cast<const scpp::hash_t<scpp::int_t<>, scpp::string_t>&>(local_b));
	auto local_z = scpp::count(static_cast<const scpp::hash_t<scpp::unique_p<scpp::int_t<>>, scpp::string_t>&>(local_u));
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_8 = local_n; auto operand_9 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_8, operand_9); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_10 = local_m; auto operand_11 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_10, operand_11); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_12 = local_z; auto operand_13 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_12, operand_13); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
