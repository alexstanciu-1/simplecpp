#include "scpp/int_t.hpp"
#include "runtime_generic_support.hpp"
#include "scpp/string_t.hpp"
#include "modules/strings/strings.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/index_read.hpp"
#include "operators/count/count.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::int_t<> local_n = ([&]() -> scpp::int_t<> {
	scpp::int_t<> argument_0 = static_cast<scpp::int_t<>>(3LL);
	return runtime_generic_test::identity(argument_0);
}());
	scpp::string_t local_s = ([&]() -> scpp::string_t {
	scpp::string_t argument_1 = scpp::string_t("ok");
	return runtime_generic_test::identity(argument_1);
}());
	auto local_length = ([&]() -> scpp::int_t<> {
	scpp::string_t argument_2 = local_s;
	return scpp::str::byte_length(argument_2);
}());
	scpp::vector_t<scpp::int_t<>> local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> {
	scpp::int_t<> argument_3 = static_cast<scpp::int_t<>>(7LL);
	return runtime_generic_test::wrap(argument_3);
}());
	auto local_first = ([&]() -> scpp::int_t<> { const auto& index_receiver_4 = local_v; scpp::int_t<> index_key_4 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_4, index_key_4); }());
	auto local_size = scpp::count(static_cast<const scpp::vector_t<scpp::int_t<>>&>(([&]() -> scpp::vector_t<scpp::int_t<>> {
	scpp::int_t<> argument_5 = static_cast<scpp::int_t<>>(8LL);
	return runtime_generic_test::wrap(argument_5);
}())));
	auto local_equal = ([&]() -> scpp::bool_t {
	scpp::int_t<> argument_6 = static_cast<scpp::int_t<>>(4LL);
	scpp::int_t<> argument_7 = static_cast<scpp::int_t<>>(4LL);
	return runtime_generic_test::same(argument_6, argument_7);
}());
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_8 = local_n; auto operand_9 = static_cast<scpp::int_t<>>(3LL); return scpp::php::not_identical(operand_8, operand_9); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_10 = local_length; auto operand_11 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_10, operand_11); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_12 = local_first; auto operand_13 = static_cast<scpp::int_t<>>(7LL); return scpp::php::not_identical(operand_12, operand_13); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_14 = local_size; auto operand_15 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_14, operand_15); }())))) || static_cast<bool>((!local_equal)))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
