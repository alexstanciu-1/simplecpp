#include "scpp/data_initializer.hpp"
#include "scpp/mixed_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/null_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/dynamic_t.hpp"
#include "operators/count/count.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::mixed_t local_m = ([&]() -> scpp::mixed_t {
scpp::initializer_buffer<scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>> initializer_0(2);
{
scpp::mixed_t initializer_key_1 = scpp::mixed_t{scpp::string_t("a")};
scpp::mixed_t initializer_value_2 = scpp::mixed_t{scpp::null};
initializer_0.append(scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>{initializer_key_1, initializer_value_2});
}
{
scpp::mixed_t initializer_key_3 = scpp::mixed_t{scpp::string_t("b")};
scpp::mixed_t initializer_value_4 = scpp::mixed_t{static_cast<scpp::int_t<>>(1LL)};
initializer_0.append(scpp::initializer_entry<scpp::mixed_t, scpp::mixed_t>{initializer_key_3, initializer_value_4});
}
return scpp::data_initializer<scpp::mixed_t>::from_key_value(initializer_0.view());
}());
	scpp::dynamic_t<> local_d = ([&]() -> scpp::dynamic_t<> {
scpp::initializer_buffer<scpp::dynamic_t<>> initializer_5(3);
{
scpp::dynamic_t<> initializer_value_6 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(1LL)};
initializer_5.append(initializer_value_6);
}
{
scpp::dynamic_t<> initializer_value_7 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(2LL)};
initializer_5.append(initializer_value_7);
}
{
scpp::dynamic_t<> initializer_value_8 = scpp::dynamic_t<>{static_cast<scpp::int_t<>>(3LL)};
initializer_5.append(initializer_value_8);
}
return scpp::data_initializer<scpp::dynamic_t<>>::from_list(initializer_5.view());
}());
	auto local_n = scpp::count(static_cast<const scpp::mixed_t&>(local_m));
	auto local_r = scpp::count(static_cast<const scpp::dynamic_t<>&>(local_d));
	auto local_again = scpp::count(static_cast<const scpp::mixed_t&>(local_m));
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_9 = local_n; auto operand_10 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_9, operand_10); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_11 = local_r; auto operand_12 = static_cast<scpp::int_t<>>(3LL); return scpp::php::not_identical(operand_11, operand_12); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_13 = local_again; auto operand_14 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_13, operand_14); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
