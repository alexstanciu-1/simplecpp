#include "scpp/data_initializer.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/hash_t.hpp"
#include "operators/count/count.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::vector_t<scpp::int_t<>>> local_v = ([&]() -> scpp::vector_t<scpp::vector_t<scpp::int_t<>>> {
scpp::initializer_buffer<scpp::vector_t<scpp::int_t<>>> initializer_0(2);
{
scpp::vector_t<scpp::int_t<>> initializer_value_1 = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_2(1);
{
scpp::int_t<> initializer_value_3 = static_cast<scpp::int_t<>>(1LL);
initializer_2.append(initializer_value_3);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_2.view());
}());
initializer_0.append(initializer_value_1);
}
{
scpp::vector_t<scpp::int_t<>> initializer_value_4 = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_5(1);
{
scpp::int_t<> initializer_value_6 = static_cast<scpp::int_t<>>(2LL);
initializer_5.append(initializer_value_6);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_5.view());
}());
initializer_0.append(initializer_value_4);
}
return scpp::data_initializer<scpp::vector_t<scpp::vector_t<scpp::int_t<>>>>::from_list(initializer_0.view());
}());
	scpp::hash_t<scpp::int_t<>, scpp::string_t> local_h = ([&]() -> scpp::hash_t<scpp::int_t<>, scpp::string_t> {
scpp::initializer_buffer<scpp::initializer_entry<scpp::int_t<>, scpp::string_t>> initializer_7(1);
{
scpp::string_t initializer_key_8 = scpp::string_t("a");
scpp::int_t<> initializer_value_9 = static_cast<scpp::int_t<>>(3LL);
initializer_7.append(scpp::initializer_entry<scpp::int_t<>, scpp::string_t>{initializer_key_8, initializer_value_9});
}
return scpp::data_initializer<scpp::hash_t<scpp::int_t<>, scpp::string_t>>::from_key_value(initializer_7.view());
}());
	auto local_n = scpp::count(static_cast<const scpp::vector_t<scpp::vector_t<scpp::int_t<>>>&>(local_v));
	auto local_m = scpp::count(static_cast<const scpp::hash_t<scpp::int_t<>, scpp::string_t>&>(local_h));
if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_10 = local_n; auto operand_11 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_10, operand_11); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_12 = local_m; auto operand_13 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_12, operand_13); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
