#include "scpp/data_initializer.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/unique_p.hpp"
#include "operators/count/count.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::int_t<>> local_a = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_0(2);
{
scpp::int_t<> initializer_value_1 = static_cast<scpp::int_t<>>(1LL);
initializer_0.append(initializer_value_1);
}
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(2LL);
initializer_0.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_0.view());
}());
	scpp::vector_t<scpp::string_t> local_b = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_3(1);
{
scpp::string_t initializer_value_4 = scpp::string_t("a");
initializer_3.append(initializer_value_4);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_3.view());
}());
	scpp::vector_t<scpp::vector_t<scpp::int_t<>>> local_c = ([&]() -> scpp::vector_t<scpp::vector_t<scpp::int_t<>>> {
scpp::initializer_buffer<scpp::vector_t<scpp::int_t<>>> initializer_5(2);
{
scpp::vector_t<scpp::int_t<>> initializer_value_6 = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_7(1);
{
scpp::int_t<> initializer_value_8 = static_cast<scpp::int_t<>>(1LL);
initializer_7.append(initializer_value_8);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_7.view());
}());
initializer_5.append(initializer_value_6);
}
{
scpp::vector_t<scpp::int_t<>> initializer_value_9 = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_10(1);
{
scpp::int_t<> initializer_value_11 = static_cast<scpp::int_t<>>(2LL);
initializer_10.append(initializer_value_11);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_10.view());
}());
initializer_5.append(initializer_value_9);
}
return scpp::data_initializer<scpp::vector_t<scpp::vector_t<scpp::int_t<>>>>::from_list(initializer_5.view());
}());
	scpp::vector_t<scpp::unique_p<scpp::int_t<>>> local_u;
	auto local_n = scpp::count(static_cast<const scpp::vector_t<scpp::int_t<>>&>(local_a));
	auto local_m = scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_b));
	auto local_p = scpp::count(static_cast<const scpp::vector_t<scpp::vector_t<scpp::int_t<>>>&>(local_c));
	auto local_z = scpp::count(static_cast<const scpp::vector_t<scpp::unique_p<scpp::int_t<>>>&>(local_u));
	auto local_again = scpp::count(static_cast<const scpp::vector_t<scpp::unique_p<scpp::int_t<>>>&>(local_u));
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_12 = local_n; auto operand_13 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_12, operand_13); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_14 = local_m; auto operand_15 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_14, operand_15); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_16 = local_p; auto operand_17 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_16, operand_17); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_18 = local_z; auto operand_19 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_18, operand_19); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_20 = local_again; auto operand_21 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_20, operand_21); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
