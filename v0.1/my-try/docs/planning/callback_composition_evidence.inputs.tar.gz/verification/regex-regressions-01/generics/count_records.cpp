// SCPP-ARTIFACT {"id":"type:Item","kind":"header","path":"types\/n4974656d.hpp"}
#pragma once
#include "scpp/int_t.hpp"
struct record_Item
{
public:
	scpp::int_t<> field_number;
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n4974656d.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/string_t.hpp"
#include "scpp/hash_t.hpp"
#include "operators/count/count.hpp"
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<record_Item> local_a;
	scpp::hash_t<record_Item, scpp::string_t> local_b;
	auto local_n = scpp::count(static_cast<const scpp::vector_t<record_Item>&>(local_a));
	auto local_m = scpp::count(static_cast<const scpp::hash_t<record_Item, scpp::string_t>&>(local_b));
if ((scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_0 = local_n; auto operand_1 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_0, operand_1); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_2 = local_m; auto operand_3 = static_cast<scpp::int_t<>>(0LL); return scpp::php::not_identical(operand_2, operand_3); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
