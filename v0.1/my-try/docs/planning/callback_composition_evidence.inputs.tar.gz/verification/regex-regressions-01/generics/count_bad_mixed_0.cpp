#include <stdexcept>
#include "scpp/null_t.hpp"
#include "scpp/mixed_t.hpp"
#include "operators/count/count.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

// SCPP-PROBE-OBSERVE-ENTRY
int observed_entry(int argc = 0, char** argv = nullptr)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::mixed_t local_x = scpp::mixed_t{scpp::null};
	auto local_n = scpp::count(static_cast<const scpp::mixed_t&>(local_x));
	return static_cast<int>((static_cast<scpp::int_t<>>(91LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

int main() { try { observed_entry(); } catch (const std::runtime_error&) { return 0; } return 92; }
