// SCPP-ARTIFACT {"id":"type:Bag","kind":"header","path":"types\/n426167.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/data_initializer.hpp"
struct record_Bag
{
public:
	scpp::vector_t<scpp::int_t<>> field_items = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_0(2);
{
scpp::int_t<> initializer_value_1 = static_cast<scpp::int_t<>>(1LL);
initializer_0.append(initializer_value_1);
}
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(2LL);
initializer_0.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_0.view());
}());
public:
};

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:produce","kind":"header","path":"callables\/n70726f64756365.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/shared_p.hpp"
struct record_Bag;
::scpp::shared_p<record_Bag> function_produce(scpp::int_t<>& local_calls);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:inspect","kind":"header","path":"callables\/n696e7370656374.hpp"}
#pragma once
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
scpp::int_t<> function_inspect(const scpp::vector_t<scpp::int_t<>>& local_v);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n70726f64756365.hpp"
#include "scpp/int_t.hpp"
#include "types/n426167.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/generated/operators.hpp"
#include "scpp/memory.hpp"
#include "callables/n696e7370656374.hpp"
#include "scpp/vector_t.hpp"
#include "operators/count/count.hpp"
::scpp::shared_p<record_Bag> function_produce(scpp::int_t<>& local_calls)
{
	static_cast<scpp::int_t<>>(local_calls++);
	return ::scpp::shared<record_Bag>();
}

scpp::int_t<> function_inspect(const scpp::vector_t<scpp::int_t<>>& local_v)
{
	return scpp::count(static_cast<const scpp::vector_t<scpp::int_t<>>&>(local_v));
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "types/n426167.hpp"
#include "scpp/memory.hpp"
#include "scpp/shared_p.hpp"
#include "scpp/int_t.hpp"
#include "scpp/vector_t.hpp"
#include "operators/count/count.hpp"
#include "callables/n70726f64756365.hpp"
#include "scpp/data_initializer.hpp"
#include "callables/n696e7370656374.hpp"
#include "scpp/bool_t.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_bag = ::scpp::shared<record_Bag>();
	auto local_calls = static_cast<scpp::int_t<>>(0LL);
	auto local_n = scpp::count(static_cast<const scpp::vector_t<scpp::int_t<>>&>((local_bag)->field_items));
	auto local_m = scpp::count(static_cast<const scpp::vector_t<scpp::int_t<>>&>((([&]() -> ::scpp::shared_p<record_Bag> {
	scpp::int_t<>& argument_0 = local_calls;
	return function_produce(argument_0);
}()))->field_items));
	scpp::vector_t<scpp::int_t<>> local_v = ([&]() -> scpp::vector_t<scpp::int_t<>> {
scpp::initializer_buffer<scpp::int_t<>> initializer_1(1);
{
scpp::int_t<> initializer_value_2 = static_cast<scpp::int_t<>>(1LL);
initializer_1.append(initializer_value_2);
}
return scpp::data_initializer<scpp::vector_t<scpp::int_t<>>>::from_list(initializer_1.view());
}());
	auto local_r = ([&]() -> scpp::int_t<> {
	const scpp::vector_t<scpp::int_t<>>& argument_3 = local_v;
	return function_inspect(argument_3);
}());
if ((scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(scpp::bool_t(static_cast<bool>(([&]() -> scpp::bool_t { auto operand_4 = local_n; auto operand_5 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_4, operand_5); }())) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_6 = local_m; auto operand_7 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_6, operand_7); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_8 = local_r; auto operand_9 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_8, operand_9); }())))) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_10 = local_calls; auto operand_11 = static_cast<scpp::int_t<>>(1LL); return scpp::php::not_identical(operand_10, operand_11); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
