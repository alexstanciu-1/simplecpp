// SCPP-ARTIFACT {"id":"callable:step","kind":"header","path":"callables\/n73746570.hpp"}
#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_step(scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n73746570.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::int_t<> function_step(scpp::int_t<>& local_n)
{
	static_cast<scpp::int_t<>>(local_n++);
	return local_n;
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "scpp/int_t.hpp"
#include "scpp/bool_t.hpp"
#include "callables/n73746570.hpp"
#include "runtime_generic_support.hpp"
#include "lang/php/operators/identity/strict_identity.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	auto local_n = static_cast<scpp::int_t<>>(0LL);
	auto local_equal = ([&]() -> scpp::bool_t {
	scpp::int_t<> argument_1 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_0 = local_n;
	return function_step(argument_0);
}());
	scpp::int_t<> argument_3 = ([&]() -> scpp::int_t<> {
	scpp::int_t<>& argument_2 = local_n;
	return function_step(argument_2);
}());
	return runtime_generic_test::same(argument_1, argument_3);
}());
if ((scpp::bool_t(static_cast<bool>(local_equal) || static_cast<bool>(([&]() -> scpp::bool_t { auto operand_4 = local_n; auto operand_5 = static_cast<scpp::int_t<>>(2LL); return scpp::php::not_identical(operand_4, operand_5); }())))).native_value()) {
	return static_cast<int>((static_cast<scpp::int_t<>>(1LL)).native_value());
}
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT
