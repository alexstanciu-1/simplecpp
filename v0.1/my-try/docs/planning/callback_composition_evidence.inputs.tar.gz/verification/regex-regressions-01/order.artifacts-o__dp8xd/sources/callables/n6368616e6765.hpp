#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_change(scpp::string_t& local_pattern, scpp::int_t<>& local_calls);
