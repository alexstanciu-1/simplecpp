#include "callables/n6368616e6765.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
scpp::string_t function_change(scpp::string_t& local_pattern, scpp::int_t<>& local_calls)
{
	local_pattern = scpp::string_t("/b/");
	static_cast<scpp::int_t<>>(local_calls++);
	return scpp::string_t("a");
}

