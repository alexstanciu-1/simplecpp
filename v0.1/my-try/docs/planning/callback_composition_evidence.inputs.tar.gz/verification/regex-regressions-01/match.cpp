#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "lang/php/support/php_string.hpp"
#include "operators/count/count.hpp"
#include "scpp/index_read.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::string_t> local_captures = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = scpp::string_t("/(ab+)-(cd+)/i");
	scpp::string_t argument_1 = scpp::string_t("xxAbb-cDDyy");
	return scpp::regex::match(argument_0, argument_1);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_captures)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_2 = local_captures; scpp::int_t<> index_key_2 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_2, index_key_2); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_3 = local_captures; scpp::int_t<> index_key_3 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_3, index_key_3); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_4 = local_captures; scpp::int_t<> index_key_4 = static_cast<scpp::int_t<>>(2LL); return scpp::checked_index_read(index_receiver_4, index_key_4); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	scpp::vector_t<scpp::string_t> local_offset = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_5 = scpp::string_t("/ab/i");
	scpp::string_t argument_6 = scpp::string_t("ab xx AB");
	scpp::int_t<> argument_7 = static_cast<scpp::int_t<>>(3LL);
	return scpp::regex::match(argument_5, argument_6, argument_7);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::string_t> local_negative = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_8 = scpp::string_t("/ab/i");
	scpp::string_t argument_9 = scpp::string_t("ab xx AB");
	scpp::int_t<> argument_10 = (-static_cast<scpp::int_t<>>(2LL));
	return scpp::regex::match(argument_8, argument_9, argument_10);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_11 = local_offset; scpp::int_t<> index_key_11 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_11, index_key_11); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_12 = local_negative; scpp::int_t<> index_key_12 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_12, index_key_12); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	scpp::vector_t<scpp::string_t> local_unicode = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_13 = scpp::string_t("/./u");
	scpp::string_t argument_14 = scpp::string_t("\xF0" "\x9F" "\x98" "\x80" "");
	scpp::int_t<> argument_15 = static_cast<scpp::int_t<>>(0LL);
	return scpp::regex::match(argument_13, argument_14, argument_15);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_16 = local_unicode; scpp::int_t<> index_key_16 = static_cast<scpp::int_t<>>(0LL); return scpp::checked_index_read(index_receiver_16, index_key_16); }()));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
