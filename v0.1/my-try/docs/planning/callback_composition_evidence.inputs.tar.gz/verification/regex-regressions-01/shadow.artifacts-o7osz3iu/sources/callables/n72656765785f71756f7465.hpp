#pragma once
#include "scpp/int_t.hpp"
scpp::int_t<> function_regexU_quote(scpp::int_t<> local_value);
