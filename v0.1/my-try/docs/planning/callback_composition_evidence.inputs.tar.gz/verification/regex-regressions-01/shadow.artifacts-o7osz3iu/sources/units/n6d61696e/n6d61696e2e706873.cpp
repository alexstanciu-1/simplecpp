#include "callables/n72656765785f71756f7465.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_regexU_quote(scpp::int_t<> local_value)
{
	return local_value;
}

