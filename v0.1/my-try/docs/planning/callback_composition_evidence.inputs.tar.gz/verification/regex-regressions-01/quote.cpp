#include "scpp/bool_t.hpp"
#include "modules/regex/regex.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::bool_t local_jit = ([&]() -> scpp::bool_t {
	return scpp::regex::jit_available();
}());
	::scpp::php::echo_one(([&]() -> scpp::string_t {
	scpp::string_t argument_0 = scpp::string_t("a+b?.");
	return scpp::regex::quote(argument_0);
}()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t {
	scpp::string_t argument_1 = scpp::string_t("a/b");
	scpp::string_t argument_2 = scpp::string_t("/");
	return scpp::regex::quote(argument_1, argument_2);
}()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t {
	scpp::string_t argument_3 = scpp::string_t("plain");
	scpp::string_t argument_4 = scpp::string_t("");
	return scpp::regex::quote(argument_3, argument_4);
}()));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
