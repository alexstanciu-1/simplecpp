#include "scpp/string_t.hpp"
#include "scpp/hash_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "scpp/int_t.hpp"
#include "lang/php/support/php_string.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::hash_t<scpp::string_t, scpp::string_t> local_named = scpp::hash_t<scpp::string_t, scpp::string_t>((([&]() -> scpp::result_or_false<scpp::hash_t<scpp::string_t, scpp::string_t>> {
	scpp::string_t argument_0 = scpp::string_t("/(?<word>ab)/i");
	scpp::string_t argument_1 = scpp::string_t("AB ab");
	return scpp::regex::match_named(argument_0, argument_1);
}())).require_value("Result required-value extraction"));
	scpp::hash_t<scpp::string_t, scpp::string_t> local_offset = scpp::hash_t<scpp::string_t, scpp::string_t>((([&]() -> scpp::result_or_false<scpp::hash_t<scpp::string_t, scpp::string_t>> {
	scpp::string_t argument_2 = scpp::string_t("/(?<word>ab)/i");
	scpp::string_t argument_3 = scpp::string_t("AB ab");
	scpp::int_t<> argument_4 = static_cast<scpp::int_t<>>(3LL);
	return scpp::regex::match_named(argument_2, argument_3, argument_4);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_5 = local_named; scpp::string_t index_key_5 = scpp::string_t("0"); return scpp::checked_index_read(index_receiver_5, index_key_5); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_6 = local_named; scpp::string_t index_key_6 = scpp::string_t("1"); return scpp::checked_index_read(index_receiver_6, index_key_6); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_7 = local_named; scpp::string_t index_key_7 = scpp::string_t("word"); return scpp::checked_index_read(index_receiver_7, index_key_7); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_8 = local_offset; scpp::string_t index_key_8 = scpp::string_t("word"); return scpp::checked_index_read(index_receiver_8, index_key_8); }()));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
