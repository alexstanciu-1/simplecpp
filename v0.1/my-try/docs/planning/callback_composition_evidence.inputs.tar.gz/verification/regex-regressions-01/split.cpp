#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "scpp/int_t.hpp"
#include "scpp/generated/operators.hpp"
#include "lang/php/support/php_string.hpp"
#include "operators/count/count.hpp"
#include "scpp/index_read.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int main(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	scpp::vector_t<scpp::string_t> local_parts = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = scpp::string_t("/,/");
	scpp::string_t argument_1 = scpp::string_t("a,b,");
	return scpp::regex::split(argument_0, argument_1);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::string_t> local_limited = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_2 = scpp::string_t("/,/");
	scpp::string_t argument_3 = scpp::string_t("a,b,c");
	scpp::int_t<> argument_4 = static_cast<scpp::int_t<>>(2LL);
	return scpp::regex::split(argument_2, argument_3, argument_4);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::string_t> local_nonempty = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_5 = scpp::string_t("/,/");
	scpp::string_t argument_6 = scpp::string_t(",a,,b,");
	scpp::int_t<> argument_7 = static_cast<scpp::int_t<>>(0LL);
	scpp::int_t<> argument_8 = static_cast<scpp::int_t<>>(1LL);
	return scpp::regex::split(argument_5, argument_6, argument_7, argument_8);
}())).require_value("Result required-value extraction"));
	scpp::vector_t<scpp::string_t> local_captured = scpp::vector_t<scpp::string_t>((([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_9 = scpp::string_t("/(,)/");
	scpp::string_t argument_10 = scpp::string_t("a,b");
	scpp::int_t<> argument_11 = (-static_cast<scpp::int_t<>>(1LL));
	scpp::int_t<> argument_12 = static_cast<scpp::int_t<>>(2LL);
	return scpp::regex::split(argument_9, argument_10, argument_11, argument_12);
}())).require_value("Result required-value extraction"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_parts)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_13 = local_parts; scpp::int_t<> index_key_13 = static_cast<scpp::int_t<>>(2LL); return scpp::checked_index_read(index_receiver_13, index_key_13); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_14 = local_limited; scpp::int_t<> index_key_14 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_14, index_key_14); }()));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(scpp::count(static_cast<const scpp::vector_t<scpp::string_t>&>(local_nonempty)));
	::scpp::php::echo_one(scpp::string_t("|"));
	::scpp::php::echo_one(([&]() -> scpp::string_t { const auto& index_receiver_15 = local_captured; scpp::int_t<> index_key_15 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_15, index_key_15); }()));
	return static_cast<int>((static_cast<scpp::int_t<>>(0LL)).native_value());
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
