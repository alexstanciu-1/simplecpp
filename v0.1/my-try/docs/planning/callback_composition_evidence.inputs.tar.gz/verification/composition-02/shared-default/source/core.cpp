
#include "scpp/util/global_string_pool.hpp"
int main() {
    auto& pool = scpp::global_string_pool::instance();
    return pool.resolve(pool.intern(scpp::string_t("core-only"))).native_value() == "core-only" ? 0 : 1;
}
