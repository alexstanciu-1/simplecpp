
#include "scpp/util/global_string_pool.hpp"
extern "C" void* provider_pool() { return &scpp::global_string_pool::instance(); }
extern "C" unsigned provider_intern() {
    return scpp::global_string_pool::instance().intern(scpp::string_t("provider-key"));
}
