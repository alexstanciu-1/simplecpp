
#include "scpp/util/global_string_pool.hpp"
extern "C" void* provider_pool();
extern "C" unsigned provider_intern();
int main() {
    auto& pool = scpp::global_string_pool::instance();
    if (provider_pool() != &pool) return 1;
    const auto id = provider_intern();
    if (pool.resolve(id).native_value() != "provider-key") return 2;
    return pool.intern(scpp::string_t("provider-key")) == id ? 0 : 3;
}
