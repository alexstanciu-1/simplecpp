// SCPP-ARTIFACT {"id":"callable:replace4","kind":"header","path":"callables\/n7265706c61636534.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::string_t& local_s, const scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:filter4","kind":"header","path":"callables\/n66696c74657234.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::vector_t<scpp::string_t>& local_s, const scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:replace3","kind":"header","path":"callables\/n7265706c61636533.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_replace3();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:filter3","kind":"header","path":"callables\/n66696c74657233.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter3();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pat","kind":"header","path":"callables\/n706174.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:rep","kind":"header","path":"callables\/n726570.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_rep(scpp::string_t& local_p, scpp::string_t& local_r, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:subject","kind":"header","path":"callables\/n7375626a656374.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_subject(scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:rows","kind":"header","path":"callables\/n726f7773.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
scpp::vector_t<scpp::string_t> function_rows(scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:limit","kind":"header","path":"callables\/n6c696d6974.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_limit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:rowlimit","kind":"header","path":"callables\/n726f776c696d6974.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_rowlimit(scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:ordered","kind":"header","path":"callables\/n6f726465726564.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:filtered","kind":"header","path":"callables\/n66696c7465726564.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filtered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n7265706c61636534.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "callables/n66696c74657234.hpp"
#include "scpp/vector_t.hpp"
#include "callables/n7265706c61636533.hpp"
#include "callables/n66696c74657233.hpp"
#include "scpp/data_initializer.hpp"
#include "callables/n706174.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n726570.hpp"
#include "callables/n7375626a656374.hpp"
#include "callables/n726f7773.hpp"
#include "callables/n6c696d6974.hpp"
#include "callables/n726f776c696d6974.hpp"
#include "scpp/index_write.hpp"
#include "callables/n6f726465726564.hpp"
#include "callables/n66696c7465726564.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::string_t& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = local_p;
	scpp::string_t argument_1 = local_r;
	scpp::string_t argument_2 = local_s;
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::replace_limited(argument_0, argument_1, argument_2, argument_3);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::vector_t<scpp::string_t>& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = local_p;
	scpp::string_t argument_1 = local_r;
	scpp::vector_t<scpp::string_t> argument_2 = local_s;
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::filter_limited(argument_0, argument_1, argument_2, argument_3);
}());
}

scpp::result_or_false<scpp::string_t> function_replace3()
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = scpp::string_t("/(a)/");
	scpp::string_t argument_1 = scpp::string_t("${1}${1}");
	scpp::string_t argument_2 = scpp::string_t("aba");
	return scpp::regex::replace(argument_0, argument_1, argument_2);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter3()
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = scpp::string_t("/(a)/");
	scpp::string_t argument_1 = scpp::string_t("$1$1");
	scpp::vector_t<scpp::string_t> argument_5 = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_2(2);
{
scpp::string_t initializer_value_3 = scpp::string_t("aba");
initializer_2.append(initializer_value_3);
}
{
scpp::string_t initializer_value_4 = scpp::string_t("z");
initializer_2.append(initializer_value_4);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_2.view());
}());
	return scpp::regex::filter(argument_0, argument_1, argument_5);
}());
}

scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(1LL); return (operand_2 + operand_3); }());
	return local_p;
}

scpp::string_t function_rep(scpp::string_t& local_p, scpp::string_t& local_r, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(2LL); return (operand_2 + operand_3); }());
	local_p = scpp::string_t("/z/");
	return local_r;
}

scpp::string_t function_subject(scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_r = scpp::string_t("Y");
	return local_s;
}

scpp::vector_t<scpp::string_t> function_rows(scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_r = scpp::string_t("Y");
	return local_s;
}

scpp::int_t<> function_limit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(4LL); return (operand_2 + operand_3); }());
	local_s = scpp::string_t("changed");
	return local_n;
}

scpp::int_t<> function_rowlimit(scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(4LL); return (operand_2 + operand_3); }());
	{ auto& write_receiver_4 = local_s; scpp::int_t<> write_key_4 = static_cast<scpp::int_t<>>(0LL); scpp::require_write_key(write_key_4); scpp::string_t write_value_4 = scpp::string_t("changed"); scpp::index_store(write_receiver_4, write_key_4, write_value_4); }
	return local_n;
}

scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_2 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_0 = local_p;
	scpp::int_t<>& argument_1 = local_t;
	return function_pat(argument_0, argument_1);
}());
	scpp::string_t argument_6 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_3 = local_p;
	scpp::string_t& argument_4 = local_r;
	scpp::int_t<>& argument_5 = local_t;
	return function_rep(argument_3, argument_4, argument_5);
}());
	scpp::string_t argument_10 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_7 = local_r;
	scpp::string_t& argument_8 = local_s;
	scpp::int_t<>& argument_9 = local_t;
	return function_subject(argument_7, argument_8, argument_9);
}());
	scpp::int_t<> argument_14 = ([&]() -> scpp::int_t<> {
	scpp::string_t& argument_11 = local_s;
	scpp::int_t<> argument_12 = local_n;
	scpp::int_t<>& argument_13 = local_t;
	return function_limit(argument_11, argument_12, argument_13);
}());
	return scpp::regex::replace_limited(argument_2, argument_6, argument_10, argument_14);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filtered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_2 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_0 = local_p;
	scpp::int_t<>& argument_1 = local_t;
	return function_pat(argument_0, argument_1);
}());
	scpp::string_t argument_6 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_3 = local_p;
	scpp::string_t& argument_4 = local_r;
	scpp::int_t<>& argument_5 = local_t;
	return function_rep(argument_3, argument_4, argument_5);
}());
	scpp::vector_t<scpp::string_t> argument_10 = ([&]() -> scpp::vector_t<scpp::string_t> {
	scpp::string_t& argument_7 = local_r;
	scpp::vector_t<scpp::string_t>& argument_8 = local_s;
	scpp::int_t<>& argument_9 = local_t;
	return function_rows(argument_7, argument_8, argument_9);
}());
	scpp::int_t<> argument_14 = ([&]() -> scpp::int_t<> {
	scpp::vector_t<scpp::string_t>& argument_11 = local_s;
	scpp::int_t<> argument_12 = local_n;
	scpp::int_t<>& argument_13 = local_t;
	return function_rowlimit(argument_11, argument_12, argument_13);
}());
	return scpp::regex::filter_limited(argument_2, argument_6, argument_10, argument_14);
}());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

#include "regex_replacement_oracle.hpp"
int main(){
 using S=scpp::string_t;using I=scpp::int_t<>;using V=scpp::vector_t<S>;
 if(regex_replacement_oracle(function_replace4,function_filter4)!=0)return 1;
 if(function_replace3().value().native_value()!="aabaa")return 2;
 auto f=function_filter3();if(!f.has_value().native_value() || f.value().size()!=1 || f.value().at(I{0}).native_value()!="aabaa")return 3;
 I n{1};auto limited=function_replace4(S{"/a/"},S{"X"},S{"aba"},n);
 if(n.native_value()!=1 || limited.value().native_value()!="Xba")return 4;
 for(std::int64_t lim:{-2,0,1}){
  S p{"/a/"},r{"X"},s{"aba"};I trace{0};bool caught=false;
  try{auto result=function_ordered(p,r,s,I{lim},trace);if(lim>=0 && result.value().native_value()!=(lim==0?"aba":"Xba"))return 5;}
  catch(const scpp::ValueError&){caught=true;}
  if(caught!=(lim<0) || trace.native_value()!=1234 || p.native_value()!="/z/" || r.native_value()!="Y" || s.native_value()!="changed")return 6;
  p=S{"/a/"};r=S{"X"};V v;v.append(S{"aba"});trace=I{0};caught=false;
  try{auto result=function_filtered(p,r,v,I{lim},trace);if(lim==0 && result.value().size()!=0)return 7;if(lim==1 && result.value().at(I{0}).native_value()!="Xba")return 8;}
  catch(const scpp::ValueError&){caught=true;}
  if(caught!=(lim<0) || trace.native_value()!=1234 || v.at(I{0}).native_value()!="changed")return 9;
 }
 S p{"/broken"},r{"X"},s{"aba"};I trace{0};
 if(!function_ordered(p,r,s,I{1},trace).is_false().native_value() || trace.native_value()!=1234)return 10;
 std::cout<<"defaults; limit preserved; ordered snapshots; provider failures after arguments\n";
}