#pragma once
#include "scpp/string_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_replace3();
