#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::string_t& local_s, const scpp::int_t<>& local_n);
