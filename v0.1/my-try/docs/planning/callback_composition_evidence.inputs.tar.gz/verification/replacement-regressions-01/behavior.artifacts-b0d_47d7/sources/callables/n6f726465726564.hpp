#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
