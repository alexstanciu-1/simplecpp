#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t);
