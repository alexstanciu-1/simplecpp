#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
scpp::vector_t<scpp::string_t> function_rows(scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<>& local_t);
