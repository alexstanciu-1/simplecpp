#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_rep(scpp::string_t& local_p, scpp::string_t& local_r, scpp::int_t<>& local_t);
