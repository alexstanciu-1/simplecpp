#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter3();
