#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::vector_t<scpp::string_t>& local_s, const scpp::int_t<>& local_n);
