#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_subject(scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<>& local_t);
