#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filtered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
