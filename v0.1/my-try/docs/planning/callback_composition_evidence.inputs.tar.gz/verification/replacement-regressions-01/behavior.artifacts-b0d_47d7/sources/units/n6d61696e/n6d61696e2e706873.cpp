#include "callables/n7265706c61636534.hpp"
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "callables/n66696c74657234.hpp"
#include "scpp/vector_t.hpp"
#include "callables/n7265706c61636533.hpp"
#include "callables/n66696c74657233.hpp"
#include "scpp/data_initializer.hpp"
#include "callables/n706174.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n726570.hpp"
#include "callables/n7375626a656374.hpp"
#include "callables/n726f7773.hpp"
#include "callables/n6c696d6974.hpp"
#include "callables/n726f776c696d6974.hpp"
#include "scpp/index_write.hpp"
#include "callables/n6f726465726564.hpp"
#include "callables/n66696c7465726564.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::string_t& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = local_p;
	scpp::string_t argument_1 = local_r;
	scpp::string_t argument_2 = local_s;
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::replace_limited(argument_0, argument_1, argument_2, argument_3);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter4(const scpp::string_t& local_p, const scpp::string_t& local_r, const scpp::vector_t<scpp::string_t>& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = local_p;
	scpp::string_t argument_1 = local_r;
	scpp::vector_t<scpp::string_t> argument_2 = local_s;
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::filter_limited(argument_0, argument_1, argument_2, argument_3);
}());
}

scpp::result_or_false<scpp::string_t> function_replace3()
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = scpp::string_t("/(a)/");
	scpp::string_t argument_1 = scpp::string_t("${1}${1}");
	scpp::string_t argument_2 = scpp::string_t("aba");
	return scpp::regex::replace(argument_0, argument_1, argument_2);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filter3()
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_0 = scpp::string_t("/(a)/");
	scpp::string_t argument_1 = scpp::string_t("$1$1");
	scpp::vector_t<scpp::string_t> argument_5 = ([&]() -> scpp::vector_t<scpp::string_t> {
scpp::initializer_buffer<scpp::string_t> initializer_2(2);
{
scpp::string_t initializer_value_3 = scpp::string_t("aba");
initializer_2.append(initializer_value_3);
}
{
scpp::string_t initializer_value_4 = scpp::string_t("z");
initializer_2.append(initializer_value_4);
}
return scpp::data_initializer<scpp::vector_t<scpp::string_t>>::from_list(initializer_2.view());
}());
	return scpp::regex::filter(argument_0, argument_1, argument_5);
}());
}

scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(1LL); return (operand_2 + operand_3); }());
	return local_p;
}

scpp::string_t function_rep(scpp::string_t& local_p, scpp::string_t& local_r, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(2LL); return (operand_2 + operand_3); }());
	local_p = scpp::string_t("/z/");
	return local_r;
}

scpp::string_t function_subject(scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_r = scpp::string_t("Y");
	return local_s;
}

scpp::vector_t<scpp::string_t> function_rows(scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_r = scpp::string_t("Y");
	return local_s;
}

scpp::int_t<> function_limit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(4LL); return (operand_2 + operand_3); }());
	local_s = scpp::string_t("changed");
	return local_n;
}

scpp::int_t<> function_rowlimit(scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(4LL); return (operand_2 + operand_3); }());
	{ auto& write_receiver_4 = local_s; scpp::int_t<> write_key_4 = static_cast<scpp::int_t<>>(0LL); scpp::require_write_key(write_key_4); scpp::string_t write_value_4 = scpp::string_t("changed"); scpp::index_store(write_receiver_4, write_key_4, write_value_4); }
	return local_n;
}

scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_2 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_0 = local_p;
	scpp::int_t<>& argument_1 = local_t;
	return function_pat(argument_0, argument_1);
}());
	scpp::string_t argument_6 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_3 = local_p;
	scpp::string_t& argument_4 = local_r;
	scpp::int_t<>& argument_5 = local_t;
	return function_rep(argument_3, argument_4, argument_5);
}());
	scpp::string_t argument_10 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_7 = local_r;
	scpp::string_t& argument_8 = local_s;
	scpp::int_t<>& argument_9 = local_t;
	return function_subject(argument_7, argument_8, argument_9);
}());
	scpp::int_t<> argument_14 = ([&]() -> scpp::int_t<> {
	scpp::string_t& argument_11 = local_s;
	scpp::int_t<> argument_12 = local_n;
	scpp::int_t<>& argument_13 = local_t;
	return function_limit(argument_11, argument_12, argument_13);
}());
	return scpp::regex::replace_limited(argument_2, argument_6, argument_10, argument_14);
}());
}

scpp::result_or_false<scpp::vector_t<scpp::string_t>> function_filtered(scpp::string_t& local_p, scpp::string_t& local_r, scpp::vector_t<scpp::string_t>& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::vector_t<scpp::string_t>> {
	scpp::string_t argument_2 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_0 = local_p;
	scpp::int_t<>& argument_1 = local_t;
	return function_pat(argument_0, argument_1);
}());
	scpp::string_t argument_6 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_3 = local_p;
	scpp::string_t& argument_4 = local_r;
	scpp::int_t<>& argument_5 = local_t;
	return function_rep(argument_3, argument_4, argument_5);
}());
	scpp::vector_t<scpp::string_t> argument_10 = ([&]() -> scpp::vector_t<scpp::string_t> {
	scpp::string_t& argument_7 = local_r;
	scpp::vector_t<scpp::string_t>& argument_8 = local_s;
	scpp::int_t<>& argument_9 = local_t;
	return function_rows(argument_7, argument_8, argument_9);
}());
	scpp::int_t<> argument_14 = ([&]() -> scpp::int_t<> {
	scpp::vector_t<scpp::string_t>& argument_11 = local_s;
	scpp::int_t<> argument_12 = local_n;
	scpp::int_t<>& argument_13 = local_t;
	return function_rowlimit(argument_11, argument_12, argument_13);
}());
	return scpp::regex::filter_limited(argument_2, argument_6, argument_10, argument_14);
}());
}

