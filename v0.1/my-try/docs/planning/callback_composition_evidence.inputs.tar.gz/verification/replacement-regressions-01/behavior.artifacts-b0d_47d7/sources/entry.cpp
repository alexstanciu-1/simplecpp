#include "callables/n7265706c61636534.hpp"
#include "callables/n66696c74657234.hpp"
#include "callables/n7265706c61636533.hpp"
#include "callables/n66696c74657233.hpp"
#include "callables/n706174.hpp"
#include "callables/n726570.hpp"
#include "callables/n7375626a656374.hpp"
#include "callables/n726f7773.hpp"
#include "callables/n6c696d6974.hpp"
#include "callables/n726f776c696d6974.hpp"
#include "callables/n6f726465726564.hpp"
#include "callables/n66696c7465726564.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

#include "regex_replacement_oracle.hpp"
int main(){
 using S=scpp::string_t;using I=scpp::int_t<>;using V=scpp::vector_t<S>;
 if(regex_replacement_oracle(function_replace4,function_filter4)!=0)return 1;
 if(function_replace3().value().native_value()!="aabaa")return 2;
 auto f=function_filter3();if(!f.has_value().native_value() || f.value().size()!=1 || f.value().at(I{0}).native_value()!="aabaa")return 3;
 I n{1};auto limited=function_replace4(S{"/a/"},S{"X"},S{"aba"},n);
 if(n.native_value()!=1 || limited.value().native_value()!="Xba")return 4;
 for(std::int64_t lim:{-2,0,1}){
  S p{"/a/"},r{"X"},s{"aba"};I trace{0};bool caught=false;
  try{auto result=function_ordered(p,r,s,I{lim},trace);if(lim>=0 && result.value().native_value()!=(lim==0?"aba":"Xba"))return 5;}
  catch(const scpp::ValueError&){caught=true;}
  if(caught!=(lim<0) || trace.native_value()!=1234 || p.native_value()!="/z/" || r.native_value()!="Y" || s.native_value()!="changed")return 6;
  p=S{"/a/"};r=S{"X"};V v;v.append(S{"aba"});trace=I{0};caught=false;
  try{auto result=function_filtered(p,r,v,I{lim},trace);if(lim==0 && result.value().size()!=0)return 7;if(lim==1 && result.value().at(I{0}).native_value()!="Xba")return 8;}
  catch(const scpp::ValueError&){caught=true;}
  if(caught!=(lim<0) || trace.native_value()!=1234 || v.at(I{0}).native_value()!="changed")return 9;
 }
 S p{"/broken"},r{"X"},s{"aba"};I trace{0};
 if(!function_ordered(p,r,s,I{1},trace).is_false().native_value() || trace.native_value()!=1234)return 10;
 std::cout<<"defaults; limit preserved; ordered snapshots; provider failures after arguments\n";
}