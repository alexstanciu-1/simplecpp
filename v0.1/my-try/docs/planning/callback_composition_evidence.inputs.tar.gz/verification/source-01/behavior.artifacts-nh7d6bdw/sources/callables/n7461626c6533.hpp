#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_table3(const scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, const scpp::string_t& local_s, const scpp::int_t<>& local_n);
