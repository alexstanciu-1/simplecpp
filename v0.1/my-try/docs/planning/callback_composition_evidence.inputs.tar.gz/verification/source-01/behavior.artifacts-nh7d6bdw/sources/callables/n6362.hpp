#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> function_cb(scpp::string_t& local_p, std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::int_t<>& local_t);
