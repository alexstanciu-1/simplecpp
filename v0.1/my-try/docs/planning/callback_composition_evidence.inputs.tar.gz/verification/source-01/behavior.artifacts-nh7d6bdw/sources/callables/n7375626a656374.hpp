#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
scpp::string_t function_subject(std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::string_t& local_s, scpp::int_t<>& local_t);
