#pragma once
#include "scpp/string_t.hpp"
scpp::string_t function_defaults();
