#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_tablesubject(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::string_t& local_s, scpp::int_t<>& local_t);
