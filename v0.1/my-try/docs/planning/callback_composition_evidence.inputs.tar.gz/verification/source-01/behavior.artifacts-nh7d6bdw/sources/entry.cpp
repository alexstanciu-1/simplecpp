#include "callables/n7265706c61636534.hpp"
#include "callables/n7461626c6533.hpp"
#include "callables/n706174.hpp"
#include "callables/n6362.hpp"
#include "callables/n7375626a656374.hpp"
#include "callables/n6c696d6974.hpp"
#include "callables/n6f726465726564.hpp"
#include "callables/n63616c6c6261636b73.hpp"
#include "callables/n7461626c657375626a656374.hpp"
#include "callables/n7461626c656c696d6974.hpp"
#include "callables/n7461626c656f726465726564.hpp"
#include "callables/n64656661756c7473.hpp"
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}

#include "regex_callbacks_oracle.hpp"
int main() {
	using S=scpp::string_t;using I=scpp::int_t<>;
	using F=std::function<S(scpp::vector_t<S>)>;using H=scpp::hash_t<F,S>;
	if(regex_callbacks_oracle(function_replace4,function_table3)!=0)return 1;
	if(function_defaults().native_value()!="CabCa:XX")return 2;
	for(std::int64_t n:{-2,0,1}) {
		S p{"/a/"},s{"aba"};F f=[](auto){return S{"X"};};I t{0};bool caught=false;
		try {auto r=function_ordered(p,f,s,I{n},t);if(r.value().native_value()!=(n==0?"aba":"Xba"))return 3;}
		catch(const scpp::ValueError&){caught=true;}
		if(caught!=(n<0)||t.native_value()!=1234||p.native_value()!="/z/"||s.native_value()!="changed"||f({}).native_value()!="Y")return 4;
		H h;h.set(S{"/a/"},[](auto){return S{"X"};});s=S{"aba"};t=I{0};caught=false;
		try {auto r=function_tableordered(h,s,I{n},t);if(r.value().native_value()!=(n==0?"aba":"Xba"))return 5;}
		catch(const scpp::ValueError&){caught=true;}
		if(caught!=(n<0)||t.native_value()!=123||s.native_value()!="changed"||h.at(S{"/a/"} )({}).native_value()!="Y")return 6;
	}
	std::cout<<"source defaults; owned captures; ordered callback and table snapshots\n";
}