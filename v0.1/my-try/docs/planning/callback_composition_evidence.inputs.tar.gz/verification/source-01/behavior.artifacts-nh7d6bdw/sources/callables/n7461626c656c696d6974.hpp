#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_tablelimit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
