// SCPP-ARTIFACT {"id":"callable:replace4","kind":"header","path":"callables\/n7265706c61636534.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, const scpp::string_t& local_s, const scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:table3","kind":"header","path":"callables\/n7461626c6533.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_table3(const scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, const scpp::string_t& local_s, const scpp::int_t<>& local_n);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:pat","kind":"header","path":"callables\/n706174.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:cb","kind":"header","path":"callables\/n6362.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> function_cb(scpp::string_t& local_p, std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:subject","kind":"header","path":"callables\/n7375626a656374.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
scpp::string_t function_subject(std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::string_t& local_s, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:limit","kind":"header","path":"callables\/n6c696d6974.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_limit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:ordered","kind":"header","path":"callables\/n6f726465726564.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:callbacks","kind":"header","path":"callables\/n63616c6c6261636b73.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> function_callbacks(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:tablesubject","kind":"header","path":"callables\/n7461626c657375626a656374.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
scpp::string_t function_tablesubject(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::string_t& local_s, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:tablelimit","kind":"header","path":"callables\/n7461626c656c696d6974.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/int_t.hpp"
scpp::int_t<> function_tablelimit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:tableordered","kind":"header","path":"callables\/n7461626c656f726465726564.hpp"}
#pragma once
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/hash_t.hpp"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
scpp::result_or_false<scpp::string_t> function_tableordered(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t);
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"callable:defaults","kind":"header","path":"callables\/n64656661756c7473.hpp"}
#pragma once
#include "scpp/string_t.hpp"
scpp::string_t function_defaults();
// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"implementation:units\/n6d61696e\/n6d61696e2e706873.cpp","kind":"translation_unit","path":"units\/n6d61696e\/n6d61696e2e706873.cpp"}
#include "callables/n7265706c61636534.hpp"
#include "scpp/string_t.hpp"
#include "scpp/vector_t.hpp"
#include "functional"
#include "scpp/int_t.hpp"
#include "scpp/result_or_false.hpp"
#include "modules/regex/regex.hpp"
#include "callables/n7461626c6533.hpp"
#include "scpp/hash_t.hpp"
#include "callables/n706174.hpp"
#include "scpp/generated/operators.hpp"
#include "callables/n6362.hpp"
#include "callables/n7375626a656374.hpp"
#include "callables/n6c696d6974.hpp"
#include "callables/n6f726465726564.hpp"
#include "callables/n63616c6c6261636b73.hpp"
#include "callables/n7461626c657375626a656374.hpp"
#include "scpp/index_write.hpp"
#include "callables/n7461626c656c696d6974.hpp"
#include "callables/n7461626c656f726465726564.hpp"
#include "callables/n64656661756c7473.hpp"
#include "scpp/index_read.hpp"
#include "scpp/data_initializer.hpp"
scpp::result_or_false<scpp::string_t> function_replace4(const scpp::string_t& local_p, const std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, const scpp::string_t& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_0 = local_p;
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> argument_1 = local_f;
	scpp::string_t argument_2 = local_s;
	scpp::int_t<> argument_3 = local_n;
	return scpp::regex::replace_callback_limited(argument_0, argument_1, argument_2, argument_3);
}());
}

scpp::result_or_false<scpp::string_t> function_table3(const scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, const scpp::string_t& local_s, const scpp::int_t<>& local_n)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> argument_0 = local_h;
	scpp::string_t argument_1 = local_s;
	scpp::int_t<> argument_2 = local_n;
	return scpp::regex::replace_callback_array_limited(argument_0, argument_1, argument_2);
}());
}

scpp::string_t function_pat(scpp::string_t& local_p, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(1LL); return (operand_2 + operand_3); }());
	return local_p;
}

std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> function_cb(scpp::string_t& local_p, std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(2LL); return (operand_2 + operand_3); }());
	local_p = scpp::string_t("/z/");
	return local_f;
}

scpp::string_t function_subject(std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::string_t& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_f = std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>{[](scpp::vector_t<scpp::string_t> local_m) -> scpp::string_t {
	return scpp::string_t("Y");
}};
	return local_s;
}

scpp::int_t<> function_limit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(4LL); return (operand_2 + operand_3); }());
	local_s = scpp::string_t("changed");
	return local_n;
}

scpp::result_or_false<scpp::string_t> function_ordered(scpp::string_t& local_p, std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& local_f, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_2 = ([&]() -> scpp::string_t {
	scpp::string_t& argument_0 = local_p;
	scpp::int_t<>& argument_1 = local_t;
	return function_pat(argument_0, argument_1);
}());
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> argument_6 = ([&]() -> std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> {
	scpp::string_t& argument_3 = local_p;
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& argument_4 = local_f;
	scpp::int_t<>& argument_5 = local_t;
	return function_cb(argument_3, argument_4, argument_5);
}());
	scpp::string_t argument_10 = ([&]() -> scpp::string_t {
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>& argument_7 = local_f;
	scpp::string_t& argument_8 = local_s;
	scpp::int_t<>& argument_9 = local_t;
	return function_subject(argument_7, argument_8, argument_9);
}());
	scpp::int_t<> argument_14 = ([&]() -> scpp::int_t<> {
	scpp::string_t& argument_11 = local_s;
	scpp::int_t<> argument_12 = local_n;
	scpp::int_t<>& argument_13 = local_t;
	return function_limit(argument_11, argument_12, argument_13);
}());
	return scpp::regex::replace_callback_limited(argument_2, argument_6, argument_10, argument_14);
}());
}

scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> function_callbacks(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(1LL); return (operand_2 + operand_3); }());
	return local_h;
}

scpp::string_t function_tablesubject(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::string_t& local_s, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(2LL); return (operand_2 + operand_3); }());
	{ auto& write_receiver_4 = local_h; scpp::string_t write_key_4 = scpp::string_t("/a/"); scpp::require_write_key(write_key_4); std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> write_value_4 = std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>{[](scpp::vector_t<scpp::string_t> local_m) -> scpp::string_t {
	return scpp::string_t("Y");
}}; scpp::index_store(write_receiver_4, write_key_4, write_value_4); }
	return local_s;
}

scpp::int_t<> function_tablelimit(scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	local_t = ([&]() -> scpp::int_t<> { auto operand_2 = ([&]() -> scpp::int_t<> { auto operand_0 = local_t; auto operand_1 = static_cast<scpp::int_t<>>(10LL); return (operand_0 * operand_1); }()); auto operand_3 = static_cast<scpp::int_t<>>(3LL); return (operand_2 + operand_3); }());
	local_s = scpp::string_t("changed");
	return local_n;
}

scpp::result_or_false<scpp::string_t> function_tableordered(scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& local_h, scpp::string_t& local_s, scpp::int_t<> local_n, scpp::int_t<>& local_t)
{
	return ([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> argument_2 = ([&]() -> scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> {
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& argument_0 = local_h;
	scpp::int_t<>& argument_1 = local_t;
	return function_callbacks(argument_0, argument_1);
}());
	scpp::string_t argument_6 = ([&]() -> scpp::string_t {
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>& argument_3 = local_h;
	scpp::string_t& argument_4 = local_s;
	scpp::int_t<>& argument_5 = local_t;
	return function_tablesubject(argument_3, argument_4, argument_5);
}());
	scpp::int_t<> argument_10 = ([&]() -> scpp::int_t<> {
	scpp::string_t& argument_7 = local_s;
	scpp::int_t<> argument_8 = local_n;
	scpp::int_t<>& argument_9 = local_t;
	return function_tablelimit(argument_7, argument_8, argument_9);
}());
	return scpp::regex::replace_callback_array_limited(argument_2, argument_6, argument_10);
}());
}

scpp::string_t function_defaults()
{
	auto local_prefix = scpp::string_t("C");
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> local_f = std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>{[local_prefix](scpp::vector_t<scpp::string_t> local_matches) mutable -> scpp::string_t {
	return ([&]() -> scpp::string_t { auto operand_1 = local_prefix; auto operand_2 = ([&]() -> scpp::string_t { const auto& index_receiver_0 = local_matches; scpp::int_t<> index_key_0 = static_cast<scpp::int_t<>>(1LL); return scpp::checked_index_read(index_receiver_0, index_key_0); }()); return (operand_1 + operand_2); }());
}};
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> local_h = ([&]() -> scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> {
scpp::initializer_buffer<scpp::initializer_entry<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>> initializer_3(2);
{
scpp::string_t initializer_key_4 = scpp::string_t("/a/");
std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> initializer_value_5 = std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>{[](scpp::vector_t<scpp::string_t> local_m) -> scpp::string_t {
	return scpp::string_t("b");
}};
initializer_3.append(scpp::initializer_entry<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>{initializer_key_4, initializer_value_5});
}
{
scpp::string_t initializer_key_6 = scpp::string_t("/b/");
std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> initializer_value_7 = std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>{[](scpp::vector_t<scpp::string_t> local_m) -> scpp::string_t {
	return scpp::string_t("X");
}};
initializer_3.append(scpp::initializer_entry<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>{initializer_key_6, initializer_value_7});
}
return scpp::data_initializer<scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t>>::from_key_value(initializer_3.view());
}());
	scpp::string_t local_a = scpp::string_t((([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::string_t argument_8 = scpp::string_t("/(a)/");
	std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)> argument_9 = local_f;
	scpp::string_t argument_10 = scpp::string_t("aba");
	return scpp::regex::replace_callback(argument_8, argument_9, argument_10);
}())).require_value("Result required-value extraction"));
	scpp::string_t local_b = scpp::string_t((([&]() -> scpp::result_or_false<scpp::string_t> {
	scpp::hash_t<std::function<scpp::string_t(scpp::vector_t<scpp::string_t>)>, scpp::string_t> argument_11 = local_h;
	scpp::string_t argument_12 = scpp::string_t("aa");
	return scpp::regex::replace_callback_array(argument_11, argument_12);
}())).require_value("Result required-value extraction"));
	return ([&]() -> scpp::string_t { auto operand_15 = ([&]() -> scpp::string_t { auto operand_13 = local_a; auto operand_14 = scpp::string_t(":"); return (operand_13 + operand_14); }()); auto operand_16 = local_b; return (operand_15 + operand_16); }());
}

// SCPP-END-ARTIFACT
// SCPP-ARTIFACT {"id":"entry","kind":"translation_unit","path":"entry.cpp"}
#include "lang/php/cli_context.hpp"
#include "scpp/runtime_error.hpp"

int unused_entry(int argc, char** argv)
{
// SCPP-ENTRY-TRY
	try {
	scpp::php::set_cli_args(argc, argv);
	return 0;
// SCPP-ENTRY-CATCH
	} catch (const std::exception& failure) {
		scpp::print_runtime_exception(failure);
		return 1;
	}
// SCPP-ENTRY-END
}
// SCPP-END-ARTIFACT

#include "regex_callbacks_oracle.hpp"
int main() {
	using S=scpp::string_t;using I=scpp::int_t<>;
	using F=std::function<S(scpp::vector_t<S>)>;using H=scpp::hash_t<F,S>;
	if(regex_callbacks_oracle(function_replace4,function_table3)!=0)return 1;
	if(function_defaults().native_value()!="CabCa:XX")return 2;
	for(std::int64_t n:{-2,0,1}) {
		S p{"/a/"},s{"aba"};F f=[](auto){return S{"X"};};I t{0};bool caught=false;
		try {auto r=function_ordered(p,f,s,I{n},t);if(r.value().native_value()!=(n==0?"aba":"Xba"))return 3;}
		catch(const scpp::ValueError&){caught=true;}
		if(caught!=(n<0)||t.native_value()!=1234||p.native_value()!="/z/"||s.native_value()!="changed"||f({}).native_value()!="Y")return 4;
		H h;h.set(S{"/a/"},[](auto){return S{"X"};});s=S{"aba"};t=I{0};caught=false;
		try {auto r=function_tableordered(h,s,I{n},t);if(r.value().native_value()!=(n==0?"aba":"Xba"))return 5;}
		catch(const scpp::ValueError&){caught=true;}
		if(caught!=(n<0)||t.native_value()!=123||s.native_value()!="changed"||h.at(S{"/a/"} )({}).native_value()!="Y")return 6;
	}
	std::cout<<"source defaults; owned captures; ordered callback and table snapshots\n";
}