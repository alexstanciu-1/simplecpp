
cmake_minimum_required(VERSION 3.20)
project(composition_probe LANGUAGES CXX)
add_subdirectory("/home/alex-ai/callback-composition/20261020-01/runtime" runtime)
add_executable(aggregate_document "/home/alex-ai/callback-composition/20261020-01/tests/runtime/native/test_json_document.cpp")
target_link_libraries(aggregate_document PRIVATE scpp_runtime scpp_runtime_test_support)
