from pathlib import Path
import concurrent.futures,subprocess,os,json
os.chdir('/home/alex-ai/mixed-predicates/20261020-01');os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=[('observation','runtime_observation',[]),('mixed','mixed',['--no-pch']),('conditionals','unbraced_conditionals',[])]
def run(row):
 n,s,extra=row
 with open('verification/regression-'+n+'.stdout','w') as out:code=subprocess.call(['python3','compiler/my-try/tests/'+s+'.py','--results','verification/regression-'+n]+extra,stdout=out,stderr=subprocess.STDOUT)
 print(n,code,flush=True);return n,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:result=dict(p.map(run,suites))
Path('verification/regression-exits.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(any(result.values()))
