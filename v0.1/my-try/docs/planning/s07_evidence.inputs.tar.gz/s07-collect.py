import json,gzip,hashlib,subprocess
from pathlib import Path
root=Path('/home/alex-ai/mixed-predicates/20261020-01');v=root/'verification'
m=json.loads((root/'s07_source_candidate.json').read_text());initial=json.loads((root/'s07_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
runtime=[p for p in m['files'] if p.startswith('runtime/') and p!='runtime/metadata/modules/core.json'];assert all(m['files'][p]==initial['files'][p] for p in runtime)
accepted=['runtime-01','source-baseline','source-02','regression-observation','regression-mixed','regression-conditionals'];summaries={n:json.loads((v/n/'summary.json').read_text()) for n in accepted if (v/n/'summary.json').exists()};assert all(s['passed'] for s in summaries.values())
assert json.loads((v/'regression-exits.json').read_text())=={'observation':0,'mixed':0,'conditionals':0}
suites={}
for n in accepted:
 commands=json.loads((v/n/'logs/commands.json').read_text());assert commands and all(c['code']==c['expected'] for c in commands),n
 suites[n]={'commands':len(commands),'all_expected_exits':True,'native_executions':sum(c['name'].endswith(('-execute','-run')) for c in commands)}
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['s07_source_initial.json','s07_source_candidate.json']:records[n]=(root/n).read_text()
records['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
records['s07-collect.py']=Path(__file__).read_text();records['s07-regress.py']=(root/'s07-regress.py').read_text();archive=gzip.compress(json.dumps(records).encode());Path('/tmp/s07-evidence.json.gz').write_bytes(archive)
checks=summaries['source-02']['checks'];assert checks['original']['sha256']==summaries['source-baseline']['checks']['sha256'];assert len(checks['rejections'])==47 and checks['recovery_cycles']==6
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'71f3d607','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'source_integrity':{'checked':len(m['files']),'mismatches':bad,'runtime_files_unchanged_except_core_metadata':len(runtime)},'toolchain':json.loads(records['toolchain.json']),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'original_fixture_end_to_end_passed':True,'remaining_s07_blockers':[],'newly_exposed_implementation_blockers':[],'attempts':{'runtime-01':'Existing runtime passed 69 exact-mixed predicate checks before metadata exposure.','source-baseline':'Original fixture reproduces unresolved is_bool.','source-01':'Preparation and original native fixture passed; behavior observer used incorrect C++ name for saved_result. Corrected test-only name mangling; no compiler changes.','source-02':'Original exact output and behavior observers pass under AddressSanitizer.','regressions':'Observation, catalog, callables, references, mixed and conditional suites pass.'},'runtime_implementation_changes':False,'metadata_changes':'Only three exact-mixed observe signatures and their three C++ bindings in core.json.','full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':26,'total':64,'percent':40.625}}
Path('/tmp/s07-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'source_files':len(m['files']),'runtime_files_unchanged':len(runtime),'suites':suites,'commands':sum(s['commands'] for s in suites.values()),'evidence_records':len(records)},indent=2))
