import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/alex-ai/regex-batch/20261020-01');v=root/'verification'
m=json.loads((root/'regex_source_candidate.json').read_text());initial=json.loads((root/'regex_source_initial.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
changed=[p for p,h in m['files'].items() if h!=initial['files'].get(p)]
runtime=[p for p in changed if p.startswith('runtime/')]
assert set(runtime)=={'runtime/include/modules/regex/regex.cpp','runtime/include/modules/regex/regex.hpp','runtime/metadata/modules/regex.json'},runtime
compiler=[p for p in changed if p.startswith('compiler/my-try/') and not p.startswith(('compiler/my-try/tests/','compiler/my-try/docs/'))];assert not compiler,compiler
accepted=['runtime-baseline','source-baseline','runtime-01','source-01','regression-02']
suites={};summaries={}
for name in accepted:
 commands=json.loads((v/name/'logs/commands.json').read_text());assert commands and all(c['code']==c['expected'] for c in commands),name
 suites[name]={'commands':len(commands),'all_expected_exits':True,'command_seconds':round(sum(c['seconds'] for c in commands),2),'native_executions':sum(c['name'].endswith(('-execute','-run')) for c in commands)}
 if (v/name/'summary.json').exists():
  summary=json.loads((v/name/'summary.json').read_text());assert summary['passed'];summaries[name]=summary
assert summaries['runtime-01']['observations']=='checks=54;failures=0\n'
assert summaries['source-01']['checks']['recoveries']==2 and len(summaries['source-01']['checks']['rejections'])==5
records={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
for n in ['regex_source_initial.json','regex_source_candidate.json']:records[n]=(root/n).read_text()
records['collector.py']=Path(__file__).read_text()
toolchain={n:subprocess.check_output(cmd,text=True) for n,cmd in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version'],'pcre2':['pkg-config','--modversion','libpcre2-8']}.items()}
records['toolchain.json']=json.dumps(toolchain)
archive=gzip.compress(json.dumps(records).encode());Path('/tmp/regex-evidence.json.gz').write_bytes(archive)
r={'doc_status':'supporting','date':'2026-10-20','passed':True,'head':'6c25e526','host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'suites':suites,'summaries':summaries,'source_integrity':{'checked':len(m['files']),'mismatches':bad,'runtime_changed':runtime,'compiler_implementation_unchanged':True},'toolchain':toolchain,'evidence_records':len(records),'evidence_sha256':hashlib.sha256(archive).hexdigest(),'runtime_implementation_changes':True,'full_matrix_run':False,'native_compiler_rebuilt':False,'original_issue_closure':{'closed':31,'partial':0,'total':64,'percent':48.4375},'remaining_batch_blockers':[],'deferred':['V-R05 callback ABI','Public count-output signatures','Legacy wrapper migration']}
Path('/tmp/regex-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'commands':sum(x['commands'] for x in suites.values()),'native_executions':sum(x['native_executions'] for x in suites.values()),'source_files':len(m['files']),'records':len(records)}))
