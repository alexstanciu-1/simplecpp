import concurrent.futures,subprocess,os,json
from pathlib import Path
os.chdir('/home/alex-ai/vl07-completion/20261020-01')
os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=[('operations','vl07_completion',[]),('bool','cross_equality',['--group','bool']),('int-arithmetic','int_carrier_compounds',[]),('int-bitwise','int_carrier_compounds',['--group','bitwise']),('int-cross','int_carrier_compounds',['--group','cross']),('float-compounds','float_compounds',[]),('widening-compounds','widening_compounds',[]),('index-compound','index_compound',[]),('carrier-updates','carrier_updates',[])]
def run(row):
 name,script,extra=row
 with open('verification/final-'+name+'.stdout','w') as out:
  code=subprocess.call(['python3','compiler/my-try/tests/'+script+'.py','--results','verification/final-'+name]+extra,stdout=out,stderr=subprocess.STDOUT)
 print(name,code,flush=True);return name,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,suites))
Path('verification/final-proof-exits.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(results.values()))
