import concurrent.futures,subprocess,os,json
from pathlib import Path
os.chdir('/home/alex-ai/vl07-completion/20261020-01')
os.environ['PATH']='/home/alex-ai/language-verification/20261018/verification/modern-bin:'+os.environ['PATH']
suites=[('guarded_operators','guarded_operators',[]),('guarded_mixed','guarded_mixed',[]),('guarded_cross','guarded_cross',[]),('eager_binary','eager_binary',[]),('scalar_admission','scalar_admission',['--jobs','12']),('string_identity','string_identity',[]),('bool','cross_equality',['--group','bool']),('cross_equality','cross_equality',[]),('cross_mixed_equality','cross_mixed_equality',[])]
def run(row):
 name,script,extra=row
 with open('verification/recheck-'+name+'.stdout','w') as out:code=subprocess.call(['python3','compiler/my-try/tests/'+script+'.py','--results','verification/recheck-'+name]+extra,stdout=out,stderr=subprocess.STDOUT)
 print(name,code,flush=True);return name,code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,suites))
Path('verification/recheck-exits.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(results.values()))
