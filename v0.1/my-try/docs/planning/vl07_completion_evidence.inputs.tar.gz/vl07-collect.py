import json,gzip,hashlib,subprocess,re
from pathlib import Path
root=Path('/home/alex-ai/vl07-completion/20261020-01');v=root/'verification'
m=json.loads((root/'vl07_completion_source_final.json').read_text())
bad=[p for p,h in m['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
assert not bad,bad
reg=json.loads((v/'regression-exits.json').read_text());rep=json.loads((v/'recheck-exits.json').read_text());extra=json.loads((v/'final-proof-exits.json').read_text());assert rep['cross_mixed_equality']==2
rep_original=dict(rep)
assert json.loads((v/'recheck-cross-mixed-corrected/summary.json').read_text())['passed']
rep['cross_mixed_equality']=0
assert not any(rep.values()) and not any(extra.values())
resolved=dict(reg)
for k in reg:
 if k in rep:resolved[k]=rep[k]
resolved['float_operators']=0
assert len(resolved)==27 and not any(resolved.values()),resolved
accepted=['runtime-final','final-generator','recheck-bool','final-operations','rejections-with-inventory','existing-paths','final-controls','indexed-text','repaired-float-operators','regression-guarded-spaceship']
accepted += ['recheck-'+k if k in rep else 'regression-'+k for k in reg if k!='float_operators']
accepted += ['recheck-cross-mixed-corrected']
accepted += ['final-'+k for k in extra if k not in ('operations','bool')]
suites={}
for name in sorted(set(accepted)):
 paths=list((v/name).rglob('commands.json'));assert paths,name
 commands=[c for p in paths for c in json.loads(p.read_text())]
 assert all(c['code']==c['expected'] for c in commands),name
 suites[name]={'commands':len(commands),'all_expected_exits':True}
ops=json.loads((v/'final-operations/summary.json').read_text());assert ops['passed'] and ops['signatures']==150
sigs=[r['signature'] for r in ops['results'].values()]
for p in (v/'recheck-bool').glob('*/signatures.json'):sigs+=json.loads(p.read_text())
assert len(sigs)==174 and len(set(map(tuple,sigs)))==174
plain={'int','float','bool','string'};carrier=[s for s in sigs if s[0] not in plain or s[2] not in plain];assert len(carrier)==168
rejections=json.loads((v/'rejections-with-inventory/summary.json').read_text());assert rejections['passed'] and rejections['recoveries']==576
existing=json.loads((v/'existing-paths/summary.json').read_text());assert existing['passed'] and existing['supported']==17 and existing['observed_rejections']==112
indexed=json.loads((v/'indexed-text/summary.json').read_text());assert all(x['supported'] for x in indexed['rows'].values())
baseline=json.loads((v/'e3-bool-baseline/summary.json').read_text());assert sum(not x['passed'] for x in baseline['runtime_results'].values())==12
counts={}
for name in suites:
 for p in (v/name).rglob('*.stdout'):
  c={k:int(n) for k,n in re.findall(r'(runtime_cases|binary_cases|local_cases|property_cases|cases)=(\d+)',p.read_text())}
  if c:counts[str(p.relative_to(root))]=c
e={str(p.relative_to(root)):p.read_text(errors='replace') for p in sorted(v.rglob('*')) if p.is_file() and p.suffix in ('.json','.stdout','.stderr')}
e['source-integrity.json']=json.dumps({'checked':len(m['files']),'mismatches':bad})
e['toolchain.json']=json.dumps({n:subprocess.check_output(c,text=True) for n,c in {'php':['/home/alex-ai/language-verification/20261018/verification/modern-bin/php','--version'],'clang':['clang++','--version'],'python':['python3','--version']}.items()})
for p in root.glob('vl07-*.py'):e[p.name]=p.read_text()
archive=gzip.compress(json.dumps(e).encode());Path('/tmp/vl07-completion-evidence.json.gz').write_bytes(archive)
results={'doc_status':'supporting','date':'2026-10-20','passed':True,'host':'alex-ai@dev002.travelfuse.ro','snapshot':str(root),'scope':{'new_carrier_signatures':168,'new_scalar_prerequisites':4,'existing_scalar_controls':2,'source_signatures':174,'new_equality':24,'new_spaceship':72,'new_power_compounds':24,'new_text':48,'intentional_rejections':576,'existing_paths_supported':17,'existing_paths_rejected':112},'signatures':sigs,'carrier_signatures':carrier,'rejections':rejections,'existing_paths':existing,'indexed_text':indexed,'controls':json.loads((v/'final-controls/summary.json').read_text()),'suites':suites,'regression_original_exits':reg,'regression_resolved_exits':resolved,'additional_proof_exits':extra,'recheck_original_exits':rep_original,'recheck_resolved_exits':rep,'counts':counts,'source_integrity':json.loads(e['source-integrity.json']),'toolchain':json.loads(e['toolchain.json']),'generator':json.loads((v/'final-generator/summary.json').read_text()),'attempts':{'bool_baseline':'12 native pair compilations fail, blocking 24 targets; eight same-family controls pass.','runtime_probe':'First text observer failed to catch std::runtime_error; corrected observer passes. Original legacy ordering returns zero for NaN and is explicitly not acceptance.','operations':'First attempts retained: fixture initialization, missing **= tokenizer/parser, obsolete power rejection, generic-type spacing and nullable error observer. Fourth and final 150-row runs pass.','controls':'First direct nullable-float-to-int cast rejects; supported explicit unwrap then numeric cast passes. No conversion implementation changed.','regressions':'Original stale power/spaceship/diagnostic expectations retained; affected suites repaired and rechecked.','recheck_launcher':'Cross-mixed recheck first used a nonexistent standalone script; corrected to mixed_equality.py --group cross and retained original launcher failure.','inventory':'Initial rejection runner missing inventory input retained; staged inventory run passes.'},'full_matrix_run':False,'native_compiler_rebuilt':False,'remaining_blockers_in_approved_scope':[],'wider_gaps':['Indexed ++/--, guarded numeric indexed compounds and indexed floating compounds remain deferred under Mutation_Preparation/Indexing_Preparation.','112 non-admitted null comparison cells remain separately owned presence-policy boundaries, not completed carrier operations.','Fixed-width/nested/object/container payloads, boxed/dynamic/table semantics, selectors and explicit error-sentinel syntax remain separate.'],'evidence_sha256':hashlib.sha256(archive).hexdigest(),'vl07_progress':{'completed_slices':37,'binary_signatures':2832,'unary_signatures':64,'compound_signatures':480,'verified_total':3376,'design_scope_candidates':0,'intentional_rejections':576,'verified_existing_paths':17,'observed_existing_rejections':112,'original_proposed_core_denominator':2080,'original_proposed_core_coverage_percent':100.0}}
Path('/tmp/vl07-completion-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'source_files':len(m['files']),'evidence_records':len(e),'acceptance_suites':len(suites),'commands':sum(s['commands'] for s in suites.values()),'new_carrier_signatures':len(carrier),'observations':sum(sum(c.values()) for c in counts.values())},indent=2))
